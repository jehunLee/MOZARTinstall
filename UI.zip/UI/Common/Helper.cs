﻿using FabSimulator;
using FabSimulatorUI.Common;
using Mozart.Extensions;
using Mozart.Studio.TaskModel.Projects;
using Mozart.Studio.TaskModel.UserLibrary;
using System.Globalization;
using System.Reflection;

namespace FabSimulatorUI
{
    partial class Helper
    {
        public static bool Like(string text, string pattern)
        {
            return Mozart.Text.LikeUtility.Like(text, pattern, true);
        }

        public static string CreateKey(params string[] args)
        {
            string sValue = null;
            foreach (string str in args)
            {
                if (sValue == null) sValue = str;
                else sValue += "@" + str;
            }

            return sValue;
        }

        public static void NotifyEmptySchema(ModelDataContext modelCtx, ExpDataContext expCtx, string[] results, params string[] schemas)
        {
            foreach (var name in schemas)
            {
                PropertyInfo modelProp = modelCtx.GetType().GetProperty(name);
                PropertyInfo expProp;

                dynamic value;
                int count = 0;

                if (modelProp != null)
                {
                    value = modelProp.GetValue(modelCtx, null);
                    count = Enumerable.Count(value);

                    if (count == 0)
                        MessageBox.Show(name + Consts.CaseEmptySchema, Consts.Notification, MessageBoxButtons.OKCancel, MessageBoxIcon.Asterisk);

                    continue;
                }

                foreach (var r in results)
                {
                    var rslt = expCtx.Result(r);
                    expProp = rslt.GetType().GetProperty(name);

                    if (expProp != null)
                    {
                        value = expProp.GetValue(rslt, null);
                        count = Enumerable.Count(value);

                        if (count == 0)
                            MessageBox.Show(r + " " + name + Consts.CaseEmptySchema, Consts.Notification, MessageBoxButtons.OKCancel, MessageBoxIcon.Asterisk);
                    }

                }
            }
        }

        public static Dictionary<DateTime, double> GetTargetDateWeightLookup(IExperimentResultItem result)
        {
            Dictionary<DateTime, double> startEndLookup = new Dictionary<DateTime, double>();

            var planStartTime = result.StartTime;
            var planStartTargetDate = ShopCalendar.StartTimeOfDayT(planStartTime);
            var planEndTargetDate = planStartTargetDate.AddDays(result.GetPlanPeriodF());
            var startInterval = (planStartTargetDate.AddDays(1) - planStartTime).TotalDays;
            var endInterval = 1 - startInterval;

            startEndLookup.Add(planStartTargetDate, startInterval);
            startEndLookup.Add(planEndTargetDate, endInterval);

            return startEndLookup;
        }

        public static DateTime SplitDateHour(this DateTime now)
        {
            TimeSpan ts = TimeSpan.FromMinutes(now.Minute) + TimeSpan.FromSeconds(now.Second);

            return now.Subtract(ts);
        }

        public static int GetTargetWeek(DateTime targetDate, DayOfWeek startDayOfWeek)
        {
            CultureInfo myCI = new CultureInfo("en-US");
            Calendar myCal = myCI.Calendar;

            return myCal.GetWeekOfYear(targetDate, CalendarWeekRule.FirstFullWeek, startDayOfWeek);
        }

        internal static string GetFormattedTargetWeek(DateTime targetDate, DayOfWeek startDayOfWeek)
        {
            var year = targetDate.Year;
            var targetWeek = GetTargetWeek(targetDate, startDayOfWeek);
            if (targetWeek == 52 && targetDate.Month == 1)
                year--;

            return year + "-" + targetWeek.ToString().PadLeft(2, '0');
        }

        public static DateTime GetWeekStartTime(this DateTime dt)
        {
            int diff = (7 + (dt.DayOfWeek - ShopCalendar.StartWeek)) % 7;

            return dt.AddDays(-1 * diff).Date + ShopCalendar.StartTime;
        }

        public static DateTime GetWeekEndDayStartTime(this DateTime dt)
        {
            // 주 마지막날의 시작시각
            var weekStartTime = GetWeekStartTime(dt);

            return weekStartTime.AddDays(6);
        }
        public static DateTime GetMonthStartTime(this DateTime dt)
        {
            return new DateTime(dt.Year, dt.Month, 1) + ShopCalendar.StartTime;
        }

        public static DateTime GetMonthEndDayStartTime(this DateTime dt)
        {
            // 월 마지막날의 시작시각
            return new DateTime(dt.Year, dt.Month, DateTime.DaysInMonth(dt.Year, dt.Month)) + ShopCalendar.StartTime;
        }

        public static DateTime GetIntervalStartDate(DateTime time, int radioIndex)
        {
            // index 0 = Month, 1 = Week, 2 = Day

            DateTime startDate = time;

            if (radioIndex == 0)
            {
                startDate = GetMonthStartTime(time);
            }
            else if (radioIndex == 1)
            {
                startDate = GetWeekStartTime(time);
            }

            return startDate;
        }

        public static DateTime GetIntervalEndDate(DateTime time, int radioIndex)
        {
            DateTime endDate = time;

            if (radioIndex == 0)
            {
                endDate = GetMonthEndDayStartTime(time);
            }
            else if (radioIndex == 1)
            {
                endDate = GetWeekEndDayStartTime(time);
            }

            return endDate;
        }

        public static string GetPhotoArea(ModelDataContext ctx)
        {
            var photoAreaConfig = ctx.GetConfigValue<string>(PARAM_GROUP: "Simulation_Report", PARAM_NAME: "photoArea");

            if (photoAreaConfig == null)
                return string.Empty;

            return photoAreaConfig;
        }

        public static int GetPeriod(string firstTargetWeek, string secondTargetWeek)
        {
            var numYear = secondTargetWeek.Substring(0, 4).ToInt32() - firstTargetWeek.Substring(0, 4).ToInt32();
            var numWeek = secondTargetWeek.Substring(5, 2).ToInt32() - firstTargetWeek.Substring(5, 2).ToInt32();

            int answer = numYear * 52 + numWeek + 1;
            answer *= 7;

            return answer;
        }

        public static double ErfInv(double x)
        {
            //Quick & dirty, tolerance under +-6e-3.Work based on "A handy approximation for the error function and its inverse" by Sergei Winitzki.

            double tt1, tt2, lnx, sgn;
            sgn = (x < 0) ? -1.0d : 1.0d;

            x = (1 - x) * (1 + x);        // x = 1 - x*x;
            lnx = Math.Log(x);

            tt1 = 2 / (Math.PI * 0.147) + 0.5f * lnx;
            tt2 = 1 / (0.147) * lnx;

            return (sgn * Math.Sqrt(-tt1 + Math.Sqrt(tt1 * tt1 - tt2)));
        }

        public static DateTime RemoveMilliseconds(this DateTime dateTime)
        {
            return new DateTime(
                dateTime.Year,
                dateTime.Month,
                dateTime.Day,
                dateTime.Hour,
                dateTime.Minute,
                dateTime.Second,
                dateTime.Kind // Local/UTC/Unspecified 보존
            );
        }
    }
}
