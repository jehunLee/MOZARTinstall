﻿using Mozart.Studio.TaskModel.UserLibrary;

namespace FabSimulatorUI
{
    public class Consts
    {
        #region Common Part

        /// <summary>   Identifier for the null. </summary>
        public static readonly string NullId = StringUtility.IdentityNull;
        /// <summary>   The list separator. </summary>
        public static readonly char ListSeparator = ',';
        /// <summary>   Query if 'id' is empty identifier. </summary>
        /// 

        public static bool IsEmptyID(string id)
        {
            return StringUtility.IsEmptyID(id);
        }

        #endregion Common Part

        #region Special Chars
        /// <summary>   all. </summary>
        public static string All = "ALL";

        /// <summary>   The percent. </summary>
        public static string Percent = "%";
        /// <summary>   The underline. </summary>
        public static string Underline = "_";

        /// <summary>   any character. </summary>
        public static char AnyChar = '_';
        /// <summary>   any string. </summary>
        public static char AnyString = '%';
        /// <summary>   any tokens. </summary>
        public static char[] AnyTokens = new char[] { AnyChar, AnyString };
        #endregion

        #region Format
        /// <summary>   The first mask qty. </summary>
        public const string Mask_Qty_1 = "###,##0.#";
        /// <summary>   The first mask aggregate qty. </summary>
        public const string Mask_AggQty_1 = "###,##0.0";
        #endregion

        #region Notification

        /// <summary>   할려면 이런식으로 쓰지 말고 Method로 빼야함. </summary>
        public const string Notification = "Notification";

        /// <summary>   The case DLL. </summary>
        public const string CaseDll = "Bring STD_Model.Schema.dll' & 'Fab.UserInterface.dll' up to date";
        /// <summary>   The case empty schema. </summary>
        public const string CaseEmptySchema = " is Empty";

        #endregion

        #region SchemaName

        /// <summary>   Inputs. </summary>
        public static string Part = "Part";

        /// <summary>   Outputs. </summary>
        public static string StepMove = "StepMove";

        #endregion
    }
}
