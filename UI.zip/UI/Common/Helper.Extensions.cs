﻿namespace FabSimulatorUI
{
    static partial class Helper
    {
        public static string ToHH(this DateTime dt)
        {
            return dt.ToString("HH");
        }

        public static string ToddHH(this DateTime dt)
        {
            return dt.ToString("dd'/'HH");
        }

        public static string ToMMddyyyy (this DateTime dt)
        {
            return dt.ToString("MM'/'dd'/'yyyy");
        }
    }
}
