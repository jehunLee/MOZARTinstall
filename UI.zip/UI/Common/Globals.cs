﻿using FabSimulator;
using Mozart.Extensions;
using Mozart.Studio.TaskModel.Projects;
using Mozart.Studio.TaskModel.UserLibrary;
using Mozart.Task.Model;

namespace FabSimulatorUI.Common
{
    public static class Globals
    {
        public static ModelDataContext ctx;
        public static void InitFactoryTimeNew(ModelDataContext modelCtx)
        {
            ctx = modelCtx;

            var info = CreateFactoryTime();
            if (info == null)
                return; // SIM_CONFIG에 factoryTime 정보가 없으면, 모델 기본값을 사용.

            var target = FactoryConfiguration.Current;
            target.TimeInfo = info;

            //FactoryConfiguration.Check(result.Model, CreateFactoryTime);
        }

        public static void InitFactoryTime(IExperimentResultItem result)
        {
            ctx = result.GetCtx<ModelDataContext>();
            var info = CreateFactoryTime();
            if (info == null)
                return; // SIM_CONFIG에 factoryTime 정보가 없으면, 모델 기본값을 사용.

            var target = FactoryConfiguration.Current;
            target.TimeInfo = info;

            //FactoryConfiguration.Check(result.Model, CreateFactoryTime);
        }
        //public static void InitFactoryTime(IModelProject project)
        //{
        //    FactoryConfiguration.Check(project, CreateFactoryTime);
        //}

        public static FactoryTimeInfo CreateFactoryTime()
        {
            var config = ctx.GetConfigValue<string>(PARAM_GROUP: "Simulation_Run", PARAM_NAME: "factoryTime");
            if (config == null)
                return null;

            FactoryTimeInfo customTimeInfo = new FactoryTimeInfo();
            customTimeInfo.Name = "FabSimulator";

            var itemSplits = config.Split(';');
            foreach (var item in itemSplits)
            {
                if (item.IsNullOrEmpty())
                    continue;

                var keyValueSplit = item.Split('=');

                if (keyValueSplit.Length != 2)
                    continue;

                var key = keyValueSplit[0];
                var value = keyValueSplit[1];

                if (key == "start_day_of_week")
                {
                    if (value == DayOfWeek.Sunday.ToString())
                        customTimeInfo.StartOfWeek = DayOfWeek.Sunday;
                    else if (value == DayOfWeek.Monday.ToString())
                        customTimeInfo.StartOfWeek = DayOfWeek.Monday;
                    else if (value == DayOfWeek.Tuesday.ToString())
                        customTimeInfo.StartOfWeek = DayOfWeek.Tuesday;
                    else if (value == DayOfWeek.Wednesday.ToString())
                        customTimeInfo.StartOfWeek = DayOfWeek.Wednesday;
                    else if (value == DayOfWeek.Thursday.ToString())
                        customTimeInfo.StartOfWeek = DayOfWeek.Thursday;
                    else if (value == DayOfWeek.Friday.ToString())
                        customTimeInfo.StartOfWeek = DayOfWeek.Friday;
                    else if (value == DayOfWeek.Saturday.ToString())
                        customTimeInfo.StartOfWeek = DayOfWeek.Saturday;
                }
                else if (key == "start_time")
                {
                    if (GetTimeAsFractionalHours(value, out var startHour))
                        customTimeInfo.StartOffset = TimeSpan.FromHours(startHour);
                }
                else if (key == "shift_hour")
                {
                    if (float.TryParse(value, out var shiftHours))
                        customTimeInfo.ShiftHours = shiftHours;
                }
                else if (key == "shift_names")
                {
                    customTimeInfo.ShiftNames = value.Split(',');
                }
            }

            return customTimeInfo;
        }

        public static DateTime GetPlanStartTime(IExperimentResultItem result)
        {
            var st = result.Experiment.GetArgument("start-time");

            if (st == null)
                return DateTime.Now;

            return (DateTime)st;
        }

        public static int GetPlanPeriod(IExperimentResultItem result)
        {
            var value = result.Experiment.GetArgument("period");

            if (value != null)
            {
                int period;
                if (int.TryParse(value.ToString(), out period))
                    return period;
            }

            return 7;
        }

        public static IEnumerable<T> GetEntityData<T>(IExperimentResultItem result, string shopList = null)
        {
            var svc = result;
            if (svc == null) //false 
                return new List<T>();

            var t = typeof(T);

            string nameSpace = t.Namespace;
            string tableName = t.Name;

            bool isInput = nameSpace.Contains("Inputs");

            IEnumerable<T> entityTable;

            string filter = null;
            if (string.IsNullOrEmpty(shopList) == false) //
            {
                var m = t.GetMember("SHOP_ID");
                if (m != null)
                    filter = string.Format("SHOP_ID IN({0})", shopList);
            }

            if (isInput)
                entityTable = svc.LoadInput<T>(tableName, filter);
            else
                entityTable = svc.LoadOutput<T>(tableName, filter);

            return entityTable;
        }

        public static Experiment GetExperiment(ModelDataContext ctx)
        {
            var expName = ctx.GetExpNames().FirstOrDefault();

            return ctx.Target.GetExperiment(expName);
        }

        public static T GetConfigValue<T>(this ModelDataContext modelDataContext, string PARAM_GROUP, string PARAM_NAME)
        {
            var experiment = GetExperiment(modelDataContext);
            try
            {
                var paramValue = modelDataContext.SIM_CONFIG.Where(x => x.PARAM_GROUP == PARAM_GROUP && x.PARAM_NAME == PARAM_NAME).First().PARAM_VALUE;
                return (T)Convert.ChangeType(paramValue, typeof(T));
            }
            catch
            {
                var paramValue = experiment.Engine.Configs.SafeGet(PARAM_NAME).InitialValue;
                return (T)Convert.ChangeType(paramValue, typeof(T));
            }
        }

        public static bool GetTimeAsFractionalHours(string str, out double result)
        {
            if (str.Length == 4)
            {
                string hours = str.Substring(0, 2);
                string minutes = str.Substring(2, 2);
                result = Convert.ToDouble(hours) + Convert.ToDouble(minutes) / 60;
                return true;
            }
            else if (str.Length == 3)
            {
                string hours = str.Substring(0, 1);
                string minutes = str.Substring(1, 2);
                result = Convert.ToDouble(hours) + Convert.ToDouble(minutes) / 60;
                return true;
            }
            else if (str.Length > 0 && str.Length < 3)
            {
                result = Convert.ToDouble(str);
                return true;
            }
            result = 0;
            return false;
        }
    }
}
