﻿using DevExpress.XtraBars;
using DevExpress.XtraCharts;
using FabSimulator.Inputs;
using FabSimulator.Outputs;
using FabSimulatorUI.Common;
using FabSimulatorUI.DataMappings;
using Mozart.Extensions;
using Mozart.Studio.TaskModel.Projects;
using Mozart.Studio.TaskModel.UserInterface;
using Mozart.Studio.TaskModel.UserLibrary;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FabSimulatorUI.Analysis
{
    public partial class StepTargetView : XtraGridControlView
    {
        #region Define Variable
        /* experiment result*/
        private IExperimentResultItem _result;

        /* DataTable */
        DataTable _dtProduct;

        /* List */
        List<filteredResult> _dtFiltered;
        List<filteredResult> _dtBeforeGrouping;
        #endregion

        #region Properties

        //Product_ID 콤보박스 선택 값을 return 해주는 프로퍼티
        public string theProduct { get { return cboProduct_ID.EditValue.ToString(); } }

        public DateTime theTargetDate { get { return (DateTime)barEditItem1.EditValue; } }

        //scaleCollapsed 텍스트박스 입력 값을 return 해주는 프로퍼티
        public int scaleCollapsed
        {
            get
            {
                int value = 1;
                if (!int.TryParse(txtScale_Collapsed.EditValue.ToString(), out value) || value <= 0)
                {
                    txtScale_Collapsed.EditValue = 10;
                    return 10;
                }
                else
                    return value;
                ;
            }
        }
        public DateTime planStartTime { get { return Globals.GetPlanStartTime(_result); } }

        //Product_ID 필터의 기본값을 설정하는 프로퍼티
        public object defaultProductIDValue { get { return repositoryItemComboBox1.Items[0]; } }

        public object defaultTargetDateValue { get { return repositoryItemComboBox2.Items[0]; } }

        //Scale_Collapsed의 기본값을 설정하는 프로퍼티
        public object defaultScaleCollapsedValue { get { return 10; } }

        #endregion

        #region Class
        internal class filteredResult
        {
            public static string productid = "PRODUCT_ID";
            public static string routeid = "ROUTE_ID";
            public static string stepseq = "STEP_SEQ";
            public static string outqty = "OUT_QTY";
            public static string stepid = "STEP_ID";
            public static string scale = "SCALE";

            public string PRODUCT_ID { get; set; }
            public string ROUTE_ID { get; set; }
            public int STEP_SEQ { get; set; }
            public double OUT_QTY { get; set; }
            public string STEPS { get; set; }
            public int SCALE { get; set; }
        }
        #endregion

        #region Constructor
        public StepTargetView()
        {
            InitializeComponent();
        }
        public StepTargetView(IServiceProvider serviceProvider)
            : base(serviceProvider)
        {
            InitializeComponent();
        }
        #endregion

        #region Load Document
        protected override void LoadDocument()
        {
            //result0 값 변수에 담아주기
            var item = (IMenuDocItem)this.Document.ProjectItem;
            _result = (IExperimentResultItem)item.Arguments[0];

            Globals.InitFactoryTime(this._result);

            //인풋의 product 관련 데이터 가져오기
            //_dtProduct = _result.LoadInput("PRODUCT");

            //기본 컨트롤 셋팅
            SetControls();
        }
        #endregion

        #region SetControls
        /// <summary>
        /// 컨트롤들 초기 설정
        /// </summary>
        private void SetControls()
        {
            //검색조건 부분 최소화
            //this.ribbonControl1.AllowMinimizeRibbon = true;
            //this.ribbonControl1.Minimized = true;

            //우클릭시 메뉴 뜨게 설정
            AddExtendGridMenu(gridView1, true);

            //우클릭시 차트에 메뉴 뜨게 설정
            //XtraChartHandler xtraChartHandler = new XtraChartHandler(this.chartControl, this.GetLayoutFullPath());
            //xtraChartHandler.SetChartOptions();

            //필터 값 초기화
            Filter_Init();

            //필터에 데이터 바인딩
            BindFilter();

            //필터에 기본 값 설정
            SetFilterDefaultValue();

            //필터 배경색 설정
            ColorFilter();

            //그리드뷰 설정
            SetGridView();

            //유효성 체크
            ValidationCheck();

            //chart point click 이벤트(popup 표시)
            chartControl.ObjectSelected += ChartControl_ObjectSelected;
        }

        private void Filter_Init()
        {
            //컨트롤 비워두기
            repositoryItemCheckedComboBoxEdit1.Items.Clear();
            txtScale_Collapsed.EditValue = string.Empty;
        }
        private void BindFilter()
        {
            SetTargetDateComobo();

            SetProductCombo();
        }

        private void SetTargetDateComobo()
        {
            var dayStartTime = ShopCalendar.StartTimeOfDayT(planStartTime);
            var dayStartTimeOfPET = ShopCalendar.StartTimeOfDayT(planStartTime.AddDays(Globals.GetPlanPeriod(_result)));

            while (dayStartTime <= dayStartTimeOfPET)
            {
                repositoryItemComboBox2.Items.Add(dayStartTime);

                dayStartTime = dayStartTime.AddDays(1);
            }
        }

        private void SetProductCombo()
        {
            var demands = Globals.GetEntityData<DEMAND>(_result);
            var products = demands.Select(x => x.PRODUCT_ID).Distinct().OrderBy(x => x);

            foreach (var product in products)
            {
                repositoryItemComboBox1.Items.Add(product);
            }

            if (products.IsNullOrEmpty())
                repositoryItemComboBox1.Items.Add(string.Empty);
        }

        private void SetFilterDefaultValue()
        {
            //product_ID와 Scale_Collapsed 초기값 설정
            barEditItem1.EditValue = defaultTargetDateValue;
            cboProduct_ID.EditValue = defaultProductIDValue;
            txtScale_Collapsed.EditValue = defaultScaleCollapsedValue;
        }
        private void ColorFilter()
        {
            //필터 배경색 흰색으로 설정
            repositoryItemComboBox1.Appearance.BackColor = Color.White;
            txtScale_Collapsed.Edit.Appearance.BackColor = Color.White;
        }
        private void SetGridView()
        {
            //전체 선택 가능하게 설정
            gridView1.OptionsSelection.MultiSelect = true;
            gridView1.OptionsSelection.MultiSelectMode = DevExpress.XtraGrid.Views.Grid.GridMultiSelectMode.RowSelect;
        }
        private void ValidationCheck()
        {
            //Scale-Collapsed 텍스트박스 숫자만 입력 받을 수 있게 유효성 체크
            repositoryItemTextEdit1.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            repositoryItemTextEdit1.Mask.EditMask = "d";
            repositoryItemTextEdit1.Mask.UseMaskAsDisplayFormat = true;
        }
        #endregion

        #region Event
        private void ChartControl_ObjectSelected(object sender, HotTrackEventArgs e)
        {
            if (e.HitInfo.SeriesPoint == null)
                return;

            Form popup = null;

            foreach (Form f in Application.OpenForms)
            {
                if (f is StepTargetPopUp)
                {
                    popup = f;
                }
            }

            if (popup != null)
                popup.Close();

            //차트에서 클릭한 지점의 정보가 담긴 객체 생성
            SeriesPoint point = e.HitInfo.SeriesPoint;

            //포인트의 밸류값 변수에 담기
            double out_qty = point.Values[0];

            //포인트의 아규먼트 변수에 담기
            int step_seq = Convert.ToInt32(point.Argument);

            //기존 데이터에서 클릭한 지점의 정보에 해당하는 값을 result에 담기
            filteredResult result = _dtFiltered.FirstOrDefault(x => x.OUT_QTY == out_qty && x.STEP_SEQ == step_seq);

            if (result == null)
                return;

            //팝업 창을 띄울때 위의 result 관련 정보를 생성자에 넘겨주기
            popup = new StepTargetPopUp(_result, theTargetDate, result.PRODUCT_ID, result.STEPS.Split(','), result.STEP_SEQ);
            popup.StartPosition = FormStartPosition.CenterScreen;
            popup.Show();
            popup.BringToFront();
        }
        #endregion

        #region Load
        private void btnLoad_ItemClick_1(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            //데이터를 다 가지고 올 때까지 모래시계를 넣어준다
            this.Cursor = Cursors.WaitCursor;

            //원하는 데이터를 가져와서 린큐로 필터링한다
            GetFilteredData();

            //그리드에 데이터 바인딩
            BindGrid(_dtFiltered);

            //차트에 데이터 바인딩
            BindChart(chartControl, _dtFiltered);

            //데이터를 다 가지고 올 때까지 모래시계를 넣어준다
            this.Cursor = Cursors.Arrow;
        }
        private IEnumerable<filteredResult> GetFilteredData()
        {
            //step target의 target date를 이미 지난 것들부터 하루치씩 가져온다
            var steptarget = from a in Globals.GetEntityData<STEP_TARGET>(_result)
                             .Where(t => ShopCalendar.StartTimeOfDayT(t.TARGET_DATE) <= theTargetDate && t.OUT_QTY > 0)
                             group a by new { a.PRODUCT_ID, a.ROUTE_ID, a.STEP_ID } into g
                             select new
                             {
                                 g.Key.PRODUCT_ID,
                                 g.Key.ROUTE_ID,
                                 g.Key.STEP_ID,
                                 OUT_QTY = g.Sum(t => t.OUT_QTY)
                             };

            //procstep에서 step seq를 가져와 step target 데이터와 transform
            var dailyTarget = (from a in Globals.GetEntityData<PRODUCT>(_result).Where(t => t.PRODUCT_ID == theProduct)
                               join b in Globals.GetEntityData<ROUTE_STEP>(_result) on a.ROUTE_ID equals b.ROUTE_ID
                               join c in steptarget on new { a.PRODUCT_ID, b.ROUTE_ID, b.STEP_ID } equals new { c.PRODUCT_ID, c.ROUTE_ID, c.STEP_ID } into outer
                               from o in outer.DefaultIfEmpty()
                               select new filteredResult
                               {
                                   PRODUCT_ID = a.PRODUCT_ID,
                                   ROUTE_ID = b.ROUTE_ID,
                                   STEPS = b.STEP_ID,
                                   STEP_SEQ = b.STEP_SEQ,
                                   OUT_QTY = o == null ? 0 : o.OUT_QTY,
                                   SCALE = b.STEP_SEQ / scaleCollapsed
                               }).ToList();

            _dtBeforeGrouping = dailyTarget;

            //step_seq별로 정렬 후 scale로 그룹핑
            var groupedTarget = (from a in dailyTarget.OrderBy(t => t.STEP_SEQ)
                                 group a by new { a.SCALE } into g
                                 let f = g.First()
                                 select new filteredResult
                                 {
                                     PRODUCT_ID = f.PRODUCT_ID,
                                     ROUTE_ID = f.ROUTE_ID,
                                     STEP_SEQ = f.STEP_SEQ,
                                     OUT_QTY = g.Sum(t => t.OUT_QTY),
                                     STEPS = String.Join(",", g.Select(t => t.STEPS)),
                                     SCALE = g.Key.SCALE
                                 }).ToList();

            _dtFiltered = groupedTarget;

            return _dtFiltered;
        }
        private DataTable CreateDataViewSchema()
        {
            DataTable dt = new DataTable();

            dt.Columns.Add(StepTargetMap.StepTarget.Schema.PRODUCT_ID, typeof(string));
            dt.Columns.Add(StepTargetMap.StepTarget.Schema.ROUTE_ID, typeof(string));
            dt.Columns.Add(StepTargetMap.StepTarget.Schema.STEP_SEQ, typeof(int));
            dt.Columns.Add(StepTargetMap.StepTarget.Schema.QTY, typeof(double));
            dt.Columns.Add(StepTargetMap.StepTarget.Schema.STEP_ID, typeof(string));



            foreach (filteredResult item in _dtFiltered)
            {
                DataRow row = dt.NewRow();
                row[StepTargetMap.StepTarget.Schema.PRODUCT_ID] = item.PRODUCT_ID;
                row[StepTargetMap.StepTarget.Schema.ROUTE_ID] = item.ROUTE_ID;
                row[StepTargetMap.StepTarget.Schema.STEP_SEQ] = item.STEP_SEQ;
                row[StepTargetMap.StepTarget.Schema.QTY] = item.OUT_QTY;
                row[StepTargetMap.StepTarget.Schema.STEP_ID] = item.STEPS;

                dt.Rows.Add(row);
            }

            return dt;
        }
        private void BindGrid(IEnumerable<filteredResult> dt)
        {
            //그리드에 데이터 바인딩
            gridControl1.DataSource = dt;
        }
        private void BindChart(DevExpress.XtraCharts.ChartControl chartControl, IEnumerable<filteredResult> chartDt)
        {
            //차트 값 초기화
            chart_Init();

            //x,y축에 들어간 step seq, outqty 변수에 담아주기
            string argumentMember = filteredResult.stepseq;
            string valueMember = filteredResult.outqty;

            //새 차트 생성
            XtraChartHelper.CreatSeries(chartControl, valueMember, argumentMember, 0, ViewType.Line, false);

            //다이어그램 세팅
            SetDiagram();

            //시리즈 뷰 세팅
            SetSeriesView();

            //차트 컨트롤 셋팅
            SetChartControl(chartDt);
        }
        private void chart_Init()
        {
            //차트 먼저 비워주기
            chartControl.Series.Clear();
        }
        private void SetDiagram()
        {
            //다이어그램 객체 생성
            DevExpress.XtraCharts.XYDiagram xyDiagram = (DevExpress.XtraCharts.XYDiagram)chartControl.Diagram;

            //다이어그램 옵션 셋팅
            xyDiagram.AxisX.Label.Visible = true;
            xyDiagram.AxisX.Label.Angle = 90;
            xyDiagram.AxisX.Label.ResolveOverlappingOptions.AllowHide = false;

            xyDiagram.AxisX.QualitativeScaleOptions.AutoGrid = false;
            xyDiagram.AxisX.QualitativeScaleComparer = null;

            xyDiagram.AxisX.NumericScaleOptions.AutoGrid = false;

            xyDiagram.EnableAxisXScrolling = true;
            xyDiagram.EnableAxisXZooming = true;
            xyDiagram.EnableAxisYScrolling = true;
            xyDiagram.EnableAxisYZooming = true;

        }
        private void SetSeriesView()
        {
            //시리즈 뷰 객체 생성
            DevExpress.XtraCharts.LineSeriesView seriesView = (DevExpress.XtraCharts.LineSeriesView)chartControl.Series[0].View;

            //시리즈 뷰 옵션 셋팅
            seriesView.Color = Color.Blue;
            seriesView.LineStyle.DashStyle = DashStyle.Solid;
            seriesView.AxisX.QualitativeScaleOptions.AutoGrid = false;
            seriesView.AxisX.NumericScaleOptions.AutoGrid = false;
        }
        private void SetChartControl(IEnumerable<filteredResult> chartDt)
        {
            //차트 컨트롤 옵션 셋팅

            DataTable dt = CreateDataViewSchema();

            foreach (DataRow row in dt.Rows)
            {
                chartControl.Series[0].Points.Add(new SeriesPoint(row.GetInt32(StepTargetMap.StepTarget.Schema.STEP_SEQ), row.GetDouble(StepTargetMap.StepTarget.Schema.QTY)));
            }

            int lastseq;
            double lastqty;
            if (_dtBeforeGrouping.IsNullOrEmpty())
            {
                lastseq = 0;
                lastqty = 0;
            }
            else
            {
                //마지막 값을 구하기, UI에 마지막 seq값을 fix하기 위함
                lastseq = _dtBeforeGrouping.ToList().FindLast(x => x.STEP_SEQ > -1).STEP_SEQ;
                lastqty = _dtBeforeGrouping.ToList().FindLast(x => x.OUT_QTY > -1).OUT_QTY;
            }

            //마지막 값을 항상 Fix
            chartControl.Series[0].Points.Add(new SeriesPoint(lastseq, lastqty));

            chartControl.Series[0].ArgumentScaleType = ScaleType.Qualitative;
        }
        #endregion
    }
}
