﻿namespace FabSimulatorUI.Analysis
{
    partial class FabLineTrendView
    {
        /// <summary> 
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 구성 요소 디자이너에서 생성한 코드

        /// <summary> 
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>        
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            DevExpress.XtraCharts.XYDiagram xyDiagram1 = new DevExpress.XtraCharts.XYDiagram();
            DevExpress.XtraCharts.Series series1 = new DevExpress.XtraCharts.Series();
            DevExpress.XtraCharts.LineSeriesView lineSeriesView1 = new DevExpress.XtraCharts.LineSeriesView();
            DevExpress.XtraCharts.Series series2 = new DevExpress.XtraCharts.Series();
            DevExpress.XtraCharts.LineSeriesView lineSeriesView2 = new DevExpress.XtraCharts.LineSeriesView();
            DevExpress.XtraCharts.LineSeriesView lineSeriesView3 = new DevExpress.XtraCharts.LineSeriesView();
            DevExpress.XtraCharts.ChartTitle chartTitle1 = new DevExpress.XtraCharts.ChartTitle();
            this.panelControl1 = new DevExpress.XtraEditors.PanelControl();
            this.pivotGridControl = new DevExpress.XtraPivotGrid.PivotGridControl();
            this.expandablePanel1 = new Mozart.Studio.UIComponents.ExpandablePanel();
            this.radioGroup1 = new DevExpress.XtraEditors.RadioGroup();
            this.endDateTimePicker = new Mozart.Studio.UIComponents.FullDateTimePicker();
            this.startDateTimePicker = new Mozart.Studio.UIComponents.FullDateTimePicker();
            this.saveLayoutBtn = new System.Windows.Forms.Button();
            this.resultCheckCtl = new DevExpress.XtraEditors.CheckedComboBoxEdit();
            this.label2 = new System.Windows.Forms.Label();
            this.btnQuery = new System.Windows.Forms.Button();
            this.dockManager1 = new DevExpress.XtraBars.Docking.DockManager(this.components);
            this.dockPanel1 = new DevExpress.XtraBars.Docking.DockPanel();
            this.dockPanel1_Container = new DevExpress.XtraBars.Docking.ControlContainer();
            this.chartProcProgress = new DevExpress.XtraCharts.ChartControl();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl1)).BeginInit();
            this.panelControl1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pivotGridControl)).BeginInit();
            this.expandablePanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.radioGroup1.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.resultCheckCtl.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dockManager1)).BeginInit();
            this.dockPanel1.SuspendLayout();
            this.dockPanel1_Container.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chartProcProgress)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(xyDiagram1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(series1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(lineSeriesView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(series2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(lineSeriesView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(lineSeriesView3)).BeginInit();
            this.SuspendLayout();
            // 
            // panelControl1
            // 
            this.panelControl1.Controls.Add(this.pivotGridControl);
            this.panelControl1.Controls.Add(this.expandablePanel1);
            this.panelControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelControl1.Location = new System.Drawing.Point(0, 0);
            this.panelControl1.Name = "panelControl1";
            this.panelControl1.Size = new System.Drawing.Size(1155, 277);
            this.panelControl1.TabIndex = 0;
            // 
            // pivotGridControl
            // 
            this.pivotGridControl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pivotGridControl.Location = new System.Drawing.Point(2, 73);
            this.pivotGridControl.Name = "pivotGridControl";
            this.pivotGridControl.OptionsView.ShowColumnTotals = false;
            this.pivotGridControl.OptionsView.ShowRowTotals = false;
            this.pivotGridControl.Size = new System.Drawing.Size(1151, 202);
            this.pivotGridControl.TabIndex = 1;
            this.pivotGridControl.CustomSummary += new DevExpress.XtraPivotGrid.PivotGridCustomSummaryEventHandler(this.pivotGridControl_CustomSummary);
            this.pivotGridControl.CustomGroupInterval += new DevExpress.XtraPivotGrid.PivotCustomGroupIntervalEventHandler(this.pivotGridControl_CustomGroupInterval);
            this.pivotGridControl.CustomChartDataSourceData += new DevExpress.XtraPivotGrid.PivotCustomChartDataSourceDataEventHandler(this.PivotGridControl_CustomChartDataSourceData);
            this.pivotGridControl.CustomCellDisplayText += new DevExpress.XtraPivotGrid.PivotCellDisplayTextEventHandler(this.PivotGridControl_CustomCellDisplayText);
            // 
            // expandablePanel1
            // 
            this.expandablePanel1.Controls.Add(this.radioGroup1);
            this.expandablePanel1.Controls.Add(this.endDateTimePicker);
            this.expandablePanel1.Controls.Add(this.startDateTimePicker);
            this.expandablePanel1.Controls.Add(this.saveLayoutBtn);
            this.expandablePanel1.Controls.Add(this.resultCheckCtl);
            this.expandablePanel1.Controls.Add(this.label2);
            this.expandablePanel1.Controls.Add(this.btnQuery);
            this.expandablePanel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.expandablePanel1.ForeColor = System.Drawing.Color.SteelBlue;
            this.expandablePanel1.Location = new System.Drawing.Point(2, 2);
            this.expandablePanel1.Name = "expandablePanel1";
            this.expandablePanel1.Size = new System.Drawing.Size(1151, 71);
            this.expandablePanel1.TabIndex = 0;
            this.expandablePanel1.Text = "Fab Line Trend";
            this.expandablePanel1.UseAnimation = true;
            // 
            // radioGroup1
            // 
            this.radioGroup1.Location = new System.Drawing.Point(471, 33);
            this.radioGroup1.Name = "radioGroup1";
            this.radioGroup1.Properties.Columns = 3;
            this.radioGroup1.Properties.GlyphAlignment = DevExpress.Utils.HorzAlignment.Default;
            this.radioGroup1.Properties.Items.AddRange(new DevExpress.XtraEditors.Controls.RadioGroupItem[] {
            new DevExpress.XtraEditors.Controls.RadioGroupItem(null, "Monthly", true, null, "radio_monthly"),
            new DevExpress.XtraEditors.Controls.RadioGroupItem(null, "Weekly", true, null, "radio_weekly"),
            new DevExpress.XtraEditors.Controls.RadioGroupItem(null, "Daily", true, null, "radio_daily")});
            this.radioGroup1.Size = new System.Drawing.Size(225, 29);
            this.radioGroup1.TabIndex = 87;
            this.radioGroup1.SelectedIndexChanged += new System.EventHandler(this.radioGroup1_SelectedIndexChanged);
            // 
            // endDateTimePicker
            // 
            this.endDateTimePicker.Location = new System.Drawing.Point(346, 37);
            this.endDateTimePicker.Margin = new System.Windows.Forms.Padding(3, 9, 3, 9);
            this.endDateTimePicker.Name = "endDateTimePicker";
            this.endDateTimePicker.Size = new System.Drawing.Size(119, 22);
            this.endDateTimePicker.TabIndex = 86;
            this.endDateTimePicker.TimeFormat = Mozart.Studio.UIComponents.FullDateTimePickerTimeFormat.Hidden;
            this.endDateTimePicker.UTCPrompt = null;
            // 
            // startDateTimePicker
            // 
            this.startDateTimePicker.Location = new System.Drawing.Point(221, 36);
            this.startDateTimePicker.Margin = new System.Windows.Forms.Padding(3, 8, 3, 8);
            this.startDateTimePicker.Name = "startDateTimePicker";
            this.startDateTimePicker.Size = new System.Drawing.Size(119, 22);
            this.startDateTimePicker.TabIndex = 85;
            this.startDateTimePicker.TimeFormat = Mozart.Studio.UIComponents.FullDateTimePickerTimeFormat.Hidden;
            this.startDateTimePicker.UTCPrompt = null;
            this.startDateTimePicker.ValueChanged += new System.EventHandler(this.StartDateTimePicker_ValueChanged);
            // 
            // saveLayoutBtn
            // 
            this.saveLayoutBtn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.saveLayoutBtn.Location = new System.Drawing.Point(964, 34);
            this.saveLayoutBtn.Name = "saveLayoutBtn";
            this.saveLayoutBtn.Size = new System.Drawing.Size(87, 27);
            this.saveLayoutBtn.TabIndex = 74;
            this.saveLayoutBtn.Text = "Save Layout";
            this.saveLayoutBtn.UseVisualStyleBackColor = true;
            this.saveLayoutBtn.Click += new System.EventHandler(this.saveLayoutBtn_Click);
            // 
            // resultCheckCtl
            // 
            this.resultCheckCtl.Location = new System.Drawing.Point(79, 38);
            this.resultCheckCtl.Name = "resultCheckCtl";
            this.resultCheckCtl.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.resultCheckCtl.Size = new System.Drawing.Size(124, 20);
            this.resultCheckCtl.TabIndex = 72;
            this.resultCheckCtl.TextChanged += new System.EventHandler(this.resultCheckCtl_TextChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(23, 41);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(45, 14);
            this.label2.TabIndex = 71;
            this.label2.Text = "Results";
            // 
            // btnQuery
            // 
            this.btnQuery.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnQuery.Location = new System.Drawing.Point(1059, 34);
            this.btnQuery.Name = "btnQuery";
            this.btnQuery.Size = new System.Drawing.Size(75, 27);
            this.btnQuery.TabIndex = 3;
            this.btnQuery.Text = "QUERY";
            this.btnQuery.UseVisualStyleBackColor = true;
            this.btnQuery.Click += new System.EventHandler(this.btnQuery_Click);
            // 
            // dockManager1
            // 
            this.dockManager1.Form = this;
            this.dockManager1.RootPanels.AddRange(new DevExpress.XtraBars.Docking.DockPanel[] {
            this.dockPanel1});
            this.dockManager1.TopZIndexControls.AddRange(new string[] {
            "DevExpress.XtraBars.BarDockControl",
            "DevExpress.XtraBars.StandaloneBarDockControl",
            "System.Windows.Forms.StatusBar",
            "System.Windows.Forms.MenuStrip",
            "System.Windows.Forms.StatusStrip",
            "DevExpress.XtraBars.Ribbon.RibbonStatusBar",
            "DevExpress.XtraBars.Ribbon.RibbonControl",
            "DevExpress.XtraBars.Navigation.OfficeNavigationBar",
            "DevExpress.XtraBars.Navigation.TileNavPane"});
            // 
            // dockPanel1
            // 
            this.dockPanel1.Controls.Add(this.dockPanel1_Container);
            this.dockPanel1.Dock = DevExpress.XtraBars.Docking.DockingStyle.Bottom;
            this.dockPanel1.ID = new System.Guid("cc1d48cf-ec4d-4e64-b1c0-ef6d8bd62b9c");
            this.dockPanel1.Location = new System.Drawing.Point(0, 277);
            this.dockPanel1.Name = "dockPanel1";
            this.dockPanel1.OriginalSize = new System.Drawing.Size(200, 200);
            this.dockPanel1.Size = new System.Drawing.Size(1155, 200);
            this.dockPanel1.Text = "Movement Chart";
            // 
            // dockPanel1_Container
            // 
            this.dockPanel1_Container.Controls.Add(this.chartProcProgress);
            this.dockPanel1_Container.Location = new System.Drawing.Point(3, 27);
            this.dockPanel1_Container.Name = "dockPanel1_Container";
            this.dockPanel1_Container.Size = new System.Drawing.Size(1149, 170);
            this.dockPanel1_Container.TabIndex = 0;
            // 
            // chartProcProgress
            // 
            xyDiagram1.AxisX.VisibleInPanesSerializable = "-1";
            xyDiagram1.AxisY.VisibleInPanesSerializable = "-1";
            this.chartProcProgress.Diagram = xyDiagram1;
            this.chartProcProgress.Dock = System.Windows.Forms.DockStyle.Fill;
            this.chartProcProgress.Legend.Name = "Default Legend";
            this.chartProcProgress.Location = new System.Drawing.Point(0, 0);
            this.chartProcProgress.Name = "chartProcProgress";
            series1.Name = "Series 1";
            series1.View = lineSeriesView1;
            series2.Name = "Series 2";
            series2.View = lineSeriesView2;
            this.chartProcProgress.SeriesSerializable = new DevExpress.XtraCharts.Series[] {
        series1,
        series2};
            this.chartProcProgress.SeriesTemplate.View = lineSeriesView3;
            this.chartProcProgress.Size = new System.Drawing.Size(1149, 170);
            this.chartProcProgress.SmallChartText.Text = "Increase the chart\'s size,\r\nto view its layout.\r\n    ";
            this.chartProcProgress.TabIndex = 5;
            chartTitle1.DXFont = new DevExpress.Drawing.DXFont("Tahoma", 12F, DevExpress.Drawing.DXFontStyle.Regular, DevExpress.Drawing.DXGraphicsUnit.Point, new DevExpress.Drawing.DXFontAdditionalProperty[] {
            new DevExpress.Drawing.DXFontAdditionalProperty("GdiCharSet", ((byte)(0)))});
            this.chartProcProgress.Titles.AddRange(new DevExpress.XtraCharts.ChartTitle[] {
            chartTitle1});
            this.chartProcProgress.CustomDrawCrosshair += new DevExpress.XtraCharts.CustomDrawCrosshairEventHandler(this.ChartProcProgress_CustomDrawCrosshair);
            this.chartProcProgress.BoundDataChanged += new DevExpress.XtraCharts.BoundDataChangedEventHandler(this.ChartProcProgress_BoundDataChanged);
            // 
            // FabLineTrendView
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 14F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.panelControl1);
            this.Controls.Add(this.dockPanel1);
            this.Name = "FabLineTrendView";
            this.Size = new System.Drawing.Size(1155, 477);
            ((System.ComponentModel.ISupportInitialize)(this.panelControl1)).EndInit();
            this.panelControl1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pivotGridControl)).EndInit();
            this.expandablePanel1.ResumeLayout(false);
            this.expandablePanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.radioGroup1.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.resultCheckCtl.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dockManager1)).EndInit();
            this.dockPanel1.ResumeLayout(false);
            this.dockPanel1_Container.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(xyDiagram1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(lineSeriesView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(series1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(lineSeriesView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(series2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(lineSeriesView3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chartProcProgress)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        /// <summary>   The first panel control. </summary>
        private DevExpress.XtraEditors.PanelControl panelControl1;
        /// <summary>   The first expandable panel. </summary>
        private Mozart.Studio.UIComponents.ExpandablePanel expandablePanel1;
        /// <summary>   The button query control. </summary>
        private System.Windows.Forms.Button btnQuery;
        /// <summary>   The pivot grid control. </summary>
        private DevExpress.XtraPivotGrid.PivotGridControl pivotGridControl;
        /// <summary>   The first dock manager. </summary>
        private DevExpress.XtraBars.Docking.DockManager dockManager1;
        /// <summary>   The first dock panel. </summary>
        private DevExpress.XtraBars.Docking.DockPanel dockPanel1;
        /// <summary>   The dock panel 1 container. </summary>
        private DevExpress.XtraBars.Docking.ControlContainer dockPanel1_Container;
        /// <summary>   The chart procedure progress. </summary>
        private DevExpress.XtraCharts.ChartControl chartProcProgress;
        /// <summary>   The result check control. </summary>
        private DevExpress.XtraEditors.CheckedComboBoxEdit resultCheckCtl;
        /// <summary>   The label 2 control. </summary>
        private System.Windows.Forms.Label label2;
        /// <summary>   The save layout control. </summary>
        private System.Windows.Forms.Button saveLayoutBtn;
        private Mozart.Studio.UIComponents.FullDateTimePicker endDateTimePicker;
        private Mozart.Studio.UIComponents.FullDateTimePicker startDateTimePicker;
        private DevExpress.XtraEditors.RadioGroup radioGroup1;
    }
}
