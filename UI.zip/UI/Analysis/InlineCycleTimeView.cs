﻿using DevExpress.XtraCharts;
using DevExpress.XtraGrid.Columns;
using DevExpress.XtraGrid.Views.Grid;
using DevExpress.XtraTab;
using FabSimulator;
using FabSimulator.Outputs;
using FabSimulatorUI.Common;
using Mozart.Data.Entity;
using Mozart.Extensions;
using Mozart.Studio.TaskModel.Projects;
using Mozart.Studio.TaskModel.UserInterface;
// for export excel; temporarily
using Mozart.Studio.TaskModel.UserLibrary;
using System.ComponentModel.DataAnnotations;
using System.Data;
//using DevExpress.PivotGrid.ServerMode.OperationGraph;

namespace FabSimulatorUI.Analysis
{
    public partial class InlineCycleTimeView : XtraGridControlView
    {
        #region Variable&Property

        IExperimentResultItem result;

        ModelDataContext modelDataContext;
        ExpDataContext expDataContext;

        bool initializing;
        bool loading;

        #endregion

        #region Ctor

        public InlineCycleTimeView(IServiceProvider serviceProvider)
            : base(serviceProvider)
        {
            InitializeComponent();

            this.initializing = true;
        }

        protected override void LoadDocument()
        {
            this.LoadInit();
            this.initializing = false;

            this.loading = true;
            this.Query();
            this.loading = false;
        }

        #endregion

        #region Init

        private void LoadInit()
        {
            this.result = this.Document.GetResultItem();

            Globals.InitFactoryTime(this.result);

            this.result.ExpResults(this.resultCheckCtl);

            this.modelDataContext = result.GetCtx<ModelDataContext>();
            this.expDataContext = result.GetCtx<ExpDataContext>();

            this.FillPeriod();

            this.radioGroup1.SelectedIndex = 1;
        }

        #endregion

        #region Query&Bind

        private void Query()
        {
            using (var wc = new Mozart.Studio.UIComponents.WaitCursor())
            {
                this.BindBegin();
                this.BindDo();
                this.BindEnd();
            }
        }

        private void BindBegin()
        {
            //this.gridControl1.BeginUpdate();
            //this.gridControl1.DataSource = null;
        }

        private void BindEnd()
        {
            // width 최대 596??
            this.dockPanel1.Size = new Size(800, this.dockPanel1.PreferredSize.Height);

            //this.gridControl1.EndUpdate();

            //this.gridControl1.UseEmbeddedNavigator = true;

            //this.gridView1.OptionsView.ColumnAutoWidth = false;
            //this.gridView1.OptionsView.ShowFooter = true;
            //this.SetFooterSummary(this.gridView1);

            //this.gridView1.BestFitColumns();
            //this.gridView1.OptionsView.ShowAutoFilterRow = true;
            //this.gridView1.OptionsSelection.MultiSelect = true;
        }

        private void BindDo()
        {
            this.xtraTabControl1.TabPages.Clear();

            // **** 변경 이력 ****
            // 1. SUMMARY_AREA_TAT, SUMMARY_PRODUCT_CT 테이블 사용 -> missing step 반영 못하는 이슈로 철회
            // 2. STEP_MOVE 테이블 사용 -> route 반영 못하는 이슈로 철회
            // 3. SUMMARY_DYNAMIC_CT, SUMMARY_DYNAMIC_CT2 테이블 사용 -> 엔진에서 missing step및 route 고려해서 계산 후 출력된 값.

            //this.CalculateNew();
            //this.CalculateWithStepMoveTable();
            this.CalculateWithDynamicCT();
        }
        #endregion

        private void FillPeriod()
        {
            this.startDateTimePicker.Value = ShopCalendar.StartTimeOfDayT(this.result.StartTime);
            this.endDateTimePicker.Value = this.startDateTimePicker.Value.AddDays(this.result.GetPlanPeriodF(1));
        }

        private void CalculateWithDynamicCT()
        {
            #region **Setup
            var results = this.resultCheckCtl.Properties.Items.GetCheckedValues().Select(x => x.ToString()).ToArray();
            if (results == null || results.Length == 0)
                return;

            var radioIndex = this.radioGroup1.SelectedIndex;

            var startTime = FabSimulatorUI.Helper.GetIntervalStartDate(this.startDateTimePicker.Value, radioIndex);
            var endTime = FabSimulatorUI.Helper.GetIntervalEndDate(this.endDateTimePicker.Value, radioIndex);

            if (startTime >= endTime)
            {
                MessageBox.Show("Invalid Period");
                return;
            }
            #endregion

            List<TATSet> areaTATList = new List<TATSet>();
            List<TATSet> partTATList = new List<TATSet>();

            List<DynamicCTInfo> dynamicCTResults = new List<DynamicCTInfo>();
            foreach (var resultName in results)
            {
                IEnumerable<DynamicCTInfo> resultOutput = GetDynamicCTInfo(startTime, endTime, resultName);

                dynamicCTResults.AddRange(resultOutput);
            }
            // missing step은 periodic 집계시 미리 계산하여 SUMMARY 테이블에 출력하므로 여기서 다시 계산할 필요 없음.

            List<TATSet> areaPartTATSets = new List<TATSet>();
            foreach (var areaItems in dynamicCTResults.GroupBy(x => x.AREA_ID))
            {
                foreach (var partItems in areaItems.GroupBy(x => x.PART_ID))
                {
                    TATSet areaPartTATSet = new TATSet(areaItems.Key, partItems.Key);
                    foreach (var stepItems in partItems.GroupBy(x => x.STEP_ID))
                    {
                        // SUMMARY_DYNAMIC_CT2를 사용하는 경우, stepItems에는 복수개의 TARGET_DATE 및 RESULT가 섞여 있게 됨.
                        // 이에 대해서는 따로 부분평균을 구하지 않고, 통째로 AreaPartStep의 TAT를 대표하는 값으로 aggregation.

                        var tatSet = new TATSet(stepItems, TATAggregationType.Average);

                        areaPartTATSet.AccumulateSet(tatSet);
                    }

                    areaPartTATSets.Add(areaPartTATSet);
                }
            }

            foreach (var areaItems in areaPartTATSets.GroupBy(x => x.AREA_ID))
            {
                areaTATList.Add(new TATSet(areaItems, TATAggregationType.Average, true));
            }

            foreach (var partItems in areaPartTATSets.GroupBy(x => x.PART_ID))
            {
                partTATList.Add(new TATSet(partItems, TATAggregationType.Sum, true));
            }

            SetTabPages(areaTATList, "Area TAT");
            SetTabPages(partTATList, "Part TAT");
        }

        private IEnumerable<DynamicCTInfo> GetDynamicCTInfo(DateTime startTime, DateTime endTime, string resultName)
        {
            var result = this.expDataContext.Result(resultName);

            IEnumerable<DynamicCTInfo> resultOutput;
            if (result.SUMMARY_DYNAMIC_CT2.IsNullOrEmpty() == false)
            {
                resultOutput = from a in result.SUMMARY_DYNAMIC_CT2.Where(x => x.TARGET_DATE >= startTime && x.TARGET_DATE <= endTime)
                               select new DynamicCTInfo(resultName, a);
            }
            else
            {
                // SUMMARY_DYNAMIC_CT2 데이터가 없으면 SUMMARY_DYNAMIC_CT 데이터를 사용
                resultOutput = from a in result.SUMMARY_DYNAMIC_CT
                               select new DynamicCTInfo(resultName, a);
            }

            return resultOutput.ToList();
        }

        private void SetTabPages(IEnumerable<TATSet> tab, string tabName)
        {
            var tabPage = new XtraTabPage();
            var gridControl = new DevExpress.XtraGrid.GridControl();
            var gridView = new DevExpress.XtraGrid.Views.Grid.GridView();

            //Do not set the MainView property while wrapping the setter with the BeginUpdate and EndUpdate method pair
            gridControl.MainView = gridView;
            gridControl.BindingContext = new BindingContext();
            gridControl.ForceInitialize();
            gridControl.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] { gridView });
            gridView.GridControl = gridControl;

            gridControl.BeginUpdate();

            gridControl.Dock = System.Windows.Forms.DockStyle.Fill;

            gridControl.DataSource = tab.OrderByDescending(x => x.TOTAL_TAT).ToBindingList();

            gridControl.EndUpdate();

            gridView.OptionsView.ColumnAutoWidth = false;
            gridView.OptionsView.ShowFooter = true;
            this.SetCation(gridView, tabName);
            this.SetFooterSummary(gridView);

            gridView.BestFitColumns();
            gridView.OptionsView.ShowAutoFilterRow = true;
            gridView.OptionsSelection.MultiSelect = true;

            tabPage.Controls.Add(gridControl);
            tabPage.Text = tabName;

            this.xtraTabControl1.TabPages.Add(tabPage);
        }

        private void SetCation(GridView gv, string tabName)
        {
            if (tabName == "Area TAT")
            {
                gv.Columns["KEY"].Caption = "AreaID";
            }
            else if (tabName == "Part TAT")
            {
                gv.Columns["KEY"].Caption = "PartID";
            }

            gv.Columns["WAIT_TAT"].Caption = "WaitDay";
            gv.Columns["RUN_TAT"].Caption = "RunDay";
            gv.Columns["TOTAL_TAT"].Caption = "TotalDay";
        }

        private void SetFooterSummary(GridView girdView)
        {
            foreach (GridColumn col in girdView.Columns)
            {
                string name = col.FieldName;

                if (name.Contains("TAT"))
                    girdView.Columns[name].SummaryItem.SetSummary(DevExpress.Data.SummaryItemType.Sum, "{0:###,##0.000}");

                //if (name.Equals("HotLot"))
                //    girdView.Columns[name].SummaryItem.SetSummary(DevExpress.Data.SummaryItemType.Custom, "{0: ###,##0}");
                //else if (name.Contains("Cnt"))
                //    girdView.Columns[name].SummaryItem.SetSummary(DevExpress.Data.SummaryItemType.Sum, "{0:###,##0}");
                //else if (name.Contains("Hr") || name.Contains("Day"))
                //    girdView.Columns[name].SummaryItem.SetSummary(DevExpress.Data.SummaryItemType.Sum, "{0:###,##0.000}");
                //else
                //    continue;
            }
        }

        #region Events

        private void btnQuery_Click(object sender, EventArgs e)
        {
            this.Query();
        }

        private void XtraTabControl1_SelectedPageChanged(object sender, DevExpress.XtraTab.TabPageChangedEventArgs e)
        {
            if (e.Page == null)
                return;

            var gridControl = e.Page.Controls[0] as DevExpress.XtraGrid.GridControl;
            var ds = gridControl.DataSource as IEnumerable<TATSet>;
            List<TATSeries> list = new List<TATSeries>();
            if (e.Page.Text == "Area TAT" || e.Page.Text == "Part TAT")
            {
                var fabIn = this.modelDataContext.GetConfigValue<string>(PARAM_GROUP: "Bop_Step", PARAM_NAME: "fabInStepID");
                var fabOut = this.modelDataContext.GetConfigValue<string>(PARAM_GROUP: "Bop_Step", PARAM_NAME: "fabOutStepID");

                foreach (var item in ds)
                {
                    if (item.KEY == fabIn || item.KEY == fabOut)
                        continue;

                    var data1 = new TATSeries();
                    data1.ARGUMENT = item.KEY;
                    data1.DATA = "RUN_DAYS";
                    data1.VALUE = item.RUN_TAT;

                    var data2 = new TATSeries();
                    data2.ARGUMENT = item.KEY;
                    data2.DATA = "WAIT_DAYS";
                    data2.VALUE = item.WAIT_TAT;

                    list.Add(data1);
                    list.Add(data2);
                }

                this.chartControl1.Series.Clear();
                this.chartControl1.DataSource = list;
                this.chartControl1.SeriesTemplate.SeriesDataMember = "DATA";
                this.chartControl1.SeriesTemplate.ArgumentDataMember = "ARGUMENT";
                this.chartControl1.SeriesTemplate.ValueDataMembers.AddRange("VALUE");
            }
            else
            {
                this.chartControl1.Series.Clear();
            }
        }

        private void ChartControl1_BoundDataChanged(object sender, EventArgs e)
        {
            var series = ((ChartControl)sender).Series;
            foreach (Series s in series)
            {
                s.ChangeView(ViewType.StackedBar);

                //StackedBarSeriesView view = (StackedBarSeriesView)s.View;
                //view.Transparency = 160;
            }
        }

        private void radioGroup1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (this.initializing)
                return;

            this.Query();
        }

        private void startDateTimePicker_ValueChanged(object sender, EventArgs e)
        {
            if (this.initializing)
                return;

            this.endDateTimePicker.Value = this.startDateTimePicker.Value.AddMonths(1);
        }

        private void resultCheckCtl_EditValueChanged(object sender, EventArgs e)
        {
            if (this.initializing)
                return;

            this.Query();
        }

        #endregion

        #region Inner Class

        class DynamicCTInfo : TATSet
        {
            public DateTime TARGET_DATE { get ; set; }
            public string? STEP_ID { get; set; }

            internal DynamicCTInfo(string resultName, SUMMARY_DYNAMIC_CT row)
            {
                KEY = resultName;
                AREA_ID = row.AREA_ID;
                PART_ID = row.PART_ID;
                RUN_TAT = row.RUN_TAT;
                WAIT_TAT = row.WAIT_TAT;
                TOTAL_TAT = row.TOTAL_TAT;
                MOVE_QTY = row.MOVE_QTY;
            }

            internal DynamicCTInfo(string resultName, SUMMARY_DYNAMIC_CT2 row)
            {
                KEY = resultName;
                TARGET_DATE = row.TARGET_DATE;
                AREA_ID = row.AREA_ID;
                PART_ID = row.PART_ID;
                STEP_ID = row.STEP_ID;
                RUN_TAT = row.RUN_TAT;
                WAIT_TAT = row.WAIT_TAT;
                TOTAL_TAT = row.TOTAL_TAT;
                MOVE_QTY = row.MOVE_QTY;
            }
        }

        enum TATAggregationType
        {
            Average = 1,
            Sum = 2
        }

        class TATSet
        {
            public string? KEY { get; set; }

            [Display(Order = -1)]
            public string AREA_ID { get; set; }

            [Display(Order = -1)]
            public string PART_ID { get; set; }

            public double RUN_TAT { get; set; }

            public double WAIT_TAT { get; set; }

            public double TOTAL_TAT { get; set; }

            [Display(Order = -1)]
            public double MOVE_QTY { get; set; }

            internal TATSet()
            {
            }

            internal TATSet(string key)
            {
                KEY = key;
            }

            internal TATSet(string areaID, string partID)
            {
                AREA_ID = areaID;
                PART_ID = partID;
            }

            internal TATSet(IEnumerable<TATSet> items, TATAggregationType type, bool finalize = false)
            {
                AREA_ID = items.First().AREA_ID;
                PART_ID = items.First().PART_ID;
                MOVE_QTY = items.Select(x => x.MOVE_QTY).Sum();

                if (type == TATAggregationType.Average)
                {
                    KEY = AREA_ID;
                    if (MOVE_QTY > 0) // 가중평균 사용
                    {
                        TOTAL_TAT = items.Select(x => x.TOTAL_TAT * x.MOVE_QTY).Sum() / MOVE_QTY;
                        WAIT_TAT = items.Select(x => x.WAIT_TAT * x.MOVE_QTY).Sum() / MOVE_QTY;
                        RUN_TAT = items.Select(x => x.RUN_TAT * x.MOVE_QTY).Sum() / MOVE_QTY;
                    }
                    else // 단순평균 사용
                    {
                        TOTAL_TAT = items.Select(x => x.TOTAL_TAT).Average();
                        WAIT_TAT = items.Select(x => x.WAIT_TAT).Average();
                        RUN_TAT = items.Select(x => x.RUN_TAT).Average();
                    }
                }
                else if (type == TATAggregationType.Sum)
                {
                    KEY = PART_ID;
                    TOTAL_TAT = items.Select(x => x.TOTAL_TAT).Sum();
                    WAIT_TAT = items.Select(x => x.WAIT_TAT).Sum();
                    RUN_TAT = items.Select(x => x.RUN_TAT).Sum();
                }

                if (finalize)
                {
                    TOTAL_TAT = Math.Round(TOTAL_TAT / 24.0, 3);
                    WAIT_TAT = Math.Round(WAIT_TAT / 24.0, 3);
                    RUN_TAT = Math.Round(RUN_TAT / 24.0, 3);
                }
            }

            internal void AccumulateSet(TATSet item)
            {
                TOTAL_TAT += item.TOTAL_TAT;
                RUN_TAT += item.RUN_TAT;
                WAIT_TAT += item.WAIT_TAT;
                MOVE_QTY += item.MOVE_QTY;
            }
        }

        class TATSeries
        {
            public string ARGUMENT { get; set; }
            public string DATA { get; set; }
            public double VALUE { get; set; }
        }

        #endregion
    }
}
