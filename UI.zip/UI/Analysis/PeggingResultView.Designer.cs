﻿namespace FabSimulatorUI.Analysis
{
    partial class PeggingResultView
    {
        /// <summary> 
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }
        #region 구성 요소 디자이너에서 생성한 코드

        /// <summary> 
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(PeggingResultView));
            DevExpress.XtraCharts.XYDiagram xyDiagram2 = new DevExpress.XtraCharts.XYDiagram();
            DevExpress.XtraCharts.Series series2 = new DevExpress.XtraCharts.Series();
            DevExpress.XtraCharts.SideBySideBarSeriesView sideBySideBarSeriesView2 = new DevExpress.XtraCharts.SideBySideBarSeriesView();
            repositoryItemPageNumberEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemPageNumberEdit();
            ribbonControl1 = new DevExpress.XtraBars.Ribbon.RibbonControl();
            buttonLoad = new DevExpress.XtraBars.BarButtonItem();
            editProduct = new DevExpress.XtraBars.BarEditItem();
            repositoryItemComboBox1 = new DevExpress.XtraEditors.Repository.RepositoryItemComboBox();
            editScale2 = new DevExpress.XtraBars.BarEditItem();
            repositoryItemSpinEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemSpinEdit();
            Space = new DevExpress.XtraBars.BarHeaderItem();
            btnLoad = new DevExpress.XtraBars.BarButtonItem();
            btnLoad2 = new DevExpress.XtraBars.BarButtonItem();
            ribbonPage1 = new DevExpress.XtraBars.Ribbon.RibbonPage();
            ribbonPageGroup1 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            ribbonPageGroup4 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            ribbonPageGroup5 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            ribbonPageGroup6 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            repositoryItemButtonEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit();
            dockManager1 = new DevExpress.XtraBars.Docking.DockManager(components);
            dockPanel1 = new DevExpress.XtraBars.Docking.DockPanel();
            dockPanel1_Container = new DevExpress.XtraBars.Docking.ControlContainer();
            gridControl1 = new DevExpress.XtraGrid.GridControl();
            gridView1 = new DevExpress.XtraGrid.Views.Grid.GridView();
            chartControl = new DevExpress.XtraCharts.ChartControl();
            ((System.ComponentModel.ISupportInitialize)repositoryItemPageNumberEdit1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)ribbonControl1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)repositoryItemComboBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)repositoryItemSpinEdit1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)repositoryItemButtonEdit1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dockManager1).BeginInit();
            dockPanel1.SuspendLayout();
            dockPanel1_Container.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)gridControl1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)gridView1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)chartControl).BeginInit();
            ((System.ComponentModel.ISupportInitialize)xyDiagram2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)series2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)sideBySideBarSeriesView2).BeginInit();
            SuspendLayout();
            // 
            // repositoryItemPageNumberEdit1
            // 
            repositoryItemPageNumberEdit1.AutoHeight = false;
            repositoryItemPageNumberEdit1.Mask.EditMask = "########;";
            repositoryItemPageNumberEdit1.Name = "repositoryItemPageNumberEdit1";
            // 
            // ribbonControl1
            // 
            ribbonControl1.ColorScheme = DevExpress.XtraBars.Ribbon.RibbonControlColorScheme.Blue;
            ribbonControl1.DrawGroupCaptions = DevExpress.Utils.DefaultBoolean.False;
            ribbonControl1.DrawGroupsBorderMode = DevExpress.Utils.DefaultBoolean.False;
            ribbonControl1.ExpandCollapseItem.Id = 0;
            ribbonControl1.Items.AddRange(new DevExpress.XtraBars.BarItem[] { ribbonControl1.ExpandCollapseItem, buttonLoad, editProduct, editScale2, Space, btnLoad, btnLoad2 });
            ribbonControl1.Location = new Point(0, 0);
            ribbonControl1.MaxItemId = 9;
            ribbonControl1.Name = "ribbonControl1";
            ribbonControl1.Pages.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPage[] { ribbonPage1 });
            ribbonControl1.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] { repositoryItemComboBox1, repositoryItemSpinEdit1, repositoryItemButtonEdit1 });
            ribbonControl1.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonControlStyle.OfficeUniversal;
            ribbonControl1.ShowApplicationButton = DevExpress.Utils.DefaultBoolean.False;
            ribbonControl1.ShowExpandCollapseButton = DevExpress.Utils.DefaultBoolean.True;
            ribbonControl1.Size = new Size(999, 54);
            ribbonControl1.ToolbarLocation = DevExpress.XtraBars.Ribbon.RibbonQuickAccessToolbarLocation.Hidden;
            // 
            // buttonLoad
            // 
            buttonLoad.Alignment = DevExpress.XtraBars.BarItemLinkAlignment.Left;
            buttonLoad.Caption = "Load";
            buttonLoad.Id = 1;
            buttonLoad.Name = "buttonLoad";
            buttonLoad.ItemClick += buttonLoad_ItemClick;
            // 
            // editProduct
            // 
            editProduct.Caption = "Product          ";
            editProduct.Edit = repositoryItemComboBox1;
            editProduct.EditWidth = 150;
            editProduct.Id = 3;
            editProduct.Name = "editProduct";
            // 
            // repositoryItemComboBox1
            // 
            repositoryItemComboBox1.Appearance.BackColor = Color.White;
            repositoryItemComboBox1.Appearance.BackColor2 = Color.White;
            repositoryItemComboBox1.Appearance.BorderColor = Color.White;
            repositoryItemComboBox1.Appearance.Options.UseBackColor = true;
            repositoryItemComboBox1.Appearance.Options.UseBorderColor = true;
            repositoryItemComboBox1.AutoHeight = false;
            repositoryItemComboBox1.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] { new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo) });
            repositoryItemComboBox1.Name = "repositoryItemComboBox1";
            // 
            // editScale2
            // 
            editScale2.Caption = "Scale_Collapsed                 ";
            editScale2.Edit = repositoryItemSpinEdit1;
            editScale2.EditWidth = 150;
            editScale2.Id = 5;
            editScale2.Name = "editScale2";
            editScale2.EditValueChanged += editScale2_EditValueChanged;
            // 
            // repositoryItemSpinEdit1
            // 
            repositoryItemSpinEdit1.Appearance.BackColor = Color.White;
            repositoryItemSpinEdit1.Appearance.BackColor2 = Color.White;
            repositoryItemSpinEdit1.Appearance.BorderColor = Color.White;
            repositoryItemSpinEdit1.Appearance.Options.UseBackColor = true;
            repositoryItemSpinEdit1.Appearance.Options.UseBorderColor = true;
            repositoryItemSpinEdit1.AutoHeight = false;
            repositoryItemSpinEdit1.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] { new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo) });
            repositoryItemSpinEdit1.Name = "repositoryItemSpinEdit1";
            // 
            // Space
            // 
            Space.Caption = "               ";
            Space.Id = 6;
            Space.Name = "Space";
            // 
            // btnLoad
            // 
            btnLoad.Caption = "Load";
            btnLoad.Id = 7;
            btnLoad.ImageOptions.Image = (Image)resources.GetObject("btnLoad.ImageOptions.Image");
            btnLoad.ImageOptions.LargeImage = (Image)resources.GetObject("btnLoad.ImageOptions.LargeImage");
            btnLoad.Name = "btnLoad";
            // 
            // btnLoad2
            // 
            btnLoad2.Caption = "Load";
            btnLoad2.Id = 8;
            btnLoad2.ImageOptions.Image = (Image)resources.GetObject("btnLoad2.ImageOptions.Image");
            btnLoad2.ImageOptions.LargeImage = (Image)resources.GetObject("btnLoad2.ImageOptions.LargeImage");
            btnLoad2.Name = "btnLoad2";
            btnLoad2.ItemClick += btnLoad2_ItemClick;
            // 
            // ribbonPage1
            // 
            ribbonPage1.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] { ribbonPageGroup1, ribbonPageGroup4, ribbonPageGroup5, ribbonPageGroup6 });
            ribbonPage1.ImageOptions.Image = (Image)resources.GetObject("ribbonPage1.ImageOptions.Image");
            ribbonPage1.Name = "ribbonPage1";
            // 
            // ribbonPageGroup1
            // 
            ribbonPageGroup1.ItemLinks.Add(editProduct);
            ribbonPageGroup1.Name = "ribbonPageGroup1";
            ribbonPageGroup1.Text = "ribbonPageGroup1";
            // 
            // ribbonPageGroup4
            // 
            ribbonPageGroup4.ItemLinks.Add(editScale2);
            ribbonPageGroup4.Name = "ribbonPageGroup4";
            ribbonPageGroup4.Text = "ribbonPageGroup4";
            // 
            // ribbonPageGroup5
            // 
            ribbonPageGroup5.ItemLinks.Add(Space);
            ribbonPageGroup5.Name = "ribbonPageGroup5";
            ribbonPageGroup5.Text = "ribbonPageGroup5";
            // 
            // ribbonPageGroup6
            // 
            ribbonPageGroup6.ItemLinks.Add(btnLoad2);
            ribbonPageGroup6.Name = "ribbonPageGroup6";
            ribbonPageGroup6.Text = "ribbonPageGroup6";
            // 
            // repositoryItemButtonEdit1
            // 
            repositoryItemButtonEdit1.AutoHeight = false;
            repositoryItemButtonEdit1.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] { new DevExpress.XtraEditors.Controls.EditorButton() });
            repositoryItemButtonEdit1.Name = "repositoryItemButtonEdit1";
            // 
            // dockManager1
            // 
            dockManager1.Form = this;
            dockManager1.RootPanels.AddRange(new DevExpress.XtraBars.Docking.DockPanel[] { dockPanel1 });
            dockManager1.TopZIndexControls.AddRange(new string[] { "DevExpress.XtraBars.BarDockControl", "DevExpress.XtraBars.StandaloneBarDockControl", "System.Windows.Forms.StatusBar", "System.Windows.Forms.MenuStrip", "System.Windows.Forms.StatusStrip", "DevExpress.XtraBars.Ribbon.RibbonStatusBar", "DevExpress.XtraBars.Ribbon.RibbonControl", "DevExpress.XtraBars.Navigation.OfficeNavigationBar", "DevExpress.XtraBars.Navigation.TileNavPane", "DevExpress.XtraBars.TabFormControl", "DevExpress.XtraBars.FluentDesignSystem.FluentDesignFormControl", "DevExpress.XtraBars.ToolbarForm.ToolbarFormControl" });
            // 
            // dockPanel1
            // 
            dockPanel1.Controls.Add(dockPanel1_Container);
            dockPanel1.Dock = DevExpress.XtraBars.Docking.DockingStyle.Bottom;
            dockPanel1.FloatVertical = true;
            dockPanel1.ID = new Guid("322ef22c-c0ee-4cbc-b58e-6faa2086829f");
            dockPanel1.Location = new Point(0, 470);
            dockPanel1.Name = "dockPanel1";
            dockPanel1.OriginalSize = new Size(999, 200);
            dockPanel1.Size = new Size(999, 200);
            dockPanel1.Text = "DataTable";
            // 
            // dockPanel1_Container
            // 
            dockPanel1_Container.Controls.Add(gridControl1);
            dockPanel1_Container.Location = new Point(3, 27);
            dockPanel1_Container.Name = "dockPanel1_Container";
            dockPanel1_Container.Size = new Size(993, 170);
            dockPanel1_Container.TabIndex = 0;
            // 
            // gridControl1
            // 
            gridControl1.Dock = DockStyle.Fill;
            gridControl1.Location = new Point(0, 0);
            gridControl1.MainView = gridView1;
            gridControl1.MenuManager = ribbonControl1;
            gridControl1.Name = "gridControl1";
            gridControl1.Size = new Size(993, 170);
            gridControl1.TabIndex = 9;
            gridControl1.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] { gridView1 });
            // 
            // gridView1
            // 
            gridView1.GridControl = gridControl1;
            gridView1.Name = "gridView1";
            // 
            // chartControl
            // 
            xyDiagram2.AxisX.Label.Angle = 90;
            xyDiagram2.AxisX.Label.ResolveOverlappingOptions.AllowHide = false;
            xyDiagram2.AxisX.ShowBehind = true;
            xyDiagram2.AxisX.VisibleInPanesSerializable = "-1";
            xyDiagram2.AxisY.VisibleInPanesSerializable = "-1";
            chartControl.Diagram = xyDiagram2;
            chartControl.Dock = DockStyle.Fill;
            chartControl.Legend.AlignmentHorizontal = DevExpress.XtraCharts.LegendAlignmentHorizontal.Center;
            chartControl.Legend.Border.Visibility = DevExpress.Utils.DefaultBoolean.False;
            chartControl.Legend.LegendID = -1;
            chartControl.Legend.MarkerMode = DevExpress.XtraCharts.LegendMarkerMode.None;
            chartControl.Legend.Name = "Default Legend";
            chartControl.Location = new Point(0, 54);
            chartControl.Name = "chartControl";
            series2.Name = "QTY";
            series2.SeriesID = 0;
            sideBySideBarSeriesView2.BarWidth = 0.2D;
            series2.View = sideBySideBarSeriesView2;
            chartControl.SeriesSerializable = new DevExpress.XtraCharts.Series[] { series2 };
            chartControl.Size = new Size(999, 416);
            chartControl.TabIndex = 7;
            // 
            // PeggingResultView
            // 
            AutoScaleDimensions = new SizeF(7F, 14F);
            AutoScaleMode = AutoScaleMode.Font;
            Controls.Add(chartControl);
            Controls.Add(dockPanel1);
            Controls.Add(ribbonControl1);
            Name = "PeggingResultView";
            Size = new Size(999, 670);
            ((System.ComponentModel.ISupportInitialize)repositoryItemPageNumberEdit1).EndInit();
            ((System.ComponentModel.ISupportInitialize)ribbonControl1).EndInit();
            ((System.ComponentModel.ISupportInitialize)repositoryItemComboBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)repositoryItemSpinEdit1).EndInit();
            ((System.ComponentModel.ISupportInitialize)repositoryItemButtonEdit1).EndInit();
            ((System.ComponentModel.ISupportInitialize)dockManager1).EndInit();
            dockPanel1.ResumeLayout(false);
            dockPanel1_Container.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)gridControl1).EndInit();
            ((System.ComponentModel.ISupportInitialize)gridView1).EndInit();
            ((System.ComponentModel.ISupportInitialize)xyDiagram2).EndInit();
            ((System.ComponentModel.ISupportInitialize)sideBySideBarSeriesView2).EndInit();
            ((System.ComponentModel.ISupportInitialize)series2).EndInit();
            ((System.ComponentModel.ISupportInitialize)chartControl).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DevExpress.XtraBars.Ribbon.RibbonControl ribbonControl1;
        private DevExpress.XtraBars.Ribbon.RibbonPage ribbonPage1;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup1;
        private DevExpress.XtraBars.Docking.DockManager dockManager1;
        private DevExpress.XtraBars.BarButtonItem buttonLoad;
        private DevExpress.XtraBars.BarEditItem editProduct;
        private DevExpress.XtraEditors.Repository.RepositoryItemComboBox repositoryItemComboBox1;
        private DevExpress.XtraEditors.Repository.RepositoryItemSpinEdit repositoryItemSpinEdit1;
        private DevExpress.XtraEditors.Repository.RepositoryItemPageNumberEdit repositoryItemPageNumberEdit1;
        private DevExpress.XtraCharts.ChartControl chartControl;
        private DevExpress.XtraBars.Docking.DockPanel dockPanel1;
        private DevExpress.XtraBars.Docking.ControlContainer dockPanel1_Container;
        private DevExpress.XtraGrid.GridControl gridControl1;
        private DevExpress.XtraGrid.Views.Grid.GridView gridView1;
        private DevExpress.XtraBars.BarEditItem editScale2;
        private DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit repositoryItemButtonEdit1;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup4;
        private DevExpress.XtraBars.BarHeaderItem Space;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup5;
        private DevExpress.XtraBars.BarButtonItem btnLoad;
        private DevExpress.XtraBars.BarButtonItem btnLoad2;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup6;
    }
}
