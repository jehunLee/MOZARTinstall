﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Mozart.Studio.TaskModel.UserInterface;
using Mozart.Studio.TaskModel.Projects;
using Mozart.Studio.Application;
using Mozart.Collections;
using DevExpress.XtraPivotGrid;
using DevExpress.XtraCharts;
using Mozart.Studio.UIComponents;
using Mozart.Studio.TaskModel.Utility;
using Mozart.Studio.TaskModel.UserLibrary; //linq2
using DevExpress.XtraEditors.Controls;// linq1
using FabSimulator;
using FabSimulatorUI.Common;

namespace FabSimulatorUI.Analysis
{
    public partial class StepWipTrendView : XtraPivotGridControlView
    {
        #region Variable&Property

        IExperimentResultItem result;

        /// <summary>   Context for the model data. </summary>
        ModelDataContext modelDataContext;
        /// <summary>   Context for the exponent data. </summary>
        ExpDataContext expDataContext;
        /// <summary>   True while initialization is in progress. </summary>
        bool initializing;
        bool loading;
        /// <summary>   The color generator. </summary>
        ColorGenerator colorGenerator = new ColorGenerator();

        /// <summary>   Full pathname of the layout file. </summary>
        string layoutPath;
        DayOfWeek startDayOfWeek;

        #endregion

        #region Ctor

        public StepWipTrendView(IServiceProvider serviceProvider)
            : base(serviceProvider)
        {
            InitializeComponent();

            this.initializing = true;
            this.ConstructInit();
        }

        protected override void LoadDocument()
        {
            this.LoadInit();
            this.initializing = false;

            this.loading = true;
            this.Query();
            this.loading = false;
        }

        protected override PivotGridControl GetPivotGrid()
        {
            return this.pivotGridControl;
        }

        protected override bool UpdateCommand(Command command)
        {
            bool handled = false;
            switch (command.CommandID)
            {
                case DataCommands.DataExportToExcel:
                    command.Enabled = true;
                    handled = true;
                    break;
            }

            if (handled) return true;
            return base.UpdateCommand(command);
        }

        protected override bool HandleCommand(Command command)
        {
            PivotGridControl gridView = this.pivotGridControl;

            bool handled = false;
            if (gridView != null)
            {
                switch (command.CommandID)
                {
                    case DataCommands.DataExportToExcel:
                        PivotGridExporter.ExportToExcel(gridView);
                        handled = true;
                        break;
                }
            }

            if (handled) return true;
            return base.HandleCommand(command);
        }

        #endregion

        #region Init

        private void ConstructInit()
        {
            this.pivotGridControl.OptionsChartDataSource.ProvideDataByColumns = false;
            this.pivotGridControl.OptionsChartDataSource.SelectionOnly = true;
            this.pivotGridControl.OptionsChartDataSource.ProvideColumnGrandTotals = false;
            this.pivotGridControl.OptionsChartDataSource.ProvideRowGrandTotals = false;

            this.pivotGridControl.OptionsChartDataSource.MaxAllowedPointCountInSeries = 0;
            this.pivotGridControl.OptionsBehavior.CopyToClipboardWithFieldValues = true;

            this.pivotGridControl.OptionsSelection.EnableAppearanceFocusedCell = false;

            this.chartProcProgress.Series.Clear();
            this.chartProcProgress.Titles[0].Visible = false;

            this.chartProcProgress.CrosshairOptions.ShowArgumentLine = false;
            this.chartProcProgress.DataSource = pivotGridControl;
        }

        private void LoadInit()
        {
            this.result = this.Document.GetResultItem();

            Globals.InitFactoryTime(this.result);

            this.modelDataContext = result.GetCtx<ModelDataContext>();
            this.expDataContext = result.GetCtx<ExpDataContext>();

            this.FillPeriod();

            this.result.ExpResults(this.resultCheckCtl);

            this.startDayOfWeek = ShopCalendar.StartWeek;

            this.SetPivotGridFields();

            this.layoutPath = System.IO.Path.Combine(this.GetService<IVsApplication>().ApplicationPath, "Layouts", "StepWipTrendView.xml");

            if (System.IO.File.Exists(this.layoutPath))
            {
                this.pivotGridControl.RestoreLayoutFromXml(this.layoutPath);
            }

            this.radioGroup1.SelectedIndex = 1;
            //var results = this.result.Experiment.Results.Select(p => p.Name).ToArray();
            //MozartUserInterface.Helper.NotifyEmptySchema(this.modelDataContext, this.expDataContext, results, Consts.Part, Consts.StepMove);
        }

        private void FillPeriod()
        {
            this.startDateTimePicker.Value = ShopCalendar.StartTimeOfDayT(this.result.StartTime);
            this.endDateTimePicker.Value = this.startDateTimePicker.Value.AddDays(this.result.GetPlanPeriodF(1));
        }

        #endregion 

        private void BindGrid()
        {
            using (var wc = new Mozart.Studio.UIComponents.WaitCursor())
            {
                this.pivotGridControl.DataSource = this.CalcuateTrend().ToBindingList();
            }
        }

        class TrendInfo
        {
            public string OPER_ID { get; set; }

            public string MFG_PRODUCT_ID { get; set; }

            public string AREA_ID { get; set; }

            public string RESULT { get; set; }

            public DateTime TargetDate { get; set; }

            public double VALUE { get; set; }

            public string TYPE { get; set; }
        }

        class ArrangeInfo
        {
            public string MFG_PRODUCT_ID { get; set; }
            public string OPER_ID { get; set; }
            public string RESOURCE_ID { get; set; }
            public string PARENT_RESOURCE_ID { get; set; }
            public string RECIPE_ID { get; set; }
            public string TOOLING_NAME { get; set; }
            public string SIM_TYPE { get; set; }
            public double UTILIZATION { get; set; }
            public double FLOW_TIME { get; set; }
            public double TACT_TIME { get; set; }
        }

        class SlopeInfo
        {
            ///
            /// <summary>   Gets or sets the group the step belongs to. </summary>
            ///
            /// <value> The step group. </value>
            ///
            public string STEP_GROUP { get; set; }

            ///
            /// <summary>   Gets or sets the target date. </summary>
            ///
            /// <value> The target date. </value>
            ///
            public string TargetDate { get; set; }

            ///
            /// <summary>   Gets or sets the slope value. </summary>
            ///
            /// <value> The slope value. </value>
            ///
            public double SLOPE_VALUE { get; set; }
        }

        class WipInfo
        {
            ///
            /// <summary>   Gets or sets the target date. </summary>
            ///
            /// <value> The target date. </value>
            ///
            public DateTime TargetDate { get; set; }

            ///
            /// <summary>   Gets or sets the WIP qty. </summary>
            ///
            /// <value> The WIP qty. </value>
            ///
            public double WipQty { get; set; }
        }

        private IEnumerable<TrendInfo> CalcuateTrend()
        {
            var results = this.resultCheckCtl.Properties.Items.GetCheckedValues().Select(x => x.ToString()).ToArray();
            if (results == null || results.Length == 0)
                return Enumerable.Empty<TrendInfo>();

            return results.SelectMany(name => CalcuateTrend(name));
        }

        private IEnumerable<TrendInfo> CalcuateTrend(string name)
        {
            var rslt = this.expDataContext.Result(name);

            var radioIndex = this.radioGroup1.SelectedIndex;

            var startTime = FabSimulatorUI.Helper.GetIntervalStartDate(this.startDateTimePicker.Value, radioIndex);
            var endTime = FabSimulatorUI.Helper.GetIntervalEndDate(this.endDateTimePicker.Value, radioIndex);

            //var part = this.modelDataContext.Part;
            var stepWip = rslt.STEP_WIP.Where(x => x.TARGET_DATE >= startTime && x.TARGET_DATE <= endTime).ToList();
            var stepMove = rslt.STEP_MOVE.Where(x => x.TARGET_DATE >= startTime && x.TARGET_DATE <= endTime).ToList();

            int minEoh = (int)this.minEohspinEdit.Value;
            DateTime lastDate = (from s in stepWip
                                 select new { s.TARGET_DATE }).Distinct().OrderByDescending(x => x.TARGET_DATE).FirstOrDefault().TARGET_DATE;

            //var query = stepWip.Join(part,
            //        s => new { s.MfgFacilityId, s.MfgPartCode },
            //        p => new { p.MfgFacilityId, p.MfgPartCode },
            //        (s, p) => new TrendInfo
            //        {
            //            RESULT = name,
            //            STEP_GROUP = s.StepName,
            //            DesignId = p.DesignId,
            //            TechNode = p.TechNode,
            //            MfgAreaId = s.MfgAreaId,
            //            WSGroup = s.WorkstationGroup,
            //            TargetDate = s.TargetDate,
            //            VALUE = s.TotalWaferQty
            //        });


            var q1 = from s in stepWip
                     select new TrendInfo
                     {
                         RESULT = name,
                         OPER_ID = s.STEP_ID,
                         MFG_PRODUCT_ID = s.PART_ID,
                         AREA_ID = s.AREA_ID,
                         TargetDate = s.TARGET_DATE,
                         VALUE = s.TOTAL_QTY,
                         TYPE = "WIP"
                     };

            var q2 = from s in stepMove
                     select new TrendInfo
                     {
                         RESULT = name,
                         OPER_ID = s.STEP_ID,
                         MFG_PRODUCT_ID = s.PART_ID,
                         AREA_ID = s.AREA_ID,
                         TargetDate = s.TARGET_DATE,
                         VALUE = s.MOVE_QTY,
                         TYPE = "MOVE"
                     };

            var query = q1.Concat(q2);

            if (minEoh > 0)
            {
                var list = (from q in q1.Where(x => x.TargetDate.Equals(lastDate) && x.VALUE >= minEoh)
                            select new { q.RESULT, q.MFG_PRODUCT_ID, q.OPER_ID }).ToArray();

                var filtered = from q in query.Where(x => list.Contains(new { x.RESULT, x.MFG_PRODUCT_ID, x.OPER_ID }))
                               select q;

                return filtered;
            }

            return query;
        }

        private void SetPivotGridFields()
        {
            this.pivotGridControl.DataSource = null;
            this.pivotGridControl.Fields.Clear();

            var f3a = this.pivotGridControl.AddFieldRowArea<TrendInfo>((c) => c.MFG_PRODUCT_ID);
            f3a.Caption = "MFG_PRODUCT_ID";
            var f1 = this.pivotGridControl.AddFieldRowArea<TrendInfo>((c) => c.OPER_ID);
            //f1.Width = 300;
            f1.Caption = "OPER_ID";

            var f2 = this.pivotGridControl.AddFieldRowArea<TrendInfo>((c) => c.RESULT);
            var f2b = this.pivotGridControl.AddFieldRowArea<TrendInfo>((c) => c.TYPE);

            var f3b = this.pivotGridControl.AddFieldPivotArea<TrendInfo>((c) => c.AREA_ID, PivotArea.FilterArea);

            var f4 = this.pivotGridControl.AddFieldColumnArea<TrendInfo>((c) => c.TargetDate, PivotGroupInterval.Custom);
            f4.SortMode = PivotSortMode.Custom;

            var f5 = this.pivotGridControl.AddFieldDataArea<TrendInfo>((c) => c.VALUE);
            f5.CellFormat.FormatString = Consts.Mask_Qty_1;
            f5.ValueFormat.FormatString = Consts.Mask_Qty_1;
            f5.SummaryType = DevExpress.Data.PivotGrid.PivotSummaryType.Custom;

            this.pivotGridControl.OptionsView.ShowColumnGrandTotals = false;

            f1.SortBySummaryInfo.Conditions.Clear();
            f1.SortBySummaryInfo.Field = f5;
            f1.SortOrder = PivotSortOrder.Descending;
            f3a.SortBySummaryInfo.Conditions.Clear();
            f3a.SortBySummaryInfo.Field = f5;
            f3a.SortOrder = PivotSortOrder.Descending;
            f3b.SortBySummaryInfo.Conditions.Clear();
            f3b.SortBySummaryInfo.Field = f5;
            f3b.SortOrder = PivotSortOrder.Descending;
        }

        private void btnQuery_Click(object sender, EventArgs e)
        {
            this.Query();
        }

        protected void pivotGridControl_CustomGroupInterval(object sender, PivotCustomGroupIntervalEventArgs e)
        {
            if (this.initializing)
                return;

            if (e.Field.Caption == "DATE1")
            {
                var targetDate = (DateTime)e.Value;
                var year = targetDate.Year;

                if (this.radioGroup1.SelectedIndex == 1)
                {
                    var targetWeek = FabSimulatorUI.Helper.GetTargetWeek(targetDate, this.startDayOfWeek);
                    if (targetWeek == 52 && targetDate.Month == 1)
                        year--;
                }

                e.GroupValue = year;
            }

            if (e.Field.Caption == "DATE2")
            {
                // SetPivotGridFields 에서 미리 세팅하도록 변경.
                //e.Field.SortMode = PivotSortMode.Custom;

                var targetDate = (DateTime)e.Value;

                if (this.radioGroup1.SelectedIndex == 0)
                {
                    e.GroupValue = "MONTH " + targetDate.Month;
                }
                else if (this.radioGroup1.SelectedIndex == 1)
                {
                    e.GroupValue = "WEEK " + FabSimulatorUI.Helper.GetTargetWeek(targetDate, this.startDayOfWeek);
                }
                else
                {
                    e.GroupValue = ((DateTime)e.Value).ToString("MM-dd");
                }
            }
        }

        private void Query()
        {
            this.BindGrid();

            this.pivotGridControl.BestFit();
        }

        private void resultCheckCtl_TextChanged(object sender, EventArgs e)
        {
            if (this.initializing)
                return;

            this.Query();
        }

        private void pivotGridControl_CustomChartDataSourceData(object sender, PivotCustomChartDataSourceDataEventArgs e)
        {
            if (e.ItemType == PivotChartItemType.CellItem)
            {
                if (e.Value.ToString() == string.Empty)
                    e.Value = 0;
            }
        }

        private void chartProcProgress_CustomDrawAxisLabel(object sender, CustomDrawAxisLabelEventArgs e)
        {
            var value = e.Item.AxisValue.ToString();
            if (value.IndexOf('|') < 0)
                return;

            var hour = value.Split('|')[1];
            e.Item.Text = hour;
        }

        private void pivotGridControl_CustomFieldSort(object sender, PivotGridCustomFieldSortEventArgs e)
        {
            if (e.Field.Caption == "DATE2")
            {
                if (e.Value1 == null || e.Value2 == null)
                    return;

                e.Handled = true;

                string x = e.Value1.ToString();
                string y = e.Value2.ToString();

                string[] s1 = x.Split(' ');
                string[] s2 = y.Split(' ');
                var weekOrMonth1 = s1.Last();
                var weekOrMonth2 = s2.Last();

                if (s1.Length == 2)
                {
                    e.Result = Convert.ToInt32(weekOrMonth1).CompareTo(Convert.ToInt32(weekOrMonth2));
                }
                else
                {
                    e.Result = weekOrMonth1.CompareTo(weekOrMonth2);
                }
            }
        }

        private void saveLayoutBtn_Click(object sender, EventArgs e)
        {
            string dircetory = System.IO.Path.Combine(this.GetService<IVsApplication>().ApplicationPath, "Layouts");
            System.IO.DirectoryInfo di = new System.IO.DirectoryInfo(dircetory);

            if (di.Exists == false)
            {
                System.IO.Directory.CreateDirectory(dircetory);
            }

            this.pivotGridControl.SaveLayoutToXml(this.layoutPath);
        }

        private void ChartProcProgress_BoundDataChanged(object sender, EventArgs e)
        {
            var series = ((ChartControl)sender).Series.Where(x => x.Name.Contains("WIP"));
            foreach (Series s in series)
            {
                s.ChangeView(ViewType.StackedBar);

                StackedBarSeriesView view = (StackedBarSeriesView)s.View;
                view.Transparency = 160;
            }

            //var s1 = ((ChartControl)sender).Series.Where(x=> x.Name.Contains("WIP")).FirstOrDefault() as Series;
            //var s2 = ((ChartControl)sender).Series.Where(x => x.Name.Contains("MOVE")).FirstOrDefault() as Series;

            //if (s1 != null)
            //    s1.ChangeView(ViewType.Bar);
        }

        private void PivotGridControl_CellSelectionChanged(object sender, EventArgs e)
        {
            var height = pivotGridControl.Cells.Selection.Height;
            if (height == 0)
            {
                gridControl1.DataSource = null;
                return;
            }

            string mfgProdID = null;
            string operID = null;

            var firstCell = pivotGridControl.Cells.MultiSelection.SelectedCells.First();
            var lastCell = pivotGridControl.Cells.MultiSelection.SelectedCells.Last();

            foreach (PivotGridField rowField in pivotGridControl.GetFieldsByArea(PivotArea.RowArea))
            {
                string rowValue = pivotGridControl.GetFieldValue(rowField, firstCell.Y)?.ToString();
                string rowValue2 = pivotGridControl.GetFieldValue(rowField, lastCell.Y)?.ToString();

                if (rowField.Caption == "OPER_ID")
                {
                    if (rowValue != rowValue2)
                    {
                        gridControl1.DataSource = null;
                        return;
                    }

                    operID = rowValue;
                }
                else if (rowField.Caption == "MFG_PRODUCT_ID")
                {
                    if (rowValue != rowValue2)
                    {
                        gridControl1.DataSource = null;
                        return;
                    }

                    mfgProdID = rowValue;
                }
            }

            if (operID == null)
            {
                gridControl1.DataSource = null;
                return;
            }

            FillArrangeDetail(mfgProdID, operID);
        }

        private void FillArrangeDetail(string mfgProdID, string operID)
        {
            var arr = this.modelDataContext.ARRANGE;
            var eqp = this.modelDataContext.EQP;
            var stepTime = this.modelDataContext.STEP_TIME;

            var resultName = this.resultCheckCtl.Properties.Items.GetCheckedValues().Select(x => x.ToString()).First();
            var rslt = this.expDataContext.Result(resultName);
            var altStepTimeLog = rslt.ERROR_LOG.Where(x => x.CATEGORY == "AltStepTime");

            List<ArrangeInfo> detail = new List<ArrangeInfo>();

            var q0 = from a in arr.Where(x => x.STEP_ID == operID)
                     join b in eqp on a.EQP_ID equals b.EQP_ID
                     let EQP_ID = string.IsNullOrEmpty(b.PARENT_EQP_ID) ? a.EQP_ID : b.PARENT_EQP_ID
                     join c in stepTime on new { a.PART_ID, a.STEP_ID, EQP_ID } equals new { c.PART_ID, c.STEP_ID, c.EQP_ID } into outer
                     join d in altStepTimeLog on new { EQP_ID, a.RECIPE_ID, a.STEP_ID } equals new { d.EQP_ID, d.RECIPE_ID, d.STEP_ID } into outer2
                     from o in outer.DefaultIfEmpty()
                     from o2 in outer2.DefaultIfEmpty()
                     select new
                     {
                         a.PART_ID,
                         a.STEP_ID,
                         a.EQP_ID,
                         b.PARENT_EQP_ID,
                         a.RECIPE_ID,
                         a.TOOLING_NAME,
                         b.SIM_TYPE,
                         b.UTILIZATION,
                         FLOW_TIME = o != null ? o.FLOW_TIME : 0,
                         TACT_TIME = o != null ? o.TACT_TIME : 0,
                         ALT_REASON = o == null && o2 != null ? o2.REASON : null
                     };

            foreach (var item in q0)
            {
                if (mfgProdID != null && item.PART_ID != mfgProdID)
                    continue;

                if (item.SIM_TYPE == "ParallelChamber" && string.IsNullOrEmpty(item.PARENT_EQP_ID))
                    continue;

                ArrangeInfo info = new ArrangeInfo();
                info.MFG_PRODUCT_ID = item.PART_ID;
                info.OPER_ID = item.STEP_ID;
                info.RESOURCE_ID = item.EQP_ID;
                info.PARENT_RESOURCE_ID = item.PARENT_EQP_ID;
                info.RECIPE_ID = item.RECIPE_ID;
                info.TOOLING_NAME = item.TOOLING_NAME;
                info.SIM_TYPE = item.SIM_TYPE;
                info.UTILIZATION = Math.Round(item.UTILIZATION, 2);
                info.FLOW_TIME = Math.Round(item.FLOW_TIME, 2);
                info.TACT_TIME = Math.Round(item.TACT_TIME, 2);

                if (item.ALT_REASON != null)
                {
                    var split = item.ALT_REASON.Split(',');

                    foreach (var str in split)
                    {
                        var index = str.IndexOf('=');
                        if (double.TryParse(str.Substring(index + 1, str.Length - index - 1), out double value))
                        {
                            if (str.Contains("Flow"))
                                info.FLOW_TIME = value;
                            else if (str.Contains("Tact"))
                                info.TACT_TIME = value;
                        }
                    }
                }

                detail.Add(info);
            }

            //result = mfgProdID == null ? q1 : q1.Where(x => x.MFG_PRODUCT_ID == mfgProdID);

            gridControl1.DataSource = detail.ToBindingList();
        }

        private void PivotGridControl_CustomCellDisplayText(object sender, PivotCellDisplayTextEventArgs e)
        {
            if (e.DisplayText == string.Empty)
            {
                e.DisplayText = "0";
            }
        }

        private void StartDateTimePicker_ValueChanged(object sender, EventArgs e)
        {
            if (this.initializing)
                return;

            this.endDateTimePicker.Value = this.startDateTimePicker.Value.AddMonths(1);
        }

        private void radioGroup1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (this.initializing)
                return;

            this.Query();
        }

        private void pivotGridControl_CustomSummary(object sender, PivotGridCustomSummaryEventArgs e)
        {
            var resultField = (sender as PivotGridControl).Fields.GetFieldByName("field_RESULT");

            if (resultField.Area == PivotArea.FilterArea)
            {
                e.CustomValue = Math.Round((decimal)e.SummaryValue.Summary / (decimal)this.resultCheckCtl.Properties.Items.GetCheckedValues().Count, 3);
            }
            else
            {
                e.CustomValue = e.SummaryValue.Summary;
            }
        }
    }
}
