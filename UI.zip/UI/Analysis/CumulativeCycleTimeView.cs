﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Mozart.Studio.TaskModel.UserInterface;
using Mozart.Studio.TaskModel.Projects;
using Mozart.Studio.Application;
using DevExpress.XtraEditors.Controls;
using DevExpress.XtraCharts;
using DevExpress.XtraTab;

using FabSimulator;
using Mozart.Data.Entity;
using Mozart.Mapping;

// for export excel; temporarily
using Mozart.Studio.UIComponents;
using Mozart.Studio.TaskModel.Utility;

using Mozart.Studio.TaskModel.UserLibrary;
using DevExpress.XtraGrid.Columns;
using DevExpress.XtraGrid.Views.Grid;
using DevExpress.XtraGrid.Views.BandedGrid;
using FabSimulator.Outputs;
using FabSimulatorUI.Common;
using Mozart.Extensions;
using DevExpress.XtraTreeList.Nodes;

namespace FabSimulatorUI.Analysis
{
    public partial class CumulatvieCycleTimeView : XtraGridControlView
    {
        #region Variable&Property

        IExperimentResultItem result;

        ModelDataContext modelDataContext;
        ExpDataContext expDataContext;
        bool initializing;
        bool loading;

        #endregion

        #region Ctor

        public CumulatvieCycleTimeView(IServiceProvider serviceProvider)
            : base(serviceProvider)
        {
            InitializeComponent();

            this.initializing = true;
        }

        protected override void LoadDocument()
        {
            this.LoadInit();
            this.initializing = false;

            this.loading = true;
            this.Query();
            this.loading = false;
        }

        #endregion

        #region Init

        private void LoadInit()
        {
            this.result = this.Document.GetResultItem();

            Globals.InitFactoryTime(this.result);

            this.result.ExpResults(this.resultCheckCtl);

            this.modelDataContext = result.GetCtx<ModelDataContext>();
            this.expDataContext = result.GetCtx<ExpDataContext>();

            this.FillPeriod();

            this.radioGroup1.SelectedIndex = 1;

            SetEqpGroupCheckedCombobox();

            CreateTreeListColumns();
        }

        private void SetEqpGroupCheckedCombobox()
        {
            this.eqpGroupCheckedComboboxEdit.Properties.Items.Add("NXE");
            this.eqpGroupCheckedComboboxEdit.Properties.Items.Add("NXT");
            this.eqpGroupCheckedComboboxEdit.Properties.Items.Add("XT");
            this.eqpGroupCheckedComboboxEdit.CheckAll();
        }

        private void CreateTreeListColumns()
        {
            var tl = this.treeList1;

            tl.BeginUpdate();

            var col1 = tl.Columns.Add();
            col1.FieldName = "Parts";
            col1.Caption = "PartGroup";
            col1.VisibleIndex = 0;

            tl.EndUpdate();
        }

        #endregion

        #region Query&Bind

        private void Query()
        {
            using (var wc = new Mozart.Studio.UIComponents.WaitCursor())
            {
                this.BindBegin();
                this.BindDo();
                this.BindEnd();
            }
        }

        private void BindBegin()
        {
            chartControl1.CrosshairOptions.GroupHeaderPattern = "{A:F0}";
        }

        private void BindEnd()
        {
        }

        private void BindDo()
        {
            this.Calculate();
        }
        #endregion

        private void FillPeriod()
        {
            this.startDateTimePicker.Value = ShopCalendar.StartTimeOfDayT(this.result.StartTime);
            this.endDateTimePicker.Value = this.startDateTimePicker.Value.AddDays(this.result.GetPlanPeriodF(1));
        }

        private void Calculate()
        {
            var results = this.resultCheckCtl.Properties.Items.GetCheckedValues().Select(x => x.ToString()).ToArray();
            if (results == null || results.Length == 0)
                return;

            var radioIndex = this.radioGroup1.SelectedIndex;

            var startTime = FabSimulatorUI.Helper.GetIntervalStartDate(this.startDateTimePicker.Value, radioIndex);
            var endTime = FabSimulatorUI.Helper.GetIntervalEndDate(this.endDateTimePicker.Value, radioIndex);

            if (startTime >= endTime)
                MessageBox.Show("invalid period");

            List<LayerCTInfo> layerCTResults = new List<LayerCTInfo>();
            foreach (var resultName in results)
            {
                IEnumerable<LayerCTInfo> resultOutput = GetLayerCTInfo(startTime, endTime, resultName);

                layerCTResults.AddRange(resultOutput);
            }

            var partCT = from a in layerCTResults
                         group a by new { a.PART_GROUP, a.PART_ID, a.LAYER_ID } into g
                         let ctAvg = Math.Round(g.GroupBy(x => x.RESULT).Average(x => x.Select(x => x.CUM_CT).Average()), 3)
                         select new LayerCTSeries
                         {
                             ARGUMENT = g.Key.LAYER_ID,
                             DATA = g.Key.PART_GROUP + "@" + g.Key.PART_ID,
                             VALUE = ctAvg
                         };

            var ds = partCT.ToBindingList();

            this.chartControl1.Series.Clear();
            this.chartControl1.DataSource = ds;
            this.chartControl1.SeriesTemplate.SeriesDataMember = "DATA";
            this.chartControl1.SeriesTemplate.ArgumentDataMember = "ARGUMENT";
            this.chartControl1.SeriesTemplate.ValueDataMembers.AddRange("VALUE");

            CreatePartGroupLegends(layerCTResults);

            CreateTreeListNodes(layerCTResults);
        }

        private void CreatePartGroupLegends(List<LayerCTInfo> layerCTResults)
        {
            foreach (var partGroup in layerCTResults.Select(x => x.PART_GROUP).Distinct())
            {
                Legend legend = new Legend(partGroup);
                legend.AlignmentVertical = LegendAlignmentVertical.Top;
                legend.AlignmentHorizontal = LegendAlignmentHorizontal.RightOutside;

                legend.Title.Text = partGroup;
                legend.Title.Visible = true;
                legend.MarkerMode = LegendMarkerMode.CheckBox;

                this.chartControl1.Legends.Add(legend);
            }
        }

        private void CreateTreeListNodes(List<LayerCTInfo> layerCTResults)
        {
            var tl = this.treeList1;
            tl.ClearNodes();

            tl.OptionsView.CheckBoxStyle = DevExpress.XtraTreeList.DefaultNodeCheckBoxStyle.Check;
            tl.OptionsBehavior.Editable = false;

            tl.BeginUnboundLoad();

            TreeListNode parentForRootNodes = null;
            tl.AppendNode(new object[] { "(Select All)" }, parentForRootNodes);

            foreach (var partGroup in layerCTResults.GroupBy(x => x.PART_GROUP))
            {
                TreeListNode rootNode = tl.AppendNode(new object[] { partGroup.Key }, parentForRootNodes);

                foreach (var partID in partGroup.Select(x => x.PART_ID).Distinct())
                {
                    tl.AppendNode(new object[] { partID }, rootNode);
                }
            }
            tl.CheckAll();
            tl.ExpandAll();

            tl.EndUnboundLoad();
        }

        private IEnumerable<LayerCTInfo> GetLayerCTInfo(DateTime startTime, DateTime endTime, string resultName)
        {
            var result = this.expDataContext.Result(resultName);

            var checkedEqpGroup = this.eqpGroupCheckedComboboxEdit.Properties.Items.GetCheckedValues().Select(x => x.ToString()).ToArray();

            IEnumerable<LayerCTInfo> resultOutput;
            if (result.SUMMARY_LAYER_CT2.IsNullOrEmpty() == false)
            {
                resultOutput = from a in result.SUMMARY_LAYER_CT2.Where(x => x.TARGET_DATE >= startTime && x.TARGET_DATE <= endTime && checkedEqpGroup.Contains(x.EQP_GROUP))
                               select new LayerCTInfo
                               {
                                   RESULT = resultName,
                                   TARGET_DATE = a.TARGET_DATE,
                                   TARGET_WEEK = FabSimulatorUI.Helper.GetTargetWeek(a.TARGET_DATE, ShopCalendar.StartWeek),
                                   PART_GROUP = a.PART_GROUP,
                                   PART_ID = a.PART_ID,
                                   LAYER_ID = a.LAYER_ID,
                                   EQP_GROUP = a.EQP_GROUP,
                                   CUM_CT = a.CUM_CT / 24.0
                               };
            }
            else
            {
                // SUMMARY_LAYER_CT2 데이터가 없으면 SUMMARY_LAYER_CT 데이터를 사용
                resultOutput = from a in result.SUMMARY_LAYER_CT.Where(x => checkedEqpGroup.Contains(x.EQP_GROUP))
                               select new LayerCTInfo
                               {
                                   RESULT = resultName,
                                   TARGET_DATE = startTime, // 전체 구간 데이터이며, startTime으로 대표.
                                   TARGET_WEEK = FabSimulatorUI.Helper.GetTargetWeek(startTime, ShopCalendar.StartWeek),
                                   PART_GROUP = a.PART_GROUP,
                                   PART_ID = a.PART_ID,
                                   LAYER_ID = a.LAYER_ID,
                                   EQP_GROUP = a.EQP_GROUP,
                                   CUM_CT = a.CUM_CT / 24.0
                               };
            }

            return resultOutput.OrderBy(x => x.PART_GROUP).ThenBy(x => x.PART_ID).ToList();
        }

        #region Events
        private void btnQuery_Click(object sender, EventArgs e)
        {
            this.Query();
        }

        private void ChartControl1_BoundDataChanged(object sender, EventArgs e)
        {
            var series = ((ChartControl)sender).Series;
            foreach (Series s in series)
            {
                s.ChangeView(ViewType.Line);

                SetLegendGroup(s);

                //StackedBarSeriesView view = (StackedBarSeriesView)s.View;
                //view.Transparency = 160;
            }

            void SetLegendGroup(Series s)
            {
                var split = s.Name.Split('@');
                var partGroup = split.First();
                var partID = split.Last();

                if (this.chartControl1.Legends.Select(x => x.Name).Contains(partGroup))
                {
                    s.Name = partID;
                    s.Legend = this.chartControl1.Legends[partGroup];
                    s.Legend.Visibility = DevExpress.Utils.DefaultBoolean.False;
                }
            }
        }

        private void radioGroup1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (this.initializing)
                return;

            this.Query();
        }

        private void startDateTimePicker_ValueChanged(object sender, EventArgs e)
        {
            if (this.initializing)
                return;

            this.endDateTimePicker.Value = this.startDateTimePicker.Value.AddMonths(1);
        }

        private void resultCheckCtl_EditValueChanged(object sender, EventArgs e)
        {
            if (this.initializing)
                return;

            this.Query();
        }

        private void chartControl1_MouseClick(object sender, MouseEventArgs e)
        {
            var hi = chartControl1.CalcHitInfo(e.X, e.Y);
            var series = hi.Series as Series;
            if (series != null)
            {
                this.chartControl1.Series.ForEach(x => (x as SeriesBase).CheckedInLegend = false);
                this.treeList1.UncheckAll();

                // 선택된 series만 check
                hi.Series.CheckedInLegend = true;

                var parent = this.treeList1.Nodes.Where(x => x.GetDisplayText("Parts") == series.Legend.Name).First();
                var node = parent.Nodes.Where(x => x.GetDisplayText("Parts") == series.Name).First();

                parent.Expand();
                node.CheckAll();

                var bros = parent.Nodes;
                if (bros.Count == 1)
                    parent.CheckAll();
            }
        }

        private void treeList1_AfterCheckNode(object sender, DevExpress.XtraTreeList.NodeEventArgs e)
        {
            var node = e.Node;
            var parent = node.ParentNode;

            var series = this.chartControl1.Series;

            if (node.HasChildren)
            {
                if (node.Checked)
                    node.CheckAll();
                else
                    node.UncheckAll();

                foreach (Series s in series)
                {
                    if (s.Legend == null)
                        continue;

                    if (s.Legend.Name.StartsWith(node.GetDisplayText("Parts")))
                        s.CheckedInLegend = node.Checked;
                }
            }
            else if (parent == null) // (Select All)
            {
                if (node.Checked)
                    this.treeList1.CheckAll();
                else
                    this.treeList1.UncheckAll();

                series.ForEach(x => (x as SeriesBase).CheckedInLegend = node.Checked);
            }
            else
            {
                var bros = parent.Nodes;
                if (bros.All(x => x.Checked))
                    node.ParentNode.CheckAll();
                else
                    parent.Checked = false; // 코드에서 세팅하면 AfterCheckNode Event Handler가 호출되지는 않음.

                foreach (Series s in series)
                {
                    if (s.Legend == null)
                        continue;

                    if (s.Name.StartsWith(node.GetDisplayText("Parts")))
                        s.CheckedInLegend = node.Checked;
                }
            }
        }

        private void splitContainerControl1_SizeChanged(object sender, EventArgs e)
        {
            this.splitContainerControl1.SplitterPosition = (int)(this.splitContainerControl1.Width * 0.75);
        }
        #endregion

        #region Inner Class

        class LayerCTInfo
        {
            public string RESULT { get; set; }
            public DateTime TARGET_DATE { get; set; }
            public int TARGET_WEEK { get; set; }
            public string PART_GROUP { get; set; }
            public string PART_ID { get; set; }
            public int LAYER_ID { get; set; }
            public string EQP_GROUP { get; set; }
            public double CUM_CT { get; set; }
        }
        class LayerCTSeries
        {
            public int ARGUMENT { get; set; }
            public string DATA { get; set; }
            public double VALUE { get; set; }
        }
        #endregion
    }
}
