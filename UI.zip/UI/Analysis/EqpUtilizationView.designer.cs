﻿namespace FabSimulatorUI.Analysis
{
    partial class EqpUtilizationView
    {
        /// <summary> 
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 구성 요소 디자이너에서 생성한 코드

        /// <summary> 
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>        
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            panelControl1 = new DevExpress.XtraEditors.PanelControl();
            splitContainerControl1 = new DevExpress.XtraEditors.SplitContainerControl();
            gridControl1 = new DevExpress.XtraGrid.GridControl();
            bandedGridView1 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridView();
            gridBand1 = new DevExpress.XtraGrid.Views.BandedGrid.GridBand();
            xtraTabControl1 = new DevExpress.XtraTab.XtraTabControl();
            xtraTabPage1 = new DevExpress.XtraTab.XtraTabPage();
            chartControl1 = new DevExpress.XtraCharts.ChartControl();
            xtraTabPage2 = new DevExpress.XtraTab.XtraTabPage();
            chartControl2 = new DevExpress.XtraCharts.ChartControl();
            dockManager1 = new DevExpress.XtraBars.Docking.DockManager(components);
            ((System.ComponentModel.ISupportInitialize)panelControl1).BeginInit();
            panelControl1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)splitContainerControl1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)splitContainerControl1.Panel1).BeginInit();
            splitContainerControl1.Panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)splitContainerControl1.Panel2).BeginInit();
            splitContainerControl1.Panel2.SuspendLayout();
            splitContainerControl1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)gridControl1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)bandedGridView1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)xtraTabControl1).BeginInit();
            xtraTabControl1.SuspendLayout();
            xtraTabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)chartControl1).BeginInit();
            xtraTabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)chartControl2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dockManager1).BeginInit();
            SuspendLayout();
            // 
            // panelControl1
            // 
            panelControl1.Controls.Add(splitContainerControl1);
            panelControl1.Dock = DockStyle.Fill;
            panelControl1.Location = new Point(0, 0);
            panelControl1.Name = "panelControl1";
            panelControl1.Size = new Size(1098, 650);
            panelControl1.TabIndex = 0;
            // 
            // splitContainerControl1
            // 
            splitContainerControl1.Dock = DockStyle.Fill;
            splitContainerControl1.Horizontal = false;
            splitContainerControl1.Location = new Point(2, 2);
            splitContainerControl1.Name = "splitContainerControl1";
            // 
            // splitContainerControl1.Panel1
            // 
            splitContainerControl1.Panel1.Controls.Add(gridControl1);
            splitContainerControl1.Panel1.Text = "Panel1";
            // 
            // splitContainerControl1.Panel2
            // 
            splitContainerControl1.Panel2.Controls.Add(xtraTabControl1);
            splitContainerControl1.Panel2.Text = "Panel2";
            splitContainerControl1.Size = new Size(1094, 646);
            splitContainerControl1.SplitterPosition = 363;
            splitContainerControl1.TabIndex = 2;
            // 
            // gridControl1
            // 
            gridControl1.Dock = DockStyle.Fill;
            gridControl1.Location = new Point(0, 0);
            gridControl1.MainView = bandedGridView1;
            gridControl1.Name = "gridControl1";
            gridControl1.Size = new Size(1094, 363);
            gridControl1.TabIndex = 1;
            gridControl1.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] { bandedGridView1 });
            // 
            // bandedGridView1
            // 
            bandedGridView1.Bands.AddRange(new DevExpress.XtraGrid.Views.BandedGrid.GridBand[] { gridBand1 });
            bandedGridView1.DetailHeight = 377;
            bandedGridView1.GridControl = gridControl1;
            bandedGridView1.Name = "bandedGridView1";
            bandedGridView1.RowStyle += bandedGridView1_RowStyle;
            // 
            // gridBand1
            // 
            gridBand1.Caption = "gridBand1";
            gridBand1.MinWidth = 12;
            gridBand1.Name = "gridBand1";
            gridBand1.VisibleIndex = 0;
            gridBand1.Width = 82;
            // 
            // xtraTabControl1
            // 
            xtraTabControl1.Dock = DockStyle.Fill;
            xtraTabControl1.Location = new Point(0, 0);
            xtraTabControl1.Name = "xtraTabControl1";
            xtraTabControl1.SelectedTabPage = xtraTabPage1;
            xtraTabControl1.Size = new Size(1094, 273);
            xtraTabControl1.TabIndex = 0;
            xtraTabControl1.TabPages.AddRange(new DevExpress.XtraTab.XtraTabPage[] { xtraTabPage1, xtraTabPage2 });
            // 
            // xtraTabPage1
            // 
            xtraTabPage1.Controls.Add(chartControl1);
            xtraTabPage1.Name = "xtraTabPage1";
            xtraTabPage1.Size = new Size(1092, 247);
            xtraTabPage1.Text = "xtraTabPage1";
            // 
            // chartControl1
            // 
            chartControl1.Dock = DockStyle.Fill;
            chartControl1.Legend.LegendID = -1;
            chartControl1.Location = new Point(0, 0);
            chartControl1.Name = "chartControl1";
            chartControl1.Size = new Size(1092, 247);
            chartControl1.TabIndex = 0;
            chartControl1.BoundDataChanged += chartControl1_BoundDataChanged;
            // 
            // xtraTabPage2
            // 
            xtraTabPage2.Controls.Add(chartControl2);
            xtraTabPage2.Name = "xtraTabPage2";
            xtraTabPage2.Size = new Size(1092, 247);
            xtraTabPage2.Text = "xtraTabPage2";
            // 
            // chartControl2
            // 
            chartControl2.Dock = DockStyle.Fill;
            chartControl2.Legend.LegendID = -1;
            chartControl2.Location = new Point(0, 0);
            chartControl2.Name = "chartControl2";
            chartControl2.Size = new Size(1092, 247);
            chartControl2.TabIndex = 0;
            chartControl2.BoundDataChanged += chartControl2_BoundDataChanged;
            // 
            // dockManager1
            // 
            dockManager1.Form = this;
            dockManager1.TopZIndexControls.AddRange(new string[] { "DevExpress.XtraBars.BarDockControl", "DevExpress.XtraBars.StandaloneBarDockControl", "System.Windows.Forms.StatusBar", "System.Windows.Forms.MenuStrip", "System.Windows.Forms.StatusStrip", "DevExpress.XtraBars.Ribbon.RibbonStatusBar", "DevExpress.XtraBars.Ribbon.RibbonControl", "DevExpress.XtraBars.Navigation.OfficeNavigationBar", "DevExpress.XtraBars.Navigation.TileNavPane" });
            // 
            // EqpUtilizationView
            // 
            AutoScaleDimensions = new SizeF(7F, 14F);
            AutoScaleMode = AutoScaleMode.Font;
            Controls.Add(panelControl1);
            Name = "EqpUtilizationView";
            Size = new Size(1098, 650);
            ((System.ComponentModel.ISupportInitialize)panelControl1).EndInit();
            panelControl1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)splitContainerControl1.Panel1).EndInit();
            splitContainerControl1.Panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)splitContainerControl1.Panel2).EndInit();
            splitContainerControl1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)splitContainerControl1).EndInit();
            splitContainerControl1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)gridControl1).EndInit();
            ((System.ComponentModel.ISupportInitialize)bandedGridView1).EndInit();
            ((System.ComponentModel.ISupportInitialize)xtraTabControl1).EndInit();
            xtraTabControl1.ResumeLayout(false);
            xtraTabPage1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)chartControl1).EndInit();
            xtraTabPage2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)chartControl2).EndInit();
            ((System.ComponentModel.ISupportInitialize)dockManager1).EndInit();
            ResumeLayout(false);
        }

        #endregion

        /// <summary>   The first panel control. </summary>
        private DevExpress.XtraEditors.PanelControl panelControl1;
        /// <summary>   The first dock manager. </summary>
        private DevExpress.XtraBars.Docking.DockManager dockManager1;
        /// <summary>   The first grid control. </summary>
        private DevExpress.XtraGrid.GridControl gridControl1;
        /// <summary>   The first banded grid view. </summary>
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridView bandedGridView1;
        /// <summary>   The first grid band. </summary>
        private DevExpress.XtraGrid.Views.BandedGrid.GridBand gridBand1;
        private DevExpress.XtraEditors.SplitContainerControl splitContainerControl1;
        private DevExpress.XtraTab.XtraTabControl xtraTabControl1;
        private DevExpress.XtraTab.XtraTabPage xtraTabPage1;
        private DevExpress.XtraTab.XtraTabPage xtraTabPage2;
        private DevExpress.XtraCharts.ChartControl chartControl1;
        private DevExpress.XtraCharts.ChartControl chartControl2;
    }
}
