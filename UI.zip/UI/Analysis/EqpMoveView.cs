﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using Mozart.Studio.TaskModel.UserInterface;
using Mozart.Studio.TaskModel.Projects;
using Mozart.Studio.TaskModel.UserLibrary;
using FabSimulator;
using FabSimulatorUI.Common;

namespace FabSimulatorUI.Analysis
{
    public partial class EqpMoveView : XtraPivotGridControlView
    {
        IExperimentResultItem result;
        ModelDataContext modelDataContext;
        ExpDataContext expDataContext;

        public EqpMoveView(IServiceProvider serviceProvider)
            : base(serviceProvider)
        {
            InitializeComponent();
        }

        protected override void LoadDocument()
        {
            this.LoadInit();

            this.Query();
        }

        private void LoadInit()
        {
            this.result = this.Document.GetResultItem();

            Globals.InitFactoryTime(this.result);

            this.modelDataContext = result.GetCtx<ModelDataContext>();
            this.expDataContext = result.GetCtx<ExpDataContext>();
        }

        private void Query()
        {
            using (var wc = new Mozart.Studio.UIComponents.WaitCursor())
            {
                this.BindBegin();
                this.BindDo();
                this.BindEnd();
            }
        }

        private void BindBegin()
        {
            this.pivotGridControl1.BeginUpdate();
            this.SetPivotGridFields();
        }

        private void BindDo()
        {
            this.pivotGridControl1.DataSource = this.Calculate().ToBindingList();
        }

        private void BindEnd()
        {
            this.pivotGridControl1.EndUpdate();
            this.pivotGridControl1.BestFit();
        }

        private void SetPivotGridFields()
        {
            this.pivotGridControl1.DataSource = null;
            this.pivotGridControl1.Fields.Clear();
            this.pivotGridControl1.OptionsBehavior.CopyToClipboardWithFieldValues = true;

            var f1 = this.pivotGridControl1.AddFieldRowArea<EqpMove>(x => x.AreaID);
            var f2 = this.pivotGridControl1.AddFieldFilterArea<EqpMove>(x => x.Workstation);
            var f3 = this.pivotGridControl1.AddFieldFilterArea<EqpMove>(x => x.Resource);
            var f4 = this.pivotGridControl1.AddFieldDataArea<EqpMove>(x => x.Moving);

            this.pivotGridControl1.OptionsView.ShowColumnGrandTotals = true;
        }

        private IEnumerable<EqpMove> Calculate()
        {
            var rslt = this.expDataContext.Result(this.result.Name);

            var eqpPlan = rslt.EQP_PLAN.Where(x => x.AREA_ID != null
                                                && x.END_TIME >= this.result.StartTime
                                                && x.END_TIME <= this.result.StartTime.AddDays(this.result.GetPlanPeriodF(1)));

            var eqpMove = from a in eqpPlan
                          select new EqpMove
                          {
                              AreaID = a.AREA_ID,
                              Workstation = a.EQP_GROUP,
                              Resource = a.EQP_ID,
                              Moving = a.WAFER_QTY
                          };

            return eqpMove;
        }

        class EqpMove
        {
            public string AreaID { get; set; }
            public string Workstation { get; set; }
            public string Resource { get; set; }
            public int Moving { get; set; }
        }
    }
}
