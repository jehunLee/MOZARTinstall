﻿namespace FabSimulatorUI.Analysis
{
    partial class StepTargetPopUp
    {
        /// <summary> 
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 구성 요소 디자이너에서 생성한 코드

        /// <summary> 
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            this.StepTargetGrid = new DevExpress.XtraGrid.GridControl();
            this.gridView1 = new DevExpress.XtraGrid.Views.Grid.GridView();
            ((System.ComponentModel.ISupportInitialize)(this.StepTargetGrid)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // StepTargetGrid
            // 
            this.StepTargetGrid.Dock = System.Windows.Forms.DockStyle.Fill;
            this.StepTargetGrid.Location = new System.Drawing.Point(0, 0);
            this.StepTargetGrid.MainView = this.gridView1;
            this.StepTargetGrid.Name = "StepTargetGrid";
            this.StepTargetGrid.Size = new System.Drawing.Size(1050, 775);
            this.StepTargetGrid.TabIndex = 0;
            this.StepTargetGrid.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridView1});
            this.StepTargetGrid.Load += new System.EventHandler(this.StepTargetGrid_Load);
            // 
            // gridView1
            // 
            this.gridView1.GridControl = this.StepTargetGrid;
            this.gridView1.Name = "gridView1";
            // 
            // StepTargetPopUp
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1050, 775);
            this.Controls.Add(this.StepTargetGrid);
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "StepTargetPopUp";
            this.Text = "StepTargetPopUp";
            ((System.ComponentModel.ISupportInitialize)(this.StepTargetGrid)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView1)).EndInit();
            this.ResumeLayout(false);

        }
        #endregion

        private DevExpress.XtraGrid.GridControl StepTargetGrid;
        private DevExpress.XtraGrid.Views.Grid.GridView gridView1;
    }
}
