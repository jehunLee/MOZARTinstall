﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Mozart.Studio.TaskModel.UserInterface;
using Mozart.Studio.TaskModel.Projects;
using Mozart.Studio.Application;
using DevExpress.XtraEditors.Controls;
using DevExpress.XtraPivotGrid;
using DevExpress.XtraCharts;

using Mozart.Studio.UIComponents;
using Mozart.Studio.TaskModel.Utility;

using Mozart.Data.Entity;
using Mozart.Mapping;

using Mozart.Studio.TaskModel.UserLibrary; //linq2

using FabSimulator;
using FabSimulatorUI.Common;

namespace FabSimulatorUI.Analysis
{
    public partial class StepMoveTrendView : XtraPivotGridControlView
    {
        #region Variable&Property

        /// <summary>   The result. </summary>
        IExperimentResultItem result;

        /// <summary>   Context for the model data. </summary>
        ModelDataContext modelDataContext;
        /// <summary>   Context for the exponent data. </summary>
        ExpDataContext expDataContext;
        /// <summary>   True while initialization is in progress. </summary>
        bool initializing;

        /// <summary>   Full pathname of the layout file. </summary>
        string layoutPath;
        bool loading;
        DayOfWeek startDayOfWeek;

        ///
        /// <summary>   Gets a value indicating whether this object is cumulative. </summary>
        ///
        /// <value> True if this object is cumulative, false if not. </value>
        ///
        private bool IsCumulative
        {
            get { return cumulativeCheckEdit.Checked; }
        }
        #endregion

        #region Ctor

        public StepMoveTrendView(IServiceProvider serviceProvider)
            : base(serviceProvider)
        {
            InitializeComponent();

            this.initializing = true;
            this.ConstructInit();
        }

        protected override void LoadDocument()
        {            
            this.LoadInit();
            this.initializing = false;

            this.loading = true;
            this.Query();
            this.loading = false;
        }

        protected override PivotGridControl GetPivotGrid()
        {
            return this.pivotGridControl;
        }

        protected override bool UpdateCommand(Command command)
        {
            bool handled = false;
            switch (command.CommandID)
            {
                case DataCommands.DataExportToExcel:
                    command.Enabled = true;
                    handled = true;
                    break;
            }

            if (handled) return true;
            return base.UpdateCommand(command);
        }

        protected override bool HandleCommand(Command command)
        {
            PivotGridControl gridView = this.pivotGridControl;

            bool handled = false;
            if (gridView != null)
            {
                switch (command.CommandID)
                {
                    case DataCommands.DataExportToExcel:
                        PivotGridExporter.ExportToExcel(gridView);
                        handled = true;
                        break;
                }
            }

            if (handled) return true;
            return base.HandleCommand(command);
        }

        #endregion

        #region Init

        private void ConstructInit()
        {
            this.pivotGridControl.OptionsChartDataSource.ProvideDataByColumns = false;
            this.pivotGridControl.OptionsChartDataSource.SelectionOnly = true;

            this.pivotGridControl.OptionsChartDataSource.ProvideColumnGrandTotals = false;
            this.pivotGridControl.OptionsChartDataSource.ProvideRowGrandTotals = false;

            this.pivotGridControl.OptionsChartDataSource.MaxAllowedPointCountInSeries = 0;
            this.pivotGridControl.OptionsBehavior.CopyToClipboardWithFieldValues = true;

            this.chartProcProgress.Series.Clear();
            this.chartProcProgress.Titles[0].Visible = false;
            this.chartProcProgress.CrosshairOptions.ShowArgumentLine = false;
            this.chartProcProgress.DataSource = pivotGridControl;
        }

        private void LoadInit()
        {
            this.result = this.Document.GetResultItem();

            Globals.InitFactoryTime(this.result);

            this.modelDataContext = result.GetCtx<ModelDataContext>();
            this.expDataContext = result.GetCtx<ExpDataContext>();

            this.FillPeriod();

            this.result.ExpResults(this.resultCheckCtl);

            var results = this.result.Experiment.Results.Select(p => p.Name).ToArray();
            FabSimulatorUI.Helper.NotifyEmptySchema(this.modelDataContext, this.expDataContext, results, Consts.Part, Consts.StepMove);

            this.startDayOfWeek = ShopCalendar.StartWeek;

            this.SetPivotGridFields();

            this.layoutPath = System.IO.Path.Combine(this.GetService<IVsApplication>().ApplicationPath, "Layouts", "StepMoveTrendView.xml");

            if (System.IO.File.Exists(this.layoutPath))
            {
                this.pivotGridControl.RestoreLayoutFromXml(this.layoutPath);
            }

            this.radioGroup1.SelectedIndex = 1;
        }

        private void FillPeriod()
        {
            this.startDateTimePicker.Value = ShopCalendar.StartTimeOfDayT(this.result.StartTime);
            this.endDateTimePicker.Value = this.startDateTimePicker.Value.AddDays(this.result.GetPlanPeriodF(1));
        }

        #endregion 

        #region Query&Bind

        private void Query()
        {
            using (var wc = new Mozart.Studio.UIComponents.WaitCursor())
            {
                this.BindBegin();
                this.BindDo();
                this.BindEnd();
            }
        }

        private void BindBegin()
        {
            this.pivotGridControl.BeginUpdate();
            //this.SetPivotGridFields();
        }

        private void BindEnd()
        {
            this.pivotGridControl.EndUpdate();
            this.pivotGridControl.BestFit();
        }

        private void BindDo()
        {
            try
            {
                this.pivotGridControl.DataSource = this.CalcuateTrend().ToBindingList();
            }
            catch (Exception)
            {
                MessageBox.Show(Consts.CaseDll, Consts.Notification, MessageBoxButtons.OKCancel, MessageBoxIcon.Asterisk);
            }
        }
        #endregion

        private void SetPivotGridFields()
        {
            this.pivotGridControl.DataSource = null;
            this.pivotGridControl.Fields.Clear();

            var f3a = this.pivotGridControl.AddFieldRowArea<TrendInfo>((c) => c.MFG_PRODUCT_ID);
            var f1 = this.pivotGridControl.AddFieldRowArea<TrendInfo>((c) => c.OPER_ID);
            //f1.Width = 300;

            var f3c = this.pivotGridControl.AddFieldRowArea<TrendInfo>((c) => c.RESOURCE_ID);
            var f2 = this.pivotGridControl.AddFieldRowArea<TrendInfo>((c) => c.RESULT);
            //var f3a = this.pivotGridControl.AddFieldPivotArea<TrendInfo>((c) => c.MFG_PRODUCT_ID, this.IsCumulative ? PivotArea.RowArea : PivotArea.FilterArea);
            var f3b = this.pivotGridControl.AddFieldPivotArea<TrendInfo>((c) => c.AREA_ID, PivotArea.FilterArea);
            f3c.Caption = "RESOURCE_ID";

            var f4 = this.pivotGridControl.AddFieldColumnArea<TrendInfo>((c) => c.TargetDate, PivotGroupInterval.Custom);
            //f4.SortMode = PivotSortMode.Custom;

            var f5 = this.pivotGridControl.AddFieldDataArea<TrendInfo>((c) => c.VALUE);
            f5.CellFormat.FormatString = Consts.Mask_Qty_1;
            f5.ValueFormat.FormatString = Consts.Mask_Qty_1;
            f5.SummaryType = DevExpress.Data.PivotGrid.PivotSummaryType.Custom;

            //var f6 = this.pivotGridControl.AddFieldFilterArea<TrendInfo>((c) => c.TechNode);
            //var f7 = this.pivotGridControl.AddFieldFilterArea<TrendInfo>((c) => c.MfgAreaId);
            //var f8 = this.pivotGridControl.AddFieldFilterArea<TrendInfo>((c) => c.WSGroup);

            this.pivotGridControl.OptionsView.ShowColumnGrandTotals = false;

            f1.SortBySummaryInfo.Conditions.Clear();
            f1.SortBySummaryInfo.Field = f5;
            f1.SortOrder = PivotSortOrder.Descending;
            f3a.SortBySummaryInfo.Conditions.Clear();
            f3a.SortBySummaryInfo.Field = f5;
            f3a.SortOrder = PivotSortOrder.Descending;
            f3b.SortBySummaryInfo.Conditions.Clear();
            f3b.SortBySummaryInfo.Field = f5;
            f3b.SortOrder = PivotSortOrder.Descending;
            f3c.SortBySummaryInfo.Conditions.Clear();
            f3c.SortBySummaryInfo.Field = f5;
            f3c.SortOrder = PivotSortOrder.Descending;
        }

        class TrendInfo
        {
            ///
            /// <summary>   Gets or sets the group the step belongs to. </summary>
            ///
            /// <value> The step group. </value>
            ///
            public string OPER_ID { get; set; }

            ///
            /// <summary>   Gets or sets the identifier of the design. </summary>
            ///
            /// <value> The identifier of the design. </value>
            ///
            public string MFG_PRODUCT_ID { get; set; }

            public string AREA_ID { get; set; }

            public string RESOURCE_ID { get; set; }

            ///
            /// <summary>   Gets or sets the result. </summary>
            ///
            /// <value> The result. </value>
            ///
            public string RESULT { get; set; }

            ///
            /// <summary>   Gets or sets the target date. </summary>
            ///
            /// <value> The target date. </value>
            ///
            public DateTime TargetDate { get; set; }

            ///
            /// <summary>   Gets or sets the value. </summary>
            ///
            /// <value> The value. </value>
            ///
            public double VALUE { get; set; }
        }

        private IEnumerable<TrendInfo> CalcuateTrend()
        {
            var results = this.resultCheckCtl.Properties.Items.GetCheckedValues().Select(x => x.ToString()).ToArray();

            var cumulative = this.IsCumulative;

            if (results == null || results.Length == 0)
                return Enumerable.Empty<TrendInfo>();

            return results.SelectMany(name => CalcuateTrend(name, cumulative));
        }

        private IEnumerable<TrendInfo> CalcuateTrend(string name, bool cumulative)
        {
            var rslt = this.expDataContext.Result(name);

            var radioIndex = this.radioGroup1.SelectedIndex;

            var startTime = FabSimulatorUI.Helper.GetIntervalStartDate(this.startDateTimePicker.Value, radioIndex);
            var endTime = FabSimulatorUI.Helper.GetIntervalEndDate(this.endDateTimePicker.Value, radioIndex);

            //var part = this.modelDataContext.Part;
            var stepMove = rslt.STEP_MOVE.Where(x=> x.TARGET_DATE >= startTime && x.TARGET_DATE <= endTime).ToList();

            //var query = stepMove.Join(part,
            //    s => new { s.MfgFacilityId, s.MfgPartCode },
            //    p => new { p.MfgFacilityId, p.MfgPartCode },
            //    (s, p) => new TrendInfo
            //    {
            //        RESULT = name,
            //        STEP_GROUP = s.StepName,
            //        PRODUCT_ID = p.DesignId,
            //        TechNode = p.TechNode,
            //        MfgAreaId = s.MfgAreaId,
            //        WSGroup = s.WorkstationGroup,
            //        TargetDate = s.TargetDate,
            //        VALUE = s.MoveQty
            //    }
            //        );

            var query = from s in stepMove
                        select new TrendInfo
                        {
                            OPER_ID = s.STEP_ID,
                            MFG_PRODUCT_ID = s.PART_ID,
                            RESOURCE_ID = s.EQP_ID,
                            AREA_ID = s.AREA_ID,
                            RESULT = name,
                            TargetDate = s.TARGET_DATE,
                            VALUE = s.MOVE_QTY
                        };

            if (cumulative)
            {
                //var cum = from r in query
                //          group r by new { r.STEP_GROUP, r.ProdCode }
                //              into g

                //              from it in g.Accumulate(0d, (i, v) => v += i.Value)
                //              select new TrendInfo
                //              {
                //                  STEP_GROUP = it.Item1.STEP_GROUP,
                //                  FlowUnit = it.Item1.FlowUnit,
                //                  RESULT = name,
                //                  TargetDate = it.Item1.TargetDate,
                //                  VALUE = it.Item2
                //              };
                //return cum;


                var groups = query.GroupBy(g => new { g.OPER_ID, g.MFG_PRODUCT_ID });

                return groups
                    .SelectMany(g => g.Accumulate(0d, (i, v) => v += i.VALUE))
                    .Select(it => new TrendInfo
                    {
                        OPER_ID = it.Item1.OPER_ID,
                        MFG_PRODUCT_ID = it.Item1.MFG_PRODUCT_ID,
                        RESOURCE_ID = it.Item1.RESOURCE_ID,
                        RESULT = name,
                        TargetDate = it.Item1.TargetDate,
                        VALUE = it.Item2
                    });

            }
            else
            {
                return query;
            }
        }

        private void btnQuery_Click(object sender, EventArgs e)
        {
            this.Query();
        }

        protected void pivotGridControl_CustomGroupInterval(object sender, PivotCustomGroupIntervalEventArgs e)
        {
            if (this.initializing)
                return;

            if (e.Field.Caption == "DATE1")
            {
                var targetDate = (DateTime)e.Value;
                var year = targetDate.Year;

                if (this.radioGroup1.SelectedIndex == 1)
                {
                    var targetWeek = FabSimulatorUI.Helper.GetTargetWeek(targetDate, this.startDayOfWeek);
                    if (targetWeek == 52 && targetDate.Month == 1)
                        year--;
                }

                e.GroupValue = year;
            }

            if (e.Field.Caption == "DATE2")
            {
                var targetDate = (DateTime)e.Value;

                if (this.radioGroup1.SelectedIndex == 0)
                {
                    e.GroupValue = "MONTH " + targetDate.Month;
                }
                else if (this.radioGroup1.SelectedIndex == 1)
                {
                    e.GroupValue = "WEEK " + FabSimulatorUI.Helper.GetTargetWeek(targetDate, this.startDayOfWeek);
                }
                else
                {
                    e.GroupValue = ((DateTime)e.Value).ToString("MM-dd");
                }
            }

            //if (e.Field.Caption == "DATE1")
            //{
            //    e.GroupValue = ((DateTime)e.Value).SplitDate().ToMMddyyyy();
            //}
            //else if (e.Field.Caption == "DATE2")
            //{
            //    e.GroupValue = ((DateTime)e.Value).ToHH();
            //    e.Field.Width = 40;
            //}
        }

        private void resultCheckCtl_TextChanged(object sender, EventArgs e)
        {
            if (this.initializing)
                return;

            this.Query();
        }

        private void saveLayoutBtn_Click(object sender, EventArgs e)
        {
            string dircetory = System.IO.Path.Combine(this.GetService<IVsApplication>().ApplicationPath, "Layouts");
            System.IO.DirectoryInfo di = new System.IO.DirectoryInfo(dircetory);

            if (di.Exists == false)
            {
                System.IO.Directory.CreateDirectory(dircetory);
            }

            this.pivotGridControl.SaveLayoutToXml(this.layoutPath);
        }

        private void PivotGridControl_CustomCellDisplayText(object sender, PivotCellDisplayTextEventArgs e)
        {
            if (e.DisplayText == string.Empty)
            {
                e.DisplayText = "0";
            }
        }

        private void PivotGridControl_CustomChartDataSourceData(object sender, PivotCustomChartDataSourceDataEventArgs e)
        {
            if (e.ItemType == PivotChartItemType.CellItem)
            {
                if (e.Value.ToString() == string.Empty)
                    e.Value = 0;
            }
        }

        private void ChartProcProgress_BoundDataChanged(object sender, EventArgs e)
        {
            this.chartProcProgress.PivotGridDataSourceOptions.MaxAllowedSeriesCount = 100;

            string prevEqpID = string.Empty;
            int i = 0;
            foreach (Series s in ((ChartControl)sender).Series)
            {
                if (s.Points.Count > 0)
                {
                    s.ChangeView(ViewType.SideBySideStackedBar);
                    var view = s.View as SideBySideStackedBarSeriesView;

                    var eqpField = pivotGridControl.GetFieldsByArea(PivotArea.RowArea).Where(x => x.Caption == "RESOURCE_ID").FirstOrDefault();
                    if (eqpField != null)
                    {
                        string rowValue = pivotGridControl.GetFieldValue(eqpField, (s.Points[0].Tag as PivotChartDataSourceRowItem).CellY)?.ToString();

                        if (rowValue != prevEqpID)
                        {
                            prevEqpID = rowValue;
                            i++;
                        }
                    }

                    view.StackedGroup = i;
                }
            }

            //var s1 = ((ChartControl)sender).Series.Where(x => x.Name.Contains("RESOURCE_ID")).FirstOrDefault() as Series;
            //var s2 = ((ChartControl)sender).Series.Where(x => x.Name.Contains("MOVE")).FirstOrDefault() as Series;

            //if (s1 != null)
            //    s1.ChangeView(ViewType.Bar);
        }

        private void StartDateTimePicker_ValueChanged(object sender, EventArgs e)
        {
            if (this.initializing)
                return;

            this.endDateTimePicker.Value = this.startDateTimePicker.Value.AddMonths(1);
        }

        private void radioGroup1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (this.initializing)
                return;

            this.Query();
        }

        private void pivotGridControl_CustomSummary(object sender, PivotGridCustomSummaryEventArgs e)
        {
            var resultField = (sender as PivotGridControl).Fields.GetFieldByName("field_RESULT");

            if (resultField.Area == PivotArea.FilterArea)
            {
                e.CustomValue = Math.Round((decimal)e.SummaryValue.Summary / (decimal)this.resultCheckCtl.Properties.Items.GetCheckedValues().Count, 3);
            }
            else
            {
                e.CustomValue = e.SummaryValue.Summary;
            }
        }
    }
}
