﻿namespace FabSimulatorUI.Analysis
{
    partial class CumulatvieCycleTimeView
    {
        /// <summary> 
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 구성 요소 디자이너에서 생성한 코드

        /// <summary> 
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>        
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            DevExpress.XtraCharts.XYDiagram xyDiagram1 = new DevExpress.XtraCharts.XYDiagram();
            DevExpress.XtraCharts.Series series1 = new DevExpress.XtraCharts.Series();
            DevExpress.XtraCharts.LineSeriesView lineSeriesView1 = new DevExpress.XtraCharts.LineSeriesView();
            DevExpress.XtraCharts.LineSeriesView lineSeriesView2 = new DevExpress.XtraCharts.LineSeriesView();
            panelControl1 = new DevExpress.XtraEditors.PanelControl();
            splitContainerControl1 = new DevExpress.XtraEditors.SplitContainerControl();
            chartControl1 = new DevExpress.XtraCharts.ChartControl();
            treeList1 = new DevExpress.XtraTreeList.TreeList();
            expandablePanel1 = new Mozart.Studio.UIComponents.ExpandablePanel();
            label4 = new Label();
            eqpGroupCheckedComboboxEdit = new DevExpress.XtraEditors.CheckedComboBoxEdit();
            resultCheckCtl = new DevExpress.XtraEditors.CheckedComboBoxEdit();
            label2 = new Label();
            radioGroup1 = new DevExpress.XtraEditors.RadioGroup();
            endDateTimePicker = new Mozart.Studio.UIComponents.FullDateTimePicker();
            startDateTimePicker = new Mozart.Studio.UIComponents.FullDateTimePicker();
            label3 = new Label();
            label1 = new Label();
            btnQuery = new Button();
            dockManager1 = new DevExpress.XtraBars.Docking.DockManager(components);
            xtraTabPage1 = new DevExpress.XtraTab.XtraTabPage();
            ((System.ComponentModel.ISupportInitialize)panelControl1).BeginInit();
            panelControl1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)splitContainerControl1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)splitContainerControl1.Panel1).BeginInit();
            splitContainerControl1.Panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)splitContainerControl1.Panel2).BeginInit();
            splitContainerControl1.Panel2.SuspendLayout();
            splitContainerControl1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)chartControl1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)xyDiagram1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)series1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)lineSeriesView1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)lineSeriesView2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)treeList1).BeginInit();
            expandablePanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)eqpGroupCheckedComboboxEdit.Properties).BeginInit();
            ((System.ComponentModel.ISupportInitialize)resultCheckCtl.Properties).BeginInit();
            ((System.ComponentModel.ISupportInitialize)radioGroup1.Properties).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dockManager1).BeginInit();
            SuspendLayout();
            // 
            // panelControl1
            // 
            panelControl1.Controls.Add(splitContainerControl1);
            panelControl1.Controls.Add(expandablePanel1);
            panelControl1.Dock = DockStyle.Fill;
            panelControl1.Location = new Point(0, 0);
            panelControl1.Name = "panelControl1";
            panelControl1.Size = new Size(1335, 477);
            panelControl1.TabIndex = 0;
            // 
            // splitContainerControl1
            // 
            splitContainerControl1.Dock = DockStyle.Fill;
            splitContainerControl1.Location = new Point(2, 73);
            splitContainerControl1.Name = "splitContainerControl1";
            // 
            // splitContainerControl1.Panel1
            // 
            splitContainerControl1.Panel1.Controls.Add(chartControl1);
            splitContainerControl1.Panel1.Text = "Panel1";
            // 
            // splitContainerControl1.Panel2
            // 
            splitContainerControl1.Panel2.Controls.Add(treeList1);
            splitContainerControl1.Panel2.Text = "Panel2";
            splitContainerControl1.Size = new Size(1331, 402);
            splitContainerControl1.SplitterPosition = 1056;
            splitContainerControl1.TabIndex = 1;
            splitContainerControl1.SizeChanged += splitContainerControl1_SizeChanged;
            // 
            // chartControl1
            // 
            xyDiagram1.AxisX.VisibleInPanesSerializable = "-1";
            xyDiagram1.AxisY.VisibleInPanesSerializable = "-1";
            chartControl1.Diagram = xyDiagram1;
            chartControl1.Dock = DockStyle.Fill;
            chartControl1.Legend.LegendID = -1;
            chartControl1.Legend.MarkerMode = DevExpress.XtraCharts.LegendMarkerMode.CheckBox;
            chartControl1.Legend.Name = "Default Legend";
            chartControl1.Location = new Point(0, 0);
            chartControl1.Name = "chartControl1";
            series1.Name = "Series 1";
            series1.SeriesID = 0;
            series1.View = lineSeriesView1;
            chartControl1.SeriesSerializable = new DevExpress.XtraCharts.Series[] { series1 };
            chartControl1.SeriesTemplate.View = lineSeriesView2;
            chartControl1.Size = new Size(1056, 402);
            chartControl1.TabIndex = 0;
            chartControl1.BoundDataChanged += ChartControl1_BoundDataChanged;
            chartControl1.MouseClick += chartControl1_MouseClick;
            // 
            // treeList1
            // 
            treeList1.Dock = DockStyle.Fill;
            treeList1.Location = new Point(0, 0);
            treeList1.Name = "treeList1";
            treeList1.Size = new Size(265, 402);
            treeList1.TabIndex = 0;
            treeList1.AfterCheckNode += treeList1_AfterCheckNode;
            // 
            // expandablePanel1
            // 
            expandablePanel1.Controls.Add(label4);
            expandablePanel1.Controls.Add(eqpGroupCheckedComboboxEdit);
            expandablePanel1.Controls.Add(resultCheckCtl);
            expandablePanel1.Controls.Add(label2);
            expandablePanel1.Controls.Add(radioGroup1);
            expandablePanel1.Controls.Add(endDateTimePicker);
            expandablePanel1.Controls.Add(startDateTimePicker);
            expandablePanel1.Controls.Add(label3);
            expandablePanel1.Controls.Add(label1);
            expandablePanel1.Controls.Add(btnQuery);
            expandablePanel1.Dock = DockStyle.Top;
            expandablePanel1.ForeColor = Color.SteelBlue;
            expandablePanel1.Location = new Point(2, 2);
            expandablePanel1.Name = "expandablePanel1";
            expandablePanel1.Size = new Size(1331, 71);
            expandablePanel1.TabIndex = 0;
            expandablePanel1.Text = "Cumulative CycleTime";
            expandablePanel1.UseAnimation = true;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(841, 41);
            label4.Name = "label4";
            label4.Size = new Size(61, 14);
            label4.TabIndex = 89;
            label4.Text = "EqpGroup";
            // 
            // eqpGroupCheckedComboboxEdit
            // 
            eqpGroupCheckedComboboxEdit.Location = new Point(908, 38);
            eqpGroupCheckedComboboxEdit.Name = "eqpGroupCheckedComboboxEdit";
            eqpGroupCheckedComboboxEdit.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] { new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo) });
            eqpGroupCheckedComboboxEdit.Size = new Size(125, 20);
            eqpGroupCheckedComboboxEdit.TabIndex = 88;
            // 
            // resultCheckCtl
            // 
            resultCheckCtl.Location = new Point(72, 38);
            resultCheckCtl.Name = "resultCheckCtl";
            resultCheckCtl.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] { new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo) });
            resultCheckCtl.Size = new Size(125, 20);
            resultCheckCtl.TabIndex = 87;
            resultCheckCtl.EditValueChanged += resultCheckCtl_EditValueChanged;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(21, 41);
            label2.Name = "label2";
            label2.Size = new Size(45, 14);
            label2.TabIndex = 86;
            label2.Text = "Results";
            // 
            // radioGroup1
            // 
            radioGroup1.Location = new Point(595, 33);
            radioGroup1.Name = "radioGroup1";
            radioGroup1.Properties.Columns = 3;
            radioGroup1.Properties.GlyphAlignment = DevExpress.Utils.HorzAlignment.Default;
            radioGroup1.Properties.Items.AddRange(new DevExpress.XtraEditors.Controls.RadioGroupItem[] { new DevExpress.XtraEditors.Controls.RadioGroupItem(null, "Monthly", true, null, "radio_monthly"), new DevExpress.XtraEditors.Controls.RadioGroupItem(null, "Weekly", true, null, "radio_weekly"), new DevExpress.XtraEditors.Controls.RadioGroupItem(null, "Daily", true, null, "radio_daily") });
            radioGroup1.Size = new Size(225, 29);
            radioGroup1.TabIndex = 85;
            radioGroup1.SelectedIndexChanged += radioGroup1_SelectedIndexChanged;
            // 
            // endDateTimePicker
            // 
            endDateTimePicker.Location = new Point(470, 36);
            endDateTimePicker.Margin = new Padding(3, 6, 3, 6);
            endDateTimePicker.Name = "endDateTimePicker";
            endDateTimePicker.Size = new Size(119, 22);
            endDateTimePicker.TabIndex = 81;
            endDateTimePicker.TimeFormat = Mozart.Studio.UIComponents.FullDateTimePickerTimeFormat.Hidden;
            endDateTimePicker.UTCPrompt = null;
            // 
            // startDateTimePicker
            // 
            startDateTimePicker.Location = new Point(274, 36);
            startDateTimePicker.Margin = new Padding(3, 5, 3, 5);
            startDateTimePicker.Name = "startDateTimePicker";
            startDateTimePicker.Size = new Size(119, 22);
            startDateTimePicker.TabIndex = 80;
            startDateTimePicker.TimeFormat = Mozart.Studio.UIComponents.FullDateTimePickerTimeFormat.Hidden;
            startDateTimePicker.UTCPrompt = null;
            startDateTimePicker.ValueChanged += startDateTimePicker_ValueChanged;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(405, 40);
            label3.Name = "label3";
            label3.Size = new Size(59, 14);
            label3.TabIndex = 76;
            label3.Text = "End Time";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(203, 40);
            label1.Name = "label1";
            label1.Size = new Size(65, 14);
            label1.TabIndex = 74;
            label1.Text = "Start Time";
            // 
            // btnQuery
            // 
            btnQuery.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            btnQuery.Location = new Point(1239, 34);
            btnQuery.Name = "btnQuery";
            btnQuery.Size = new Size(75, 27);
            btnQuery.TabIndex = 3;
            btnQuery.Text = "QUERY";
            btnQuery.UseVisualStyleBackColor = true;
            btnQuery.Click += btnQuery_Click;
            // 
            // dockManager1
            // 
            dockManager1.Form = this;
            dockManager1.TopZIndexControls.AddRange(new string[] { "DevExpress.XtraBars.BarDockControl", "DevExpress.XtraBars.StandaloneBarDockControl", "System.Windows.Forms.StatusBar", "System.Windows.Forms.MenuStrip", "System.Windows.Forms.StatusStrip", "DevExpress.XtraBars.Ribbon.RibbonStatusBar", "DevExpress.XtraBars.Ribbon.RibbonControl", "DevExpress.XtraBars.Navigation.OfficeNavigationBar", "DevExpress.XtraBars.Navigation.TileNavPane" });
            // 
            // xtraTabPage1
            // 
            xtraTabPage1.Name = "xtraTabPage1";
            xtraTabPage1.Size = new Size(1088, 373);
            // 
            // CumulatvieCycleTimeView
            // 
            AutoScaleDimensions = new SizeF(7F, 14F);
            AutoScaleMode = AutoScaleMode.Font;
            Controls.Add(panelControl1);
            Name = "CumulatvieCycleTimeView";
            Size = new Size(1335, 477);
            ((System.ComponentModel.ISupportInitialize)panelControl1).EndInit();
            panelControl1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)splitContainerControl1.Panel1).EndInit();
            splitContainerControl1.Panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)splitContainerControl1.Panel2).EndInit();
            splitContainerControl1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)splitContainerControl1).EndInit();
            splitContainerControl1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)xyDiagram1).EndInit();
            ((System.ComponentModel.ISupportInitialize)lineSeriesView1).EndInit();
            ((System.ComponentModel.ISupportInitialize)series1).EndInit();
            ((System.ComponentModel.ISupportInitialize)lineSeriesView2).EndInit();
            ((System.ComponentModel.ISupportInitialize)chartControl1).EndInit();
            ((System.ComponentModel.ISupportInitialize)treeList1).EndInit();
            expandablePanel1.ResumeLayout(false);
            expandablePanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)eqpGroupCheckedComboboxEdit.Properties).EndInit();
            ((System.ComponentModel.ISupportInitialize)resultCheckCtl.Properties).EndInit();
            ((System.ComponentModel.ISupportInitialize)radioGroup1.Properties).EndInit();
            ((System.ComponentModel.ISupportInitialize)dockManager1).EndInit();
            ResumeLayout(false);
        }

        #endregion

        /// <summary>   The first panel control. </summary>
        private DevExpress.XtraEditors.PanelControl panelControl1;
        /// <summary>   The first expandable panel. </summary>
        private Mozart.Studio.UIComponents.ExpandablePanel expandablePanel1;
        /// <summary>   The button query control. </summary>
        private Button btnQuery;
        /// <summary>   The first dock manager. </summary>
        private DevExpress.XtraBars.Docking.DockManager dockManager1;
        /// <summary>   The label 1 control. </summary>
        private Label label1;
        /// <summary>   The label 3 control. </summary>
        private Label label3;
        /// <summary>   The end date time picker. </summary>
        private Mozart.Studio.UIComponents.FullDateTimePicker endDateTimePicker;
        /// <summary>   The start date time picker. </summary>
        private Mozart.Studio.UIComponents.FullDateTimePicker startDateTimePicker;
        private DevExpress.XtraTab.XtraTabPage xtraTabPage1;
        private DevExpress.XtraCharts.ChartControl chartControl1;
        private DevExpress.XtraEditors.RadioGroup radioGroup1;
        private DevExpress.XtraEditors.CheckedComboBoxEdit resultCheckCtl;
        private Label label2;
        private Label label4;
        private DevExpress.XtraEditors.CheckedComboBoxEdit eqpGroupCheckedComboboxEdit;
        private DevExpress.XtraEditors.SplitContainerControl splitContainerControl1;
        private DevExpress.XtraTreeList.TreeList treeList1;
    }
}
