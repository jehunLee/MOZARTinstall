﻿using DevExpress.XtraCharts;
using DevExpress.XtraGrid.Views.BandedGrid;
using DevExpress.XtraGrid.Views.Grid;
using FabSimulator;
using FabSimulator.Inputs;
using FabSimulator.Outputs;
using FabSimulatorUI.Common;
using Mozart.Collections;
using Mozart.Data.Entity;
using Mozart.Studio.TaskModel.Projects;
using Mozart.Studio.TaskModel.UserInterface;
using Mozart.Studio.TaskModel.UserLibrary;
using System.ComponentModel;
using System.Data;

namespace FabSimulatorUI.Analysis
{
    public partial class EqpUtilizationView : XtraGridControlView
    {
        #region Variable&Property

        /// <summary>   The result. </summary>
        IExperimentResultItem result;

        /// <summary>   Context for the model data. </summary>
        ModelDataContext modelDataContext;
        /// <summary>   Context for the exponent data. </summary>
        ExpDataContext expDataContext;
        /// <summary>   True while initialization is in progress. </summary>
        bool initializing;
        /// <summary>   True to loading. </summary>
        bool loading;

        double totalDays;

        MultiDictionary<string, EqpDailyStat> eqpDict = new MultiDictionary<string, EqpDailyStat>();

        #endregion

        #region Ctor

        public EqpUtilizationView(IServiceProvider serviceProvider)
            : base(serviceProvider)
        {
            InitializeComponent();

            this.initializing = true;
        }

        protected override void LoadDocument()
        {
            this.LoadInit();
            this.initializing = false;

            this.loading = true;
            this.Query();
            this.loading = false;
        }

        protected override GridView GetGridView()
        {
            return this.bandedGridView1;
        }

        #endregion

        #region Init

        private void LoadInit()
        {
            this.result = this.Document.GetResultItem();

            Globals.InitFactoryTime(this.result);

            this.modelDataContext = result.GetCtx<ModelDataContext>();
            this.expDataContext = result.GetCtx<ExpDataContext>();

            this.totalDays = Convert.ToDouble(this.result.GetPlanPeriodF());
        }

        #endregion

        #region Query&Bind

        private void Query()
        {
            using (var wc = new Mozart.Studio.UIComponents.WaitCursor())
            {
                this.BindBegin();
                this.BindDo();
                this.BindEnd();
            }
        }

        private void BindBegin()
        {
            this.gridControl1.BeginUpdate();
            this.gridControl1.DataSource = null;
            this.bandedGridView1.OptionsSelection.MultiSelect = true;
            this.bandedGridView1.OptionsView.ShowAutoFilterRow = true;
            //this.bandedGridView1.OptionsBehavior.Editable = false;
            this.bandedGridView1.FocusedRowChanged += BandedGridView1_FocusedRowChanged;
            //this.bandedGridView1.SelectionChanged += BandedGridView1_SelectionChanged;

            this.chartControl1.SeriesTemplate.ChangeView(ViewType.StackedBar);
            this.chartControl2.SeriesTemplate.ChangeView(ViewType.StackedBar);
            this.xtraTabControl1.TabPages.First().Text = "Utilization";
            this.xtraTabControl1.TabPages.Last().Text = "OEE";
        }

        private void BandedGridView1_FocusedRowChanged(object sender, DevExpress.XtraGrid.Views.Base.FocusedRowChangedEventArgs e)
        {
            var row = this.bandedGridView1.GetFocusedRow() as UtilInfo;
            if (row == null)
                return;

            DrawUtilChart(row);

            DrawOeeChart(row);
        }

        private void DrawUtilChart(UtilInfo row)
        {
            var list = new List<ChartInfo>();

            string argument, key;
            if (row.ITEM_EqpGroup == "-")
            {
                argument = "area";
                key = "FAB";
            }
            else if (row.ITEM_EqpID == "-")
            {
                argument = "ws";
                key = row.ITEM_AreaID;
            }
            else
            {
                argument = "eqp";
                key = row.ITEM_EqpGroup;
            }

            // 특정 eqpId를 선택한 경우와 eqpGroup을 선택한 경우를 구분
            if (row.ITEM_EqpID != "-")
                list = DrawUtilChartWhenEqpID(eqpId: row.ITEM_EqpID);
            else
                list = DrawUtilChartWhenEqpGroup(argument: argument, areaId : row.ITEM_AreaID, eqpGroup: row.ITEM_EqpGroup);

            this.chartControl1.Series.Clear();
            this.chartControl1.DataSource = list;
            this.chartControl1.SeriesTemplate.SeriesDataMember = "DATA";
            this.chartControl1.SeriesTemplate.ArgumentDataMember = "ARGUMENT";
            this.chartControl1.SeriesTemplate.ValueDataMembers.AddRange("VALUE");

#if false
            var title = new ChartTitle();
            title.Text = string.Format("UTILIZATION ({0})", key);
            this.chartControl1.Titles.Clear();
            this.chartControl1.Titles.Add(title); 
#endif
        }

        private List<ChartInfo> DrawUtilChartWhenEqpID(string eqpId)
        {
            var list = new List<ChartInfo>();
            var eqpDailyDict = eqpDict[eqpId].ToList();
            foreach (var item in eqpDailyDict)
            {
                var info = new ChartInfo();
                info.ARGUMENT = item.TARGET_DATE.ToShortDateString();
                info.DATA = "PRODUCTIVE TIME(%)";
                info.VALUE = Math.Round(item.PRODUCTIVE_TIME * item.TARGET_DATE_WEIGHT, 2);

                var info2 = new ChartInfo();
                info2.ARGUMENT = item.TARGET_DATE.ToShortDateString();
                info2.DATA = "STANDBY TIME(%)";
                info2.VALUE = Math.Round(item.STANDBY_TIME * item.TARGET_DATE_WEIGHT, 2);

                var info3 = new ChartInfo();
                info3.ARGUMENT = item.TARGET_DATE.ToShortDateString();
                info3.DATA = "ENGINEERING TIME(%)";
                info3.VALUE = Math.Round(item.ENGINEERING_TIME * item.TARGET_DATE_WEIGHT, 2);

                var info4 = new ChartInfo();
                info4.ARGUMENT = item.TARGET_DATE.ToShortDateString();
                info4.DATA = "SCHEDULED DOWNTIME(%)";
                info4.VALUE = Math.Round(item.SCHEDULED_DOWNTIME * item.TARGET_DATE_WEIGHT, 2);

                var info5 = new ChartInfo();
                info5.ARGUMENT = item.TARGET_DATE.ToShortDateString();
                info5.DATA = "UNSCHEDULED DOWNTIME(%)";
                info5.VALUE = Math.Round(item.UNSCHEDULED_DOWNTIME * item.TARGET_DATE_WEIGHT, 2);

                list.Add(info);
                list.Add(info2);
                list.Add(info3);
                list.Add(info4);
                list.Add(info5);
            }
            return list;
        }

        private List<ChartInfo> DrawUtilChartWhenEqpGroup(string argument, string areaId, string eqpGroup)
        {
            var list = new List<ChartInfo>();
            foreach (var item in this.bandedGridView1.DataSource as BindingList<UtilInfo>)
            {
                if (argument == "area" && item.ITEM_EqpGroup != "-")
                    continue;

                if (argument == "ws" && (item.ITEM_EqpGroup == "-" || item.ITEM_EqpID != "-" || item.ITEM_AreaID != areaId))
                    continue;

                if (argument == "eqp" && (item.ITEM_EqpID == "-" || item.ITEM_EqpGroup != eqpGroup))
                    continue;

                string arg = argument == "area" ? item.ITEM_AreaID : argument == "ws" ? item.ITEM_EqpGroup : item.ITEM_EqpID;
                var info = new ChartInfo();
                info.ARGUMENT = arg;
                info.DATA = "PRODUCTIVE TIME(%)";
                info.VALUE = item.PRODUCTIVE_Total;

                var info2 = new ChartInfo();
                info2.ARGUMENT = arg;
                info2.DATA = "STANDBY TIME(%)";
                info2.VALUE = item.STANDBY_Total;

                var info3 = new ChartInfo();
                info3.ARGUMENT = arg;
                info3.DATA = "ENGINEERING TIME(%)";
                info3.VALUE = item.ENG_Total;

                var info4 = new ChartInfo();
                info4.ARGUMENT = arg;
                info4.DATA = "SCHEDULED DOWNTIME(%)";
                info4.VALUE = item.PM_Total;

                var info5 = new ChartInfo();
                info5.ARGUMENT = arg;
                info5.DATA = "UNSCHEDULED DOWNTIME(%)";
                info5.VALUE = item.BM_Total;

                list.Add(info);
                list.Add(info2);
                list.Add(info3);
                list.Add(info4);
                list.Add(info5);
            }
            return list;
        }

        private void DrawOeeChart(UtilInfo row)
        {
            var list = new List<ChartInfo>();

            string argument, key;
            if (row.ITEM_EqpGroup == "-")
            {
                argument = "area";
            }
            else if (row.ITEM_EqpID == "-")
            {
                argument = "ws";
            }
            else
            {
                argument = "eqp";
            }

            if (row.ITEM_EqpID != "-")
                list = DrawOeeChartWhenEqpID(row.ITEM_EqpID);
            else
                list = DrawOeeChartWhenEqpGruop(argument, row.ITEM_AreaID, row.ITEM_EqpGroup);

            this.chartControl2.Series.Clear();
            this.chartControl2.DataSource = list;
            this.chartControl2.SeriesTemplate.SeriesDataMember = "DATA";
            this.chartControl2.SeriesTemplate.ArgumentDataMember = "ARGUMENT";
            this.chartControl2.SeriesTemplate.ValueDataMembers.AddRange("VALUE");
        }

        private List<ChartInfo> DrawOeeChartWhenEqpID(string eqpId)
        {
            List<ChartInfo > list = new List<ChartInfo>();

            var rslt = this.expDataContext.Result(this.result.Name);
            var qualityLoss = rslt.QUALITY_LOSS.ToList();
            var photoEqpList = rslt.SUMMARY_PHOTO_EQP.ToList();

            var eqpDailyDict = eqpDict[eqpId].ToList();
            var eqpSummaryPhotoEqp = photoEqpList.Where(x => x.EQP_ID == eqpId).ToList();

            foreach (var item in eqpDailyDict)
            {
                double productiveTotal = Math.Round(item.PRODUCTIVE_TIME, 2);
                double standbyTotal = Math.Round(item.STANDBY_TIME, 2);
                double engTotal = Math.Round(item.ENGINEERING_TIME, 2);
                double pmTotal = Math.Round(item.SCHEDULED_DOWNTIME, 2);
                double bmTotal = Math.Round(item.UNSCHEDULED_DOWNTIME, 2);

                var dailySummary = eqpSummaryPhotoEqp.Where(x => x.TARGET_DATE == item.TARGET_DATE).FirstOrDefault();
                var targetDateMinutes = 1440 * item.TARGET_DATE_WEIGHT;

                var productiveReticleSwitch = dailySummary != null ? Math.Round(dailySummary.RETICLE_MIN / targetDateMinutes * 100, 2) : 0;
                var productiveChuckSwap = dailySummary != null ? Math.Round(dailySummary.CHUCK_MIN / targetDateMinutes * 100, 2) : 0;
                var productiveRework = dailySummary != null ? Math.Round(dailySummary.REWORK_MIN / targetDateMinutes * 100, 2) : 0;
                var productiveScrap = dailySummary != null ? Math.Round(dailySummary.SCRAP_MIN / targetDateMinutes * 100, 2) : 0;

                double aeLossValue = pmTotal + bmTotal;
                double oeLossValue = standbyTotal;
                double erLossValue = engTotal;
                double reLossValue = productiveReticleSwitch + productiveChuckSwap;
                double qeLossValue = productiveRework + productiveScrap;
                double oeeValue = productiveTotal - qeLossValue - reLossValue;

                var info = new ChartInfo();
                info.ARGUMENT = item.TARGET_DATE.ToShortDateString();
                info.DATA = "OEE(%)";
                info.VALUE = oeeValue;

                var info2 = new ChartInfo();
                info2.ARGUMENT = item.TARGET_DATE.ToShortDateString();
                info2.DATA = "AE Loss(%)";
                info2.VALUE = aeLossValue;

                var info3 = new ChartInfo();
                info3.ARGUMENT = item.TARGET_DATE.ToShortDateString();
                info3.DATA = "OE Loss(%)";
                info3.VALUE = oeLossValue;

                var info4 = new ChartInfo();
                info4.ARGUMENT = item.TARGET_DATE.ToShortDateString();
                info4.DATA = "ER Loss(%)";
                info4.VALUE = erLossValue;

                var info5 = new ChartInfo();
                info5.ARGUMENT = item.TARGET_DATE.ToShortDateString();
                info5.DATA = "RE Loss(%)";
                info5.VALUE = reLossValue;

                var info6 = new ChartInfo();
                info6.ARGUMENT = item.TARGET_DATE.ToShortDateString();
                info6.DATA = "QE Loss(%)";
                info6.VALUE = qeLossValue;

                list.Add(info);
                list.Add(info2);
                list.Add(info3);
                list.Add(info4);
                list.Add(info5);
                list.Add(info6);
            }
            return list;
        }

        private List<ChartInfo> DrawOeeChartWhenEqpGruop(string argument, string areaId, string eqpGruop)
        {
            var list = new List<ChartInfo>();
            foreach (var item in this.bandedGridView1.DataSource as BindingList<UtilInfo>)
            {
                if (argument == "area" && item.ITEM_EqpGroup != "-")
                    continue;

                if (argument == "ws" && (item.ITEM_EqpGroup == "-" || item.ITEM_EqpID != "-" || item.ITEM_AreaID != areaId))
                    continue;

                if (argument == "eqp" && (item.ITEM_EqpID == "-" || item.ITEM_EqpGroup != eqpGruop))
                    continue;

                string arg = argument == "area" ? item.ITEM_AreaID : argument == "ws" ? item.ITEM_EqpGroup : item.ITEM_EqpID;

                //double availabilityEfficiency = (item.PRODUCTIVE_Total + item.STANDBY_Total + item.ENG_Total) / 100;
                //double rateEfficiency = (item.PRODUCTIVE_Total - item.PRODUCTIVE_ReticleSwitch - item.PRODUCTIVE_ChuckSwap) / item.PRODUCTIVE_Total;
                //double performanceEfficiency = (item.PRODUCTIVE_Total / availabilityEfficiency) * rateEfficiency;
                //double qualityEfficiency = (item.PRODUCTIVE_Total - item.PRODUCTIVE_EqpRework - item.PRODUCTIVE_StepRework - item.PRODUCTIVE_StepYieldScrap) / item.PRODUCTIVE_Total;

                double aeLossValue = item.PM_Total + item.BM_Total;
                double oeLossValue = item.STANDBY_Total;
                double erLossValue = item.ENG_Total;
                double reLossValue = item.PRODUCTIVE_ReticleSwitch + item.PRODUCTIVE_ChuckSwap;
                double qeLossValue = item.PRODUCTIVE_EqpRework + item.PRODUCTIVE_StepRework + item.PRODUCTIVE_StepYieldScrap;
                double oeeValue = item.PRODUCTIVE_Total - qeLossValue - reLossValue;

#if true
                var info = new ChartInfo();
                info.ARGUMENT = arg;
                info.DATA = "OEE(%)";
                info.VALUE = oeeValue;

                var info2 = new ChartInfo();
                info2.ARGUMENT = arg;
                info2.DATA = "AE Loss(%)";
                info2.VALUE = aeLossValue;

                var info3 = new ChartInfo();
                info3.ARGUMENT = arg;
                info3.DATA = "OE Loss(%)";
                info3.VALUE = oeLossValue;

                var info4 = new ChartInfo();
                info4.ARGUMENT = arg;
                info4.DATA = "ER Loss(%)";
                info4.VALUE = erLossValue;

                var info5 = new ChartInfo();
                info5.ARGUMENT = arg;
                info5.DATA = "RE Loss(%)";
                info5.VALUE = reLossValue;

                var info6 = new ChartInfo();
                info6.ARGUMENT = arg;
                info6.DATA = "QE Loss(%)";
                info6.VALUE = qeLossValue;
#else
                double total = Math.Abs(oeeValue) + aeLossValue + oeLossValue + reLossValue + qeLossValue;

                var info = new ChartInfo();
                info.ARGUMENT = arg;
                info.DATA = "OEE(%)";
                info.VALUE = oeeValue * 100 / total;

                var info2 = new ChartInfo();
                info2.ARGUMENT = arg;
                info2.DATA = "AE Loss(%)";
                info2.VALUE = aeLossValue * 100 / total;

                var info3 = new ChartInfo();
                info3.ARGUMENT = arg;
                info3.DATA = "OE Loss(%)";
                info3.VALUE = oeLossValue * 100 / total;

                var info4 = new ChartInfo();
                info4.ARGUMENT = arg;
                info4.DATA = "RE Loss(%)";
                info4.VALUE = reLossValue * 100 / total;

                var info5 = new ChartInfo();
                info5.ARGUMENT = arg;
                info5.DATA = "QE Loss(%)";
                info5.VALUE = qeLossValue * 100 / total; 
#endif

                list.Add(info);
                list.Add(info2);
                list.Add(info3);
                list.Add(info4);
                list.Add(info5);
                list.Add(info6);
            }
            return list;
        }

        //private void BandedGridView1_SelectionChanged(object sender, DevExpress.Data.SelectionChangedEventArgs e)
        //{
        //    var list = new List<ChartInfo>();

        //    // Add the selected rows to the list.
        //    Int32[] selectedRowHandles = this.bandedGridView1.GetSelectedRows();
        //    for (int i = 0; i < selectedRowHandles.Length; i++)
        //    {
        //        int handle = selectedRowHandles[i];
        //        if (handle >= 0)
        //        {
        //            var row = this.bandedGridView1.GetRow(handle) as UtilInfo;

        //            var info = new ChartInfo();
        //            info.ARGUMENT = row.ITEM_EqpID;
        //            info.DATA = "UTIL";
        //            info.VALUE = row.BUSY_Total;

        //            list.Add(info);
        //        }
        //    }

        //    this.chartControl1.Series.Clear();
        //    this.chartControl1.DataSource = list;
        //    this.chartControl1.SeriesTemplate.SeriesDataMember = "DATA";
        //    this.chartControl1.SeriesTemplate.ArgumentDataMember = "ARGUMENT";
        //    this.chartControl1.SeriesTemplate.ValueDataMembers.AddRange("VALUE");
        //}

        private void BindEnd()
        {
            this.SetGridControlFields();
            this.gridControl1.EndUpdate();

            this.bandedGridView1.Columns[Type<UtilInfo>.NameOf(x => x.PRODUCTIVE_Total)].AppearanceCell.BackColor =
                Color.FromArgb(230, 255, 255); //ColorTranslator.FromHtml("#01b051");
            this.bandedGridView1.Columns[Type<UtilInfo>.NameOf(x => x.STANDBY_Total)].AppearanceCell.BackColor =
                Color.FromArgb(230, 255, 255); //ColorTranslator.FromHtml("#0167fe");
            this.bandedGridView1.Columns[Type<UtilInfo>.NameOf(x => x.ENG_Total)].AppearanceCell.BackColor =
                Color.FromArgb(230, 255, 255); //Color.Yellow;
            this.bandedGridView1.Columns[Type<UtilInfo>.NameOf(x => x.PM_Total)].AppearanceCell.BackColor =
                Color.FromArgb(230, 255, 255); //ColorTranslator.FromHtml("#cc01ff");
            this.bandedGridView1.Columns[Type<UtilInfo>.NameOf(x => x.BM_Total)].AppearanceCell.BackColor =
                Color.FromArgb(230, 255, 255); //ColorTranslator.FromHtml("#fe0101");

            //this.bandedGridView1.OptionsView.ShowFooter = true;
            //SetFooterSummary();

            this.bandedGridView1.BestFitColumns();

            //this.dockPanel1.Size = new Size(this.dockPanel1.PreferredSize.Width, 300);
        }

        private void BindDo()
        {
            this.gridControl1.DataSource = this.Calculate().ToBindingList();
        }
        #endregion

        private IEnumerable<UtilInfo> Calculate()
        {
            return CalculateNew(this.result.Name);
            //return CalculateObsolete(this.result.Name);
        }

        private IEnumerable<UtilInfo> CalculateNew(string resultName)
        {
            // TODO: 출력에 필요한 테이블이 없거나, 비었을 경우 알림 처리 필요.

            var rslt = this.expDataContext.Result(resultName);
            var equip = this.modelDataContext.EQP.Where(x => string.IsNullOrEmpty(x.PARENT_EQP_ID)).ToList();
            var loadStat = rslt.LOAD_STAT.ToList();
            var qualityLoss = rslt.QUALITY_LOSS.ToList();
            var standbyTime = rslt.STANDBY_TIME.ToList();
            var photoEqpList = rslt.SUMMARY_PHOTO_EQP.ToList();

            var totalDays = Convert.ToDouble(this.result.GetPlanPeriodF());

            Dictionary<DateTime, double> weightLookup = FabSimulatorUI.Helper.GetTargetDateWeightLookup(this.result);
            
            eqpDict = new MultiDictionary<string, EqpDailyStat>();
            foreach (var item in loadStat)
            {
                EqpDailyStat info = new EqpDailyStat(item, weightLookup);

                // 설비별로 그룹핑
                eqpDict.Add(info.EQP_ID, info);
            }

            List<UtilInfo> query = new List<UtilInfo>();
            MultiDictionary<string, UtilInfo> eqpGroupDict = new MultiDictionary<string, UtilInfo>();
            MultiDictionary<string, UtilInfo> areaDict = new MultiDictionary<string, UtilInfo>();
            foreach (var kvp in eqpDict)
            {
                var eqp = equip.Where(x => x.EQP_ID == kvp.Key).FirstOrDefault();
                if (eqp == null)
                    continue;

                var eqpQualityLoss = qualityLoss.Where(x => x.EQP_ID == kvp.Key).ToList();
                var eqpStandbyTime = standbyTime.Where(x => x.EQP_ID == kvp.Key).ToList();
                var eqpSummaryPhotoEqp = photoEqpList.Where(x => x.EQP_ID == kvp.Key).ToList();

                UpdateEqpDailyStatEng(kvp.Value, eqpSummaryPhotoEqp);

                UtilInfo info = new UtilInfo(eqp, kvp.Value, eqpQualityLoss, eqpSummaryPhotoEqp, eqpStandbyTime, this.totalDays);

                query.Add(info);
                eqpGroupDict.Add(eqp.EQP_GROUP, info);
                areaDict.Add(eqp.AREA_ID, info);
            }

            foreach (var kvp in eqpGroupDict)
            {
                UtilInfo info = new UtilInfo(kvp.Value, false);
                query.Add(info);
            }
            foreach (var kvp in areaDict)
            {
                UtilInfo info = new UtilInfo(kvp.Value, true);
                query.Add(info);
            }

            return query.OrderBy(t => t.ITEM_AreaID).ThenBy(t => t.ITEM_EqpGroup).ThenBy(t => t.ITEM_EqpID);
        }

        private void UpdateEqpDailyStatEng(ICollection<EqpDailyStat> dailyStats, List<SUMMARY_PHOTO_EQP> eqpSummaryPhotoEqp)
        {
            foreach (var item in dailyStats)
            {
                var dailySummary = eqpSummaryPhotoEqp.Where(x => x.TARGET_DATE == item.TARGET_DATE).FirstOrDefault();
                if (dailySummary == null)
                    continue;

                var targetDateMinutes = 1440 * item.TARGET_DATE_WEIGHT;

                item.ENGINEERING_TIME = Math.Round(dailySummary.ENG_MIN / targetDateMinutes * 100, 3);
                item.PRODUCTIVE_TIME -= item.ENGINEERING_TIME;
            }
        }

        private void SetGridControlFields()
        {
            this.bandedGridView1.Bands.Clear();
            this.bandedGridView1.OptionsView.ShowGroupPanel = false;

            foreach (BandedGridColumn col in this.bandedGridView1.Columns)
            {
                if (col.FieldName.Contains('_'))
                {
                    var split = col.FieldName.Split('_');

                    var band = this.bandedGridView1.Bands.Where(x => x.Caption == split[0]).FirstOrDefault();

                    if (band == null)
                        band = this.bandedGridView1.Bands.AddBand(split[0]);

                    band.Columns.Add(col);
                    col.Caption = split[1];
                }
                else
                {
                    var band = this.bandedGridView1.Bands.AddBand(col.FieldName);
                    band.Columns.Add(col);
                }
            }
        }

        //private void SetFooterSummary()
        //{
        //    foreach (BandedGridColumn col in this.bandedGridView1.Columns)
        //    {
        //        string name = col.FieldName;

        //        if (name.Contains("Item"))
        //            continue;
        //        else if (name.Contains("Ratio") || name.Contains("Utilization"))
        //            this.bandedGridView1.Columns[name].SummaryItem.SetSummary(DevExpress.Data.SummaryItemType.Average, "{0:#0.00}");
        //        else if (name.Contains("AvgReticlePod"))
        //            this.bandedGridView1.Columns[name].SummaryItem.SetSummary(DevExpress.Data.SummaryItemType.Custom, "{0:#0.00}");
        //        else
        //            this.bandedGridView1.Columns[name].SummaryItem.SetSummary(DevExpress.Data.SummaryItemType.Sum, string.Empty);
        //    }
        //}

        #region Events

        private void btnQuery_Click(object sender, EventArgs e)
        {
            this.Query();
        }
        #endregion

        #region Inner Class

        class ChartInfo
        {
            public string ARGUMENT { get; set; }
            public string DATA { get; set; }
            public double VALUE { get; set; }
        }

        class EqpDailyStat
        {
            public string EQP_ID { get; set; }
            public DateTime TARGET_DATE { get; set; }
            public double TARGET_DATE_WEIGHT { get; set; }
            public double PRODUCTIVE_TIME { get; set; }
            public double STANDBY_TIME { get; set; }
            public double ENGINEERING_TIME { get; set; }
            public double SCHEDULED_DOWNTIME { get; set; }
            public double UNSCHEDULED_DOWNTIME { get; set; }

            public EqpDailyStat(LOAD_STAT loadStat, Dictionary<DateTime, double> weightLookup)
            {
                // ASML Metric에서 사용할 Setup은 PRODUCTIVE_TIME 에 속함.

                EQP_ID = loadStat.EQP_ID;
                TARGET_DATE = loadStat.TARGET_DATE;
                TARGET_DATE_WEIGHT = weightLookup.ContainsKey(TARGET_DATE) ? weightLookup[TARGET_DATE] : 1; // StartDay, EndDay Adjustment
                PRODUCTIVE_TIME = loadStat.BUSY + loadStat.SETUP; // - EngineeringTime （SUMMARY_PHOTO_EQP로 집계하여 후처리)
                STANDBY_TIME = loadStat.IDLE + loadStat.IDLERUN;
                //ENGINEERING_TIME = 0;
                SCHEDULED_DOWNTIME = loadStat.PM;
                UNSCHEDULED_DOWNTIME = loadStat.BM;
            }
        }

        class UtilInfo
        {
            public string ITEM_AreaID { get; set; }
            public string ITEM_EqpGroup { get; set; }
            public string ITEM_EqpID { get; set; }
            public string ITEM_SimType { get; set; }

            public double PRODUCTIVE_Total { get; set; }
            public double PRODUCTIVE_EqpRework { get; set; }
            public double PRODUCTIVE_StepRework { get; set; }
            public double PRODUCTIVE_StepYieldScrap { get; set; }
            public double PRODUCTIVE_ReticleSwitch { get; set; }
            public double PRODUCTIVE_ChuckSwap { get; set; }
            public double STANDBY_Total { get; set; }
            public double STANDBY_NoWip { get; set; }
            public double STANDBY_WaitForReticle { get; set; }
            public double STANDBY_WaitForEngineer { get; set; }
            public double STANDBY_NoReason { get; set; }
            public double ENG_Total { get; set; }
            public double PM_Total { get; set; }
            public double BM_Total { get; set; }

            public UtilInfo(EQP eqp, ICollection<EqpDailyStat> loadStatValues, ICollection<QUALITY_LOSS> qualityLossValues,
                ICollection<SUMMARY_PHOTO_EQP> photoEqpLossValues, ICollection<STANDBY_TIME> standbyTimeValues, double totalDays)
            {
                ITEM_AreaID = eqp.AREA_ID;
                ITEM_EqpGroup = eqp.EQP_GROUP;
                ITEM_EqpID = eqp.EQP_ID;
                ITEM_SimType = eqp.SIM_TYPE;

                var totalHours = totalDays * 24.0;
                var totalMinutes = totalHours * 60.0;

                PRODUCTIVE_Total = Math.Round(loadStatValues.Select(x => x.PRODUCTIVE_TIME * x.TARGET_DATE_WEIGHT).Sum() / totalDays, 2);
                STANDBY_Total = Math.Round(loadStatValues.Select(x => x.STANDBY_TIME * x.TARGET_DATE_WEIGHT).Sum() / totalDays, 2);
                ENG_Total = Math.Round(loadStatValues.Select(x => x.ENGINEERING_TIME * x.TARGET_DATE_WEIGHT).Sum() / totalDays, 2);
                PM_Total = Math.Round(loadStatValues.Select(x => x.SCHEDULED_DOWNTIME * x.TARGET_DATE_WEIGHT).Sum() / totalDays, 2);
                BM_Total = Math.Round(loadStatValues.Select(x => x.UNSCHEDULED_DOWNTIME * x.TARGET_DATE_WEIGHT).Sum() / totalDays, 2);

                PRODUCTIVE_EqpRework = Math.Round(qualityLossValues.Where(x => x.LOSS_REASON == "EQP_REWORK")
                    .Select(x => x.LOSS_HRS).Sum() * 100 / totalHours, 2);
                PRODUCTIVE_StepRework = Math.Round(qualityLossValues.Where(x => x.LOSS_REASON == "STEP_REWORK" || x.LOSS_REASON == "BOH_REWORK")
                    .Select(x => x.LOSS_HRS).Sum() * 100 / totalHours, 2);
                PRODUCTIVE_StepYieldScrap = Math.Round(qualityLossValues.Where(x => x.LOSS_REASON == "STEP_YIELD_SCRAP")
                    .Select(x => x.LOSS_HRS).Sum() * 100 / totalHours, 2);

                PRODUCTIVE_ReticleSwitch = Math.Round(photoEqpLossValues.Select(x => x.RETICLE_MIN).Sum() * 100 / totalMinutes, 2);
                PRODUCTIVE_ChuckSwap = Math.Round(photoEqpLossValues.Select(x => x.CHUCK_MIN).Sum() * 100 / totalMinutes, 2);

                STANDBY_NoWip = Math.Round(standbyTimeValues.Where(x => x.IDLE_CODE == "NoWip")
                    .Select(x => x.IDLE_MIN).Sum() * 100 / totalMinutes, 2);
                STANDBY_WaitForReticle = Math.Round(standbyTimeValues.Where(x => x.IDLE_CODE == "WaitForReticle")
                    .Select(x => x.IDLE_MIN).Sum() * 100 / totalMinutes, 2);
                STANDBY_WaitForEngineer = Math.Round(standbyTimeValues.Where(x => x.IDLE_CODE == "WaitForEngineer")
                    .Select(x => x.IDLE_MIN).Sum() * 100 / totalMinutes, 2);
                STANDBY_NoReason = Math.Round(standbyTimeValues.Where(x => x.IDLE_CODE == "NoReason")
                    .Select(x => x.IDLE_MIN).Sum() * 100 / totalMinutes, 2);
            }

            public UtilInfo(ICollection<UtilInfo> utilInfoValues, bool isArea)
            {
                ITEM_AreaID = utilInfoValues.First().ITEM_AreaID;
                ITEM_EqpGroup = isArea ? "-" : utilInfoValues.First().ITEM_EqpGroup;
                ITEM_EqpID = "-";
                ITEM_SimType = "-";

                PRODUCTIVE_Total = Math.Round(utilInfoValues.Select(x => x.PRODUCTIVE_Total).Average(), 2);
                STANDBY_Total = Math.Round(utilInfoValues.Select(x => x.STANDBY_Total).Average(), 2);

                ENG_Total = Math.Round(utilInfoValues.Select(x => x.ENG_Total).Average(), 2);
                PM_Total = Math.Round(utilInfoValues.Select(x => x.PM_Total).Average(), 2);
                BM_Total = Math.Round(utilInfoValues.Select(x => x.BM_Total).Average(), 2);

                PRODUCTIVE_EqpRework = Math.Round(utilInfoValues.Select(x => x.PRODUCTIVE_EqpRework).Average(), 2);
                PRODUCTIVE_StepRework = Math.Round(utilInfoValues.Select(x => x.PRODUCTIVE_StepRework).Average(), 2);
                PRODUCTIVE_StepYieldScrap = Math.Round(utilInfoValues.Select(x => x.PRODUCTIVE_StepYieldScrap).Average(), 2);

                PRODUCTIVE_ReticleSwitch = Math.Round(utilInfoValues.Select(x => x.PRODUCTIVE_ReticleSwitch).Average(), 2);
                PRODUCTIVE_ChuckSwap = Math.Round(utilInfoValues.Select(x => x.PRODUCTIVE_ChuckSwap).Average(), 2);

                STANDBY_NoWip = Math.Round(utilInfoValues.Select(x => x.STANDBY_NoWip).Average(), 2);
                STANDBY_WaitForReticle = Math.Round(utilInfoValues.Select(x => x.STANDBY_WaitForReticle).Average(), 2);
                STANDBY_WaitForEngineer = Math.Round(utilInfoValues.Select(x => x.STANDBY_WaitForEngineer).Average(), 2);
                STANDBY_NoReason = Math.Round(utilInfoValues.Select(x => x.STANDBY_NoReason).Average(), 2);
            }
        }
        #endregion

        private void bandedGridView1_RowStyle(object sender, RowStyleEventArgs e)
        {
            if (this.bandedGridView1.Columns.Count == 0)
                return;

            string ws = bandedGridView1.GetRowCellDisplayText(e.RowHandle, bandedGridView1.Columns["ITEM_EqpGroup"]);
            string eqpId = bandedGridView1.GetRowCellDisplayText(e.RowHandle, bandedGridView1.Columns["ITEM_EqpID"]);

            if (eqpId == "-")
            {
                if (ws == "-")
                    e.Appearance.BackColor = Color.FromArgb(150, 255, 150);
                else
                    e.Appearance.BackColor = Color.FromArgb(230, 255, 230);
            }
        }

        private void chartControl1_BoundDataChanged(object sender, EventArgs e)
        {
            if (this.chartControl1.Diagram == null)
                return;

            SecondaryAxisY myAxisY = new SecondaryAxisY("my Y-Axis");
            ((XYDiagram)chartControl1.Diagram).SecondaryAxesY.Clear();
            ((XYDiagram)chartControl1.Diagram).SecondaryAxesY.Add(myAxisY);

            var util = ((ChartControl)sender).Series.Where(x => x.Name.Contains("%"));
            var tat = ((ChartControl)sender).Series.Where(x => x.Name.Contains("TAT"));

            foreach (Series s in util)
            {
                s.ChangeView(ViewType.StackedBar);

                StackedBarSeriesView view = (StackedBarSeriesView)s.View;
                //view.Transparency = 40;
                if (s.Name == "PRODUCTIVE TIME(%)")
                    view.Color = ColorTranslator.FromHtml("#01b051");
                else if (s.Name == "STANDBY TIME(%)")
                    view.Color = ColorTranslator.FromHtml("#0167fe");
                else if (s.Name == "ENGINEERING TIME(%)")
                    view.Color = Color.Yellow;
                else if (s.Name == "SCHEDULED DOWNTIME(%)")
                    view.Color = ColorTranslator.FromHtml("#cc01ff");
                else if (s.Name == "UNSCHEDULED DOWNTIME(%)")
                    view.Color = ColorTranslator.FromHtml("#fe0101");
            }

            foreach (Series s in tat)
            {
                s.ChangeView(ViewType.Line);

                LineSeriesView view = (LineSeriesView)s.View;
                view.AxisY = myAxisY;
            }
        }

        private void chartControl2_BoundDataChanged(object sender, EventArgs e)
        {
            if (this.chartControl2.Diagram == null)
                return;

            SecondaryAxisY myAxisY = new SecondaryAxisY("my Y-Axis");
            ((XYDiagram)chartControl2.Diagram).SecondaryAxesY.Clear();
            ((XYDiagram)chartControl2.Diagram).SecondaryAxesY.Add(myAxisY);

            var series = ((ChartControl)sender).Series;

            foreach (Series s in series)
            {
                StackedBarSeriesView view = (StackedBarSeriesView)s.View;

                if (s.Name == "OEE(%)")
                    view.Color = ColorTranslator.FromHtml("#01b051"); // DarkGreen
                else if (s.Name == "AE Loss(%)")
                    view.Color = ColorTranslator.FromHtml("#fe0101"); // Red
                else if (s.Name == "OE Loss(%)") 
                    view.Color = ColorTranslator.FromHtml("#0167fe"); // Blue
                else if (s.Name == "ER Loss(%)")
                    view.Color = Color.Yellow;
                else if (s.Name == "RE Loss(%)")
                    view.Color = Color.LightGreen;
                else if (s.Name == "QE Loss(%)")
                    view.Color = Color.Orange;
            }
        }
    }
}