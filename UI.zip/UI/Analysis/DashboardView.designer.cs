﻿namespace FabSimulatorUI.Analysis
{
    partial class DashboardView
    {
        /// <summary> 
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 구성 요소 디자이너에서 생성한 코드

        /// <summary> 
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>        
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            DevExpress.XtraCharts.XYDiagram xyDiagram1 = new DevExpress.XtraCharts.XYDiagram();
            DevExpress.XtraCharts.Series series1 = new DevExpress.XtraCharts.Series();
            DevExpress.XtraCharts.XYDiagram xyDiagram2 = new DevExpress.XtraCharts.XYDiagram();
            DevExpress.XtraCharts.Series series2 = new DevExpress.XtraCharts.Series();
            DevExpress.XtraCharts.XYDiagram xyDiagram3 = new DevExpress.XtraCharts.XYDiagram();
            DevExpress.XtraCharts.Series series3 = new DevExpress.XtraCharts.Series();
            panelControl1 = new DevExpress.XtraEditors.PanelControl();
            xtraTabControl1 = new DevExpress.XtraTab.XtraTabControl();
            xtraTabPage1 = new DevExpress.XtraTab.XtraTabPage();
            chartControl1 = new DevExpress.XtraCharts.ChartControl();
            xtraTabPage2 = new DevExpress.XtraTab.XtraTabPage();
            chartControl2 = new DevExpress.XtraCharts.ChartControl();
            xtraTabPage3 = new DevExpress.XtraTab.XtraTabPage();
            chartControl3 = new DevExpress.XtraCharts.ChartControl();
            expandablePanel1 = new Mozart.Studio.UIComponents.ExpandablePanel();
            label4 = new Label();
            resultCheckCtl = new DevExpress.XtraEditors.CheckedComboBoxEdit();
            label2 = new Label();
            radioGroup1 = new DevExpress.XtraEditors.RadioGroup();
            button1 = new Button();
            comboBoxEdit1 = new DevExpress.XtraEditors.ComboBoxEdit();
            endDateTimePicker = new Mozart.Studio.UIComponents.FullDateTimePicker();
            startDateTimePicker = new Mozart.Studio.UIComponents.FullDateTimePicker();
            label3 = new Label();
            label1 = new Label();
            dockManager1 = new DevExpress.XtraBars.Docking.DockManager(components);
            ((System.ComponentModel.ISupportInitialize)panelControl1).BeginInit();
            panelControl1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)xtraTabControl1).BeginInit();
            xtraTabControl1.SuspendLayout();
            xtraTabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)chartControl1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)xyDiagram1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)series1).BeginInit();
            xtraTabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)chartControl2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)xyDiagram2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)series2).BeginInit();
            xtraTabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)chartControl3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)xyDiagram3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)series3).BeginInit();
            expandablePanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)resultCheckCtl.Properties).BeginInit();
            ((System.ComponentModel.ISupportInitialize)radioGroup1.Properties).BeginInit();
            ((System.ComponentModel.ISupportInitialize)comboBoxEdit1.Properties).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dockManager1).BeginInit();
            SuspendLayout();
            // 
            // panelControl1
            // 
            panelControl1.Controls.Add(xtraTabControl1);
            panelControl1.Controls.Add(expandablePanel1);
            panelControl1.Dock = DockStyle.Fill;
            panelControl1.Location = new Point(0, 0);
            panelControl1.Margin = new Padding(3, 4, 3, 4);
            panelControl1.Name = "panelControl1";
            panelControl1.Size = new Size(1464, 613);
            panelControl1.TabIndex = 0;
            // 
            // xtraTabControl1
            // 
            xtraTabControl1.Dock = DockStyle.Fill;
            xtraTabControl1.Location = new Point(2, 93);
            xtraTabControl1.Margin = new Padding(3, 4, 3, 4);
            xtraTabControl1.Name = "xtraTabControl1";
            xtraTabControl1.SelectedTabPage = xtraTabPage1;
            xtraTabControl1.Size = new Size(1460, 518);
            xtraTabControl1.TabIndex = 2;
            xtraTabControl1.TabPages.AddRange(new DevExpress.XtraTab.XtraTabPage[] { xtraTabPage1, xtraTabPage2, xtraTabPage3 });
            xtraTabControl1.SelectedPageChanged += XtraTabControl1_SelectedPageChanged;
            // 
            // xtraTabPage1
            // 
            xtraTabPage1.Controls.Add(chartControl1);
            xtraTabPage1.Margin = new Padding(3, 4, 3, 4);
            xtraTabPage1.Name = "xtraTabPage1";
            xtraTabPage1.Size = new Size(1458, 486);
            xtraTabPage1.Text = "xtraTabPage1";
            // 
            // chartControl1
            // 
            xyDiagram1.AxisX.VisibleInPanesSerializable = "-1";
            xyDiagram1.AxisY.VisibleInPanesSerializable = "-1";
            chartControl1.Diagram = xyDiagram1;
            chartControl1.Dock = DockStyle.Fill;
            chartControl1.Legend.LegendID = -1;
            chartControl1.Legend.Name = "Default Legend";
            chartControl1.Location = new Point(0, 0);
            chartControl1.Margin = new Padding(3, 4, 3, 4);
            chartControl1.Name = "chartControl1";
            series1.Name = "Series 1";
            series1.SeriesID = 0;
            chartControl1.SeriesSerializable = new DevExpress.XtraCharts.Series[]
    {
    series1
    };
            chartControl1.Size = new Size(1458, 486);
            chartControl1.TabIndex = 0;
            chartControl1.BoundDataChanged += ChartControl1_BoundDataChanged;
            // 
            // xtraTabPage2
            // 
            xtraTabPage2.Controls.Add(chartControl2);
            xtraTabPage2.Margin = new Padding(3, 4, 3, 4);
            xtraTabPage2.Name = "xtraTabPage2";
            xtraTabPage2.Size = new Size(1458, 486);
            xtraTabPage2.Text = "xtraTabPage2";
            // 
            // chartControl2
            // 
            xyDiagram2.AxisX.VisibleInPanesSerializable = "-1";
            xyDiagram2.AxisY.VisibleInPanesSerializable = "-1";
            chartControl2.Diagram = xyDiagram2;
            chartControl2.Dock = DockStyle.Fill;
            chartControl2.Legend.LegendID = -1;
            chartControl2.Legend.Name = "Default Legend";
            chartControl2.Location = new Point(0, 0);
            chartControl2.Margin = new Padding(3, 4, 3, 4);
            chartControl2.Name = "chartControl2";
            series2.Name = "Series 1";
            series2.SeriesID = 0;
            chartControl2.SeriesSerializable = new DevExpress.XtraCharts.Series[]
    {
    series2
    };
            chartControl2.Size = new Size(1458, 486);
            chartControl2.TabIndex = 0;
            chartControl2.BoundDataChanged += ChartControl2_BoundDataChanged;
            // 
            // xtraTabPage3
            // 
            xtraTabPage3.Controls.Add(chartControl3);
            xtraTabPage3.Margin = new Padding(3, 4, 3, 4);
            xtraTabPage3.Name = "xtraTabPage3";
            xtraTabPage3.Size = new Size(1458, 486);
            xtraTabPage3.Text = "xtraTabPage3";
            // 
            // chartControl3
            // 
            xyDiagram3.AxisX.VisibleInPanesSerializable = "-1";
            xyDiagram3.AxisY.VisibleInPanesSerializable = "-1";
            chartControl3.Diagram = xyDiagram3;
            chartControl3.Dock = DockStyle.Fill;
            chartControl3.Legend.LegendID = -1;
            chartControl3.Legend.Name = "Default Legend";
            chartControl3.Location = new Point(0, 0);
            chartControl3.Margin = new Padding(3, 4, 3, 4);
            chartControl3.Name = "chartControl3";
            series3.Name = "Series 1";
            series3.SeriesID = 0;
            chartControl3.SeriesSerializable = new DevExpress.XtraCharts.Series[]
    {
    series3
    };
            chartControl3.Size = new Size(1458, 486);
            chartControl3.TabIndex = 0;
            chartControl3.BoundDataChanged += ChartControl3_BoundDataChanged;
            // 
            // expandablePanel1
            // 
            expandablePanel1.Controls.Add(label4);
            expandablePanel1.Controls.Add(resultCheckCtl);
            expandablePanel1.Controls.Add(label2);
            expandablePanel1.Controls.Add(radioGroup1);
            expandablePanel1.Controls.Add(button1);
            expandablePanel1.Controls.Add(comboBoxEdit1);
            expandablePanel1.Controls.Add(endDateTimePicker);
            expandablePanel1.Controls.Add(startDateTimePicker);
            expandablePanel1.Controls.Add(label3);
            expandablePanel1.Controls.Add(label1);
            expandablePanel1.Dock = DockStyle.Top;
            expandablePanel1.ForeColor = Color.SteelBlue;
            expandablePanel1.Location = new Point(2, 2);
            expandablePanel1.Margin = new Padding(3, 4, 3, 4);
            expandablePanel1.Name = "expandablePanel1";
            expandablePanel1.Size = new Size(1460, 91);
            expandablePanel1.TabIndex = 0;
            expandablePanel1.Text = "Simulation Dashboard";
            expandablePanel1.UseAnimation = true;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(958, 54);
            label4.Name = "label4";
            label4.Size = new Size(63, 18);
            label4.TabIndex = 85;
            label4.Text = "NXT Set";
            // 
            // resultCheckCtl
            // 
            resultCheckCtl.Location = new Point(87, 50);
            resultCheckCtl.Margin = new Padding(3, 4, 3, 4);
            resultCheckCtl.Name = "resultCheckCtl";
            resultCheckCtl.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] { new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo) });
            resultCheckCtl.Size = new Size(143, 24);
            resultCheckCtl.TabIndex = 72;
            resultCheckCtl.EditValueChanged += resultCheckCtl_EditValueChanged;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(29, 54);
            label2.Name = "label2";
            label2.Size = new Size(54, 18);
            label2.TabIndex = 71;
            label2.Text = "Results";
            // 
            // radioGroup1
            // 
            radioGroup1.Location = new Point(686, 45);
            radioGroup1.Margin = new Padding(3, 4, 3, 4);
            radioGroup1.Name = "radioGroup1";
            radioGroup1.Properties.Columns = 3;
            radioGroup1.Properties.GlyphAlignment = DevExpress.Utils.HorzAlignment.Default;
            radioGroup1.Properties.Items.AddRange(new DevExpress.XtraEditors.Controls.RadioGroupItem[] { new DevExpress.XtraEditors.Controls.RadioGroupItem(null, "Monthly", true, null, "radio_monthly"), new DevExpress.XtraEditors.Controls.RadioGroupItem(null, "Weekly", true, null, "radio_weekly"), new DevExpress.XtraEditors.Controls.RadioGroupItem(null, "Daily", true, null, "radio_daily") });
            radioGroup1.Size = new Size(257, 37);
            radioGroup1.TabIndex = 84;
            radioGroup1.SelectedIndexChanged += radioGroup1_SelectedIndexChanged;
            // 
            // button1
            // 
            button1.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            button1.Location = new Point(1359, 46);
            button1.Margin = new Padding(3, 4, 3, 4);
            button1.Name = "button1";
            button1.Size = new Size(86, 30);
            button1.TabIndex = 83;
            button1.Text = "QUERY";
            button1.UseVisualStyleBackColor = true;
            button1.Click += Button1_Click;
            // 
            // comboBoxEdit1
            // 
            comboBoxEdit1.Location = new Point(1025, 50);
            comboBoxEdit1.Margin = new Padding(3, 4, 3, 4);
            comboBoxEdit1.Name = "comboBoxEdit1";
            comboBoxEdit1.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] { new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo) });
            comboBoxEdit1.Size = new Size(121, 24);
            comboBoxEdit1.TabIndex = 4;
            comboBoxEdit1.SelectedValueChanged += ComboBoxEdit1_SelectedValueChanged;
            // 
            // endDateTimePicker
            // 
            endDateTimePicker.Location = new Point(543, 49);
            endDateTimePicker.Margin = new Padding(3, 8, 3, 8);
            endDateTimePicker.Name = "endDateTimePicker";
            endDateTimePicker.Size = new Size(136, 26);
            endDateTimePicker.TabIndex = 81;
            endDateTimePicker.TimeFormat = Mozart.Studio.UIComponents.FullDateTimePickerTimeFormat.Hidden;
            endDateTimePicker.UTCPrompt = null;
            // 
            // startDateTimePicker
            // 
            startDateTimePicker.Location = new Point(323, 49);
            startDateTimePicker.Margin = new Padding(3, 6, 3, 6);
            startDateTimePicker.Name = "startDateTimePicker";
            startDateTimePicker.Size = new Size(136, 26);
            startDateTimePicker.TabIndex = 80;
            startDateTimePicker.TimeFormat = Mozart.Studio.UIComponents.FullDateTimePickerTimeFormat.Hidden;
            startDateTimePicker.UTCPrompt = null;
            startDateTimePicker.ValueChanged += startDateTimePicker_ValueChanged;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(469, 54);
            label3.Name = "label3";
            label3.Size = new Size(70, 18);
            label3.TabIndex = 76;
            label3.Text = "End Time";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(242, 54);
            label1.Name = "label1";
            label1.Size = new Size(77, 18);
            label1.TabIndex = 74;
            label1.Text = "Start Time";
            // 
            // dockManager1
            // 
            dockManager1.Form = this;
            dockManager1.TopZIndexControls.AddRange(new string[] { "DevExpress.XtraBars.BarDockControl", "DevExpress.XtraBars.StandaloneBarDockControl", "System.Windows.Forms.StatusBar", "System.Windows.Forms.MenuStrip", "System.Windows.Forms.StatusStrip", "DevExpress.XtraBars.Ribbon.RibbonStatusBar", "DevExpress.XtraBars.Ribbon.RibbonControl", "DevExpress.XtraBars.Navigation.OfficeNavigationBar", "DevExpress.XtraBars.Navigation.TileNavPane" });
            // 
            // DashboardView
            // 
            AutoScaleDimensions = new SizeF(8F, 18F);
            AutoScaleMode = AutoScaleMode.Font;
            Controls.Add(panelControl1);
            Margin = new Padding(3, 4, 3, 4);
            Name = "DashboardView";
            Size = new Size(1464, 613);
            ((System.ComponentModel.ISupportInitialize)panelControl1).EndInit();
            panelControl1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)xtraTabControl1).EndInit();
            xtraTabControl1.ResumeLayout(false);
            xtraTabPage1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)xyDiagram1).EndInit();
            ((System.ComponentModel.ISupportInitialize)series1).EndInit();
            ((System.ComponentModel.ISupportInitialize)chartControl1).EndInit();
            xtraTabPage2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)xyDiagram2).EndInit();
            ((System.ComponentModel.ISupportInitialize)series2).EndInit();
            ((System.ComponentModel.ISupportInitialize)chartControl2).EndInit();
            xtraTabPage3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)xyDiagram3).EndInit();
            ((System.ComponentModel.ISupportInitialize)series3).EndInit();
            ((System.ComponentModel.ISupportInitialize)chartControl3).EndInit();
            expandablePanel1.ResumeLayout(false);
            expandablePanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)resultCheckCtl.Properties).EndInit();
            ((System.ComponentModel.ISupportInitialize)radioGroup1.Properties).EndInit();
            ((System.ComponentModel.ISupportInitialize)comboBoxEdit1.Properties).EndInit();
            ((System.ComponentModel.ISupportInitialize)dockManager1).EndInit();
            ResumeLayout(false);
        }

        #endregion

        /// <summary>   The first panel control. </summary>
        private DevExpress.XtraEditors.PanelControl panelControl1;
        /// <summary>   The first expandable panel. </summary>
        private Mozart.Studio.UIComponents.ExpandablePanel expandablePanel1;
        /// <summary>   The first dock manager. </summary>
        private DevExpress.XtraBars.Docking.DockManager dockManager1;
        /// <summary>   The label 1 control. </summary>
        private System.Windows.Forms.Label label1;
        /// <summary>   The label 3 control. </summary>
        private System.Windows.Forms.Label label3;
        /// <summary>   The end date time picker. </summary>
        private Mozart.Studio.UIComponents.FullDateTimePicker endDateTimePicker;
        /// <summary>   The start date time picker. </summary>
        private Mozart.Studio.UIComponents.FullDateTimePicker startDateTimePicker;
        /// <summary>   The first xtra tab control. </summary>
        private DevExpress.XtraTab.XtraTabControl xtraTabControl1;
        private DevExpress.XtraEditors.ComboBoxEdit comboBoxEdit1;
        private DevExpress.XtraTab.XtraTabPage xtraTabPage1;
        private DevExpress.XtraCharts.ChartControl chartControl1;
        private DevExpress.XtraTab.XtraTabPage xtraTabPage2;
        private DevExpress.XtraCharts.ChartControl chartControl2;
        private DevExpress.XtraTab.XtraTabPage xtraTabPage3;
        private DevExpress.XtraCharts.ChartControl chartControl3;
        private System.Windows.Forms.Button button1;
        private DevExpress.XtraEditors.RadioGroup radioGroup1;
        private DevExpress.XtraEditors.CheckedComboBoxEdit resultCheckCtl;
        private Label label2;
        private Label label4;
    }
}
