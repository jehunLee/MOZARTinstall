﻿using DevExpress.XtraCharts;
using DevExpress.XtraEditors;
using DevExpress.XtraGrid.Views.Grid;
using FabSimulator;
using FabSimulator.Inputs;
using FabSimulator.Outputs;
using FabSimulatorUI.Common;
using FabSimulatorUI.DataMappings;
using Mozart.Studio.TaskModel.Projects;
using Mozart.Studio.TaskModel.UserInterface;
using Mozart.Studio.TaskModel.UserLibrary;
using System.Data;

namespace FabSimulatorUI.Analysis
{
    public partial class PeggingResultView : XtraGridTemplate
    {
        #region Variable

        List<PeggingResultItem> _query;
        Dictionary<string, double> ctLabelPoints = new Dictionary<string, double>();
        Dictionary<string, double> pegLabelPoints = new Dictionary<string, double>();
        ColorGenerator colorGen = new ColorGenerator();
        //XtraChartHandler ChartHandler;

        #endregion

        #region Ctor

        public PeggingResultView()
        {
            InitializeComponent();
        }

        public PeggingResultView(IServiceProvider service) : base(service)
        {
            InitializeComponent();
        }

        #endregion

        #region LoadDocument

        protected override void LoadDocument()
        {
            base.LoadDocument();
            Globals.InitFactoryTime(this.Result);
            SetControls();
        }

        #endregion

        #region Control

        private void SetControls()
        {
            SetInitializeOption(gridControl1);
            SetGridView(this.MainGridView);
            AddExtendGridMenu(this.MainGridView);
            SetChartControl(chartControl);
            SetProductCombo(editProduct);
            this.editScale2.EditValue = 10; //default 
        }

        private void SetGridView(GridView view)
        {
            SetGridLayout(view);
            view.DoubleClick += View_DoubleClick;
            view.DataSourceChanged += View_DataSourceChanged;
            view.OptionsBehavior.Editable = false;
            view.OptionsView.ColumnAutoWidth = false;
            view.OptionsSelection.MultiSelect = true;
            view.OptionsSelection.MultiSelectMode = GridMultiSelectMode.RowSelect;
        }

        private void SetChartControl(ChartControl chartControl)
        {
            chartControl.AutoLayout = false;
            chartControl.CustomDrawSeriesPoint += ChartControl_CustomDrawSeriesPoint;
            chartControl.CustomDrawCrosshair += ChartControl_CustomDrawCrosshair;
            chartControl.ObjectSelected += ChartControl_ObjectSelected;
            SetDiagram(chartControl);
            //this.ChartHandler = new XtraChartHandler(this.chartControl, this.GetLayoutFullPath(gridView1));
            //this.ChartHandler.SetChartOptions();
        }

        private void SetDiagram(ChartControl chartControl)
        {
            XYDiagram xyDiagram = chartControl.Diagram as XYDiagram;
            xyDiagram.AxisX.Label.ResolveOverlappingOptions.AllowHide = false;
            xyDiagram.AxisX.QualitativeScaleOptions.AutoGrid = false;
            xyDiagram.AxisX.QualitativeScaleComparer = null;
            xyDiagram.AxisX.NumericScaleOptions.AutoGrid = false;
            xyDiagram.AxisX.Label.Angle = 90;
            xyDiagram.AxisX.WholeRange.SideMarginsValue = PeggingResultMap.Caption.SIDE_MARGIN_VALUE;
            xyDiagram.EnableAxisXScrolling = false;
            xyDiagram.EnableAxisYScrolling = true;

            xyDiagram.PaneLayout.AutoLayoutMode = PaneAutoLayoutMode.Grid;
            xyDiagram.PaneLayout.RowDefinitions.Add(new LayoutDefinition { SizeMode = PaneSizeMode.UseWeight, Weight = 1 });
            xyDiagram.PaneLayout.RowDefinitions.Add(new LayoutDefinition { SizeMode = PaneSizeMode.UseSizeInPixels, SizeInPixels = 40 });
            xyDiagram.PaneLayout.RowDefinitions.Add(new LayoutDefinition { SizeMode = PaneSizeMode.UseSizeInPixels, SizeInPixels = 40 });
            xyDiagram.PaneDistance = 5;
        }

        private void SetProductCombo(DevExpress.XtraBars.BarEditItem combo)
        {
            if (editProduct == null)
                return;

            var demands = Globals.GetEntityData<DEMAND>(Result);
            var products = demands.Select(x => x.PRODUCT_ID).Distinct().OrderBy(x => x);
            combo.EditValue = products.FirstOrDefault();
            foreach (var product in products)
            {
                repositoryItemComboBox1.Items.Add(product);
            }
        }

        #endregion

        #region Query&Bind

        protected override void Query()
        {
            using (var waitDlg = new WaitDialog())
            {
                DataTable dt = GetData();
                BindData(dt);
            }
        }

        protected override DataTable GetData()
        {
            int scaleCollapsed = Convert.ToInt32(this.editScale2.EditValue);

            if (scaleCollapsed < 1)
                return null;

            var planStartTime = Result.StartTime;
            var planStartWeek = DateUtility.WeekNoOfYearTF(planStartTime);
            var theProduct = this.editProduct.EditValue.ToString();

            double sum = 0;

            var stdsteps = from a in Globals.GetEntityData<ROUTE_STEP>(Result)
                           join b in Globals.GetEntityData<PRODUCT>(Result).Where(t => t.PRODUCT_ID == theProduct) on a.ROUTE_ID equals b.ROUTE_ID
                           select new
                           {
                               b.PRODUCT_ID,
                               a.ROUTE_ID,
                               a.STEP_ID,
                               a.STEP_SEQ,
                               a.POT_DAYS
                           };

            ModelDataContext modelDataContext = this.Document.GetCtx<ModelDataContext>();
            var wipConfig = modelDataContext.GetConfigValue<string>(PARAM_GROUP: "Lot_Wip", PARAM_NAME: "useWIP");

            bool useWIP = wipConfig == null || wipConfig != "N";

            var wip = from a in Globals.GetEntityData<WIP>(Result)
                      group a by new { a.ROUTE_ID, a.STEP_ID } into g
                      select new
                      {
                          g.Key.ROUTE_ID,
                          g.Key.STEP_ID,
                          Qty = useWIP ? g.Sum(t => t.WAFER_QTY) : 0
                      };

            var peg = from a in Globals.GetEntityData<PEG_HISTORY>(Result)
                      group a by new { a.PRODUCT_ID, a.STEP_ID } into g
                      select new
                      {
                          g.Key.PRODUCT_ID,
                          g.Key.STEP_ID,
                          MO_DUE_DATE = g.Min(t => t.MO_DUE_DATE),
                          TARGET_DATE = g.Min(t => t.TARGET_DATE),
                      };

            int pegWeek = GetMoWeek(planStartWeek, theProduct);

            var result = from a in stdsteps.OrderByDescending(t => t.STEP_SEQ)
                         join b in peg on new { a.PRODUCT_ID, a.STEP_ID } equals new { b.PRODUCT_ID, b.STEP_ID } into outer
                         join c in wip on new { a.ROUTE_ID, a.STEP_ID } equals new { c.ROUTE_ID, c.STEP_ID } into outer2
                         from o in outer.DefaultIfEmpty()
                         from o2 in outer2.DefaultIfEmpty()
                         select new
                         {
                             a.PRODUCT_ID,
                             a.STEP_ID,
                             a.STEP_SEQ,
                             QTY = o2 == null ? 0 : o2.Qty,
                             CT_WEEK = DateUtility.DiffWeekNo(planStartWeek, DateUtility.WeekNoOfYearTF(planStartTime.AddDays(a.POT_DAYS))),
                             PEG_WEEK = o == null ? pegWeek : pegWeek = DateUtility.DiffWeekNo(planStartWeek, DateUtility.WeekNoOfYearTF(o.MO_DUE_DATE)),
                             Scale = a.STEP_SEQ / scaleCollapsed
                         };

            var query = from a in result.OrderBy(t => t.STEP_SEQ)
                        group a by new { a.Scale } into g
                        let f = g.First()
                        select new PeggingResultItem
                        {
                            PRODUCT_ID = f.PRODUCT_ID,
                            STEP_ID = f.STEP_ID,
                            STEP_SEQ = f.STEP_SEQ,
                            QTY = g.Sum(t => t.QTY),
                            CT_WEEK = f.CT_WEEK,
                            PEG_WEEK = f.PEG_WEEK,
                            steps = String.Join(",", g.Select(t => t.STEP_ID))
                        };

            _query = query.OrderBy(t => t.STEP_SEQ).ToList();
            DataTable dt = CreateDataViewSchema();
            for (int i = 0; i < _query.Count; i++)
            {
                var item = _query[i];
                for (int j = _query.Count - 1; j > i; j--)
                {
                    if ((item.PEG_WEEK < _query[j].PEG_WEEK))
                    {
                        item.PEG_WEEK = _query[j].PEG_WEEK;
                        break;
                    }
                }
                dt.Rows.Add(item.PRODUCT_ID, item.STEP_ID, item.STEP_SEQ, item.QTY, item.CT_WEEK, item.PEG_WEEK);
            }
            return dt;
        }

        private int GetMoWeek(string planStartWeek, string theProduct)
        {
            var demands = Globals.GetEntityData<DEMAND>(Result).Where(t => t.PRODUCT_ID == theProduct);
            if (demands.Count() == 0)
                return int.MinValue;

            int moWeek = DateUtility.DiffWeekNo(planStartWeek, DateUtility.WeekNoOfYearTF(demands.Min(x => x.DUE_DATE)));
            return moWeek;
        }

        protected override void BindData(DataTable dt)
        {
            if (dt == null)
                return;

            base.BindData(dt);
            FillChart();
        }

        private DataTable CreateDataViewSchema()
        {
            DataTable dt = new DataTable();
            dt.Columns.Add(PeggingResultMap.Caption.PRODUCT_ID, typeof(string));
            dt.Columns.Add(PeggingResultMap.Caption.STEP_ID, typeof(string));
            dt.Columns.Add(PeggingResultMap.Caption.STEP_SEQ, typeof(int));
            dt.Columns.Add(PeggingResultMap.Caption.QTY, typeof(double));
            dt.Columns.Add(PeggingResultMap.Caption.CT_WEEK, typeof(int));
            dt.Columns.Add(PeggingResultMap.Caption.PEG_WEEK, typeof(int));
            return dt;
        }

        #endregion

        #region Chart

        private void FillChart()
        {
            if (_query == null)
                return;

            this.chartControl.Series.Clear();

            DrawBar();
            SetSecondaryAxis();
            SetPane();

            List<double> points = new List<double>();
            double lastStep = _query.Max(t => t.STEP_SEQ);
            DrawLine(_query, lastStep, points, true);
            DrawLine(_query, lastStep, points, false);

            SetLabelPoints(points);
        }

        private void DrawBar()
        {
            Series series = new Series(PeggingResultMap.Caption.QTY, ViewType.Bar);
            series.ArgumentScaleType = ScaleType.Qualitative;
            foreach (var item in _query)
            {
                series.Points.Add(new SeriesPoint(item.STEP_SEQ, item.QTY));
            }
            chartControl.Series.Add(series);
        }

        private void SetLabelPoints(List<double> points)
        {
            ctLabelPoints.Clear();
            pegLabelPoints.Clear();

            points.Sort();

            foreach (Series s in chartControl.Series)
            {
                if (!(s.View is LineSeriesView))
                    continue;

                double min = s.Points.Min(p => p.ArgumentX.NumericalArgument);
                double max = s.Points.Max(p => p.ArgumentX.NumericalArgument);

                var a = points.OrderBy(p => p).Where(p => p >= min && p <= max).ToList();

                string paneName = (s.View as LineSeriesView).Pane.Name;
                int cnt = a.Count;
                double labelPoint = 0;

                if (cnt < 3)
                    labelPoint = min < Convert.ToInt32(editScale2.EditValue) ? a[0] : a[a.Count - 1];
                else
                    labelPoint = cnt % 2 == 0 ? a[cnt / 2 - 1] : a[cnt / 2];

                if (paneName == PeggingResultMap.Caption.CT_WEEK)
                    ctLabelPoints.Add(s.Name, labelPoint);
                else
                    pegLabelPoints.Add(s.Name, labelPoint);
            }
        }

        private void SetPane()
        {
            if (chartControl.Diagram == null)
                return;

            XYDiagram xyDiagram = chartControl.Diagram as XYDiagram;

            xyDiagram.Panes.Clear();

            CreatePane(xyDiagram, PeggingResultMap.Caption.CT_WEEK);
            CreatePane(xyDiagram, PeggingResultMap.Caption.PEG_WEEK);

            xyDiagram.DefaultPane.LayoutOptions.Row = 1;
            xyDiagram.Panes[PeggingResultMap.Caption.CT_WEEK].LayoutOptions.Row = 2;
            xyDiagram.Panes[PeggingResultMap.Caption.PEG_WEEK].LayoutOptions.Row = 3;
        }

        private void SetSecondaryAxis()
        {
            if (chartControl.Diagram == null)
                return;

            XYDiagram xyDiagram = chartControl.Diagram as XYDiagram;
            xyDiagram.SecondaryAxesY.Clear();
            xyDiagram.SecondaryAxesX.Clear();

            SecondaryAxisY axisY = new SecondaryAxisY(PeggingResultMap.Caption.SECONDARY_AXIS);
            axisY.Visibility = DevExpress.Utils.DefaultBoolean.False;

            SecondaryAxisX axisX = new SecondaryAxisX(PeggingResultMap.Caption.SECONDARY_AXIS);
            axisX.QualitativeScaleComparer = new StepSeqComparer();
            axisX.Visibility = DevExpress.Utils.DefaultBoolean.True;
            axisX.VisibleInPanesSerializable = "2";
            axisX.WholeRange.SideMarginsValue = PeggingResultMap.Caption.SIDE_MARGIN_VALUE;
            axisX.Label.ResolveOverlappingOptions.AllowHide = false;
            axisX.QualitativeScaleOptions.AutoGrid = false;

            xyDiagram.SecondaryAxesY.Add(axisY);
            xyDiagram.SecondaryAxesX.Add(axisX);
        }

        private XYDiagramPane CreatePane(XYDiagram xyDiagram, string name)
        {
            XYDiagramPane pane = new XYDiagramPane(name);
            pane.BorderVisible = false;
            pane.StackedBarTotalLabel.Visible = true;
            pane.Title.Visibility = DevExpress.Utils.DefaultBoolean.True;
            pane.Title.Text = name;
            pane.Title.Font = new Font("Tahoma", 8F);
            xyDiagram.SecondaryAxesX[0].SetVisibilityInPane(true, pane);
            xyDiagram.SecondaryAxesY[0].SetVisibilityInPane(true, pane);
            xyDiagram.Panes.Add(pane);
            return pane;
        }

        private void DrawLine(List<PeggingResultItem> query, double lastStep, List<double> labelPoint, bool isCTWeek)
        {
            var group = query.GroupBy(t => isCTWeek ? t.CT_WEEK : t.PEG_WEEK).OrderBy(t => t.Key).ToList();

            for (int i = 0; i < group.Count; i++)
            {
                if (group[i].Key == null)
                    continue;

                string seriesName = string.Format("W{0}", group[i].Key);
                Color color = colorGen.GetColor(group[i].Key.ToString());
                Series series = CreateSeries(isCTWeek, color, seriesName);
                List<PeggingResultItem> list = group[i].OrderBy(t => t.STEP_SEQ).ToList();
                double collapsed = Convert.ToDouble(this.editScale2.EditValue) / 2;
                List<double> points = new List<double>();

                for (int j = 0; j < list.Count; j++)
                {
                    points.Add(list[j].STEP_SEQ);
                    if (list[j].STEP_SEQ == 1)
                        points.Add(list[j].STEP_SEQ + collapsed - 1);
                    else if (j < list.Count - 1 || list.Count == 1)
                        points.Add(list[j].STEP_SEQ + collapsed);
                }

                if (list.Min(t => t.STEP_SEQ) - collapsed > 0)
                    points.Add(list.Min(t => t.STEP_SEQ) - collapsed);
                if (list.Max(t => t.STEP_SEQ) + collapsed < lastStep && list.Max(t => t.STEP_SEQ) >= collapsed)
                    points.Add(list.Max(t => t.STEP_SEQ) + collapsed);

                foreach (var item in points)
                {
                    if (item > lastStep)
                        continue;
                    series.Points.Add(new SeriesPoint(item, 1));
                }

                SetLabel(series);
                chartControl.Series.Add(series);

                foreach (var item in points)
                {
                    if (labelPoint.Exists(d => d == item))
                        continue;
                    labelPoint.Add(item);
                }
            }
        }

        private Series CreateSeries(bool isCTWeek, Color color, string seriesName)
        {
            Series series = new Series(seriesName, ViewType.Line);
            LineSeriesView view = series.View as LineSeriesView;
            XYDiagram xyDiagram = chartControl.Diagram as XYDiagram;

            view.Pane = xyDiagram.Panes[isCTWeek ? PeggingResultMap.Caption.CT_WEEK : PeggingResultMap.Caption.PEG_WEEK];
            view.AxisX = xyDiagram.SecondaryAxesX[PeggingResultMap.Caption.SECONDARY_AXIS];
            view.AxisY = xyDiagram.SecondaryAxesY[PeggingResultMap.Caption.SECONDARY_AXIS];
            view.LineStyle.Thickness = 30;
            view.LineStyle.LineJoin = System.Drawing.Drawing2D.LineJoin.Round;
            view.Color = Color.FromArgb(150, color.R, color.G, color.B);

            series.ArgumentScaleType = ScaleType.Qualitative;
            series.LabelsVisibility = DevExpress.Utils.DefaultBoolean.True;
            series.ShowInLegend = false;
            series.CrosshairHighlightPoints = DevExpress.Utils.DefaultBoolean.False;
            return series;
        }

        private void SetLabel(Series series)
        {
            PointSeriesLabel label = series.Label as PointSeriesLabel;
            label.Position = PointLabelPosition.Center;
            label.TextAlignment = StringAlignment.Center;
            label.LineVisibility = DevExpress.Utils.DefaultBoolean.False;
            label.TextColor = Color.Black;
            label.BackColor = Color.Transparent;
            label.Border.Visibility = DevExpress.Utils.DefaultBoolean.False;
            label.ResolveOverlappingMode = ResolveOverlappingMode.None;
        }


        #endregion

        #region Event

        private void ChartControl_ObjectSelected(object sender, HotTrackEventArgs e)
        {
            if (e.HitInfo.SeriesPoint == null || _query.Count < 1)
                return;

            SeriesPoint point = e.HitInfo.SeriesPoint;
            PeggingResultItem item = _query.FirstOrDefault(q => q.STEP_SEQ == Convert.ToDouble(point.Argument));

            ShowPopup(Result, item);
        }

        private void ChartControl_CustomDrawCrosshair(object sender, CustomDrawCrosshairEventArgs e)
        {
            if (_query == null)
                return;
            foreach (var group in e.CrosshairElementGroups)
            {
                if ((group.CrosshairElements.First().Series.View as LineSeriesView) == null)
                    continue;

                CrosshairGroupHeaderElement groupHeaderElement = group.HeaderElement;
                string header = (group.CrosshairElements.First().Series.View as LineSeriesView).Pane.Name;
                groupHeaderElement.Text = header;

                foreach (var elem in group.CrosshairElements)
                {
                    if (!_query.Any(q => q.STEP_SEQ.ToString() == elem.SeriesPoint.Argument))
                    {
                        elem.Visible = false;
                        continue;
                    }
                    if (elem.Series.Name.StartsWith("W"))
                    {
                        elem.LabelElement.MarkerVisible = false;
                        elem.LabelElement.Text = string.Format("{0}\r\nSTEP_SEQ : {1}", elem.Series.Name, elem.SeriesPoint.Argument);
                    }

                }
            }
        }

        private void ChartControl_CustomDrawSeriesPoint(object sender, CustomDrawSeriesPointEventArgs e)
        {
            if (e.SeriesPoint == null || !(e.Series.View is LineSeriesView))
                return;
            XYDiagram xyDiagram = chartControl.Diagram as XYDiagram;
            LineSeriesView view = e.Series.View as LineSeriesView;

            Dictionary<string, double> points = view.Pane.Name == PeggingResultMap.Caption.CT_WEEK ? ctLabelPoints : pegLabelPoints;

            bool isLabelPoint = points.Values.Contains(Convert.ToDouble(e.SeriesPoint.Argument));
            e.LabelText = isLabelPoint ? points.FirstOrDefault(p => p.Value == Convert.ToDouble(e.SeriesPoint.Argument)).Key : null;
        }

        private void buttonLoad_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            Query();
        }

        private void View_DoubleClick(object sender, EventArgs e)
        {
            DevExpress.Utils.DXMouseEventArgs args = e as DevExpress.Utils.DXMouseEventArgs;
            GridView view = sender as GridView;
            DevExpress.XtraGrid.Views.Grid.ViewInfo.GridHitInfo info = view.CalcHitInfo(args.Location);
            if (info.InRow || info.InRowCell || info.InDataRow)
            {
                if (info.RowHandle >= 0)
                {
                    //string stepID = (view.DataSource as DataView).ToTable().Rows[info.RowInfo.VisibleIndex].GetString(PeggingResultMap.Caption.STEP_ID);
                    string stepID = view.GetRowCellValue(info.RowHandle, PeggingResultMap.Caption.STEP_ID).ToString();
                    PeggingResultItem item = _query.FirstOrDefault(t => t.STEP_ID == stepID);
                    if (item == null)
                        return;
                    ShowPopup(this.Result, item);
                }
            }
        }

        private void View_DataSourceChanged(object sender, EventArgs e)
        {
            GridView view = sender as GridView;
            view.BestFitColumns();
        }

        private void ShowPopup(IExperimentResultItem result, PeggingResultItem item)
        {
            Form popup = null;

            foreach (Form f in Application.OpenForms)
            {
                if (f is PeggingResultViewPopup)
                {
                    popup = f;
                }
            }

            if (popup != null)
                popup.Close();

            popup = new PeggingResultViewPopup(result, item.PRODUCT_ID, item.STEP_SEQ, item.STEPS);
            popup.StartPosition = FormStartPosition.CenterParent;
            popup.Show();
        }
        #endregion

        #region Class

        class PeggingResultItem
        {
            private int? pegWeek;
            public string PRODUCT_ID { get; set; }
            public string STEP_ID { get; set; }
            public int STEP_SEQ { get; set; }
            public double QTY { get; set; }
            public int CT_WEEK { get; set; }
            public int MO_WEEK { get; set; }
            public int? PEG_WEEK
            {
                get
                {
                    return pegWeek == int.MinValue ? null : pegWeek;
                }
                set
                {
                    pegWeek = value;
                }
            }
            public string[] STEPS
            {
                get
                {
                    if (steps.Length < 1)
                        return null;
                    return this.steps.Split(',');
                }
            }
            public string steps { get; set; }
        }

        #endregion

        #region Comparer

        class StepSeqComparer : System.Collections.IComparer
        {
            public int Compare(object x, object y)
            {
                try
                {
                    double xD = Convert.ToDouble(x);
                    double yD = Convert.ToDouble(y);
                    return Convert.ToInt32(xD - yD);
                }
                catch
                {
                    return 0;
                }
            }
        }

        #endregion

        private void editScale2_EditValueChanged(object sender, EventArgs e)
        {
            if (Convert.ToInt32(this.editScale2.EditValue) < 1)
            {
                XtraMessageBox.Show("1보다 작은 값은 입력불가");
                this.editScale2.EditValue = 10;
            }
        }

        private void btnLoad2_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            Query();
        }
    }
}
