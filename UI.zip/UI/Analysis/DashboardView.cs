﻿///
// file:	Analysis\InlineCycleTimeView.cs
//
// summary:	Implements the inline cycle time view class
///
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Mozart.Studio.TaskModel.UserInterface;
using Mozart.Studio.TaskModel.Projects;
using Mozart.Studio.Application;
using DevExpress.XtraEditors.Controls;
using DevExpress.XtraCharts;
using DevExpress.XtraTab;

using FabSimulator;
using Mozart.Data.Entity;
using Mozart.Mapping;

// for export excel; temporarily
using Mozart.Studio.UIComponents;
using Mozart.Studio.TaskModel.Utility;

using Mozart.Studio.TaskModel.UserLibrary;
using DevExpress.XtraGrid.Columns;
using DevExpress.XtraGrid.Views.Grid;
using DevExpress.XtraGrid.Views.BandedGrid;
using FabSimulator.Inputs;
using FabSimulator.Outputs;
using System.Windows.Input;
using FabSimulatorUI.Common;
using Mozart.Extensions;

namespace FabSimulatorUI.Analysis
{
    public partial class DashboardView : XtraGridControlView
    {
        #region Variable&Property

        /// <summary>   The result. </summary>
        IExperimentResultItem result;

        /// <summary>   Context for the model data. </summary>
        ModelDataContext modelDataContext;
        /// <summary>   Context for the exponent data. </summary>
        ExpDataContext expDataContext;
        /// <summary>   True while initialization is in progress. </summary>
        bool initializing;
        /// <summary>   True to loading. </summary>
        bool loading;

        #endregion

        #region Ctor

        public DashboardView(IServiceProvider serviceProvider)
            : base(serviceProvider)
        {
            InitializeComponent();

            this.initializing = true;
        }

        protected override void LoadDocument()
        {
            this.LoadInit();
            this.initializing = false;

            this.loading = true;
            this.Query();
            this.loading = false;
        }

        #endregion

        #region Init

        private void LoadInit()
        {
            this.result = this.Document.GetResultItem();

            Globals.InitFactoryTime(this.result);

            this.result.ExpResults(this.resultCheckCtl);

            this.modelDataContext = result.GetCtx<ModelDataContext>();
            this.expDataContext = result.GetCtx<ExpDataContext>();

            this.FillPeriod();
            this.FillWorkstation();

            this.xtraTabPage1.Text = "FAB IN/OUT";
            this.xtraTabPage2.Text = "Photo Step TAT/WIP";
            this.xtraTabPage3.Text = "Photo Eqp TAT/WPD";

            this.radioGroup1.SelectedIndex = 1;
        }

        #endregion

        #region Query&Bind

        private void Query()
        {
            using (var wc = new Mozart.Studio.UIComponents.WaitCursor())
            {
                this.BindBegin();
                this.BindDo();
                this.BindEnd();
            }
        }

        private void BindBegin()
        {
            
        }

        private void BindEnd()
        {
        }

        private void BindDo()
        {
            this.Calculate();
        }
        #endregion

        private void FillPeriod()
        {
            this.startDateTimePicker.Value = ShopCalendar.StartTimeOfDayT(this.result.StartTime);
            this.endDateTimePicker.Value = this.startDateTimePicker.Value.AddDays(this.result.GetPlanPeriodF(1));
        }

        private void FillWorkstation()
        {
            //var photoWS = modelDataContext.EQP.Where(x => x.AREA_ID == "F1-PHT").Select(x => x.WORKSTATION_ID).Distinct();
            var photoWS = new string[] { "NXT", "XT" };
            this.comboBoxEdit1.FillValues(photoWS);
        }

        private void Calculate()
        {
            var startTime = this.startDateTimePicker.Value;
            var endTime = this.endDateTimePicker.Value;

            if (startTime >= endTime)
                MessageBox.Show("invalid period");

            Calc1New();
        }

        private double CalcFabCT(string sinceDay = "1900-01-01")
        {
            double fabCT = 0;
            DateTime sinceDate = Convert.ToDateTime(sinceDay);

            var results = this.resultCheckCtl.Properties.Items.GetCheckedValues().Select(x => x.ToString()).ToArray();
            if (results == null || results.Length == 0)
                return 0;

            foreach (var resultName in results)
            {
                var result = this.expDataContext.Result(resultName);

                var ctRaw = from a in result.FAB_OUT_RESULT.Where(t => t.FAB_IN_TIME >= sinceDate && t.CT_DAYS > 0 && !t.LOT_ID.Contains("_R"))
                            select new
                            {
                                PART_ID = "NONE",
                                a.WAFER_QTY,
                                a.CT_DAYS,
                                CT_WEIGHTED = a.WAFER_QTY * a.CT_DAYS
                            };

                var ct = from a in ctRaw
                         group a by new { a.PART_ID } into grp
                         select new
                         {
                             CT_WEIGHTED = grp.Sum(t => t.CT_WEIGHTED),
                             WAFER_QTY = grp.Sum(t => t.WAFER_QTY)
                         };

                fabCT = ct.Sum(t => t.CT_WEIGHTED) / ct.Sum(t => t.WAFER_QTY);
            }
            return fabCT;
        }

        private void Calc1New()
        {
            var results = this.resultCheckCtl.Properties.Items.GetCheckedValues().Select(x => x.ToString()).ToArray();
            if (results == null || results.Length == 0)
                return;

            var radioIndex = this.radioGroup1.SelectedIndex;

            var startTime = FabSimulatorUI.Helper.GetIntervalStartDate(this.startDateTimePicker.Value, radioIndex);
            var endTime = FabSimulatorUI.Helper.GetIntervalEndDate(this.endDateTimePicker.Value, radioIndex);

            List<SummaryDataCalc1> summaryFabInOutWip = new List<SummaryDataCalc1>();
            foreach (var resultName in results)
            {
                var result = this.expDataContext.Result(resultName);

                var resultOutput = from a in result.SUMMARY_FABIO_WIP.Where(x => x.TARGET_DATE >= startTime && x.TARGET_DATE <= endTime)
                                   select new SummaryDataCalc1
                                   {
                                       RESULT = resultName,
                                       KEY = GetSummaryKey(radioIndex, a),
                                       TARGET_DATE = a.TARGET_DATE,
                                       FABIN_QTY = a.FABIN_QTY,
                                       FABOUT_QTY = a.FABOUT_QTY,
                                       WIP_QTY = a.WIP_QTY,
                                       SCRAP_QTY = a.SCRAP_QTY
                                   };

                summaryFabInOutWip.AddRange(resultOutput);
            }

            if (summaryFabInOutWip.IsNullOrEmpty())
                return;

            List<FabSeries> fabInMove = new List<FabSeries>();
            List<FabSeries> fabOutMove = new List<FabSeries>();
            List<FabSeries> fabScrap = new List<FabSeries>();
            List<FabSeries> fabWip = new List<FabSeries>();

            foreach (var group in summaryFabInOutWip.GroupBy(x => x.KEY).OrderBy(g => g.Key))
            {
                var key = group.Key;
                
                var fabIn = new FabSeries();
                fabIn.ARGUMENT = key;
                fabIn.DATA = "FAB In";
                fabIn.VALUE = Math.Round(group.GroupBy(x => x.RESULT).Average(x => x.Select(x => x.FABIN_QTY).Sum()), 2);
                fabInMove.Add(fabIn);

                var fabOut = new FabSeries();
                fabOut.ARGUMENT = key;
                fabOut.DATA = "FAB Out";
                fabOut.VALUE = Math.Round(group.GroupBy(x => x.RESULT).Average(x => x.Select(x => x.FABOUT_QTY).Sum()), 2);
                fabOutMove.Add(fabOut);

                var scrap = new FabSeries();
                scrap.ARGUMENT = key;
                scrap.DATA = "SCRAP";
                scrap.VALUE = Math.Round(group.GroupBy(x => x.RESULT).Average(x => x.Select(x => x.SCRAP_QTY).Sum()), 2);
                fabScrap.Add(scrap);

                var wip = new FabSeries();
                wip.ARGUMENT = key;
                wip.DATA = "WIP";

                if (key.StartsWith("WEEK") || key.StartsWith("MONTH"))
                {
                    var representTargetDate = group.Min(x => x.TARGET_DATE);
                    var representGroup = group.Where(x => x.TARGET_DATE == representTargetDate);

                    wip.VALUE = Math.Round(representGroup.GroupBy(x => x.RESULT).Average(x => x.Select(x => x.WIP_QTY).Sum()), 2);
                }
                else
                {
                    wip.VALUE = Math.Round(group.GroupBy(x => x.RESULT).Average(x => x.Select(x => x.WIP_QTY).Sum()), 2);
                }

                fabWip.Add(wip);
            }

            List<FabSeries> list = new List<FabSeries>();

            list.AddRange(fabInMove);
            list.AddRange(fabOutMove);
            list.AddRange(fabScrap);
            list.AddRange(fabWip);

            this.chartControl1.Series.Clear();
            this.chartControl1.DataSource = list;
            this.chartControl1.SeriesTemplate.SeriesDataMember = "DATA";
            this.chartControl1.SeriesTemplate.ArgumentDataMember = "ARGUMENT";
            this.chartControl1.SeriesTemplate.ValueDataMembers.AddRange("VALUE");

            var title = new ChartTitle();
            title.Text = "FAB IN/OUT/WIP Trend";
            this.chartControl1.Titles.Clear();
            this.chartControl1.Titles.Add(title);


            double fabInAvg = Math.Round(fabInMove.Average(x => x.VALUE), 2);
            double fabOutAvg = Math.Round(fabOutMove.Average(x => x.VALUE), 2);
            double fabScrapAvg = Math.Round(fabScrap.Average(x => x.VALUE), 2);
            double wipAvg = Math.Round(fabWip.Average(x => x.VALUE), 2);
            double fabCT = CalcFabCT();

            var title2 = new ChartTitle();
            title2.Text = string.Format("           FAB In : {0:0,0.00}   FAB Out : {1:0,0.00}   SCRAP : {2:0,0.00}   WIP : {3:0,0.00}    FabCT : {4:0,0.00} ", fabInAvg, fabOutAvg, fabScrapAvg, wipAvg, fabCT);
            title2.Alignment = StringAlignment.Near;
            title2.TextColor = Color.Black;
            title2.Font = new Font("Tahoma", 9f);
            this.chartControl1.Titles.Add(title2);

            static string GetSummaryKey(int radioIndex, SUMMARY_FABIO_WIP a)
            {
                string key;
                int year = a.TARGET_DATE.Year;
                //if (a.TARGET_WEEK == 52 && a.TARGET_DATE.Month == 1 && radioIndex == 1)
                //    year--;

                if (radioIndex == 0)
                    key = "MONTH " + a.TARGET_MONTH;
                else if (radioIndex == 1)
                    key = "WEEK " + a.TARGET_WEEK;
                else
                    key = a.TARGET_DATE.ToShortDateString();

                return key;
            }
        }

        private void Calc2New()
        {
            var results = this.resultCheckCtl.Properties.Items.GetCheckedValues().Select(x => x.ToString()).ToArray();
            if (results == null || results.Length == 0)
                return;

            var radioIndex = this.radioGroup1.SelectedIndex;

            var startTime = FabSimulatorUI.Helper.GetIntervalStartDate(this.startDateTimePicker.Value, radioIndex);
            var endTime = FabSimulatorUI.Helper.GetIntervalEndDate(this.endDateTimePicker.Value, radioIndex);

            var photoGen = this.comboBoxEdit1.SelectedItem.ToString();

            List<SummaryDataCalc2> summaryPhotoStepWip = new List<SummaryDataCalc2>();
            foreach (var resultName in results)
            {
                var result = this.expDataContext.Result(resultName);

                var resultOutput = from a in result.SUMMARY_PHOTO_WIP.Where(x => x.TARGET_DATE >= startTime && x.TARGET_DATE <= endTime && x.PHOTO_GEN == photoGen)
                                   select new SummaryDataCalc2
                                   {
                                       RESULT = resultName,
                                       OPER_ID = a.STEP_ID,
                                       RUN_TAT = a.RUN_TAT,
                                       WAIT_TAT = a.WAIT_TAT,
                                       WIP_QTY = a.WIP_QTY
                                   };

                summaryPhotoStepWip.AddRange(resultOutput);
            }

            List<WokrstationSeries> avgTimesRUN = new List<WokrstationSeries>();
            List<WokrstationSeries> avgTimesWAIT = new List<WokrstationSeries>();
            List<WokrstationSeries> avgStepWIP = new List<WokrstationSeries>();

            foreach (var group in summaryPhotoStepWip.OrderBy(x => x.OPER_ID).GroupBy(x => x.OPER_ID))
            {
                var run = new WokrstationSeries();
                run.ARGUMENT = group.Key;
                run.DATA = "RUN_HRS";
                run.VALUE = Math.Round(group.GroupBy(x => x.RESULT).Average(x => x.Select(x => x.RUN_TAT).Average()), 2);

                avgTimesRUN.Add(run);

                var wait = new WokrstationSeries();
                wait.ARGUMENT = group.Key;
                wait.DATA = "WAIT_HRS";
                wait.VALUE = Math.Round(group.GroupBy(x => x.RESULT).Average(x => x.Select(x => x.WAIT_TAT).Average()), 2);

                avgTimesWAIT.Add(wait);

                var wip = new WokrstationSeries();
                wip.ARGUMENT = group.Key;
                wip.DATA = "WIP";
                wip.VALUE = Math.Round(group.GroupBy(x => x.RESULT).Average(x => x.Select(x => x.WIP_QTY).Average()), 2);

                avgStepWIP.Add(wip);
            }

            List<WokrstationSeries> list = new List<WokrstationSeries>();
            list.AddRange(avgTimesRUN);
            list.AddRange(avgTimesWAIT);
            list.AddRange(avgStepWIP);

            this.chartControl2.Series.Clear();
            this.chartControl2.DataSource = list;
            this.chartControl2.SeriesTemplate.SeriesDataMember = "DATA";
            this.chartControl2.SeriesTemplate.ArgumentDataMember = "ARGUMENT";
            this.chartControl2.SeriesTemplate.ValueDataMembers.AddRange("VALUE");

            var title = new ChartTitle();
            title.Text = string.Format("Photo Step TAT/WIP ({0})", photoGen);
            this.chartControl2.Titles.Clear();
            this.chartControl2.Titles.Add(title);
        }
        private void Calc3New()
        {
            var results = this.resultCheckCtl.Properties.Items.GetCheckedValues().Select(x => x.ToString()).ToArray();
            if (results == null || results.Length == 0)
                return;

            var radioIndex = this.radioGroup1.SelectedIndex;

            var startTime = FabSimulatorUI.Helper.GetIntervalStartDate(this.startDateTimePicker.Value, radioIndex);
            var endTime = FabSimulatorUI.Helper.GetIntervalEndDate(this.endDateTimePicker.Value, radioIndex);

            var photoGen = this.comboBoxEdit1.SelectedItem.ToString();

            List<SummaryDataCalc3> summaryPhotoResourceWPD = new List<SummaryDataCalc3>();
            foreach (var resultName in results)
            {
                var result = this.expDataContext.Result(resultName);

                var resultOutput = from a in result.SUMMARY_PHOTO_WPD.Where(x => x.TARGET_DATE >= startTime && x.TARGET_DATE <= endTime && x.PHOTO_GEN == photoGen)
                                   select new SummaryDataCalc3
                                   {
                                       RESULT = resultName,
                                       RESOURCE_ID = a.EQP_ID,
                                       RUN_TAT = a.RUN_TAT,
                                       WAIT_TAT = a.WAIT_TAT,
                                       MOVE_QTY = a.MOVE_QTY
                                   };

                summaryPhotoResourceWPD.AddRange(resultOutput);
            }

            List<WokrstationSeries> avgTimesRUN = new List<WokrstationSeries>();
            List<WokrstationSeries> avgTimesWAIT = new List<WokrstationSeries>();
            List<WokrstationSeries> eqpWPD = new List<WokrstationSeries>();

            foreach (var group in summaryPhotoResourceWPD.OrderBy(x => x.RESOURCE_ID).GroupBy(x => x.RESOURCE_ID))
            {
                var run = new WokrstationSeries();
                run.ARGUMENT = group.Key;
                run.DATA = "RUN_HRS";
                run.VALUE = Math.Round(group.GroupBy(x => x.RESULT).Average(x => x.Select(x => x.RUN_TAT).Average()), 2);

                avgTimesRUN.Add(run);

                var wait = new WokrstationSeries();
                wait.ARGUMENT = group.Key;
                wait.DATA = "WAIT_HRS";
                wait.VALUE = Math.Round(group.GroupBy(x => x.RESULT).Average(x => x.Select(x => x.WAIT_TAT).Average()), 2);

                avgTimesWAIT.Add(wait);

                var wpd = new WokrstationSeries();
                wpd.ARGUMENT = group.Key;
                wpd.DATA = "WPD";
                wpd.VALUE = Math.Round(group.GroupBy(x => x.RESULT).Average(x => x.Select(x => x.MOVE_QTY).Average()), 2);

                eqpWPD.Add(wpd);
            }

            List<WokrstationSeries> list = new List<WokrstationSeries>();
            list.AddRange(avgTimesRUN);
            list.AddRange(avgTimesWAIT);
            list.AddRange(eqpWPD);

            this.chartControl3.Series.Clear();
            this.chartControl3.DataSource = list;
            this.chartControl3.SeriesTemplate.SeriesDataMember = "DATA";
            this.chartControl3.SeriesTemplate.ArgumentDataMember = "ARGUMENT";
            this.chartControl3.SeriesTemplate.ValueDataMembers.AddRange("VALUE");

            var title = new ChartTitle();
            title.Text = string.Format("Photo Eqp TAT/WPD ({0})", photoGen);
            this.chartControl3.Titles.Clear();
            this.chartControl3.Titles.Add(title);
        }

        class SummaryDataCalc1
        {
            public string RESULT { get; set; }
            public string KEY { get; set; }
            public DateTime TARGET_DATE { get; set; }
            public double FABIN_QTY { get; set; }
            public double FABOUT_QTY { get; set; }
            public double WIP_QTY { get; set; }
            public double SCRAP_QTY { get; set; }
        }

        class SummaryDataCalc2
        {
            public string RESULT { get; set; }
            public string OPER_ID { get; set; }
            public double RUN_TAT { get; set; }
            public double WAIT_TAT { get; set; }
            public int WIP_QTY { get; set; }
        }

        class SummaryDataCalc3
        {
            public string RESULT { get; set; }
            public string RESOURCE_ID { get; set; }
            public double RUN_TAT { get; set; }
            public double WAIT_TAT { get; set; }
            public int MOVE_QTY { get; set; }
        }

        class FabSeries
        {
            public string ARGUMENT { get; set; }
            public string DATA { get; set; }
            public double VALUE { get; set; }
        }

        class WokrstationSeries
        {
            public string ARGUMENT { get; set; }
            public string DATA { get; set; }
            public double VALUE { get; set; }
        }

        private void XtraTabControl1_SelectedPageChanged(object sender, DevExpress.XtraTab.TabPageChangedEventArgs e)
        {

        }

        private void ChartControl1_BoundDataChanged(object sender, EventArgs e)
        {
            SecondaryAxisY myAxisY = new SecondaryAxisY("my Y-Axis");
            ((XYDiagram)chartControl1.Diagram).SecondaryAxesY.Clear();
            ((XYDiagram)chartControl1.Diagram).SecondaryAxesY.Add(myAxisY);

            var move = ((ChartControl)sender).Series.Where(x => x.Name.Contains("FAB"));
            var wip = ((ChartControl)sender).Series.Where(x => x.Name.Contains("WIP"));

            foreach (Series s in move)
            {
                s.ChangeView(ViewType.Bar);

                BarSeriesView view = (BarSeriesView)s.View;
                view.Transparency = 160;
            }

            foreach (Series s in wip)
            {
                s.ChangeView(ViewType.Line);

                LineSeriesView view = (LineSeriesView)s.View;
                view.AxisY = myAxisY;
            }
            if (this.chartControl1.Series["SCRAP"] != null)
            {
                this.chartControl1.Series["SCRAP"].ChangeView(ViewType.Line);
                this.chartControl1.Series["SCRAP"].View.Color = Color.Transparent;
            }
        }

        private void ChartControl2_BoundDataChanged(object sender, EventArgs e)
        {
            SecondaryAxisY myAxisY = new SecondaryAxisY("my Y-Axis");
            ((XYDiagram)chartControl2.Diagram).SecondaryAxesY.Clear();
            ((XYDiagram)chartControl2.Diagram).SecondaryAxesY.Add(myAxisY);

            var tat = ((ChartControl)sender).Series.Where(x => x.Name.Contains("HRS"));
            var wip = ((ChartControl)sender).Series.Where(x => x.Name.Contains("WIP"));

            foreach (Series s in tat)
            {
                s.ChangeView(ViewType.StackedBar);

                StackedBarSeriesView view = (StackedBarSeriesView)s.View;
                view.Transparency = 160;
            }

            foreach (Series s in wip)
            {
                s.ChangeView(ViewType.Line);

                LineSeriesView view = (LineSeriesView)s.View;
                view.AxisY = myAxisY;
            }
        }

        private void ComboBoxEdit1_SelectedValueChanged(object sender, EventArgs e)
        {
            //if (this.xtraTabControl1.SelectedTabPage == this.xtraTabPage2)
                Calc2New();

            //if (this.xtraTabControl1.SelectedTabPage == this.xtraTabPage3)
                Calc3New();
        }

        private void ChartControl3_BoundDataChanged(object sender, EventArgs e)
        {
            SecondaryAxisY myAxisY = new SecondaryAxisY("my Y-Axis");
            ((XYDiagram)chartControl3.Diagram).SecondaryAxesY.Clear();
            ((XYDiagram)chartControl3.Diagram).SecondaryAxesY.Add(myAxisY);

            var move = ((ChartControl)sender).Series.Where(x => x.Name.Contains("WPD"));
            var tat = ((ChartControl)sender).Series.Where(x => x.Name.Contains("HRS"));

            foreach (Series s in tat)
            {
                s.ChangeView(ViewType.StackedBar);

                StackedBarSeriesView view = (StackedBarSeriesView)s.View;
                view.Transparency = 160;
            }

            foreach (Series s in move)
            {
                s.ChangeView(ViewType.Line);

                LineSeriesView view = (LineSeriesView)s.View;
                view.AxisY = myAxisY;
            }
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            QueryAll();
        }

        private void radioGroup1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (this.initializing)
                return;

            QueryAll();
        }

        private void QueryAll()
        {
            using (var wc = new Mozart.Studio.UIComponents.WaitCursor())
            {
                var startTime = this.startDateTimePicker.Value;
                var endTime = this.endDateTimePicker.Value;

#if false
                var radioIndex = this.radioGroup1.SelectedIndex;
                if (radioIndex == 0) // Month
                {
                    this.startDateTimePicker.Value = FabSimulatorUI.Helper.GetMonthStartTime(startTime);
                    this.endDateTimePicker.Value = FabSimulatorUI.Helper.GetMonthEndDayStartTime(endTime);
                }
                else if (radioIndex == 1) // Week
                {
                    this.startDateTimePicker.Value = FabSimulatorUI.Helper.GetWeekStartTime(startTime);
                    this.endDateTimePicker.Value = FabSimulatorUI.Helper.GetWeekEndDayStartTime(endTime);
                } 
#endif

                if (startTime >= endTime)
                {
                    MessageBox.Show("invalid period");
                    return;
                }

                Calc1New();
                Calc2New();
                Calc3New();
            }
        }

        private void startDateTimePicker_ValueChanged(object sender, EventArgs e)
        {
            if (this.initializing)
                return;

            this.endDateTimePicker.Value = this.startDateTimePicker.Value.AddMonths(1);
        }

        private void resultCheckCtl_EditValueChanged(object sender, EventArgs e)
        {
            if (this.initializing)
                return;

            QueryAll();
        }
    }
}
