﻿using DevExpress.XtraGrid;
using FabSimulator.Outputs;
using FabSimulatorUI.Common;
using FabSimulatorUI.DataMappings;
using Mozart.Studio.TaskModel.Projects;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FabSimulatorUI.Analysis
{
    public partial class StepTargetPopUp : DevExpress.XtraEditors.XtraForm
    {
        #region Define Variables
        IExperimentResultItem rst = null;
        string productID = null;
        string[] stepID = null;
        int stepSeq = 0;
        DateTime theTargetDate = DateTime.MinValue;
        DataTable dt = new DataTable();
        #endregion

        #region Constructor
        public StepTargetPopUp()
        {
            InitializeComponent();
        }

        public StepTargetPopUp(IExperimentResultItem rst, DateTime tgtDate, string productID, string[] stepID, int stepSeq) : this()
        {
            this.rst = rst;
            this.productID = productID;
            this.stepID = stepID;
            this.stepSeq = stepSeq;

            //planStartTime = Globals.GetPlanStartTime(rst);
            theTargetDate = tgtDate;

            SetControls();
        }
        #endregion

        #region SetControl
        private void SetControls()
        {
            //선택한 stepSeq를 사용자에게 알려주기
            this.Text = stepSeq.ToString();
        }
        #endregion

        #region Load
        private void StepTargetGrid_Load(object sender, EventArgs e)
        {
            this.Cursor = Cursors.WaitCursor;

            if (theTargetDate == DateTime.MinValue)
                theTargetDate = Globals.GetPlanStartTime(rst);

            //step target 데이터 가져오기            
            DataTable dt = rst.LoadOutput(StepTargetMap.STEP_TARGET_DATA_TABLE_NAME);

            // step id 순서로 정렬하기
            var rows = dt.AsEnumerable().Where(x =>
            {
                if (x[StepTargetMap.Caption.ProductID].ToString() != productID)
                    return false;

                if (!stepID.Contains(x[StepTargetMap.Caption.StepID].ToString()))
                    return false;

                if (Convert.ToInt32(x[StepTargetMap.Caption.Qty]) <= 0)
                    return false;

                return true;
            }).ToList().Where(x => x.GetDateTime(StepTargetMap.Caption.PlanDate) < theTargetDate.AddDays(1) &&
            x.GetDouble(StepTargetMap.Caption.Qty) > 0).OrderBy(x => x[StepTargetMap.Caption.StepID]);

            //전역 변수 dt에 만들어준 값을 담아주기
            GetBindingDataTable(rows);

            //그리드에 데이터 바인딩
            BindGrid();

            this.Cursor = Cursors.Arrow;
        }

        private void GetBindingDataTable(IOrderedEnumerable<DataRow> rows)
        {
            //그리드에 바인딩 시켜줄 데이터 테이블 컬럼 세팅
            DataTable dataTable = new DataTable();

            dataTable.Columns.Add(StepTargetMap.Caption.ProductID, typeof(string));
            dataTable.Columns.Add(StepTargetMap.Caption.StepID, typeof(string));
            dataTable.Columns.Add(StepTargetMap.Caption.StepSeq, typeof(int));
            dataTable.Columns.Add(StepTargetMap.Caption.TargetShift, typeof(DateTime));
            dataTable.Columns.Add(StepTargetMap.Caption.Qty, typeof(double));
            dataTable.Columns.Add(StepTargetMap.Caption.DemandID, typeof(string));
            dataTable.Columns.Add(StepTargetMap.Caption.Mo_Due_Date, typeof(DateTime));

            //그리드에 바인딩 시켜줄 데이터 테이블 로우 세팅
            foreach (DataRow row in rows)
            {
                DataRow dataRow = dataTable.NewRow();

                dataRow[StepTargetMap.Caption.ProductID] = row[StepTargetMap.Caption.ProductID];
                dataRow[StepTargetMap.Caption.StepID] = row[StepTargetMap.Caption.StepID];
                dataRow[StepTargetMap.Caption.StepSeq] = row[StepTargetMap.Caption.StepSeq];
                dataRow[StepTargetMap.Caption.TargetShift] = row[StepTargetMap.Caption.TargetShift];
                dataRow[StepTargetMap.Caption.Qty] = row[StepTargetMap.Caption.Qty];
                dataRow[StepTargetMap.Caption.DemandID] = row[StepTargetMap.Caption.DemandID];
                dataRow[StepTargetMap.Caption.Mo_Due_Date] = row[StepTargetMap.Caption.Mo_Due_Date];

                dataTable.Rows.Add(dataRow);
            }

            //전역 변수에 만들어준 데이터 테이블 값 담아주기
            this.dt = dataTable;
        }

        private void BindGrid()
        {
            //그리드 뷰에 데이터 바인딩
            StepTargetGrid.BeginUpdate();
            StepTargetGrid.DataSource = dt;
            SetGridView();
            StepTargetGrid.EndUpdate();
        }

        private void SetGridView()
        {
            //날짜가 시간까지 모두 나오게 세팅
            this.gridView1.Columns[3].DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.gridView1.Columns[6].DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.gridView1.Columns[3].DisplayFormat.FormatString = "yyyy-MM-dd HH:mm:ss";
            this.gridView1.Columns[6].DisplayFormat.FormatString = "yyyy-MM-dd HH:mm:ss";

            //그리드 뷰 길이 자동 조정
            gridView1.BestFitColumns();

            gridView1.OptionsMenu.ShowGroupSummaryEditorItem = true;
            gridView1.OptionsView.ShowFooter = true;

            GridColumnSummaryItem item1 = new GridColumnSummaryItem(DevExpress.Data.SummaryItemType.Sum);
            gridView1.Columns[StepTargetMap.Caption.Qty].Summary.Add(item1);
        }
        #endregion
    }
}
