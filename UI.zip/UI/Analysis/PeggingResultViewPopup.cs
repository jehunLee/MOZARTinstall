﻿using DevExpress.XtraEditors;
using DevExpress.XtraGrid;
using DevExpress.XtraGrid.Views.Grid;
using FabSimulator.Inputs;
using FabSimulator.Outputs;
using FabSimulatorUI.Common;
using FabSimulatorUI.DataMappings;
using Mozart.Studio.TaskModel.Projects;
using Mozart.Studio.TaskModel.UserLibrary;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FabSimulatorUI.Analysis
{
    public partial class PeggingResultViewPopup : XtraForm
    {
        #region Class&Variable
        class PeggingResultPopupItem
        {
            public string PRODUCT_ID { get; set; }
            public string STEP_ID { get; set; }
            public string LOT_ID { get; set; }
            public double QTY { get; set; }
            public string MO_DEMAND_ID { get; set; }
            public int STEP_SEQ { get; set; }
            public string TARGET_DATE { get; set; }
        }

        IExperimentResultItem result;
        string prodID;
        string[] steps;
        #endregion

        #region Ctor
        public PeggingResultViewPopup()
        {
            InitializeComponent();
        }

        public PeggingResultViewPopup(IExperimentResultItem result, string prodID, int stepSeq, string[] steps)
        {
            InitializeComponent();

            this.result = result;
            this.prodID = prodID;
            this.steps = steps;
            this.Text = string.Format("{0} / {1} ~ {2}", prodID, stepSeq, stepSeq + steps.Length - 1);

            SetGridView();
            DataTable dt = GetData();
            FillGrid(dt);
        }
        #endregion

        #region Control
        private void SetGridView()
        {
            GridView view = gridControl1.MainView as GridView;
            view.OptionsSelection.MultiSelect = true;
            view.OptionsSelection.MultiSelectMode = GridMultiSelectMode.RowSelect;
            view.OptionsView.ShowAutoFilterRow = true;

            view.OptionsMenu.ShowGroupSummaryEditorItem = true;
            view.OptionsView.ShowFooter = true;
        }
        #endregion

        #region Query&Bind
        private DataTable GetData()
        {
            DataTable dt = CreateTable();
            Query(dt);
            return dt;
        }

        private void Query(DataTable dt)
        {
            var theProduct = this.prodID;
            var theSteps = this.steps;

            var pegHistory = Globals.GetEntityData<PEG_HISTORY>(result);
            var unpegHistory = Globals.GetEntityData<UNPEG_HISTORY>(result);
            var step = Globals.GetEntityData<ROUTE_STEP>(result);
            var product = Globals.GetEntityData<PRODUCT>(result);



            var peg = from a in pegHistory.Where(t => t.PRODUCT_ID == theProduct && theSteps.Contains(t.STEP_ID))
                      join p in product on a.PRODUCT_ID equals p.PRODUCT_ID
                      join b in step on new { p.ROUTE_ID, a.STEP_ID } equals new { b.ROUTE_ID, b.STEP_ID }
                      select new PeggingResultPopupItem
                      {
                          PRODUCT_ID = a.PRODUCT_ID,
                          STEP_ID = a.STEP_ID,
                          LOT_ID = a.LOT_ID,
                          QTY = a.PEG_QTY,
                          MO_DEMAND_ID = a.DEMAND_ID,
                          STEP_SEQ = b.STEP_SEQ,
                          TARGET_DATE = DateUtility.ToDisplayString(a.TARGET_DATE),
                      };

            var unpeg = from a in unpegHistory.Where(t => t.PRODUCT_ID == theProduct && theSteps.Contains(t.STEP_ID))
                        join p in product on a.PRODUCT_ID equals p.PRODUCT_ID
                        join b in step on new { p.ROUTE_ID, a.STEP_ID } equals new { b.ROUTE_ID, b.STEP_ID }
                        select new PeggingResultPopupItem
                        {
                            PRODUCT_ID = a.PRODUCT_ID,
                            STEP_ID = a.STEP_ID,
                            LOT_ID = a.LOT_ID,
                            QTY = a.WAFER_QTY,
                            MO_DEMAND_ID = "UNPEG: " + a.REASON,
                            STEP_SEQ = b.STEP_SEQ,
                            TARGET_DATE = string.Empty
                        };

            peg = peg.Union(unpeg).OrderBy(t => t.STEP_SEQ).ThenBy(t => t.LOT_ID);

            foreach (var hist in peg)
            {
                dt.Rows.Add(hist.PRODUCT_ID, hist.STEP_ID, hist.STEP_SEQ, hist.LOT_ID, hist.QTY, hist.MO_DEMAND_ID, hist.TARGET_DATE);
            }
        }

        private DataTable CreateTable()
        {
            DataTable dt = new DataTable();

            dt.Columns.Add(PeggingResultMap.Caption.PRODUCT_ID, typeof(string));
            dt.Columns.Add(PeggingResultMap.Caption.STEP_ID, typeof(string));
            dt.Columns.Add(PeggingResultMap.Caption.STEP_SEQ, typeof(string));
            dt.Columns.Add(PeggingResultMap.Caption.LOT_ID, typeof(string));
            dt.Columns.Add(PeggingResultMap.Caption.QTY, typeof(int));
            dt.Columns.Add(PeggingResultMap.Caption.MO_DEMAND_ID, typeof(string));
            dt.Columns.Add(PeggingResultMap.Caption.TARGET_DATE, typeof(string));

            return dt;
        }

        private void FillGrid(DataTable dt)
        {
            this.gridControl1.BeginUpdate();
            this.gridControl1.DataSource = null;
            this.gridControl1.DataSource = dt;
            DecorateTable();
            this.gridControl1.EndUpdate();

            GridView view = gridControl1.MainView as GridView;
            view.BestFitColumns();
        }
        private void DecorateTable()
        {
            GridView view = gridControl1.MainView as GridView;
            //소수점 표시
            foreach (DevExpress.XtraGrid.Columns.GridColumn col in view.Columns)
            {
                if (col.FieldName == PeggingResultMap.Caption.QTY)
                {
                    col.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Custom;
                    col.DisplayFormat.FormatString = "###,##0";
                }
            }

            GridColumnSummaryItem item1 = new GridColumnSummaryItem(DevExpress.Data.SummaryItemType.Sum);
            view.Columns[PeggingResultMap.Caption.QTY].Summary.Add(item1);
        }
        #endregion
    }
}
