﻿using Mozart.Studio.TaskModel.UserLibrary;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FabSimulatorUI.DataMappings
{
    internal class StepTargetMap
    {
        #region Input Table Name

        public const string STEP_TARGET_DATA_TABLE_NAME = "STEP_TARGET";

        #endregion


        #region Input Data Transform

        public class StepTarget
        {
            public string LineID;
            public string StepID;
            public string ProductID;
            public string RouteID;
            public string TargetShift;
            public int StepSeq;
            public DateTime PlanDate;
            //public int MoPriority;
            public double Qty;
            public float Scale;
            public string Mo_Demand_ID;
            public string Mo_Product_ID;
            public DateTime Mo_Due_Date;
            public StepTarget()
            {
                this.LineID = string.Empty;
                this.ProductID = string.Empty;
                this.RouteID = string.Empty;
                this.StepID = string.Empty;
                this.TargetShift = string.Empty;
                this.StepSeq = 0;
                this.PlanDate = DateTime.MinValue;
                this.Qty = 0;
                this.Mo_Demand_ID = string.Empty;
                this.Mo_Product_ID = string.Empty;
                this.Mo_Due_Date = DateTime.MinValue;
            }
            public StepTarget(DataRow row) : this()
            {
                ParseRow(row);
            }


            public class Schema
            {
                public const string LINE_ID = "LINE_ID";
                public const string PRODUCT_ID = "PRODUCT_ID";
                public const string ROUTE_ID = "ROUTE_ID";
                public const string STEP_ID = "STEP_ID";
                public const string STEP_SEQ = "STEP_SEQ";
                public const string TARGET_SHIFT = "TARGET_SHIFT";
                public const string TARGET_DATE = "TARGET_DATE";
                public const string QTY = "OUT_QTY";
                public const string MO_DEMAND_ID = "MO_DEMAND_ID";
                public const string MO_PRODUCT_ID = "MO_PRODUCT_ID";
                public const string MO_DUE_DATE = "MO_DUE_DATE";
            }

            private void ParseRow(DataRow row)
            {
                // LINE_ID
                LineID = row.GetString(Schema.LINE_ID);

                // PRODUCT_ID
                ProductID = row.GetString(Schema.PRODUCT_ID);

                // ROUTE_ID
                RouteID = row.GetString(Schema.ROUTE_ID);

                //TARGET_SHIFT
                TargetShift = row.GetString(Schema.TARGET_SHIFT);

                //STEP_SEQ
                StepSeq = row.GetInt32(Schema.STEP_SEQ);

                // STEP_ID
                StepID = row.GetString(Schema.STEP_ID);

                // PLAN_DATE
                PlanDate = row.GetString(Schema.TARGET_DATE).DbToDateTime();

                // QTY
                Qty = row.GetDouble(Schema.QTY);

                // Mo_Demand_ID
                Mo_Demand_ID = row.GetString(Schema.MO_DEMAND_ID);

                // Mo_Product_ID
                Mo_Product_ID = row.GetString(Schema.MO_PRODUCT_ID);

                // Mo_Due_Date
                Mo_Due_Date = row.GetString(Schema.MO_DUE_DATE).DbToDateTime();
            }
        }


        #endregion


        #region UI 화면 Caption

        public const string TITLE = "StepTarget";
        public const string CHART_TITLE = "";

        #endregion


        #region Captions

        internal struct Caption
        {
            public static string LineID = "LINE_ID";
            public static string StepID = "STEP_ID";
            public static string ProductID = "PRODUCT_ID";
            public static string ProcessID = "PROCESS_ID";
            public static string TargetShift = "TARGET_SHIFT";
            public static string StepSeq = "STEP_SEQ";
            public static string PlanDate = "TARGET_DATE";
            public static string Qty = "OUT_QTY";
            public static string DemandID = "DEMAND_ID";
            public static string Mo_Product_ID = "MO_PRODUCT_ID";
            public static string Mo_Due_Date = "MO_DUE_DATE";

        }

        #endregion
    }
}
