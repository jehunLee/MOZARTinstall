﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FabSimulatorUI.DataMappings
{
    internal class PeggingResultMap
    {
        #region Input Table Name

        public const string PRODUCT_TABLE_NAME = "Product";
        public const string PROC_STEP_TABLE_NAME = "ProcStep";
        public const string STEP_TAT_TABLE_NAME = "StepTatInfo";
        public const string WIP_TABLE_NAME = "Wip";
        public const string DEMAND_TABLE_NAME = "Demand";
        public const string PEG_HISTORY_TABLE_NAME = "PegHistory";
        public const string UNPEG_HISTORY_TABLE_NAME = "UnpegHistory";
        public const string STEP_TARGET_TABLE_NAME = "StepTarget";

        #endregion

        #region Captions

        internal struct Caption
        {
            public const string PRODUCT_ID = "PRODUCT_ID";
            public const string STEP_ID = "STEP_ID";
            public const string STEP_SEQ = "STEP_SEQ";
            public const string QTY = "QTY";
            public const string CT_WEEK = "CT_WEEK";
            public const string MO_WEEK = "MO_WEEK";
            public const string SECONDARY_AXIS = "SECONDARY_AXIS";
            public const string PEG_WEEK = "PEG_WEEK";
            public const string LOT_ID = "LOT_ID";
            public const string MO_DEMAND_ID = "MO_DEMAND_ID";
            public const string TARGET_DATE = "TARGET_DATE";
            public const double SIDE_MARGIN_VALUE = 0.1;
        }

        #endregion
    }
}
