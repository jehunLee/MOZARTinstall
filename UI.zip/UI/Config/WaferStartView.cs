﻿using DevExpress.XtraEditors;
using DevExpress.XtraEditors.Repository;
using DevExpress.XtraPivotGrid;
using FabSimulator;
using FabSimulator.Inputs;
using FabSimulatorUI.Common;
using Mozart.Extensions;
using Mozart.Studio.TaskModel.UserInterface;
using Mozart.Studio.TaskModel.UserLibrary;
using Mozart.Task.Model;
using System.ComponentModel.DataAnnotations;
using System.Data;

namespace FabSimulatorUI.Config
{
    public partial class WaferStartView : XtraPivotGridControlView
    {
        #region Variable&Property

        ModelDataContext modelDataContext;
        Experiment experiment;

        bool initializing;
        bool loading;
        bool generating;
        bool userTyping;

        string layoutPath;

        List<WaferInfo> waferStartData = new List<WaferInfo>();
        int colCount;
        DayOfWeek startDayOfWeek;

        Dictionary<string, DateTime> weekStartDateDict = new Dictionary<string, DateTime>();

        #endregion

        #region Ctor

        public WaferStartView(IServiceProvider serviceProvider)
            : base(serviceProvider)
        {
            InitializeComponent();

            this.initializing = true;
            this.ConstructInit();
        }

        protected override void LoadDocument()
        {
            this.LoadInit();
            this.initializing = false;

            this.loading = true;
            this.Query();
            this.loading = false;
        }

        private void Query()
        {
            using (var wc = new Mozart.Studio.UIComponents.WaitCursor())
            {
                this.BindBegin();
                this.BindDo();
                this.BindEnd();
            }
        }

        #endregion

        #region Init

        private void ConstructInit()
        {

        }

        private void LoadInit()
        {
            this.modelDataContext = this.Document.GetCtx<ModelDataContext>();
            this.experiment = Globals.GetExperiment(this.modelDataContext);

            Globals.InitFactoryTimeNew(this.modelDataContext);

            this.startDayOfWeek = ShopCalendar.StartWeek;

            this.dateEdit1.EditValue = this.experiment.Arguments["start-time"];
            this.spinEdit1.EditValue = this.experiment.Arguments["period"];

            this.spinEdit2.EditValue = 35000;
        }
        #endregion 

        private void BindBegin()
        {
            this.pivotGridControl1.BeginUpdate();
            this.SetPivotGridFields();
        }
        private void SetPivotGridFields()
        {
            this.pivotGridControl1.DataSource = null;
            this.pivotGridControl1.Fields.Clear();
            this.pivotGridControl1.OptionsBehavior.CopyToClipboardWithFieldValues = true;

            var f1 = this.pivotGridControl1.AddFieldRowArea<WaferInfo>(x => x.MFG_PART_ID);
            var f2 = this.pivotGridControl1.AddFieldRowArea<WaferInfo>(x => x.PRIORITY);
            var f3 = this.pivotGridControl1.AddFieldDataArea<WaferInfo>(x => x.WAFER_QTY);

            var f4 = this.pivotGridControl1.AddFieldColumnArea<WaferInfo>(x => x.YEAR);
            var f5 = this.pivotGridControl1.AddFieldColumnArea<WaferInfo>(x => x.MONTH);
            var f6 = this.pivotGridControl1.AddFieldColumnArea<WaferInfo>(x => x.WEEK);

            f1.Options.AllowDrag = DevExpress.Utils.DefaultBoolean.False;
            f2.Options.AllowDrag = DevExpress.Utils.DefaultBoolean.False;
            f3.Options.AllowDrag = DevExpress.Utils.DefaultBoolean.False;
            f4.Options.AllowDrag = DevExpress.Utils.DefaultBoolean.False;
            f5.Options.AllowDrag = DevExpress.Utils.DefaultBoolean.False;
            f6.Options.AllowDrag = DevExpress.Utils.DefaultBoolean.False;

            this.pivotGridControl1.OptionsView.ShowColumnGrandTotals = true;
        }

        private void BindDo()
        {
            using (var wc = new Mozart.Studio.UIComponents.WaitCursor())
            {
                SetVersionComboxBox();

                this.FillGrid();
            }
        }

        private void SetVersionComboxBox()
        {
            if (this.comboBoxEdit1.Properties.Items.Count > 0 && this.comboBoxEdit1.Text != "New")
                return;

            var versions = this.modelDataContext.UI_FAB_IN_PLAN.Select(x => x.VERSION_ID).OrderByDescending(x => x).Distinct().ToList();
            versions.Add("New");

            this.comboBoxEdit1.Properties.Items.Clear();
            this.comboBoxEdit1.FillValues(versions);
        }

        private void FillGrid()
        {
            this.generating = true;

            this.pivotGridControl1.DataSource = this.GenerateInputs().ToBindingList();

            this.generating = false;
        }

        private IEnumerable<WaferInfo> GenerateInputs()
        {
            this.waferStartData.Clear();

            var pst = Convert.ToDateTime(this.dateEdit1.EditValue);
            var uiFabInPlan = this.modelDataContext.UI_FAB_IN_PLAN.Where(x => x.VERSION_ID == this.comboBoxEdit1.Text).ToList();
            var period = (int)this.spinEdit1.Value; //day

            if (uiFabInPlan.IsNullOrEmpty() == false && userTyping == false)
            {
                var arrWeek = uiFabInPlan.Select(x => x.TARGET_WEEK).Distinct().OrderBy(x => x).ToList();
                period = FabSimulatorUI.Helper.GetPeriod(arrWeek[0], arrWeek[arrWeek.Count - 1]);
                this.spinEdit1.Value = period;
            }

            var weeklyMax = (int)this.spinEdit2.Value; //wafers // 용도??
            bool autoSpread = this.checkBox1.Checked;

            var mfgPartList = this.modelDataContext.PRODUCT.Select(x => x.MFG_PART_ID).Distinct().ToList();
            var weekStartDate = FabSimulatorUI.Helper.GetIntervalStartDate(pst, 1);
            var weekCount = Math.Ceiling((double)period / 7.0);

            this.colCount = (int)weekCount;

            for (int i = 0; i < weekCount; i++)
            {
                foreach (var item in mfgPartList)
                {
                    var info1 = new WaferInfo(item, "Hot", weekStartDate, 0, this.startDayOfWeek);
                    var info2 = new WaferInfo(item, "Normal", weekStartDate, 0, this.startDayOfWeek);

                    var existData1 = uiFabInPlan.Where(x => x.MFG_PART_ID == item && x.TARGET_WEEK == info1.TARGET_WEEK && x.PRIORITY == info1.PRIORITY_INT).FirstOrDefault();
                    if (existData1 != null)
                        info1.WAFER_QTY = existData1.WAFER_QTY;

                    var existData2 = uiFabInPlan.Where(x => x.MFG_PART_ID == item && x.TARGET_WEEK == info2.TARGET_WEEK && x.PRIORITY == info2.PRIORITY_INT).FirstOrDefault();
                    if (existData2 != null)
                        info2.WAFER_QTY = existData2.WAFER_QTY;

                    this.waferStartData.Add(info1);
                    this.waferStartData.Add(info2);

                    var key = info1.TARGET_WEEK;
                    if (this.weekStartDateDict.ContainsKey(key) == false)
                        this.weekStartDateDict.Add(key, weekStartDate);
                }

                weekStartDate = weekStartDate.AddDays(7);
            }

            return this.waferStartData;
        }

        private void BindEnd()
        {
            ResetEditingAppearance();

            this.pivotGridControl1.EndUpdate();

            this.pivotGridControl1.OptionsView.ShowColumnTotals = false;
            this.pivotGridControl1.OptionsView.ShowRowTotals = false;

            //this.pivotGridControl1.BestFitColumnArea();
            this.pivotGridControl1.BestFitRowArea();
        }

        private void ResetEditingAppearance()
        {
            this.SaveButton.Enabled = false;

            this.pivotGridControl1.RefreshData();

            this.waferStartData.ForEach(x => x.IS_EDITED = false);
        }

        class WaferInfo
        {
            public WaferInfo(string mFG_PART_ID, string pRIORITY, DateTime dt, int wAFER_QTY, DayOfWeek startDayOfWeek)
            {
                MFG_PART_ID = mFG_PART_ID;
                PRIORITY = pRIORITY;
                YEAR = dt.Year;
                MONTH = dt.Month;
                WEEK = FabSimulatorUI.Helper.GetTargetWeek(dt, startDayOfWeek);
                WAFER_QTY = wAFER_QTY;

                TARGET_WEEK = FabSimulatorUI.Helper.GetFormattedTargetWeek(dt, startDayOfWeek);
                PRIORITY_INT = pRIORITY == "Hot" ? 0 : 1;
            }

            public string MFG_PART_ID { get; set; }
            public string PRIORITY { get; set; }
            public int YEAR { get; set; }
            public int MONTH { get; set; }
            public int WEEK { get; set; }
            public int WAFER_QTY { get; set; }

            [Display(Order = -1)]
            public string TARGET_WEEK { get; set; }
            [Display(Order = -1)]
            public int PRIORITY_INT { get; set; }
            [Display(Order = -1)]
            public bool IS_EDITED { get; set; }
        }

        private void pivotGridControl1_CustomCellEdit(object sender, PivotCustomCellEditEventArgs e)
        {
            e.RepositoryItem = new RepositoryItemCalcEdit();
            //e.RepositoryItem = new RepositoryItemSpinEdit();
        }

        private void pivotGridControl1_CustomCellDisplayText(object sender, PivotCellDisplayTextEventArgs e)
        {
            if (e.DisplayText == string.Empty)
            {
                e.DisplayText = "0";
            }
        }

        private void pivotGridControl1_EditValueChanged(object sender, EditValueChangedEventArgs e)
        {
            this.SaveButton.Enabled = true;

            ChangeCellValue(e, Convert.ToInt32(e.Value), Convert.ToInt32(e.Editor.EditValue));
        }

        private void ChangeCellValue(EditValueChangedEventArgs e, int oldValue, int newValue)
        {
            if (this.checkBox1.Checked)
            {
                for (int i = 0; i < this.colCount; i++)
                {
                    var ds = pivotGridControl1.CreateDrillDownDataSource(i, e.RowIndex);

                    ds.SetValue(0, e.DataField, newValue);

                    ds[0]["IS_EDITED"] = true;
                }
            }
            else
            {
                PivotDrillDownDataSource ds = e.CreateDrillDownDataSource();

                ds.SetValue(0, e.DataField, newValue);

                ds[0]["IS_EDITED"] = true;
            }
        }

        private void dateEdit1_EditValueChanged(object sender, EventArgs e)
        {
            if (this.initializing || this.loading || this.generating)
                return;

            this.FillGrid();
        }

        private void spinEdit1_EditValueChanged(object sender, EventArgs e)
        {
            if (this.initializing || this.loading || this.generating)
                return;

            this.userTyping = true;
            this.FillGrid();
            this.userTyping = false;
        }

        private void spinEdit2_EditValueChanged(object sender, EventArgs e)
        {

        }

        private void SaveButton_Click(object sender, EventArgs e)
        {
            using (var wc = new Mozart.Studio.UIComponents.WaitCursor())
            {
                SaveChanges();
            }
        }

        private void SaveChanges()
        {
            try
            {
                DeleteUIVdat();

                InsertUIVdat();

                SetVersionComboxBox();

                ResetEditingAppearance();

                XtraMessageBox.Show("success to save changes", "Note");
            }
            catch (Exception ex)
            {
                XtraMessageBox.Show("fail to save changes", "Alert");
            }
        }

        private void convertButton_Click(object sender, EventArgs e)
        {
            using (var wc = new Mozart.Studio.UIComponents.WaitCursor())
            {
                try
                {
                    SaveChanges();

                    DeleteConvertedVdat();

                    InsertConvertedVdat();

                    XtraMessageBox.Show("success to convert", "Note");
                }
                catch (Exception ex)
                {
                    XtraMessageBox.Show("fail to convert", "Alert");
                }
            }
        }

        #region Data Interface
        private void DeleteUIVdat()
        {
            using (var acc = this.modelDataContext.Target.LocalAccessorFor("UI_FAB_IN_PLAN"))
            {
                var dtable = acc.QueryTable(null, -1, -1);

                List<DataRow> removable = new List<DataRow>();

                foreach (DataRow row in dtable.Rows)
                {
                    if (row["VERSION_ID"].ToString() == this.comboBoxEdit1.Text)
                        removable.Add(row);
                }

                removable.ForEach(x => dtable.Rows.Remove(x));

                acc.Save(dtable);
            }
        }

        private void InsertUIVdat()
        {
            using (var acc = this.modelDataContext.Target.LocalAccessorFor("UI_FAB_IN_PLAN"))
            {
                var dtable = acc.QueryTable(null, -1, -1);

                var versionID = this.comboBoxEdit1.Text;
                if (versionID == "New")
                    versionID = "UI_" + DateTime.Now.ToString("yyyyMMddHHmmss");

                foreach (var item in this.waferStartData)
                {
                    if (item.WAFER_QTY <= 0)
                        continue;

                    var nrow = dtable.NewRow();

                    nrow["VERSION_ID"] = versionID;
                    nrow["MFG_PART_ID"] = item.MFG_PART_ID;
                    nrow["TARGET_WEEK"] = item.TARGET_WEEK;

                    nrow["PRIORITY"] = item.PRIORITY_INT;
                    nrow["WAFER_QTY"] = item.WAFER_QTY;

                    dtable.Rows.Add(nrow);
                }

                acc.Save(dtable);
            }
        }

        private void DeleteConvertedVdat()
        {
            DeleteFabInPlan();
        }

        private void DeleteFabInPlan()
        {
            using (var acc = this.modelDataContext.Target.LocalAccessorFor("FAB_IN_PLAN"))
            {
                var dtable = acc.QueryTable(null, -1, -1);

                List<DataRow> removable = new List<DataRow>();

                foreach (DataRow row in dtable.Rows)
                {
                    removable.Add(row);
                }

                removable.ForEach(x => dtable.Rows.Remove(x));

                acc.Save(dtable);
            }
        }

        private void InsertConvertedVdat()
        {
            //modelDataContext => Studio에서 가져오는 파일의 모델 정보 가져오기

            var currentData = this.modelDataContext.UI_FAB_IN_PLAN.Where(x => x.VERSION_ID == this.comboBoxEdit1.Text).ToList();

            InsertFabInPlan(currentData);
        }

        private void InsertFabInPlan(IEnumerable<UI_FAB_IN_PLAN> infos)
        {
            using (var acc = this.modelDataContext.Target.LocalAccessorFor("FAB_IN_PLAN"))
            {
                var dtable = acc.QueryTable(null, -1, -1);


                foreach (var item in infos)
                {
                    for (int i = 0; i < 7; i++)
                    {
                        var nrow = dtable.NewRow();

                        //string
                        nrow["MFG_PART_ID"] = item.MFG_PART_ID;
                        //DateTime
                        nrow["START_DATETIME"] = this.weekStartDateDict.SafeGet(item.TARGET_WEEK).AddDays(i);
                        //int
                        nrow["WAFER_QTY"] = Math.Ceiling(item.WAFER_QTY / 7.0);
                        //int
                        nrow["LOT_SIZE"] = this.modelDataContext.GetConfigValue<int>(PARAM_GROUP: "Lot_Default", PARAM_NAME: "lotSize");
                        //string
                        nrow["FAB_IN_STATUS"] = "WAITING";
                        //int
                        nrow["PRIORITY"] = item.PRIORITY;

                        dtable.Rows.Add(nrow);
                    }
                }

                acc.Save(dtable);
            }
        }

        #endregion

        private void comboBoxEdit1_EditValueChanged(object sender, EventArgs e)
        {
            if (this.initializing || this.loading || this.generating)
                return;

            ResetEditingAppearance();

            FillGrid();
        }

        private void pivotGridControl1_CustomAppearance(object sender, PivotCustomAppearanceEventArgs e)
        {
            if (this.initializing || this.loading)
                return;

            var ds = pivotGridControl1.CreateDrillDownDataSource(e.ColumnIndex, e.RowIndex);

            if ((bool)ds[0]["IS_EDITED"])
            {
                e.Appearance.BackColor = Color.FloralWhite;
                e.Appearance.ForeColor = Color.Blue;
            }
            else
            {
                e.Appearance.BackColor = Color.White;
                e.Appearance.ForeColor = Color.Black;
            }
        }
    }
}
