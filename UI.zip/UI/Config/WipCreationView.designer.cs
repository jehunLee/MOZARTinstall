﻿
namespace FabSimulatorUI.Config
{
    partial class WipCreationView
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 구성 요소 디자이너에서 생성한 코드

        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            panelControl1 = new DevExpress.XtraEditors.PanelControl();
            gridControl1 = new DevExpress.XtraGrid.GridControl();
            gridView1 = new DevExpress.XtraGrid.Views.Grid.GridView();
            expandablePanel1 = new Mozart.Studio.UIComponents.ExpandablePanel();
            lblCycleTimeFactor = new Label();
            numericUpDown1 = new NumericUpDown();
            priorityButton = new Button();
            capacityButton = new Button();
            convertButton = new Button();
            comboBoxEdit1 = new DevExpress.XtraEditors.ComboBoxEdit();
            saveButton = new Button();
            labe1 = new Label();
            dockManager1 = new DevExpress.XtraBars.Docking.DockManager(components);
            ((System.ComponentModel.ISupportInitialize)panelControl1).BeginInit();
            panelControl1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)gridControl1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)gridView1).BeginInit();
            expandablePanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)numericUpDown1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)comboBoxEdit1.Properties).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dockManager1).BeginInit();
            SuspendLayout();
            // 
            // panelControl1
            // 
            panelControl1.Controls.Add(gridControl1);
            panelControl1.Controls.Add(expandablePanel1);
            panelControl1.Dock = DockStyle.Fill;
            panelControl1.Location = new Point(0, 0);
            panelControl1.Margin = new Padding(3, 4, 3, 4);
            panelControl1.Name = "panelControl1";
            panelControl1.Size = new Size(1371, 883);
            panelControl1.TabIndex = 0;
            // 
            // gridControl1
            // 
            gridControl1.Dock = DockStyle.Fill;
            gridControl1.EmbeddedNavigator.Margin = new Padding(3, 4, 3, 4);
            gridControl1.Location = new Point(2, 101);
            gridControl1.MainView = gridView1;
            gridControl1.Margin = new Padding(3, 4, 3, 4);
            gridControl1.Name = "gridControl1";
            gridControl1.Size = new Size(1367, 780);
            gridControl1.TabIndex = 1;
            gridControl1.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] { gridView1 });
            // 
            // gridView1
            // 
            gridView1.DetailHeight = 450;
            gridView1.GridControl = gridControl1;
            gridView1.Name = "gridView1";
            gridView1.OptionsEditForm.PopupEditFormWidth = 914;
            gridView1.CellValueChanged += gridView1_CellValueChanged;
            // 
            // expandablePanel1
            // 
            expandablePanel1.Controls.Add(lblCycleTimeFactor);
            expandablePanel1.Controls.Add(numericUpDown1);
            expandablePanel1.Controls.Add(priorityButton);
            expandablePanel1.Controls.Add(capacityButton);
            expandablePanel1.Controls.Add(convertButton);
            expandablePanel1.Controls.Add(comboBoxEdit1);
            expandablePanel1.Controls.Add(saveButton);
            expandablePanel1.Controls.Add(labe1);
            expandablePanel1.Dock = DockStyle.Top;
            expandablePanel1.ForeColor = Color.SteelBlue;
            expandablePanel1.Location = new Point(2, 2);
            expandablePanel1.Margin = new Padding(3, 4, 3, 4);
            expandablePanel1.Name = "expandablePanel1";
            expandablePanel1.Size = new Size(1367, 99);
            expandablePanel1.TabIndex = 0;
            expandablePanel1.Text = "Description";
            expandablePanel1.UseAnimation = true;
            // 
            // lblCycleTimeFactor
            // 
            lblCycleTimeFactor.AutoSize = true;
            lblCycleTimeFactor.BackColor = Color.Transparent;
            lblCycleTimeFactor.ForeColor = SystemColors.ActiveCaptionText;
            lblCycleTimeFactor.Location = new Point(517, 52);
            lblCycleTimeFactor.Name = "lblCycleTimeFactor";
            lblCycleTimeFactor.Size = new Size(126, 18);
            lblCycleTimeFactor.TabIndex = 90;
            lblCycleTimeFactor.Text = "Cycle Time Factor";
            // 
            // numericUpDown1
            // 
            numericUpDown1.DecimalPlaces = 2;
            numericUpDown1.Location = new Point(649, 50);
            numericUpDown1.Name = "numericUpDown1";
            numericUpDown1.Size = new Size(106, 26);
            numericUpDown1.TabIndex = 89;
            numericUpDown1.Value = new decimal(new int[] { 1, 0, 0, 0 });
            // 
            // priorityButton
            // 
            priorityButton.Location = new Point(393, 48);
            priorityButton.Name = "priorityButton";
            priorityButton.Size = new Size(105, 29);
            priorityButton.TabIndex = 88;
            priorityButton.Text = "Set Priority";
            priorityButton.UseVisualStyleBackColor = true;
            priorityButton.Click += PriorityButton_Click;
            // 
            // capacityButton
            // 
            capacityButton.Location = new Point(282, 48);
            capacityButton.Name = "capacityButton";
            capacityButton.Size = new Size(105, 29);
            capacityButton.TabIndex = 87;
            capacityButton.Text = "Set Capacity";
            capacityButton.UseVisualStyleBackColor = true;
            capacityButton.Click += CapacityButton_Click;
            // 
            // convertButton
            // 
            convertButton.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            convertButton.Location = new Point(1231, 45);
            convertButton.Margin = new Padding(3, 4, 3, 4);
            convertButton.Name = "convertButton";
            convertButton.Size = new Size(110, 35);
            convertButton.TabIndex = 86;
            convertButton.Text = "Convert";
            convertButton.UseVisualStyleBackColor = true;
            convertButton.Click += ConvertButton_Click;
            // 
            // comboBoxEdit1
            // 
            comboBoxEdit1.Location = new Point(85, 49);
            comboBoxEdit1.Margin = new Padding(3, 4, 3, 4);
            comboBoxEdit1.Name = "comboBoxEdit1";
            comboBoxEdit1.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] { new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo) });
            comboBoxEdit1.Size = new Size(177, 24);
            comboBoxEdit1.TabIndex = 85;
            comboBoxEdit1.SelectedIndexChanged += comboBoxEdit1_SelectedIndexChanged;
            comboBoxEdit1.EditValueChanged += ComboBoxEdit1_EditValueChanged;
            // 
            // saveButton
            // 
            saveButton.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            saveButton.Location = new Point(1138, 44);
            saveButton.Margin = new Padding(3, 4, 3, 4);
            saveButton.Name = "saveButton";
            saveButton.Size = new Size(86, 35);
            saveButton.TabIndex = 3;
            saveButton.Text = "Save";
            saveButton.UseVisualStyleBackColor = true;
            saveButton.Click += SaveButton_Click;
            // 
            // labe1
            // 
            labe1.AutoSize = true;
            labe1.Location = new Point(24, 53);
            labe1.Name = "labe1";
            labe1.Size = new Size(55, 18);
            labe1.TabIndex = 61;
            labe1.Text = "Version";
            // 
            // dockManager1
            // 
            dockManager1.Form = this;
            dockManager1.TopZIndexControls.AddRange(new string[] { "DevExpress.XtraBars.BarDockControl", "DevExpress.XtraBars.StandaloneBarDockControl", "System.Windows.Forms.StatusBar", "System.Windows.Forms.MenuStrip", "System.Windows.Forms.StatusStrip", "DevExpress.XtraBars.Ribbon.RibbonStatusBar", "DevExpress.XtraBars.Ribbon.RibbonControl", "DevExpress.XtraBars.Navigation.OfficeNavigationBar", "DevExpress.XtraBars.Navigation.TileNavPane" });
            // 
            // WipCreationView
            // 
            AutoScaleDimensions = new SizeF(8F, 18F);
            AutoScaleMode = AutoScaleMode.Font;
            Controls.Add(panelControl1);
            Margin = new Padding(3, 4, 3, 4);
            Name = "WipCreationView";
            Size = new Size(1371, 883);
            ((System.ComponentModel.ISupportInitialize)panelControl1).EndInit();
            panelControl1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)gridControl1).EndInit();
            ((System.ComponentModel.ISupportInitialize)gridView1).EndInit();
            expandablePanel1.ResumeLayout(false);
            expandablePanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)numericUpDown1).EndInit();
            ((System.ComponentModel.ISupportInitialize)comboBoxEdit1.Properties).EndInit();
            ((System.ComponentModel.ISupportInitialize)dockManager1).EndInit();
            ResumeLayout(false);
        }

        #endregion

        /// <summary>   The first panel control. </summary>
        private DevExpress.XtraEditors.PanelControl panelControl1;
        /// <summary>   The first expandable panel. </summary>
        private Mozart.Studio.UIComponents.ExpandablePanel expandablePanel1;
        /// <summary>   The label 2 control. </summary>
        private Label labe1;
        /// <summary>   The button query control. </summary>
        private Button saveButton;
        /// <summary>   The first dock manager. </summary>
        private DevExpress.XtraBars.Docking.DockManager dockManager1;
        private DevExpress.XtraEditors.ComboBoxEdit comboBoxEdit1;
        private Button convertButton;
        private DevExpress.XtraGrid.GridControl gridControl1;
        private DevExpress.XtraGrid.Views.Grid.GridView gridView1;
        private Button priorityButton;
        private Button capacityButton;
        private NumericUpDown numericUpDown1;
        private Label lblCycleTimeFactor;
    }
}
