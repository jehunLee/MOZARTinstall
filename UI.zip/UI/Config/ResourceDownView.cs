﻿using DevExpress.XtraEditors;
using FabSimulator;
using FabSimulator.Inputs;
using FabSimulatorUI.Common;
using Mozart.Extensions;
using Mozart.Studio.TaskModel.UserInterface;
using Mozart.Studio.TaskModel.UserLibrary;
using Mozart.Task.Model;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Data;

namespace FabSimulatorUI.Config
{
    public partial class ResourceDownView : XtraGridControlView
    {
        #region Variable&Property

        ModelDataContext modelDataContext;
        Experiment experiment;

        bool initializing;
        bool loading;
        bool onEdit;

        string photoArea;
        List<ResourceDownInfo> resourceDownInfos;

        List<string> areaList;
        List<string> eqpGroupList;
        List<string> eqpList;

        Random random = new Random(1);

        #endregion

        #region Ctor

        public ResourceDownView(IServiceProvider serviceProvider)
            : base(serviceProvider)
        {
            InitializeComponent();

            this.initializing = true;
            this.ConstructInit();
        }

        protected override void LoadDocument()
        {
            this.LoadInit();
            this.initializing = false;

            this.loading = true;
            this.Query();
            this.loading = false;
        }

        private void Query()
        {
            using (var wc = new Mozart.Studio.UIComponents.WaitCursor())
            {
                this.BindBegin();
                this.BindDo();
                this.BindEnd();
            }
        }

        #endregion

        #region Init

        private void ConstructInit()
        {
        }

        private void LoadInit()
        {
            this.modelDataContext = this.Document.GetCtx<ModelDataContext>();
            this.experiment = Globals.GetExperiment(this.modelDataContext);

            this.photoArea = this.modelDataContext.GetConfigValue<string>(PARAM_GROUP: "Simulation_Report", PARAM_NAME: "photoArea");

            this.areaList = this.modelDataContext.EQP.Select(x => x.AREA_ID).Distinct().ToList();
            this.eqpGroupList = this.modelDataContext.EQP.Select(x => x.EQP_GROUP).Distinct().ToList();
            this.eqpList = this.modelDataContext.EQP.Select(x => x.EQP_ID).Distinct().ToList();

            Globals.InitFactoryTimeNew(this.modelDataContext);
        }
        #endregion

        #region Data Binding
        private void BindBegin()
        {
            this.gridControl1.BeginUpdate();
        }

        private void BindDo()
        {
            using (var wc = new Mozart.Studio.UIComponents.WaitCursor())
            {
                SetVersionComboxBox();

                FillGrid();
            }
        }

        private void SetVersionComboxBox()
        {
            if (this.comboBoxEdit1.Properties.Items.Count > 0 && this.comboBoxEdit1.Text != "New")
                return;

            var versions = this.modelDataContext.UI_RESOURCE_DOWN.Select(x => x.VERSION_ID).OrderByDescending(x => x).Distinct().ToList();
            versions.Add("New");

            this.comboBoxEdit1.Properties.Items.Clear();
            this.comboBoxEdit1.FillValues(versions);
        }

        private void FillGrid()
        {
            var areas = this.areaList;
            var xt = "XT";
            var nxEqps = this.modelDataContext.EQP.Where(x => x.EQP_GROUP == "NXT" || x.EQP_GROUP == "NXE").Select(x => x.EQP_ID);
            var existList = this.modelDataContext.UI_RESOURCE_DOWN.Where(x => x.VERSION_ID == this.comboBoxEdit1.Text).Select(x => x.RESOURCE_ID);

            var resourceList = areas.Concat(xt).Concat(nxEqps).Concat(existList).Distinct();

            this.resourceDownInfos = (from a in resourceList
                                      join b in this.modelDataContext.UI_RESOURCE_DOWN.Where(x => x.VERSION_ID == this.comboBoxEdit1.Text) on a equals b.RESOURCE_ID into outer
                                      let resourceType = areas.Contains(a) ? "1.AREA" : (a == "XT" ? "2.EQP_GROUP" : "3.EQP")
                                      from o in outer.DefaultIfEmpty()
                                      select new ResourceDownInfo
                                      {
                                          RESOURCE = a,
                                          RESOURCE_TYPE = o != null ? o.RESOURCE_TYPE : resourceType,
                                          AVAILABILITY = o != null ? o.AVAILABILITY : 0,
                                          EXPECTED_UD_COUNT = o != null ? o.UD_COUNT : 0,
                                          MTTR = o != null ? o.MTTR : 0,
                                          MTTF = o != null ? o.MTTF : 0,
                                          INITIAL_BM = o != null ? o.INIT_BM : 0
                                      }).ToList();

            this.gridControl1.DataSource = this.resourceDownInfos.ToBindingList();
        }

        private void BindEnd()
        {
            SetCaption();

            SetHeaderOption();

            ResetEditingAppearance();

            this.gridView1.BestFitColumns();
            this.gridView1.OptionsView.ColumnAutoWidth = false;
            this.gridView1.OptionsView.ShowGroupPanel = true;
            this.gridView1.OptionsSelection.EnableAppearanceFocusedRow = false;

            this.gridControl1.UseEmbeddedNavigator = true;
            //this.gridView1.OptionsView.NewItemRowPosition = DevExpress.XtraGrid.Views.Grid.NewItemRowPosition.Bottom;

            this.gridControl1.EndUpdate();
        }

        private void SetCaption()
        {
            this.gridView1.Columns[1].Caption = "Availability(%)";
            this.gridView1.Columns[2].Caption = "Expected UD Count";
            this.gridView1.Columns[5].Caption = "Initial BM";
        }

        private void SetHeaderOption()
        {
            for (int i = 3; i < 6; i++)
            {
                this.gridView1.Columns[i].OptionsColumn.AllowEdit = false;
                this.gridView1.Columns[i].OptionsColumn.AllowFocus = false;
            }

            for (int i = 0; i < 3; i++)
            {
                this.gridView1.Columns[i].OptionsColumn.AllowEdit = true;
                this.gridView1.Columns[i].OptionsColumn.AllowFocus = true;
                this.gridView1.Columns[i].AppearanceCell.BackColor = Color.FloralWhite;
            }
        }

        private void ResetEditingAppearance()
        {
            this.saveButton.Enabled = false;

            this.gridView1.RefreshData();

            this.resourceDownInfos.ForEach(x => x.IS_EDITED = false);
        }

        #endregion

        #region Event Handler

        private void gridView1_CellValueChanged(object sender, DevExpress.XtraGrid.Views.Base.CellValueChangedEventArgs e)
        {
            if (this.onEdit)
                return;

            this.onEdit = true;
            this.saveButton.Enabled = true;

            var availCol = this.gridView1.Columns[1];
            var udCountCol = this.gridView1.Columns[2];
            var mttrCol = this.gridView1.Columns[3];
            var mttfCol = this.gridView1.Columns[4];
            var initBmCol = this.gridView1.Columns[5];

            var availability = (double)this.gridView1.GetRowCellValue(e.RowHandle, availCol) / 100;
            var expectedUDCount = (double)this.gridView1.GetRowCellValue(e.RowHandle, udCountCol);

            var mttr = Math.Round((365 * 24 * (1 - availability)) / expectedUDCount, 3);
            var mttf = Math.Round((365 * 24 * availability) / expectedUDCount, 3);
            var initBm = Math.Round(mttf * 0.5, 3);

            this.gridView1.SetRowCellValue(e.RowHandle, mttrCol, mttr);
            this.gridView1.SetRowCellValue(e.RowHandle, mttfCol, mttf);
            this.gridView1.SetRowCellValue(e.RowHandle, initBmCol, initBm);

            var info = GetResourceDownInfo(e.RowHandle);
            if (info != null)
                info.IS_EDITED = true;

            this.onEdit = false;
        }

        private void gridView1_RowStyle(object sender, DevExpress.XtraGrid.Views.Grid.RowStyleEventArgs e)
        {
            if (this.initializing || this.loading)
                return;

            var info = GetResourceDownInfo(e.RowHandle);
            if (info == null)
                return;

            if (info.RESOURCE_TYPE == "ERROR")
                e.Appearance.ForeColor = Color.Red;
            else if (info.IS_EDITED)
                e.Appearance.ForeColor = Color.Blue;
            else
                e.Appearance.ForeColor = Color.Black;
        }

        private ResourceDownInfo GetResourceDownInfo(int rowHandle)
        {
            ResourceDownInfo info = null;

            var resourceCol = this.gridView1.Columns[0];
            var value = this.gridView1.GetRowCellValue(rowHandle, resourceCol);
            if (value != null)
            {
                info = this.resourceDownInfos.Where(x => x.RESOURCE == value.ToString()).FirstOrDefault();

                if (info == null)
                {
                    var newItem = new ResourceDownInfo();
                    newItem.RESOURCE = value.ToString();
                    newItem.AVAILABILITY = (double)this.gridView1.GetRowCellValue(rowHandle, this.gridView1.Columns[1]);
                    newItem.EXPECTED_UD_COUNT = (double)this.gridView1.GetRowCellValue(rowHandle, this.gridView1.Columns[2]);

                    this.resourceDownInfos.Add(newItem);

                    info = newItem;
                }
            }

            return info;
        }

        private void gridView1_RowDeleted(object sender, DevExpress.Data.RowDeletedEventArgs e)
        {
            this.saveButton.Enabled = true;
        }

        private void comboBoxEdit1_EditValueChanged(object sender, EventArgs e)
        {
            if (this.initializing || this.loading)
                return;

            ResetEditingAppearance();

            FillGrid();
        }

        private void SaveButton_Click(object sender, EventArgs e)
        {
            using (var wc = new Mozart.Studio.UIComponents.WaitCursor())
            {
                SaveChanges();
            }
        }

        private void SaveChanges()
        {
            try
            {
                DeleteUIVdat();

                InsertUIVdat();

                SetVersionComboxBox();

                ResetEditingAppearance();

                FillGrid(); // 이미 Versioning 된 상태에서 저장 시, 색상 반영을 위해 호출.

                XtraMessageBox.Show("success to save changes", "Note");
            }
            catch (Exception ex)
            {
                XtraMessageBox.Show("fail to save changes", "Alert");
            }
        }

        private void convertButton_Click(object sender, EventArgs e)
        {
            using (var wc = new Mozart.Studio.UIComponents.WaitCursor())
            {
                try
                {
                    SaveChanges();

                    DeleteConvertedVdat();

                    InsertConvertedVdat();

                    XtraMessageBox.Show("success to convert", "Note");
                }
                catch (Exception ex)
                {
                    XtraMessageBox.Show("fail to convert", "Alert");
                }
            }
        }

        #endregion

        #region Data Interface
        private void DeleteUIVdat()
        {
            using (var acc = this.modelDataContext.Target.LocalAccessorFor("UI_RESOURCE_DOWN"))
            {
                var dtable = acc.QueryTable(null, -1, -1);

                List<DataRow> removable = new List<DataRow>();

                foreach (DataRow row in dtable.Rows)
                {
                    if (row["VERSION_ID"].ToString() == this.comboBoxEdit1.Text)
                        removable.Add(row);
                }

                removable.ForEach(x => dtable.Rows.Remove(x));

                acc.Save(dtable);
            }
        }

        private void InsertUIVdat()
        {
            using (var acc = this.modelDataContext.Target.LocalAccessorFor("UI_RESOURCE_DOWN"))
            {
                var dtable = acc.QueryTable(null, -1, -1);

                var versionID = this.comboBoxEdit1.Text;
                if (versionID == "New")
                    versionID = "UI_" + DateTime.Now.ToString("yyyyMMddHHmmss");

                foreach (var item in this.gridControl1.DataSource as BindingList<ResourceDownInfo>)
                {
                    SetResourceType(item);

                    if (item.IS_SAMPLE)
                        continue;

                    var nrow = dtable.NewRow();

                    nrow["VERSION_ID"] = versionID;
                    nrow["RESOURCE_ID"] = item.RESOURCE;
                    nrow["AVAILABILITY"] = item.AVAILABILITY;
                    nrow["UD_COUNT"] = item.EXPECTED_UD_COUNT;
                    nrow["INIT_BM"] = item.INITIAL_BM;
                    nrow["MTTF"] = item.MTTF;
                    nrow["MTTR"] = item.MTTR;
                    nrow["RESOURCE_TYPE"] = item.RESOURCE_TYPE;

                    dtable.Rows.Add(nrow);
                }

                acc.Save(dtable);
            }
        }

        private void SetResourceType(ResourceDownInfo info)
        {
            // 즉시 반영하기에는 경우에 따른 핸들링이 어려워서 Save시에만 체크.
            info.IS_SAMPLE = info.AVAILABILITY == 0 && info.EXPECTED_UD_COUNT == 0 && info.RESOURCE_TYPE != null && info.RESOURCE_TYPE != "ERROR";

            bool isValid = info.IS_SAMPLE || (info.MTTR > 0 && info.MTTF > 0 && info.INITIAL_BM > 0 && info.AVAILABILITY > 0 && info.EXPECTED_UD_COUNT > 0);
            if (isValid == false)
                info.RESOURCE_TYPE = "ERROR";
            else
            {
                if (this.areaList.Contains(info.RESOURCE))
                    info.RESOURCE_TYPE = "1.AREA";
                else if (this.eqpGroupList.Contains(info.RESOURCE))
                    info.RESOURCE_TYPE = "2.EQP_GROUP";
                else if (this.eqpList.Contains(info.RESOURCE))
                    info.RESOURCE_TYPE = "3.EQP";
                else
                    info.RESOURCE_TYPE = "ERROR";
            }
        }

        private void DeleteConvertedVdat()
        {
            DeleteEqpDownCondVdat();
        }

        private void DeleteEqpDownCondVdat()
        {
            using (var acc = this.modelDataContext.Target.LocalAccessorFor("EQP_DOWN_COND"))
            {
                var dtable = acc.QueryTable(null, -1, -1);

                List<DataRow> removable = new List<DataRow>();

                foreach (DataRow row in dtable.Rows)
                {
                    if (row["EVENT_CODE"].ToString() == "RESOURCE_DOWN_UI")
                    {
                        removable.Add(row);
                    }
                }

                removable.ForEach(x => dtable.Rows.Remove(x));

                acc.Save(dtable);
            }
        }

        private void InsertConvertedVdat()
        {
            var currentData = this.modelDataContext.UI_RESOURCE_DOWN.Where(x => x.VERSION_ID == this.comboBoxEdit1.Text).OrderByDescending(x => x.RESOURCE_TYPE).ToList();

            InsertEqpDownCond(currentData);
        }

        private void InsertEqpDownCond(IEnumerable<UI_RESOURCE_DOWN> infos)
        {
            random = new Random(1);

            List<string> insertedEqpList = new List<string>();

            using (var acc = this.modelDataContext.Target.LocalAccessorFor("EQP_DOWN_COND"))
            {
                var test_table = this.modelDataContext.EQP_DOWN_COND;

                var dtable = acc.QueryTable(null, -1, -1);

                var eqpList = new List<string>();
                var pstDate = Convert.ToDateTime(this.experiment.Arguments["start-time"]);

                foreach (var item in infos)
                {
                    if (item.RESOURCE_TYPE == "ERROR")
                        continue;

                    eqpList.Clear();

                    if (item.RESOURCE_TYPE == "1.AREA")
                        eqpList = this.modelDataContext.EQP.Where(x => x.PARENT_EQP_ID.IsNullOrEmpty() && x.AREA_ID == item.RESOURCE_ID).Select(x => x.EQP_ID).ToList();
                    else if (item.RESOURCE_TYPE == "2.EQP_GROUP")
                        eqpList = this.modelDataContext.EQP.Where(x => x.PARENT_EQP_ID.IsNullOrEmpty() && x.EQP_GROUP == item.RESOURCE_ID).Select(x => x.EQP_ID).ToList();
                    else
                        eqpList.Add(item.RESOURCE_ID);

                    foreach (var eqp in eqpList)
                    {
                        if (insertedEqpList.Contains(eqp))
                            continue;

                        insertedEqpList.Add(eqp);

                        var nrow = dtable.NewRow();

                        nrow["EQP_ID"] = eqp;
                        nrow["EVENT_CODE"] = "RESOURCE_DOWN_UI";

                        double initBm = GetDistributionRandomNumber(1.0 / item.INIT_BM);
                        if (initBm >= item.INIT_BM * item.INIT_BM * 3)
                            initBm = item.INIT_BM;

                        nrow["LAST_EVENT_TIME"] = pstDate - TimeSpan.FromHours(initBm);
                        nrow["DOWN_TYPE"] = "BM_TBM";
                        nrow["MTTF_HRS_PDF"] = string.Format("Exponential({0})", item.MTTF);
                        nrow["MTTR_HRS_PDF"] = string.Format("Exponential({0})", item.MTTR);

                        dtable.Rows.Add(nrow);
                    }
                }

                acc.Save(dtable);
            }
        }

        private double GetDistributionRandomNumber(double lamda)
        {
            double u;
            do
            {
                u = random.NextDouble();
            } while (u == 0.0);
            double x = -Math.Log(u) / lamda;

            return x;
        }

        #endregion

        #region Data Class
        class ResourceDownInfo
        {
            public string RESOURCE { get; set; }
            public double AVAILABILITY { get; set; }
            public double EXPECTED_UD_COUNT { get; set; }
            public double MTTR { get; set; }
            public double MTTF { get; set; }
            public double INITIAL_BM { get; set; }

            [Display(Order = -1)]
            public string RESOURCE_TYPE { get; set; }
            [Display(Order = -1)]
            public bool IS_EDITED { get; set; }
            [Display(Order = -1)]
            public bool IS_SAMPLE { get; set; }

        }

        #endregion
    }
}