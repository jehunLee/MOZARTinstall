﻿
namespace FabSimulatorUI.Config
{
    partial class ResourceDownView
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 구성 요소 디자이너에서 생성한 코드

        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            panelControl1 = new DevExpress.XtraEditors.PanelControl();
            gridControl1 = new DevExpress.XtraGrid.GridControl();
            gridView1 = new DevExpress.XtraGrid.Views.Grid.GridView();
            expandablePanel1 = new Mozart.Studio.UIComponents.ExpandablePanel();
            convertButton = new Button();
            comboBoxEdit1 = new DevExpress.XtraEditors.ComboBoxEdit();
            saveButton = new Button();
            labe1 = new Label();
            dockManager1 = new DevExpress.XtraBars.Docking.DockManager(components);
            ((System.ComponentModel.ISupportInitialize)panelControl1).BeginInit();
            panelControl1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)gridControl1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)gridView1).BeginInit();
            expandablePanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)comboBoxEdit1.Properties).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dockManager1).BeginInit();
            SuspendLayout();
            // 
            // panelControl1
            // 
            panelControl1.Controls.Add(gridControl1);
            panelControl1.Controls.Add(expandablePanel1);
            panelControl1.Dock = DockStyle.Fill;
            panelControl1.Location = new Point(0, 0);
            panelControl1.Name = "panelControl1";
            panelControl1.Size = new Size(1200, 687);
            panelControl1.TabIndex = 0;
            // 
            // gridControl1
            // 
            gridControl1.Dock = DockStyle.Fill;
            gridControl1.Location = new Point(2, 79);
            gridControl1.MainView = gridView1;
            gridControl1.Name = "gridControl1";
            gridControl1.Size = new Size(1196, 606);
            gridControl1.TabIndex = 1;
            gridControl1.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] { gridView1 });
            // 
            // gridView1
            // 
            gridView1.GridControl = gridControl1;
            gridView1.Name = "gridView1";
            gridView1.RowStyle += gridView1_RowStyle;
            gridView1.CellValueChanged += gridView1_CellValueChanged;
            gridView1.RowDeleted += gridView1_RowDeleted;
            // 
            // expandablePanel1
            // 
            expandablePanel1.Controls.Add(convertButton);
            expandablePanel1.Controls.Add(comboBoxEdit1);
            expandablePanel1.Controls.Add(saveButton);
            expandablePanel1.Controls.Add(labe1);
            expandablePanel1.Dock = DockStyle.Top;
            expandablePanel1.ForeColor = Color.SteelBlue;
            expandablePanel1.Location = new Point(2, 2);
            expandablePanel1.Name = "expandablePanel1";
            expandablePanel1.Size = new Size(1196, 77);
            expandablePanel1.TabIndex = 0;
            expandablePanel1.Text = "Resource DOWN";
            expandablePanel1.UseAnimation = true;
            // 
            // convertButton
            // 
            convertButton.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            convertButton.Location = new Point(1077, 35);
            convertButton.Name = "convertButton";
            convertButton.Size = new Size(96, 27);
            convertButton.TabIndex = 86;
            convertButton.Text = "Convert";
            convertButton.UseVisualStyleBackColor = true;
            convertButton.Click += convertButton_Click;
            // 
            // comboBoxEdit1
            // 
            comboBoxEdit1.Location = new Point(74, 38);
            comboBoxEdit1.Name = "comboBoxEdit1";
            comboBoxEdit1.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] { new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo) });
            comboBoxEdit1.Size = new Size(155, 20);
            comboBoxEdit1.TabIndex = 85;
            comboBoxEdit1.EditValueChanged += comboBoxEdit1_EditValueChanged;
            // 
            // saveButton
            // 
            saveButton.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            saveButton.Location = new Point(996, 34);
            saveButton.Name = "saveButton";
            saveButton.Size = new Size(75, 27);
            saveButton.TabIndex = 3;
            saveButton.Text = "Save";
            saveButton.UseVisualStyleBackColor = true;
            saveButton.Click += SaveButton_Click;
            // 
            // labe1
            // 
            labe1.AutoSize = true;
            labe1.Location = new Point(21, 41);
            labe1.Name = "labe1";
            labe1.Size = new Size(47, 14);
            labe1.TabIndex = 61;
            labe1.Text = "Version";
            // 
            // dockManager1
            // 
            dockManager1.Form = this;
            dockManager1.TopZIndexControls.AddRange(new string[] { "DevExpress.XtraBars.BarDockControl", "DevExpress.XtraBars.StandaloneBarDockControl", "System.Windows.Forms.StatusBar", "System.Windows.Forms.MenuStrip", "System.Windows.Forms.StatusStrip", "DevExpress.XtraBars.Ribbon.RibbonStatusBar", "DevExpress.XtraBars.Ribbon.RibbonControl", "DevExpress.XtraBars.Navigation.OfficeNavigationBar", "DevExpress.XtraBars.Navigation.TileNavPane" });
            // 
            // ResourceDownView
            // 
            AutoScaleDimensions = new SizeF(7F, 14F);
            AutoScaleMode = AutoScaleMode.Font;
            Controls.Add(panelControl1);
            Name = "ResourceDownView";
            Size = new Size(1200, 687);
            ((System.ComponentModel.ISupportInitialize)panelControl1).EndInit();
            panelControl1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)gridControl1).EndInit();
            ((System.ComponentModel.ISupportInitialize)gridView1).EndInit();
            expandablePanel1.ResumeLayout(false);
            expandablePanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)comboBoxEdit1.Properties).EndInit();
            ((System.ComponentModel.ISupportInitialize)dockManager1).EndInit();
            ResumeLayout(false);
        }

        #endregion

        /// <summary>   The first panel control. </summary>
        private DevExpress.XtraEditors.PanelControl panelControl1;
        /// <summary>   The first expandable panel. </summary>
        private Mozart.Studio.UIComponents.ExpandablePanel expandablePanel1;
        /// <summary>   The label 2 control. </summary>
        private Label labe1;
        /// <summary>   The button query control. </summary>
        private Button saveButton;
        /// <summary>   The first dock manager. </summary>
        private DevExpress.XtraBars.Docking.DockManager dockManager1;
        private DevExpress.XtraEditors.ComboBoxEdit comboBoxEdit1;
        private Button convertButton;
        private DevExpress.XtraGrid.GridControl gridControl1;
        private DevExpress.XtraGrid.Views.Grid.GridView gridView1;
    }
}
