﻿using System.Data;
using Mozart.Studio.TaskModel.UserInterface;
using Mozart.Studio.TaskModel.UserLibrary;
using FabSimulator;
using DevExpress.XtraGrid.Views.Grid;
using DevExpress.XtraEditors.Repository;
using FabSimulatorUI.Common;
using Mozart.Extensions;
using FabSimulator.Inputs;
using DevExpress.XtraEditors;
using DevExpress.XtraEditors.Controls;
using System.ComponentModel.DataAnnotations;
using Mozart.Task.Model;

namespace FabSimulatorUI.Config
{
    public partial class ResourceBackupView : XtraGridControlView
    {
        #region Variable&Property

        ModelDataContext modelDataContext;
        Experiment experiment;

        bool initializing;
        bool loading;

        List<EqpBackupInfo> photoBackupInfos;
        GridView _currentGrid;

        public GridView CurrentGrid
        {
            get { return _currentGrid; }
            set { _currentGrid = value; }
        }

        #endregion

        #region Ctor

        public ResourceBackupView(IServiceProvider serviceProvider)
            : base(serviceProvider)
        {
            InitializeComponent();

            this.initializing = true;
            this.ConstructInit();
        }

        protected override void LoadDocument()
        {
            this.LoadInit();
            this.initializing = false;

            this.loading = true;
            this.Query();
            this.loading = false;
        }

        private void Query()
        {
            using (var wc = new Mozart.Studio.UIComponents.WaitCursor())
            {
                this.BindBegin();
                this.BindDo();
                this.BindEnd();
            }
        }

        #endregion

        #region Init

        private void ConstructInit()
        {
        }

        private void LoadInit()
        {
            this.modelDataContext = this.Document.GetCtx<ModelDataContext>();
            this.experiment = Globals.GetExperiment(this.modelDataContext);

            Globals.InitFactoryTimeNew(this.modelDataContext);
        }
        #endregion

        #region Data Binding
        private void BindBegin()
        {
            this.gridControl1.BeginUpdate();
        }

        private void BindDo()
        {
            using (var wc = new Mozart.Studio.UIComponents.WaitCursor())
            {
                SetVersionComboxBox();

                FillGrid();
            }
        }

        private void SetVersionComboxBox()
        {
            if (this.comboBoxEdit1.Properties.Items.Count > 0 && this.comboBoxEdit1.Text != "New")
                return;

            var versions = this.modelDataContext.UI_PHOTO_BACKUP.Select(x => x.VERSION_ID).OrderByDescending(x => x).Distinct().ToList();
            versions.Add("New");

            this.comboBoxEdit1.Properties.Items.Clear();
            this.comboBoxEdit1.FillValues(versions);
        }

        private void FillGrid()
        {
            this.photoBackupInfos = (from a in this.modelDataContext.EQP.Where(x => x.EQP_GROUP == "NXT" || x.EQP_GROUP == "NXE")
                                     join b in this.modelDataContext.UI_PHOTO_BACKUP.Where(x => x.VERSION_ID == this.comboBoxEdit1.Text) on a.EQP_ID equals b.EQP_ID into outer
                                     from o in outer.DefaultIfEmpty()
                                     select new EqpBackupInfo
                                     {
                                         EQP_GROUP = a.EQP_GROUP,
                                         EQP_ID = a.EQP_ID,
                                         BACKUP_SET = o != null ? o.BACKUP_SET : string.Empty
                                     }).ToList();

            this.gridControl1.DataSource = this.photoBackupInfos;
        }

        private void BindEnd()
        {
            //SetCaption();

            SetHeaderOption();

            ResetEditingAppearance();

            this.gridView1.BestFitColumns();
            this.gridView1.OptionsView.ColumnAutoWidth = false;
            this.gridView1.OptionsView.ShowGroupPanel = true;
            this.gridView1.OptionsSelection.EnableAppearanceFocusedRow = false;

            this.gridControl1.EndUpdate();
        }

        private void SetHeaderOption()
        {
            for (int i = 0; i < 2; i++)
            {
                this.gridView1.Columns[i].OptionsColumn.AllowEdit = false;
                this.gridView1.Columns[i].OptionsColumn.AllowFocus = false;
            }

            this.gridView1.Columns[2].AppearanceCell.BackColor = Color.FloralWhite;
        }

        private void ResetEditingAppearance()
        {
            this.saveButton.Enabled = false;

            this.gridView1.RefreshData();

            this.photoBackupInfos.ForEach(x => x.IS_EDITED = false);
        }
        #endregion

        #region Event Handler

        private void gridView1_CustomRowCellEdit(object sender, CustomRowCellEditEventArgs e)
        {
            if (e.Column.FieldName != "BACKUP_SET")
                return;

            e.RepositoryItem = GetRepositoryItem(e);
        }

        private RepositoryItem? GetRepositoryItem(CustomRowCellEditEventArgs e)
        {
            var gv = gridView1;

            RepositoryItemButtonEdit repositoryItemButton = new RepositoryItemButtonEdit();

            var eb = new EditorButton();

            var mainEqp = gv.GetRowCellValue(e.RowHandle, "EQP_ID").ToString();
            var eqpGroup = gv.GetRowCellValue(e.RowHandle, "EQP_GROUP").ToString();
            var backupSet = gv.GetRowCellValue(e.RowHandle, "BACKUP_SET")?.ToString();
            List<string> availableEqpList = new List<string>();
            foreach (var row in photoBackupInfos)
            {
                if (row.EQP_ID == mainEqp)
                    continue;

                if (backupSet != null && backupSet.Contains(row.EQP_ID))
                    continue;

                if (row.EQP_GROUP == eqpGroup)
                    availableEqpList.Add(row.EQP_ID);
            }

            eb.Tag = e.RowHandle;
            eb.Tag += "|";
            eb.Tag += string.Join(',', availableEqpList);
            eb.Tag += "|";
            eb.Tag += backupSet;

            repositoryItemButton.Buttons.Clear();
            repositoryItemButton.Buttons.Add(eb);

            repositoryItemButton.ButtonClick += new ButtonPressedEventHandler(this.OnButtonClick);

            return repositoryItemButton;
        }

        private void gridView1_CellValueChanged(object sender, DevExpress.XtraGrid.Views.Base.CellValueChangedEventArgs e)
        {
            this.saveButton.Enabled = true;

            var info = GetEqpBackupInfo(e.RowHandle);
            if (info != null)
                info.IS_EDITED = true;
        }

        private void gridView1_RowCellStyle(object sender, RowCellStyleEventArgs e)
        {
            if (this.initializing || this.loading)
                return;

            var info = GetEqpBackupInfo(e.RowHandle);
            if (info == null)
                return;

            if (info.IS_EDITED)
                e.Appearance.ForeColor = Color.Blue;
            else
                e.Appearance.ForeColor = Color.Black;
        }

        private EqpBackupInfo GetEqpBackupInfo(int rowHandle)
        {
            EqpBackupInfo info = null;

            var eqpCol = this.gridView1.Columns[1];
            var value = this.gridView1.GetRowCellValue(rowHandle, eqpCol);
            if (value != null)
            {
                info = this.photoBackupInfos.Where(x => x.EQP_ID == value.ToString()).FirstOrDefault();
            }

            return info;
        }

        private void OnButtonClick(object sender, ButtonPressedEventArgs e)
        {
            //ButtonEdit editor = (ButtonEdit)sender;

            Form popup = null;

            foreach (Form f in Application.OpenForms)
            {
                if (f is Config.BackupSetViewPopup)
                {
                    popup = f;
                }
            }

            if (popup != null)
                popup.Close();

            _currentGrid = gridView1;

            var dialog = new BackupSetViewPopup(this, e.Button.Tag);
            dialog.Show(this);
        }

        private void comboBoxEdit1_EditValueChanged(object sender, EventArgs e)
        {
            if (this.initializing || this.loading)
                return;

            ResetEditingAppearance();

            FillGrid();
        }

        private void SaveButton_Click(object sender, EventArgs e)
        {
            using (var wc = new Mozart.Studio.UIComponents.WaitCursor())
            {
                SaveChanges();
            }
        }

        private void SaveChanges()
        {
            try
            {
                DeleteUIVdat();

                InsertUIVdat();

                SetVersionComboxBox();

                ResetEditingAppearance();

                XtraMessageBox.Show("success to save changes", "Note");
            }
            catch (Exception)
            {
                XtraMessageBox.Show("fail to save changes", "Alert");
            }
        }

        private void convertButton_Click(object sender, EventArgs e)
        {
            using (var wc = new Mozart.Studio.UIComponents.WaitCursor())
            {
                try
                {
                    SaveChanges();

                    DeleteConvertedVdat();

                    InsertConvertedVdat();

                    XtraMessageBox.Show("success to convert", "Note");
                }
                catch (Exception ex)
                {
                    XtraMessageBox.Show("fail to convert", "Alert");
                }
            }
        }

        #endregion

        #region Data Interface
        private void DeleteUIVdat()
        {
            using (var acc = this.modelDataContext.Target.LocalAccessorFor("UI_PHOTO_BACKUP"))
            {
                var dtable = acc.QueryTable(null, -1, -1);

                List<DataRow> removable = new List<DataRow>();

                foreach (DataRow row in dtable.Rows)
                {
                    if (row["VERSION_ID"].ToString() == this.comboBoxEdit1.Text)
                        removable.Add(row);
                }

                removable.ForEach(x => dtable.Rows.Remove(x));

                acc.Save(dtable);
            }
        }

        private void InsertUIVdat()
        {
            using (var acc = this.modelDataContext.Target.LocalAccessorFor("UI_PHOTO_BACKUP"))
            {
                var dtable = acc.QueryTable(null, -1, -1);

                var versionID = this.comboBoxEdit1.Text;
                if (versionID == "New")
                    versionID = "UI_" + DateTime.Now.ToString("yyyyMMddHHmmss");

                foreach (var item in this.gridControl1.DataSource as List<EqpBackupInfo>)
                {
                    if (item.BACKUP_SET.IsNullOrEmpty())
                        continue;

                    var nrow = dtable.NewRow();

                    nrow["VERSION_ID"] = versionID;
                    nrow["EQP_ID"] = item.EQP_ID;
                    nrow["BACKUP_SET"] = item.BACKUP_SET;

                    dtable.Rows.Add(nrow);
                }

                acc.Save(dtable);
            }
        }

        private void DeleteConvertedVdat()
        {
            DeleteEqpParamVdat();
        }

        private void DeleteEqpParamVdat()
        {
            using (var acc = this.modelDataContext.Target.LocalAccessorFor("EQP_PARAM"))
            {
                var dtable = acc.QueryTable(null, -1, -1);

                List<DataRow> removable = new List<DataRow>();

                foreach (DataRow row in dtable.Rows)
                {
                    if (row["PARAM_NAME"].ToString() == "BACKUP_EQP")
                        removable.Add(row);
                }

                removable.ForEach(x => dtable.Rows.Remove(x));

                acc.Save(dtable);
            }
        }

        private void InsertConvertedVdat()
        {
            var currentData = this.modelDataContext.UI_PHOTO_BACKUP.Where(x => x.VERSION_ID == this.comboBoxEdit1.Text).ToList();

            InsertEqpParam(currentData);
        }

        private void InsertEqpParam(IEnumerable<UI_PHOTO_BACKUP> infos)
        {
            using (var acc = this.modelDataContext.Target.LocalAccessorFor("EQP_PARAM"))
            {
                var dtable = acc.QueryTable(null, -1, -1);

                foreach (var item in infos)
                {
                    if (item.BACKUP_SET.IsNullOrEmpty())
                        continue;

                    var nrow1 = dtable.NewRow();
                    nrow1["EQP_ID"] = item.EQP_ID;
                    nrow1["PARAM_NAME"] = "BACKUP_EQP";
                    nrow1["PARAM_VALUE"] = item.BACKUP_SET;

                    dtable.Rows.Add(nrow1);
                }

                acc.Save(dtable);
            }
        }

        #endregion

        #region Data Class
        class EqpBackupInfo
        {
            public string EQP_GROUP { get; set; }
            public string EQP_ID { get; set; }
            public string BACKUP_SET { get; set; }
            [Display(Order = -1)]
            public bool IS_EDITED { get; set; }
        }

        #endregion
    }
}