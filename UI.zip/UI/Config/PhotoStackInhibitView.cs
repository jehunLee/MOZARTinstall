﻿using System.Data;
using Mozart.Studio.TaskModel.UserInterface;
using Mozart.Studio.TaskModel.UserLibrary;
using FabSimulator;
using DevExpress.XtraGrid.Views.Grid;
using DevExpress.XtraEditors.Repository;
using FabSimulatorUI.Common;
using Mozart.Extensions;
using FabSimulator.Inputs;
using System.Text;
using DevExpress.XtraEditors;
using Mozart.Task.Model;

namespace FabSimulatorUI.Config
{
    public partial class PhotoStackInhibitView : XtraGridControlView
    {
        #region Variable&Property

        ModelDataContext modelDataContext;
        Experiment experiment;

        bool initializing;
        bool loading;

        List<EqpDownSchedInfo> totalDownSchedInfo = new List<EqpDownSchedInfo>();

        #endregion

        #region Ctor

        public PhotoStackInhibitView(IServiceProvider serviceProvider)
            : base(serviceProvider)
        {
            InitializeComponent();

            this.initializing = true;
            this.ConstructInit();
        }

        protected override void LoadDocument()
        {
            this.LoadInit();
            this.initializing = false;

            this.loading = true;
            this.Query();
            this.loading = false;
        }

        private void Query()
        {
            using (var wc = new Mozart.Studio.UIComponents.WaitCursor())
            {
                this.BindBegin();
                this.BindDo();
                this.BindEnd();
            }
        }

        #endregion

        #region Init

        private void ConstructInit()
        {
        }

        private void LoadInit()
        {
            this.modelDataContext = this.Document.GetCtx<ModelDataContext>();
            this.experiment = Globals.GetExperiment(this.modelDataContext);

            Globals.InitFactoryTimeNew(this.modelDataContext);
        }
        #endregion

        #region Data Binding
        private void BindBegin()
        {
            this.gridControl1.BeginUpdate();
            this.gridControl2.BeginUpdate();
        }

        private void BindDo()
        {
            using (var wc = new Mozart.Studio.UIComponents.WaitCursor())
            {
                SetVersionComboxBox();

                SetEventCodeCheckedComboBox();

                FillGrid();
            }
        }

        private void SetVersionComboxBox()
        {
            if (this.comboBoxEdit1.Properties.Items.Count > 0 && this.comboBoxEdit1.Text != "New")
                return;

            var versions = this.modelDataContext.UI_STACK_INHIBIT.Select(x => x.VERSION_ID).OrderByDescending(x => x).Distinct().ToList();
            versions.Add("New");

            this.comboBoxEdit1.Properties.Items.Clear();
            this.comboBoxEdit1.FillValues(versions);
        }

        private void SetEventCodeCheckedComboBox()
        {
            var photoEqp = this.modelDataContext.EQP.Where(x => x.EQP_GROUP == "NXT" || x.EQP_GROUP == "NXE").ToArray();
            var eqpDownSched = this.modelDataContext.EQP_DOWN_SCHED;

            this.totalDownSchedInfo = (from a in photoEqp
                                       join b in eqpDownSched on a.EQP_ID equals b.EQP_ID
                                       select new EqpDownSchedInfo
                                       {
                                           EVENT_CODE = b.EVENT_CODE,
                                           EQP_ID = b.EQP_ID,
                                           EQP_GROUP = a.EQP_GROUP,
                                           START_DATETIME = b.START_DATETIME,
                                           END_DATETIME = b.END_DATETIME,
                                           DURATION = Math.Round((b.END_DATETIME - b.START_DATETIME).TotalHours, 2),
                                       }).OrderBy(x => x.EVENT_CODE).ToList();

            var codes = this.totalDownSchedInfo.Select(x => x.EVENT_CODE).Distinct().ToArray();

            foreach (var code in codes)
            {
                if (code != null)
                    this.checkedComboBoxEdit1.Properties.Items.Add(code);
            }

            this.checkedComboBoxEdit1.CheckAll();
        }

        private void FillGrid(bool existOnly = true)
        {
            if (this.comboBoxEdit1.Text == "New")
                existOnly = false;

            FillStackInhibitGrid(existOnly);

            FiilSchedDownGrid();
        }

        private void FillStackInhibitGrid(bool existOnly = true)
        {
            DataTable dt = CreateStackInhibitSchema();

            var existingData = this.modelDataContext.UI_STACK_INHIBIT.Where(x => x.VERSION_ID == this.comboBoxEdit1.Text).ToArray();

            if (existOnly) // Version ComboBox를 선택해서 이미 입력된 값을 불러올 경우, CheckedComoboBox도 자동 변경되어 해당하는 값만 표시
            {
                if (existingData.Length > 0)
                {
                    foreach (var existingRow in existingData)
                    {
                        var row = dt.NewRow();
                        row[0] = existingRow.EVENT_CODE;
                        row[1] = existingRow.PRE_INHIBIT;
                        row[2] = existingRow.POST_INHIBIT;
                        row[3] = existingRow.REWORK_RATE;
                        row[4] = existingRow.REWORK_HRS;
                        row[5] = existingRow.POST_LIMIT;

                        dt.Rows.Add(row);
                    }

                    UpdateEventCodeChecking(existingData);
                }
            }
            else // EVENT_CODE CheckedComboBox를 변경할 경우, 해당 Version의 기존 입력된 값을 유지하면서 추가로 표시
            {
                foreach (var item in this.checkedComboBoxEdit1.Properties.GetItems().GetCheckedValues())
                {
                    if (item == null) continue;
                    var code = item.ToString();

                    var row = dt.NewRow();
                    row[0] = code;

                    var existingRow = existingData.Where(x => x.EVENT_CODE == code).FirstOrDefault();
                    if (existingRow != null)
                    {
                        row[1] = existingRow.PRE_INHIBIT;
                        row[2] = existingRow.POST_INHIBIT;
                        row[3] = existingRow.REWORK_RATE;
                        row[4] = existingRow.REWORK_HRS;
                        row[5] = existingRow.POST_LIMIT;
                    }

                    dt.Rows.Add(row);
                }
            }

            this.gridControl1.DataSource = dt;

            this.gridView1.Columns[6].Visible = false;
        }

        private void UpdateEventCodeChecking(UI_STACK_INHIBIT[] existingData)
        {
            var codes = existingData.Select(x => x.EVENT_CODE).Distinct();

            for (int i = 0; i < this.checkedComboBoxEdit1.Properties.Items.Count; i++)
            {
                var item = this.checkedComboBoxEdit1.Properties.Items[i];

                if (codes.Contains(item.Value.ToString()))
                    item.CheckState = CheckState.Checked;
                else
                    item.CheckState = CheckState.Unchecked;
            }
        }

        private DataTable CreateStackInhibitSchema()
        {
            DataTable dt = new DataTable();
            dt.Columns.Add("EVENT_CODE", typeof(string));
            dt.Columns.Add("PRE_INHIBIT", typeof(float));
            dt.Columns.Add("POST_INHIBIT", typeof(float));
            dt.Columns.Add("REWORK_RATE", typeof(float));
            dt.Columns.Add("REWORK_HRS", typeof(float));
            dt.Columns.Add("POST_PM_DAILY_LIMIT", typeof(int));

            dt.Columns.Add("IS_EDITED", typeof(bool));

            return dt;
        }

        private void FiilSchedDownGrid()
        {
            var selectedCodes = this.checkedComboBoxEdit1.Properties.Items.GetCheckedValues().Select(x => x.ToString()).ToArray();
            var query = this.totalDownSchedInfo.Where(x => selectedCodes.Contains(x.EVENT_CODE)).ToArray();

            this.gridControl2.DataSource = query;
        }

        private void BindEnd()
        {
            SetCaption();

            SetHeaderOption();

            ResetEditingAppearance();

            this.gridView1.BestFitColumns();
            this.gridView1.OptionsView.ColumnAutoWidth = false;
            this.gridView1.OptionsView.ShowGroupPanel = false;
            this.gridView1.OptionsSelection.EnableAppearanceFocusedRow = false;

            this.gridView2.BestFitColumns();
            this.gridView2.OptionsView.ColumnAutoWidth = false;

            this.gridControl1.EndUpdate();
            this.gridControl2.EndUpdate();
        }

        private void SetCaption()
        {
            this.gridView1.Columns[1].Caption = "Pre Inhibit (Days)";
            this.gridView1.Columns[2].Caption = "Post Inhibit (Days)";
            this.gridView1.Columns[3].Caption = "Rework Rate (%)";
            this.gridView1.Columns[4].Caption = "Rework Hold (Hrs)";
            this.gridView1.Columns[5].Caption = "Post PM Daily Limit";
            
            this.gridView2.Columns[3].DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.gridView2.Columns[3].DisplayFormat.FormatString = "yyyy-MM-dd HH:mm:ss";

            this.gridView2.Columns[4].DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.gridView2.Columns[4].DisplayFormat.FormatString = "yyyy-MM-dd HH:mm:ss";
        }

        private void SetHeaderOption()
        {
            this.gridView1.Columns[0].OptionsColumn.AllowEdit = false;
            this.gridView1.Columns[0].OptionsColumn.AllowFocus = false;

            for (int i = 1; i < 6; i++)
            {
                this.gridView1.Columns[i].AppearanceCell.BackColor = Color.FloralWhite;
            }

            for (int i = 0; i < 7; i++)
            {
                this.gridView2.Columns[i].OptionsColumn.AllowEdit = false;
                this.gridView2.Columns[i].OptionsColumn.AllowFocus = false;
            }
        }
        private void ResetEditingAppearance()
        {
            this.saveButton.Enabled = false;

            this.gridView1.RefreshData();
        }
        #endregion

        #region Event Handler
        private void GridView1_CustomRowCellEdit(object sender, CustomRowCellEditEventArgs e)
        {
            if (e.Column.FieldName == "EVENT_CODE")
                return;

            e.RepositoryItem = new RepositoryItemCalcEdit();
        }

        private void gridView1_CellValueChanged(object sender, DevExpress.XtraGrid.Views.Base.CellValueChangedEventArgs e)
        {
            var row = this.gridView1.GetRow(e.RowHandle) as DataRowView;
            row[6] = true; // IS_EDITED

            this.saveButton.Enabled = true;
        }

        private void gridView1_RowStyle(object sender, RowStyleEventArgs e)
        {
            var row = this.gridView1.GetRow(e.RowHandle) as DataRowView;

            if (row != null && row[6] is bool && (bool)row[6] == true) // IS_EDITED
                e.Appearance.ForeColor = Color.Blue;
            else
                e.Appearance.ForeColor = Color.Black;
        }

        private void comboBoxEdit1_EditValueChanged(object sender, EventArgs e)
        {
            if (this.initializing || this.loading)
                return;

            if (this.comboBoxEdit1.Text == "New")
                this.checkedComboBoxEdit1.CheckAll();

            FillGrid();
        }

        private void checkedComboBoxEdit1_EditValueChanged(object sender, EventArgs e)
        {
            if (this.initializing || this.loading)
                return;

            ResetEditingAppearance();

            FillGrid(false);
        }

        private void SaveButton_Click(object sender, EventArgs e)
        {
            using (var wc = new Mozart.Studio.UIComponents.WaitCursor())
            {
                SaveChanges();
            }
        }

        private void SaveChanges()
        {
            try
            {
                DeleteUIVdat();

                InsertUIVdat();

                SetVersionComboxBox();

                ResetEditingAppearance();

                XtraMessageBox.Show("success to save changes", "Note");
            }
            catch (Exception)
            {
                XtraMessageBox.Show("fail to save changes", "Alert");
            }
        }

        private void convertButton_Click(object sender, EventArgs e)
        {
            using (var wc = new Mozart.Studio.UIComponents.WaitCursor())
            {
                try
                {
                    SaveChanges();

                    DeleteConvertedVdat();

                    InsertConvertedVdat();

                    XtraMessageBox.Show("success to convert", "Note");
                }
                catch (Exception)
                {
                    XtraMessageBox.Show("fail to convert", "Alert");
                }
            }
        }

        #endregion

        #region Data Interface
        private void DeleteUIVdat()
        {
            using (var acc = this.modelDataContext.Target.LocalAccessorFor("UI_STACK_INHIBIT"))
            {
                var dtable = acc.QueryTable(null, -1, -1);

                List<DataRow> removable = new List<DataRow>();

                foreach (DataRow row in dtable.Rows)
                {
                    if (row["VERSION_ID"].ToString() == this.comboBoxEdit1.Text)
                        removable.Add(row);
                }

                removable.ForEach(x => dtable.Rows.Remove(x));

                acc.Save(dtable);
            }
        }

        private void InsertUIVdat()
        {
            using (var acc = this.modelDataContext.Target.LocalAccessorFor("UI_STACK_INHIBIT"))
            {
                var dtable = acc.QueryTable(null, -1, -1);

                var versionID = this.comboBoxEdit1.Text;
                if (versionID == "New")
                    versionID = "UI_" + DateTime.Now.ToString("yyyyMMddHHmmss");

                foreach (DataRow item in (this.gridControl1.DataSource as DataTable).Rows)
                {
                    var nrow = dtable.NewRow();

                    nrow["VERSION_ID"] = versionID;
                    nrow["EVENT_CODE"] = item["EVENT_CODE"];
                    nrow["PRE_INHIBIT"] = item["PRE_INHIBIT"];
                    nrow["POST_INHIBIT"] = item["POST_INHIBIT"];
                    nrow["REWORK_RATE"] = item["REWORK_RATE"];
                    nrow["REWORK_HRS"] = item["REWORK_HRS"];
                    nrow["POST_LIMIT"] = item["POST_PM_DAILY_LIMIT"];

                    dtable.Rows.Add(nrow);
                }

                acc.Save(dtable);
            }
        }

        private void DeleteConvertedVdat()
        {
            DeleteSimConfigVdat();

            DeleteEqpParamVdat();

            DeleteArrangeParamVdat();
        }

        private void DeleteSimConfigVdat()
        {
            using (var acc = this.modelDataContext.Target.LocalAccessorFor("SIM_CONFIG"))
            {
                var dtable = acc.QueryTable(null, -1, -1);

                List<DataRow> removable = new List<DataRow>();

                foreach (DataRow row in dtable.Rows)
                {
                    if (row["PARAM_GROUP"].ToString() == "Logic_Photo" && row["PARAM_NAME"].ToString() == "stackPmCode")
                        removable.Add(row);
                }

                removable.ForEach(x => dtable.Rows.Remove(x));

                acc.Save(dtable);
            }
        }

        private void DeleteEqpParamVdat()
        {
            using (var acc = this.modelDataContext.Target.LocalAccessorFor("EQP_PARAM"))
            {
                var dtable = acc.QueryTable(null, -1, -1);

                List<DataRow> removable = new List<DataRow>();

                foreach (DataRow row in dtable.Rows)
                {
                    if (row["PARAM_NAME"].ToString() == "reworkHrStackPm")
                        removable.Add(row);
                    if (row["PARAM_NAME"].ToString() == "daily_limit_post_stack_pm")
                        removable.Add(row);
                }

                removable.ForEach(x => dtable.Rows.Remove(x));

                acc.Save(dtable);
            }
        }

        private void DeleteArrangeParamVdat()
        {
            using (var acc = this.modelDataContext.Target.LocalAccessorFor("ARRANGE_PARAM"))
            {
                var dtable = acc.QueryTable(null, -1, -1);

                List<DataRow> removable = new List<DataRow>();

                foreach (DataRow row in dtable.Rows)
                {
                    if (row["PARAM_NAME"].ToString() == "reworkRateStackPm")
                        removable.Add(row);
                }

                removable.ForEach(x => dtable.Rows.Remove(x));

                acc.Save(dtable);
            }
        }

        private void InsertConvertedVdat()
        {
            var currentData = this.modelDataContext.UI_STACK_INHIBIT.Where(x => x.VERSION_ID == this.comboBoxEdit1.Text).ToList();

            InsertSimConfg(currentData);

            IEnumerable<EqpStackInhibitParamInfo> infos = CreateEqpStackInhibitParamInfo(currentData);

            InsertEqpParam(infos);

            InsertArrangeParam(infos);
        }

        private IEnumerable<EqpStackInhibitParamInfo> CreateEqpStackInhibitParamInfo(List<UI_STACK_INHIBIT> currentData)
        {
            // 하나의 설비가 여러개의 EVENT_CODE를 쓰는 경우 PM의 StartTime이 빠른 것을 사용

            List<EqpStackInhibitParamInfo> list = new List<EqpStackInhibitParamInfo>();

            var query = (from a in this.modelDataContext.EQP_DOWN_SCHED
                         join b in currentData on a.EVENT_CODE equals b.EVENT_CODE
                         select new
                         {
                             a.EQP_ID,
                             a.EVENT_CODE,
                             a.START_DATETIME,
                             b.PRE_INHIBIT,
                             b.POST_INHIBIT,
                             b.REWORK_RATE,
                             b.REWORK_HRS,
                             b.POST_LIMIT
                         }).OrderBy(x => x.EQP_ID).ThenBy(x => x.START_DATETIME).ToArray();

            string prevEqpID = string.Empty;
            foreach (var item in query)
            {
                if (item.EQP_ID == prevEqpID)
                    continue;

                EqpStackInhibitParamInfo info = new EqpStackInhibitParamInfo();
                info.EQP_ID = item.EQP_ID;
                info.EVENT_CODE = item.EVENT_CODE;
                info.PRE_INHIBIT = item.PRE_INHIBIT;
                info.POST_INHIBIT = item.POST_INHIBIT;
                info.REWORK_RATE = item.REWORK_RATE;
                info.REWORK_HRS = item.REWORK_HRS;
                info.POST_LIMIT = item.POST_LIMIT;

                list.Add(info);

                prevEqpID = item.EQP_ID;
            }

            return list;
        }

        private void InsertSimConfg(List<UI_STACK_INHIBIT> currentData)
        {
            string paramValue = CreateStackPmCode(currentData);

            using (var acc = this.modelDataContext.Target.LocalAccessorFor("SIM_CONFIG"))
            {
                var dtable = acc.QueryTable(null, -1, -1);

                var nrow = dtable.NewRow();

                nrow["PARAM_GROUP"] = "Logic_Photo";
                nrow["PARAM_NAME"] = "stackPmCode";
                nrow["PARAM_VALUE"] = paramValue;
                nrow["DESCRIPTION"] = "[pmCode,preInhibitDays,postInhibitDays;] Stacking PM Information (semi-colon seperated)";
                nrow["PARAM_TYPE"] = "String";

                dtable.Rows.Add(nrow);

                acc.Save(dtable);
            }
        }

        private string CreateStackPmCode(List<UI_STACK_INHIBIT> currentData)
        {
            StringBuilder sb = new StringBuilder();

            foreach (var row in currentData)
            {
                sb.Append(row.EVENT_CODE);
                sb.Append(",");
                sb.Append(row.PRE_INHIBIT);
                sb.Append(",");
                sb.Append(row.POST_INHIBIT);
                sb.Append(";");
            }

            return sb.ToString();
        }

        private void InsertEqpParam(IEnumerable<EqpStackInhibitParamInfo> infos)
        {
            using (var acc = this.modelDataContext.Target.LocalAccessorFor("EQP_PARAM"))
            {
                var dtable = acc.QueryTable(null, -1, -1);

                foreach (var item in infos)
                {
                    var nrow = dtable.NewRow();
                    nrow["EQP_ID"] = item.EQP_ID;
                    nrow["PARAM_NAME"] = "reworkHrStackPm";
                    nrow["PARAM_VALUE"] = item.REWORK_HRS;
                    dtable.Rows.Add(nrow);
                }
                acc.Save(dtable);

                foreach (var item in infos)
                {
                    var nrow = dtable.NewRow();
                    nrow["EQP_ID"] = item.EQP_ID;
                    nrow["PARAM_NAME"] = "daily_limit_post_stack_pm";
                    nrow["PARAM_VALUE"] = item.POST_LIMIT;
                    dtable.Rows.Add(nrow);
                }
                acc.Save(dtable);
            }
        }

        private void InsertArrangeParam(IEnumerable<EqpStackInhibitParamInfo> infos)
        {
            IEnumerable<ARRANGE_PARAM> arrangeParamInfos = CreateArrangeParam(infos);

            using (var acc = this.modelDataContext.Target.LocalAccessorFor("ARRANGE_PARAM"))
            {
                var dtable = acc.QueryTable(null, -1, -1);

                foreach (var item in arrangeParamInfos)
                {
                    var nrow = dtable.NewRow();
                    nrow["EQP_ID"] = item.EQP_ID;
                    nrow["RECIPE_ID"] = item.RECIPE_ID;
                    nrow["PARAM_NAME"] = item.PARAM_NAME;
                    nrow["PARAM_VALUE"] = item.PARAM_VALUE;

                    dtable.Rows.Add(nrow);
                }

                acc.Save(dtable);
            }
        }

        private IEnumerable<ARRANGE_PARAM> CreateArrangeParam(IEnumerable<EqpStackInhibitParamInfo> infos)
        {
            var query = from a in this.modelDataContext.ARRANGE.GroupBy(x => new { x.EQP_ID, x.RECIPE_ID })
                        join b in infos on a.Key.EQP_ID equals b.EQP_ID
                        select new ARRANGE_PARAM
                        {
                            EQP_ID = a.Key.EQP_ID,
                            RECIPE_ID = a.Key.RECIPE_ID,
                            PARAM_NAME = "reworkRateStackPm",
                            PARAM_VALUE = b.REWORK_RATE.ToString()
                        };

            return query;
        }

        #endregion

        #region Data Class
        class EqpDownSchedInfo
        {
            public string EVENT_CODE { get; set; }
            public string EQP_ID { get; set; }
            public string EQP_GROUP { get; set; }
            public DateTime START_DATETIME { get; set; }
            public DateTime END_DATETIME { get; set; }
            public double DURATION { get; set; }
            public string DESCRIPTION { get; set; }
        }

        class EqpStackInhibitParamInfo
        {
            public string EQP_ID { get; set; }
            public string EVENT_CODE { get; set; }
            public float PRE_INHIBIT { get; set; }
            public float POST_INHIBIT { get; set; }
            public float REWORK_RATE { get; set; } // ARRANGE_PARAM.PARAM=reworkRateStackPm
            public float REWORK_HRS { get; set; } // EQP_PARAM.PARAM_NAME=reworkHrStackPm
            public int POST_LIMIT { get; set; } // EQP_PARAM.PARAM_NAME=daily_limit_post_stack_pm
        }

        #endregion
    }
}