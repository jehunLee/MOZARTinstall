﻿using DevExpress.XtraEditors;
using FabSimulator;
using FabSimulatorUI.Common;
using Mozart.Collections;
using Mozart.Extensions;
using Mozart.Studio.TaskModel.UserInterface;
using Mozart.Studio.TaskModel.UserLibrary;
using Mozart.Task.Model;
using System.Data;

namespace FabSimulatorUI.Config
{
    public partial class WipCreationView : XtraGridControlView
    {
        #region Variable&Property

        private ModelDataContext modelDataContext;
        private Experiment experiment;

        private bool initializing;
        private bool loading;
        private bool isEdit;

        private int preRadioRecord = 1;
        private string preVersionRecord = "";

        private List<ResourceLittlesRawInfo> resourceLittlesRawInfos = new List<ResourceLittlesRawInfo>();
        private List<TypeWip> typeWips = new List<TypeWip>();

        public static int numericOne = 100;
        public static int numericTwo = 0;

        // Key1 = RouteID; Key2 = StackGroup
        public Dictionary<string, Dictionary<string, Tuple<int, int, string>>> stackGroupDict = new Dictionary<string, Dictionary<string, Tuple<int, int, string>>>();

        // Key1 = PartID + "@" + StepID
        public MultiDictionary<string, string> stackArrangeDict = new MultiDictionary<string, string>();

        // Sampling without replacement + refill when it becomes empty
        public MultiDictionary<string, string> stackArrangeDict2 = new MultiDictionary<string, string>();

        // Key = MfgPartID
        public Dictionary<string, string> partDict = new Dictionary<string, string>();

        // Key1 = RouteID + "@" + StepID
        public Dictionary<string, int> stepSeqDict = new Dictionary<string, int>();
        private Dictionary<string, double> potDays = new Dictionary<string, double>();

        public Dictionary<string, (string lineId, string productId, string mfgPartId, string routeId)> partIdProductInfoDict = new Dictionary<string, (string, string, string, string)>();

        public Dictionary<string, List<(string partId, string stepId)>> eqpPartStepDict = new Dictionary<string, List<(string, string)>>();

        public Dictionary<string, (string holdRate, string minHoldHr, string maxHoldHr, string maxHoldCount)> eqpIdParamDict = new Dictionary<string, (string, string, string, string)>();

        public Dictionary<string, Double> eqpAvgTactTimeHrsDict = new Dictionary<string, Double>();

        private List<TypeWip> selectedWips = new List<TypeWip>();

        // 동일한 Input에 대해서는 Convert시 재현 되도록 RandomSeed 설정.
        Random random = new Random(1);
        #endregion

        #region Ctor

        public WipCreationView(IServiceProvider serviceProvider)
            : base(serviceProvider)
        {
            InitializeComponent();

            this.initializing = true;
        }

        protected override void LoadDocument()
        {
            this.LoadInit();
            this.initializing = false;

            this.loading = true;
            this.Query();
            this.loading = false;
        }

        private void Query()
        {
            using (var wc = new Mozart.Studio.UIComponents.WaitCursor())
            {
                this.BindBegin();
                this.BindDo();
                this.BindEnd();
            }
        }
        #endregion

        #region Init
        private void LoadInit()
        {
            this.modelDataContext = this.Document.GetCtx<ModelDataContext>();
            this.experiment = Globals.GetExperiment(this.modelDataContext);

            Globals.InitFactoryTimeNew(this.modelDataContext);

            SetStackGroupDict();
            SetStackArrangeDict();
            SetPartDict();
            SetStepSeqDict();
            SetPotDays();
            SetEqpPartStepDict();
            SetEqpIdParamDict();
            SetEqpAvgTactTimeDict();
        }
        #endregion

        #region Data Binding
        private void BindBegin()
        {
            this.gridControl1.BeginUpdate();
        }

        private void BindDo()
        {
            using (var wc = new Mozart.Studio.UIComponents.WaitCursor())
            {
                SetVersionComboxBox();

                if (comboBoxEdit1.Text == "New")
                    FillNewGrid();
                else
                    FillVersionGrid();
            }
        }

        private void SetVersionComboxBox()
        {
            if (this.comboBoxEdit1.Properties.Items.Count > 0 && this.comboBoxEdit1.Text != "New")
                return;

            var versions = this.modelDataContext.UI_WIP_INIT.Select(x => x.VERSION_ID).OrderByDescending(x => x).Distinct().ToList();
            versions.Add("New");

            this.comboBoxEdit1.Properties.Items.Clear();
            this.comboBoxEdit1.FillValues(versions);
        }

        private void BindEnd()
        {
            this.gridView1.BestFitColumns();
            this.gridView1.OptionsView.ColumnAutoWidth = false;
            this.gridView1.OptionsView.ShowGroupPanel = true;
            this.gridView1.OptionsSelection.EnableAppearanceFocusedRow = false;

            this.gridControl1.UseEmbeddedNavigator = false;
            this.gridControl1.EndUpdate();
        }

        #endregion

        #region Event Handler

        private void gridView1_CellValueChanged(object sender, DevExpress.XtraGrid.Views.Base.CellValueChangedEventArgs e)
        {
            if (this.isEdit)
                return;

            this.isEdit = true;
            var dayCapaCol = this.gridView1.Columns[1];
            var normalCapaCol = this.gridView1.Columns[3];
            var hotCapaCol = this.gridView1.Columns[4];

            int dayCapa = 0;
            int normalCapa = 0;
            int hotCapa = 0;

            if (this.gridView1.GetRowCellValue(e.RowHandle, dayCapaCol) is int)
                dayCapa = (int)this.gridView1.GetRowCellValue(e.RowHandle, dayCapaCol);
            if (this.gridView1.GetRowCellValue(e.RowHandle, normalCapaCol) is int)
                normalCapa = (int)this.gridView1.GetRowCellValue(e.RowHandle, normalCapaCol);
            if (this.gridView1.GetRowCellValue(e.RowHandle, hotCapaCol) is int)
                hotCapa = (int)this.gridView1.GetRowCellValue(e.RowHandle, hotCapaCol);

            switch (e.Column.FieldName)
            {
                case "DAY_CAPA":
                    normalCapa = dayCapa - hotCapa;
                    this.gridView1.SetRowCellValue(e.RowHandle, normalCapaCol, normalCapa);
                    break;
                case "NORMAL_CAPA":
                    dayCapa = normalCapa + hotCapa;
                    this.gridView1.SetRowCellValue(e.RowHandle, dayCapaCol, dayCapa);
                    break;
                case "HOT_CAPA":
                    normalCapa = dayCapa - hotCapa;
                    this.gridView1.SetRowCellValue(e.RowHandle, normalCapaCol, normalCapa);
                    break;
                default: break;
            }
            isEdit = false;
        }

        private void ComboBoxEdit1_EditValueChanged(object sender, EventArgs e)
        {
            if (this.initializing || this.loading)
                return;

            if (comboBoxEdit1.Text == "New")
                FillNewGrid();
            else
                FillVersionGrid();

            ResetEditingAppearance();
        }
        private void comboBoxEdit1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (preVersionRecord != comboBoxEdit1.Text)
            {
                numericOne = 100;
                numericTwo = 0;
            }
            preVersionRecord = comboBoxEdit1.Text;
        }
        private void CapacityButton_Click(object sender, EventArgs e)
        {
            Form popup = null;

            foreach (Form f in Application.OpenForms)
            {
                if (f is Config.WipCreationViewPopup_Capa)
                {
                    popup = f;
                }
            }

            if (popup != null)
                popup.Close();

            var dialog = new WipCreationViewPopup_Capa();

            dialog.FormSendEvent += new FormSendDataHandler(this.BindingPopupData);

            dialog.Show(this);
        }

        private void PriorityButton_Click(object sender, EventArgs e)
        {
            Form popup = null;

            foreach (Form f in Application.OpenForms)
            {
                if (f is Config.WipCreationViewPopup_Pri)
                {
                    popup = f;
                }
            }

            if (popup != null)
                popup.Close();

            var dialog = new WipCreationViewPopup_Pri();

            dialog.FormSendEvent += new FormSendDataHandler(this.BindingPopupData);

            dialog.Show(this);
        }

        private void SaveButton_Click(object sender, EventArgs e)
        {
            using (var wc = new Mozart.Studio.UIComponents.WaitCursor())
            {
                SaveChanges();
            }
        }

        private void SaveChanges()
        {
            try
            {
                DeleteUIWipInit();

                InsertUIWipTable();

                SetVersionComboxBox();

                ResetEditingAppearance();

                XtraMessageBox.Show("success to save changes", "Note");
            }
            catch (Exception ex)
            {
                XtraMessageBox.Show("fail to save changes", "Alert");
            }
        }

        private void ConvertButton_Click(object sender, EventArgs e)
        {
            using (var wc = new Mozart.Studio.UIComponents.WaitCursor())
            {
                ConvertChanges();
            }
        }

        private void ConvertChanges()
        {
            try
            {
                SaveChanges();

                DeleteUIWip();

                DeleteUIStackActiveLot();

                ConvertBtnCalculate();

                InsertStackActiveLotTable();

                LotIdGenerator.Instance.Reset();

                XtraMessageBox.Show("success to convert", "Note");
            }
            catch (Exception ex)
            {
                XtraMessageBox.Show("fail to convert", "Alert");
            }
        }

        #endregion

        #region Data Interface

        private void FillNewGrid(int num = 1, int lotNormal = 100, int lotHot = 0)
        {
            var prod = modelDataContext.PRODUCT;
            var demand = modelDataContext.DEMAND;
            var fab_plan = modelDataContext.FAB_IN_PLAN;

            var demand2 = from a in demand
                          join b in prod on a.PRODUCT_ID equals b.PRODUCT_ID
                          select new
                          {
                              PRODUCT_ID = a.PRODUCT_ID,
                              MFG_PART_ID = b.MFG_PART_ID,
                              WAFER_QTY = a.WAFER_QTY,
                              DUE_DATE = a.DUE_DATE
                          };

            var fab2 = from a in fab_plan
                       join b in prod on a.MFG_PART_ID equals b.MFG_PART_ID
                       select new
                       {
                           MFG_PART_ID = a.MFG_PART_ID,
                           WAFER_QTY = a.WAFER_QTY,
                           DUE_DATE = a.START_DATETIME
                       };

            switch (num)
            {
                case -1:
                    this.resourceLittlesRawInfos.Select(x => x.NORMAL_CAPA = (x.DAY_CAPA * lotNormal) / 100).ToList();
                    this.resourceLittlesRawInfos.Select(x => x.HOT_CAPA = (x.DAY_CAPA * lotHot) / 100).ToList();
                    break;
                case (int)ERadioButton.Demand:
                    this.resourceLittlesRawInfos = (List<ResourceLittlesRawInfo>)(
                    from a in demand2
                    group a by a.MFG_PART_ID into g
                    let minDate = g.Min(x => x.DUE_DATE)
                    let maxDate = g.Max(x => x.DUE_DATE)
                    let period = (maxDate - minDate).TotalDays
                    let total = g.Sum(x => x.WAFER_QTY)
                    select new ResourceLittlesRawInfo
                    {
                        MFG_PART_ID = g.Key,
                        DAY_CAPA = (int)(total / period),
                        CYCLE_TIME = potDays[g.Key],
                        NORMAL_CAPA = (int)(lotNormal * total / period / 100),
                        HOT_CAPA = (int)(lotHot * total / period / 100)
                    }).ToList();
                    break;
                case (int)ERadioButton.FabInPlan:
                    this.resourceLittlesRawInfos = (
                    from a in fab2
                    group a by a.MFG_PART_ID into g
                    let minDate = g.Min(x => x.DUE_DATE)
                    let maxDate = g.Max(x => x.DUE_DATE)
                    let period = (maxDate - minDate).TotalDays
                    let total = g.Sum(x => x.WAFER_QTY)
                    select new ResourceLittlesRawInfo
                    {
                        MFG_PART_ID = g.Key,
                        DAY_CAPA = (int)(total / period),
                        CYCLE_TIME = potDays[g.Key],
                        NORMAL_CAPA = (int)(lotNormal * total / period / 100),
                        HOT_CAPA = (int)(lotHot * total / period / 100)
                    }).ToList();
                    break;
            }

            this.resourceLittlesRawInfos.Sort((p1, p2) => p1.MFG_PART_ID.CompareTo(p2.MFG_PART_ID));
            this.gridControl1.DataSource = this.resourceLittlesRawInfos.ToBindingList();
        }

        private void FillVersionGrid(int numRadio = -1, int lotNormal = -1, int lotHot = -1)
        {
            var prod = from a in this.modelDataContext.UI_WIP_INIT.Where(x => x.VERSION_ID == this.comboBoxEdit1.Text && x.PARAM_NAME == "DAY_CAPA")
                       select new
                       {
                           MFG_PART_ID = a.MFG_PART_ID,
                           DAY_CAPA = a.PARAM_VALUE,
                       };

            var proc = from a in this.modelDataContext.UI_WIP_INIT.Where(x => x.VERSION_ID == this.comboBoxEdit1.Text && x.PARAM_NAME == "NORMAL_CAPA")
                       select new
                       {
                           MFG_PART_ID = a.MFG_PART_ID,
                           NORMAL_CAPA = a.PARAM_VALUE,
                       };

            var pros = from a in this.modelDataContext.UI_WIP_INIT.Where(x => x.VERSION_ID == this.comboBoxEdit1.Text && x.PARAM_NAME == "HOT_CAPA")
                       select new
                       {
                           MFG_PART_ID = a.MFG_PART_ID,
                           HOT_CAPA = a.PARAM_VALUE
                       };

            if (numRadio == -1)
            {
                this.resourceLittlesRawInfos = (from a in prod
                                                join b in proc on a.MFG_PART_ID equals b.MFG_PART_ID
                                                join c in pros on a.MFG_PART_ID equals c.MFG_PART_ID
                                                select new ResourceLittlesRawInfo
                                                {
                                                    MFG_PART_ID = a.MFG_PART_ID,
                                                    DAY_CAPA = a.DAY_CAPA,
                                                    CYCLE_TIME = potDays[a.MFG_PART_ID],
                                                    NORMAL_CAPA = (lotNormal == -1) ? b.NORMAL_CAPA : (a.DAY_CAPA * lotNormal) / 100,
                                                    HOT_CAPA = (lotHot == -1) ? c.HOT_CAPA : (a.DAY_CAPA * lotHot) / 100
                                                }).ToList();
            }
            else
            {
                this.resourceLittlesRawInfos.Select(x => x.NORMAL_CAPA = (x.DAY_CAPA * lotNormal) / 100).ToList();
                this.resourceLittlesRawInfos.Select(x => x.HOT_CAPA = (x.DAY_CAPA * lotHot) / 100).ToList();
            }

            this.gridControl1.DataSource = this.resourceLittlesRawInfos;
        }

        private void DeleteUIWipInit()
        {
            using (var acc = this.modelDataContext.Target.LocalAccessorFor("UI_WIP_INIT"))
            {
                var dtable = acc.QueryTable(null, -1, -1);

                List<DataRow> removable = new List<DataRow>();

                foreach (DataRow row in dtable.Rows)
                {
                    if (row["VERSION_ID"].ToString() == this.comboBoxEdit1.Text)
                        removable.Add(row);
                }

                removable.ForEach(x => dtable.Rows.Remove(x));

                acc.Save(dtable);
            }
        }

        private void DeleteUIWip()
        {
            using (var acc = this.modelDataContext.Target.LocalAccessorFor("WIP"))
            {
                var dtable = acc.QueryTable(null, -1, -1);

                List<DataRow> removable = new List<DataRow>();

                foreach (DataRow row in dtable.Rows)
                    removable.Add(row);

                removable.ForEach(x => dtable.Rows.Remove(x));

                acc.Save(dtable);
            }
        }

        private void DeleteUIStackActiveLot()
        {
            using (var acc = this.modelDataContext.Target.LocalAccessorFor("STACK_ACTIVE_LOT"))
            {
                var dtable = acc.QueryTable(null, -1, -1);

                List<DataRow> removable = new List<DataRow>();

                foreach (DataRow row in dtable.Rows)
                    removable.Add(row);

                removable.ForEach(x => dtable.Rows.Remove(x));

                acc.Save(dtable);
            }
        }

        private void InsertUIWipTable()
        {
            using (var acc = this.modelDataContext.Target.LocalAccessorFor("UI_WIP_INIT"))
            {
                var dtable = acc.QueryTable(null, -1, -1);
                var versionID = this.comboBoxEdit1.Text;

                if (versionID == "New")
                    versionID = "UI_" + DateTime.Now.ToString("yyyyMMddHHmmss");

                insertParamValue("DAY_CAPA");
                insertParamValue("NORMAL_CAPA");
                insertParamValue("HOT_CAPA");

                void insertParamValue(string tag)
                {
                    foreach (var item in this.resourceLittlesRawInfos)
                    {
                        if (item is null)
                            continue;

                        var nrow = dtable.NewRow();

                        nrow["VERSION_ID"] = versionID;
                        nrow["MFG_PART_ID"] = item.MFG_PART_ID.ToString();
                        nrow["PARAM_NAME"] = tag;
                        if (tag == "DAY_CAPA")
                            nrow["PARAM_VALUE"] = (int)item.DAY_CAPA;
                        else if (tag == "NORMAL_CAPA")
                            nrow["PARAM_VALUE"] = (int)item.NORMAL_CAPA;
                        else if (tag == "HOT_CAPA")
                            nrow["PARAM_VALUE"] = (int)item.HOT_CAPA;

                        dtable.Rows.Add(nrow);
                    }

                    acc.Save(dtable);
                }
            }
        }

        private void InsertWIPTable()
        {
            using (var acc = this.modelDataContext.Target.LocalAccessorFor("WIP"))
            {
                var dtable = acc.QueryTable(null, -1, -1);

                foreach (var item in this.typeWips)
                {
                    if (item is null)
                        continue;

                    var nrow = dtable.NewRow();

                    nrow["LINE_ID"] = item.LINE_ID;
                    nrow["LOT_ID"] = item.LOT_ID;
                    nrow["LOT_START_TIME"] = item.LOT_START_TIME;
                    nrow["PRODUCT_ID"] = item.PRODUCT_ID;
                    nrow["MFG_PART_ID"] = item.MFG_PART_ID;
                    nrow["ROUTE_ID"] = item.ROUTE_ID;
                    nrow["STEP_ID"] = item.STEP_ID;
                    nrow["WAFER_QTY"] = item.WAFER_QTY;
                    nrow["LOT_PRIORITY_STATUS"] = item.LOT_PRIORITY_STATUS;
                    nrow["LOT_STATE"] = item.LOT_STATE;

                    dtable.Rows.Add(nrow);
                    selectedWips.Add(item);
                }
                acc.Save(dtable);
            }
            return;
        }

        private void InsertStackActiveLotTable()
        {
            using (var acc = this.modelDataContext.Target.LocalAccessorFor("STACK_ACTIVE_LOT"))
            {
                var dtable = acc.QueryTable(null, -1, -1);

                foreach (var item in this.modelDataContext.WIP)
                {
                    if (item is null)
                        continue;

                    var routeID = item.ROUTE_ID;
                    var stepID = item.STEP_ID;

                    string partID = "";
                    if (partDict.ContainsKey(item.MFG_PART_ID) == false)
                        continue;

                    partID = partDict[item.MFG_PART_ID];

                    var partRouteKey = FabSimulatorUI.Helper.CreateKey(partID, routeID);
                    var stackGroups = stackGroupDict.SafeGet(partRouteKey);
                    if (stackGroups == null)
                        continue;

                    if (stepSeqDict.ContainsKey(routeID + "@" + stepID) == false)
                        continue;

                    var stepSeq = stepSeqDict[routeID + "@" + stepID];

                    foreach (var sg in stackGroups)
                    {
                        var stackGroupID = sg.Key;
                        var minSeq = sg.Value.Item1;
                        var maxSeq = sg.Value.Item2;
                        var sStepID = sg.Value.Item3;

                        if (item.STEP_ID == sStepID && item.LOT_STATE == "WAIT")
                            continue;

                        if (stepSeq >= minSeq && stepSeq <= maxSeq) // StackGroup에 속한다는 의미.
                        {
                            var key = partID + "@" + sStepID; // S Step의 Eqp를 찾아줘야 함.
                            var eqpID = GetRandomStackEqp(key);
                            if (eqpID == null)
                                continue;

                            var nrow = dtable.NewRow();

                            nrow["LOT_ID"] = item.LOT_ID;
                            nrow["STEP_ID"] = sStepID;
                            nrow["EQP_ID"] = eqpID;
                            nrow["STACK_GROUP"] = stackGroupID;

                            dtable.Rows.Add(nrow);
                        }
                    }
                }
                acc.Save(dtable);
            }
        }

        private string? GetRandomStackEqp(string partStep)
        {
            var arranges = stackArrangeDict2.SafeGet(partStep);
            if (arranges.IsNullOrEmpty())
            {
                var fullArranges = stackArrangeDict.SafeGet(partStep);
                if (fullArranges.IsNullOrEmpty())
                    return null; // 기준정보 오류

                // Refill
                stackArrangeDict2.AddMany(partStep, fullArranges);
                arranges = stackArrangeDict2.SafeGet(partStep);
            }

            var index = random.Next(arranges.Count);
            var eqpID = arranges.ToArray()[index];

            // 골고루 사용하게 하기 위해 비복원 추출
            stackArrangeDict2.Remove(partStep, eqpID);

            return eqpID;
        }

        private void ResetEditingAppearance()
        {
            this.gridView1.RefreshData();
        }

        private void BindingPopupData(int numRadio, int numNormal, int numHot, int tag)
        {
            if (comboBoxEdit1.Text == "New")
                preRadioRecord = -1;

            switch (comboBoxEdit1.Text)
            {
                case "New":
                    switch (tag)
                    {
                        case (int)ECapacityButton.Capacity:
                            preRadioRecord = numRadio;
                            FillNewGrid(numRadio, numericOne, numericTwo);
                            break;
                        case (int)ECapacityButton.Priority:
                            FillNewGrid(preRadioRecord, numericOne, numericTwo);
                            break;
                    }
                    break;
                default:
                    switch (tag)
                    {
                        case (int)ECapacityButton.Capacity:
                            preRadioRecord = numRadio;
                            FillNewGrid(numRadio, numericOne, numericTwo);
                            break;
                        case (int)ECapacityButton.Priority:
                            FillVersionGrid(preRadioRecord, numericOne, numericTwo);
                            break;
                    }
                    break;
            }
            ResetEditingAppearance();
        }

        private void SetStackGroupDict()
        {
            foreach (var item in this.modelDataContext.STACK_INFO.GroupBy(x => x.STACK_GROUP))
            {
                var sample = item.First();
                var partID = sample.PART_ID;

                // part에 속한 route 별로  startSeq와 endSeq를 구하시오.
                var routeIDs = this.modelDataContext.PRODUCT.Where(x => x.PART_ID == partID).Select(x => x.ROUTE_ID).Distinct().ToList();
                foreach (var routeID in routeIDs)
                {
                    var routeSteps = this.modelDataContext.ROUTE_STEP.Where(x => x.ROUTE_ID == routeID).ToList();
                    if (routeSteps == null)
                        continue;

                    int startSeq = 0;
                    int endSeq = 0;
                    string sStepID = string.Empty;
                    foreach (var info in item)
                    {
                        if (info.STACK_TYPE == "S")
                        {
                            //startseq 기록하기.
                            var routeStep = routeSteps.FirstOrDefault(x => x.STEP_ID == info.STEP_ID);
                            if (routeStep == null)
                                continue;

                            startSeq = routeStep.STEP_SEQ;
                            sStepID = info.STEP_ID;
                        }
                        else
                        {
                            //몇번째 step인지 파악을 통해 가장 마지막 step이 누구인지 알아야 한다.
                            var routeStep = routeSteps.FirstOrDefault(x => x.STEP_ID == info.STEP_ID);
                            if (routeStep == null)
                                continue;

                            endSeq = Math.Max(endSeq, routeStep.STEP_SEQ);
                        }
                    }

                    var partRouteKey = FabSimulatorUI.Helper.CreateKey(partID, routeID);
                    if (stackGroupDict.ContainsKey(partRouteKey))
                    {
                        stackGroupDict.SafeGet(partRouteKey).Add(item.Key, Tuple.Create(startSeq, endSeq, sStepID));
                    }
                    else
                    {
                        var partGroupDict = new Dictionary<string, Tuple<int, int, string>>();
                        partGroupDict.Add(item.Key, Tuple.Create(startSeq, endSeq, sStepID));
                        stackGroupDict.Add(partRouteKey, partGroupDict);
                    }
                }
            }
        }

        private void SetStackArrangeDict()
        {
            var sPartSteps = this.modelDataContext.STACK_INFO.Where(x => x.STACK_TYPE == "S")
                .Select(x => x.PART_ID + "@" + x.STEP_ID).Distinct().ToList();

            foreach (var item in this.modelDataContext.ARRANGE)
            {
                var key = item.PART_ID + "@" + item.STEP_ID;

                if (sPartSteps.Contains(key))
                {
                    stackArrangeDict.Add(key, item.EQP_ID);
                    stackArrangeDict2.Add(key, item.EQP_ID);
                }
            }
        }

        private void SetPartDict()
        {
            foreach (var item in this.modelDataContext.PRODUCT)
            {
                if (partDict.ContainsKey(item.MFG_PART_ID))
                    partDict[item.MFG_PART_ID] = item.PART_ID;
                else
                    partDict.Add(item.MFG_PART_ID, item.PART_ID);

                // 추가로 Part_ID를 키로 가지고 PRODUCT_ID, MFG_PART_ID, ROUTE_ID를 가지는 partIdProductInfoDict dictionary를 생성하자.
                if (partIdProductInfoDict.ContainsKey(item.PART_ID))
                    partIdProductInfoDict[item.PART_ID] = (item.LINE_ID, item.PRODUCT_ID, item.MFG_PART_ID, item.ROUTE_ID);
                else
                    partIdProductInfoDict.Add(item.PART_ID, (item.LINE_ID, item.PRODUCT_ID, item.MFG_PART_ID, item.ROUTE_ID));

            }
        }

        private void SetStepSeqDict()
        {
            foreach (var item in this.modelDataContext.ROUTE_STEP)
            {
                if (stepSeqDict.ContainsKey(item.ROUTE_ID + "@" + item.STEP_ID))
                    stepSeqDict[item.ROUTE_ID + "@" + item.STEP_ID] = item.STEP_SEQ;
                else
                    stepSeqDict.Add(item.ROUTE_ID + "@" + item.STEP_ID, item.STEP_SEQ);
            }
        }

        private void SetPotDays()
        {
            var fabInStepID = this.modelDataContext.GetConfigValue<string>(PARAM_GROUP: "Bop_Step", PARAM_NAME: "fabInStepID");
            var routeID = this.modelDataContext.ROUTE_STEP.Where(x => x.STEP_ID == fabInStepID).ToDictionary(x => x.ROUTE_ID, v => v.POT_DAYS);

            potDays = this.modelDataContext.PRODUCT.Where(x => routeID.ContainsKey(x.ROUTE_ID))
                .ToDictionary(k => k.MFG_PART_ID, v => Math.Round(routeID[v.ROUTE_ID], 3));
        }

        private void SetEqpPartStepDict()
        {
            foreach (var item in this.modelDataContext.ARRANGE)
            {
                (string, string) key = (item.PART_ID, item.STEP_ID);

                if (eqpPartStepDict.ContainsKey(item.EQP_ID))
                    eqpPartStepDict[item.EQP_ID].Add(key);
                else
                    eqpPartStepDict.Add(item.EQP_ID, new List<(string, string)> { key });
            }
        }


        private void SetEqpIdParamDict()
        {
            foreach (var item in this.modelDataContext.EQP_PARAM)
            {
                if (item.PARAM_NAME == "engineer_hold")
                {
                    var pairs = item.PARAM_VALUE.Split(';');
                    var dict = pairs.Select(x => x.Split('=')).ToDictionary(x => x[0], x => x[1]);

                    string holdRate = dict["hold_rate"];
                    string minHoldHr = dict["min_hold_hr"];
                    string maxHoldHr = dict["max_hold_hr"];
                    string maxHoldCount = dict["max_hold_count"];

                    // EQP_PARAM 테이블에서 engineer_hold 컬럼은 1개만 존재 가능
                    eqpIdParamDict.Add(item.EQP_ID, (holdRate, minHoldHr, maxHoldHr, maxHoldCount));
                }
            }
        }

        private void SetEqpAvgTactTimeDict()
        {
            int lotSize = Int32.Parse(this.modelDataContext.GetConfigValue<string>(PARAM_GROUP: "Lot_Default", PARAM_NAME: "lotSize"));

            // STEP_TIME 테이블에서 EQP_ID 별로 그룹화를 시켜서 TACT_TIME을 전부 더한 값을 EQP_ID의 COUNT만큼 나눈 평균을 값으로 가지는 Dictionary를 만든다.
            this.eqpAvgTactTimeHrsDict = this.modelDataContext.STEP_TIME
                .GroupBy(x => x.EQP_ID)
                .ToDictionary(g => g.Key, g => (double)g.Sum(x => x.TACT_TIME * lotSize) / g.Count() / 3600);
            return;
        }

        private void ConvertBtnCalculate()
        {
            var lotSize = this.modelDataContext.GetConfigValue<int>(PARAM_GROUP: "Lot_Default", PARAM_NAME: "lotSize");
            var fabIn = this.modelDataContext.GetConfigValue<string>(PARAM_GROUP: "Bop_Step", PARAM_NAME: "fabInStepID");

            var pstDate = this.experiment.Arguments["start-time"];
            DateTime pst = Convert.ToDateTime(pstDate);

            var CT = from a in modelDataContext.ROUTE_STEP
                     where a.AREA_ID == fabIn
                     select new
                     {
                         a.ROUTE_ID,
                         a.POT_DAYS
                     };

            var twip = from a in modelDataContext.ROUTE_STEP
                       join b in modelDataContext.PRODUCT on a.ROUTE_ID equals b.ROUTE_ID
                       join c in this.resourceLittlesRawInfos on b.MFG_PART_ID equals c.MFG_PART_ID
                       join d in CT on a.ROUTE_ID equals d.ROUTE_ID
                       select new
                       {
                           a.LINE_ID,
                           LOT_START_TIME = pst.AddDays(-d.POT_DAYS + a.POT_DAYS),
                           b.PRODUCT_ID,
                           b.MFG_PART_ID,
                           a.ROUTE_ID,
                           a.STEP_ID,
                           a.QT_MINS,
                           a.PT_MINS,
                           a.STEP_SEQ,
                           NormalQty = a.CT_MINS / 1440 * c.NORMAL_CAPA,
                           HotQty = a.CT_MINS / 1440 * c.HOT_CAPA
                       };

            string cprod = "";
            double cqty = 0;
            int GetLotCount(string p, double q)
            {
                if (cprod != p)
                {
                    cqty = 0;
                    cprod = p;
                }
                cqty += q;
                int wcnt = Convert.ToInt32(Math.Floor(cqty / lotSize));
                cqty -= wcnt * lotSize;
                return wcnt;
            }

            int idx = 1;

            QtyCalculate("NORMAL");
            InsertWIPTable();

            QtyCalculate("HOT");
            InsertWIPTable();

            InsertEngineerHoldWip();

            void QtyCalculate(string tag)
            {
                var nwip = from a in twip.OrderBy(t => t.PRODUCT_ID).ThenBy(t => t.STEP_SEQ)
                           let numericValue = (float)numericUpDown1.Value
                           let wipQty = (tag == "NORMAL") ? (int)(a.NormalQty * numericValue) : (int)(a.HotQty * numericValue)
                           select new
                           {
                               a.MFG_PART_ID,
                               a.STEP_ID,
                               a.STEP_SEQ,
                               wipQty,
                               LotCount = GetLotCount(a.MFG_PART_ID, wipQty),
                               cqty,
                               a.LINE_ID,
                               a.LOT_START_TIME,
                               a.ROUTE_ID,
                               a.PRODUCT_ID
                           };

                var wip = new List<TypeWip>() { };

                foreach (var item in nwip.Where(t => t.LotCount > 0))
                {
                    for (int i = 0; i < item.LotCount; i++)
                    {
                        TypeWip w = new TypeWip
                        {
                            LINE_ID = item.LINE_ID,
                            LOT_ID = LotIdGenerator.Instance.GetNextId(),
                            LOT_START_TIME = item.LOT_START_TIME,
                            PRODUCT_ID = item.PRODUCT_ID,
                            MFG_PART_ID = item.MFG_PART_ID,
                            ROUTE_ID = item.ROUTE_ID,
                            STEP_ID = item.STEP_ID,
                            WAFER_QTY = lotSize,
                            LOT_PRIORITY_STATUS = tag,
                            LOT_STATE = "WAIT"
                        };
                        wip.Add(w);
                    }
                }
                wip.ToList();
                this.typeWips = wip;
            }

            void InsertEngineerHoldWip()
            {
                var acc = this.modelDataContext.Target.LocalAccessorFor("WIP");
                var dtable = acc.QueryTable(null, -1, -1);
                var lotIdRowMap = dtable.AsEnumerable().ToDictionary(row => row.Field<string>("LOT_ID"));

                // 사용한 productId, stepId를 저장하기 위한 Dictionary
                Dictionary<(string productId, string stepId), bool> productIdStepIdCheckDict = new Dictionary<(string, string), bool>();
                var partIdToProductId = modelDataContext.PRODUCT.ToDictionary(p => p.PART_ID, p => p.PRODUCT_ID);
                var productIdToPartId = modelDataContext.PRODUCT.ToDictionary(p => p.PRODUCT_ID, p => p.PART_ID);

                foreach (var eqp in eqpIdParamDict)
                {
                    // STEP_TIME에 정보가 없다면 다음 eqp로 넘어간다.
                    if (eqpAvgTactTimeHrsDict.TryGetValue(eqp.Key, out var eqpAvgTactTimeHrs) == false)
                        continue;

                    // 현재 EQP에 할당된 part-step이 존재하지 않는다면 다음 eqp로 넘어간다.
                    if (eqpPartStepDict.TryGetValue(eqp.Key, out var eqpPartSteps) == false)
                        continue;

                    var (holdRate, minHoldHr, maxHoldHr, maxHoldCount) = eqp.Value;
                    double meanHoldHr = (Convert.ToDouble(minHoldHr) + Convert.ToDouble(maxHoldHr)) / 2;

                    // 발생시킬 EngineerHold 개수(n) = r / x * m(반올림)
                    int targetEngineerHoldCount = (int)Math.Round(Double.Parse(holdRate) / eqpAvgTactTimeHrsDict[eqp.Key] * meanHoldHr);
                    targetEngineerHoldCount = Math.Min(targetEngineerHoldCount, Convert.ToInt32(maxHoldCount)); // 최대 maxHoldCount개로 제한                    

                    // 현재 만들어진 Wip의 list중에서 이전에 productid-stepid 조합이 사용된 적이 없는 애들만 필터링
                    // productId를 partId로 변환
                    // 해당 값이 현재 eqp에 할당된 part-step 목록에 포함되어 있는지 확인
                    // 이후 random을 돌려서 targetEngineerHoldCount만큼 가져온다.
                    var selected = selectedWips.Where(x => !productIdStepIdCheckDict.TryGetValue((x.PRODUCT_ID, x.STEP_ID), out var isUsed) && productIdToPartId.TryGetValue(x.PRODUCT_ID, out var partId)
                    && eqpPartStepDict[eqp.Key].Contains((partId, x.STEP_ID)))
                        .GroupBy(x => (x.PRODUCT_ID, x.STEP_ID))
                        .Select(g => g.OrderBy(_ => random.Next()).First())
                        .OrderBy(x => random.Next())
                        .Take(targetEngineerHoldCount)
                        .ToList();

                    // 선택된 part-step을 사용 중으로 표시
                    foreach (var ps in selected)
                    {
                        var partStep = (ps.PRODUCT_ID, ps.STEP_ID);

                        if (productIdStepIdCheckDict.ContainsKey(partStep) == false)
                            productIdStepIdCheckDict.Add(partStep, true);
                        else
                            productIdStepIdCheckDict[partStep] = true;
                    }

                    foreach (var lot in selected)
                    {
                        if (!lotIdRowMap.TryGetValue(lot.LOT_ID, out var nrow))
                            continue; // LOT_ID가 없는 경우 스킵

                        // pst + (표준정규분포((minHoldHr + maxHoldHr) / 2), ((maxHoldHr - minHoldHr) / 2 ) * 0.3)) / 2
                        var u = random.NextDouble();
                        var holdHr = meanHoldHr + ((meanHoldHr * 0.3 * Math.Sqrt(2) * FabSimulatorUI.Helper.ErfInv(2 * u - 1))) / 2;
                        holdHr = Math.Clamp(holdHr, Double.Parse(minHoldHr), Double.Parse(maxHoldHr));
                        var lotStateChangeDateTime = pst + TimeSpan.FromHours(holdHr);

                        nrow["HOLD_CODE"] = "ENGINEER_HOLD";
                        nrow["LOT_STATE"] = "HOLD";
                        nrow["LOT_STATE_CHANGE_DATETIME"] = lotStateChangeDateTime;
                    }
                    acc.Save(dtable);
                }
            }
        }

        #endregion
        
        #region Data Class
        class ResourceLittlesRawInfo
        {
            public string MFG_PART_ID { get; set; }
            public int DAY_CAPA { get; set; }
            public double CYCLE_TIME { get; set; }
            public int NORMAL_CAPA { get; set; }
            public int HOT_CAPA { get; set; }
        }

        class TypeWip
        {
            public string LINE_ID { get; set; }
            public string LOT_ID { get; set; }
            public DateTime LOT_START_TIME { get; set; }
            public string PRODUCT_ID { get; set; }
            public string MFG_PART_ID { get; set; }
            public string ROUTE_ID { get; set; }
            public string STEP_ID { get; set; }
            public int WAFER_QTY { get; set; }
            public string LOT_PRIORITY_STATUS { get; set; }
            public string LOT_STATE { get; set; }
        }

        public class LotIdGenerator
        {
            private static LotIdGenerator instance;
            private int currentId = 1;

            private LotIdGenerator() { }

            public static LotIdGenerator Instance
            {
                get
                {
                    if (instance == null)
                        instance = new LotIdGenerator();
                    return instance;
                }
            }
            public void Reset()
            {
                currentId = 1;
            }

            public string GetNextId()
            {
                return $"L{currentId++:00000}";
            }
        }

        enum ERadioButton
        {
            Demand = 1,
            FabInPlan = 2
        }
        enum ECapacityButton
        {
            Capacity = 1,
            Priority = 2
        }
        #endregion
        
    }    
}