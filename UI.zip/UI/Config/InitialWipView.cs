﻿using DevExpress.XtraEditors;
using DevExpress.XtraEditors.Controls;// linq1
using DevExpress.XtraLayout;
using FabSimulator;
using FabSimulator.Inputs;
using FabSimulatorUI.Common;
using Mozart.Studio.TaskModel.Projects;
using Mozart.Studio.TaskModel.UserInterface;
using Mozart.Studio.TaskModel.UserLibrary; //linq2
using System.Data;

namespace FabSimulatorUI.Config
{
    public partial class InitialWipView : XtraPivotGridControlView
    {
        #region Variable&Property
        int totalWipMaxCount = 1000000;
        int hotNReworkMaxPercent = 2000;
        int percent = 10000;

        IExperimentResultItem result;
        ModelDataContext modelDataContext;
        ExpDataContext expDataContext;
        bool initializing;
        bool loading;

        Dictionary<string, BaseEdit> findControl;
        List<TrackBarControl> productRatioTBCList;
        List<TrackBarControl> areaRatioTBCList;
        List<string> paraCategories = new List<string>() { "BAY NAME", "MAIN ROUTE ID", "RETURN STEP ID" };
        TrackBarControl selectedTBC;

        DataTable wipDt;
        DataTable wipParaDt;

        Dictionary<string, Product> findProdcut = new Dictionary<string, Product>();
        Dictionary<string, Route> findRoute = new Dictionary<string, Route>();
        Dictionary<string, float> findStepCT = new Dictionary<string, float>();
        Dictionary<string, int> findLotStateChangeCount = new Dictionary<string, int>();
        List<Route> reworkRouteList = new List<Route>();
        List<string> eqpLocations = new List<string>();
        HashSet<string> onlyReworkArea = new HashSet<string>();
        HashSet<string> exceptStepArea = new HashSet<string>();

        Random rand = new Random();
        string lineID = string.Empty;
        string startOperation = string.Empty;
        string endOperation = string.Empty;
        DateTime engineStartTime = DateTime.Now;
        #endregion

        #region Ctor
        public InitialWipView(IServiceProvider serviceProvider)
            : base(serviceProvider)
        {
            InitializeComponent();

            this.initializing = true;
        }

        protected override void LoadDocument()
        {
            this.LoadInit();

            this.loading = true;
            this.Query();
            this.loading = false;

            this.ConstructInit();

            this.initializing = false;
        }

        private void Query()
        {
            using (var wc = new Mozart.Studio.UIComponents.WaitCursor())
            {
                this.SetRawData();
            }
        }
        #endregion

        #region Class
        class Product
        {
            public string MFG_PRODUCT_ID { get; set; }
            public string SOP_PRODUCT_ID { get; set; }
            public string ROUTE_ID { get; set; }
            public PRODUCT OrgData { get; set; }
            public Route ROUTE { get; set; }

            public Product(PRODUCT product)
            {
                this.MFG_PRODUCT_ID = product.PART_ID;
                this.SOP_PRODUCT_ID = product.PRODUCT_ID;
                this.ROUTE_ID = product.ROUTE_ID;
                this.OrgData = product;
            }
        }

        class Route
        {
            public string ROUTE_ID { get; set; }
            public List<string> MainSteps { get; set; }
            public List<string> OperIDs { get; set; }
            public Dictionary<string, List<string>> AreaToOperSet { get; set; }
            public bool IsRework { get; set; }

            public Route(ROUTE route)
            {
                this.ROUTE_ID = route.ROUTE_ID;
                this.MainSteps = new List<string>();
                this.OperIDs = new List<string>();
                this.AreaToOperSet = new Dictionary<string, List<string>>();
                this.IsRework = route.ROUTE_TYPE == "REWORK";
            }
        }
        #endregion

        #region Events
        void trackBarControl_Scroll(object sender, EventArgs e)
        {
            TrackBarControl currentTBC = sender as TrackBarControl;

            int value = currentTBC.Value;

            string name = currentTBC.Name;

            if (name.Contains("hotRatio"))
            {
                this.hotRatioTextEdit.EditValue = (float)value / 100f;
            }
            else if (name.Contains("reworkRatio"))
            {
                this.reworkRatioTextEdit.EditValue = (float)value / 100f;
            }
            else if (name.Contains("totalWip"))
            {
                this.totalWipTextEdit.EditValue = value;
                this.inputSmoothingTextEdit.EditValue = (int)this.lotSizeTextEdit.EditValue != 0 ? (int)((int)this.totalWipTextEdit.EditValue / (int)this.lotSizeTextEdit.EditValue) : 0;
            }
        }

        void textChanged(object sender, EventArgs e)
        {
            string name = (sender as TextEdit).Name;

            //int value = name.Contains("Ratio") ? (int)((float)(sender as TextEdit).EditValue * 100) : (int)(sender as TextEdit).EditValue;
            int value = name.Contains("Ratio") ? (int)(Math.Round((float)(sender as TextEdit).EditValue * 100)) : (int)(sender as TextEdit).EditValue;

            int max = int.MaxValue;

            if (name.Contains("HRatio"))
            {
                max = percent;
            }
            else if (name.Contains("Ratio"))
            {
                max = hotNReworkMaxPercent;
            }
            else if (name.Contains("totalWip"))
                max = totalWipMaxCount;

            if (value > max)
                value = max;

            if (value < 0)
                value = 0;

            if (name.Contains("HRatio"))
            {
                (sender as TextEdit).EditValue = (float)value / 100f;

                BaseEdit tbc;
                if (findControl.TryGetValue(name, out tbc))
                    (tbc as TrackBarControl).Value = value;
            }
            else if (name.Contains("hotRatio"))
            {
                this.hotRatioTextEdit.EditValue = (float)value / 100f;
                this.hotRatioTrackBarControl.Value = value;
            }
            else if (name.Contains("reworkRatio"))
            {
                this.reworkRatioTextEdit.EditValue = (float)value / 100f;
                this.reworkRatioTrackBarControl.Value = value;
            }
            else if (name.Contains("totalWip"))
            {
                this.totalWipTextEdit.EditValue = value;
                this.totalWipTrackBarControl.Value = value;
                this.inputSmoothingTextEdit.EditValue = (int)this.lotSizeTextEdit.EditValue != 0 ? (int)((int)this.totalWipTextEdit.EditValue / (int)this.lotSizeTextEdit.EditValue) : 0;
            }
        }

        void lotSizeTextChanged(object sender, EventArgs e)
        {
            int value = (int)(sender as TextEdit).EditValue;

            if (value < 25)
            {
                value = 25;
                (sender as TextEdit).EditValue = value;
            }
            else if (value > 125)
            {
                value = 125;
                (sender as TextEdit).EditValue = value;
            }

            this.inputSmoothingTextEdit.EditValue = value != 0 ? (int)((int)this.totalWipTextEdit.EditValue / value) : 0;

        }

        private void trackBarControl1_BeforeShowValueToolTip(object sender, DevExpress.XtraEditors.TrackBarValueToolTipEventArgs e)
        {
            string name = (sender as TrackBarControl).Name;

            if (name.Contains("Ratio") || name.Contains("HTrack"))
                e.ShowArgs.ToolTip = string.Format("Value = {0:f2}", (float)((sender as TrackBarControl).Value / 100f));
            else if (name.Contains("totalWip"))
                e.ShowArgs.ToolTip = string.Format("Value = {0:n0}", (sender as TrackBarControl).Value);
        }

        int changedValue = 0;
        private void trackBar_editValueChanged(object sender, EventArgs e)
        {
            TrackBarControl currentTBC = sender as TrackBarControl;

            string name = currentTBC.Name;

            List<TrackBarControl> trackBarArea = name.Contains("area") ? areaRatioTBCList : productRatioTBCList;

            int value = currentTBC.Value;

            int oldValue = (int)(e as ChangingEventArgs).OldValue;

            if (currentTBC == selectedTBC)
                changedValue = oldValue - value;

            if (changedValue != 0)
            {
                foreach (TrackBarControl productTbc in trackBarArea)
                {
                    if (productTbc == selectedTBC)
                        continue;

                    int otherValue = (int)productTbc.Value;

                    if (changedValue > 0)
                    {
                        if (otherValue == 10000)
                            continue;

                        int sum = otherValue + changedValue;

                        if (sum > 10000)
                            changedValue = sum - 10000;
                        else
                            changedValue = 0;

                        productTbc.EditValue = sum;
                    }
                    else
                    {
                        if (otherValue == 0)
                            continue;

                        int sum = otherValue + changedValue;

                        if (sum < 0)
                        {
                            changedValue = sum;
                            sum = 0;
                        }
                        else
                            changedValue = 0;

                        productTbc.EditValue = sum;
                    }
                }
            }

            BaseEdit textEdit;
            if (findControl.TryGetValue(name, out textEdit))
                (textEdit as TextEdit).EditValue = (float)value / 100f;
        }

        private void trackBar_MouseEnter(object sender, EventArgs e)
        {
            selectedTBC = sender as TrackBarControl;
        }

        private void trackBar_MouseDown(object sender, MouseEventArgs e)
        {
            selectedTBC = sender as TrackBarControl;
        }

        private void text_MouseEnter(object sender, EventArgs e)
        {
            string name = (sender as TextEdit).Name;

            BaseEdit edit;
            if (findControl.TryGetValue(name, out edit))
            {
                selectedTBC = edit as TrackBarControl;
            }
        }

        private void text_MouseDown(object sender, MouseEventArgs e)
        {
            string name = (sender as TextEdit).Name;

            BaseEdit edit;
            if (findControl.TryGetValue(name, out edit))
            {
                selectedTBC = edit as TrackBarControl;
            }
        }

        private void SaveButton_Click(object sender, EventArgs e)
        {
            if (XtraMessageBox.Show("Create WIP & WIP_PARAM Data?", "Alert", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                using (var wc = new Mozart.Studio.UIComponents.WaitCursor())
                {
                    CreateData();
                    DeleteVdat();
                    InsertVdat();
                }
            }
        }

        private void InputSmoothingCheckEdit_CheckStateChanged(object sender, EventArgs e)
        {
            var value = ((sender as CheckEdit).CheckState == CheckState.Checked).ToString();
            UpdateConfigVdat("ApplyInputSmoothing", value);
        }

        private void WipLevelKeepingCheckEdit_CheckStateChanged(object sender, EventArgs e)
        {
            var value = ((sender as CheckEdit).CheckState == CheckState.Checked).ToString();
            UpdateConfigVdat("ApplyWipLevelKeeping", value);
        }

        private void LotSizeTextEdit_EditValueChanged(object sender, EventArgs e)
        {
            var value = (sender as TextEdit).Text;
            UpdateConfigVdat("DefaultLotSize", value);
        }

        //private void dockPanel_Resize(object sender, EventArgs e)
        //{
        //    int height = (int)Math.Round((sender as InitialWipView).Size.Height * 0.75);
        //    (sender as InitialWipView).dockPanel1.Size = new Size((sender as InitialWipView).dockPanel1.Size.Width, height);
        //    (sender as InitialWipView).dockPanel2.Size = new Size((sender as InitialWipView).dockPanel2.Size.Width, height);
        //}
        #endregion

        #region Init
        private void SetRawData()
        {
            HashSet<string> mainArea = new HashSet<string>();

            GetArgumentValue();

            foreach (ROUTE route in modelDataContext.ROUTE.OrderBy(x => x.ROUTE_ID))
            {
                if (findRoute.ContainsKey(route.ROUTE_ID) == false)
                {
                    Route rt = new Route(route);
                    findRoute.Add(route.ROUTE_ID, rt);

                    if (rt.IsRework)
                        reworkRouteList.Add(rt);
                }
            }

            foreach (var routeSet in modelDataContext.ROUTE_STEP.GroupBy(x => x.ROUTE_ID))
            {
                foreach (ROUTE_STEP step in routeSet.ToList().OrderBy(x => x.STEP_SEQ))
                {
                    Route rt;
                    if (findRoute.TryGetValue(step.ROUTE_ID, out rt))
                    {
                        if (step.STEP_LEVEL == 1)
                            rt.MainSteps.Add(step.STEP_ID);

                        rt.OperIDs.Add(step.STEP_ID);

                        List<string> operSet;
                        if (rt.AreaToOperSet.TryGetValue(step.AREA_ID, out operSet) == false)
                        {
                            operSet = new List<string>();
                            rt.AreaToOperSet.Add(step.AREA_ID, operSet);

                            if (rt.IsRework)
                                onlyReworkArea.Add(step.AREA_ID);
                            else
                                mainArea.Add(step.AREA_ID);
                        }

                        operSet.Add(step.STEP_ID);
                    }
                }
            }

            foreach (PRODUCT product in modelDataContext.PRODUCT)
            {
                if (findProdcut.ContainsKey(product.PART_ID) == false)
                {
                    Product pt = new Product(product);
                    findProdcut.Add(product.PART_ID, pt);

                    Route rt;
                    if (findRoute.TryGetValue(pt.ROUTE_ID, out rt))
                        pt.ROUTE = rt;

                }
            }

            foreach (string area in mainArea)
                onlyReworkArea.Remove(area);

            //foreach (STEP_CT ct in modelDataContext.STEP_CT)
            //{
            //    string key = ct.SOP_PRODUCT_ID + ct.OPER_ID;

            //    float value;
            //    if (findStepCT.TryGetValue(key, out value) == false)
            //        findStepCT.Add(key, ct.CT_MINS);
            //}

            foreach (var eqpLocation in modelDataContext.EQP_LOCATION.GroupBy(x => x.BAY_ID))
            {
                if (eqpLocations.Contains(eqpLocation.Key) == false)
                    eqpLocations.Add(eqpLocation.Key);
            }
        }

        private void LoadInit()
        {
            this.result = this.Document.GetResultItem();

            Globals.InitFactoryTime(this.result);

            this.modelDataContext = result.GetCtx<ModelDataContext>();
            this.expDataContext = result.GetCtx<ExpDataContext>();
        }

        private void ConstructInit()
        {
            #region Total Wip TrackBar Setting
            this.totalWipTextEdit.EditValue = totalWipMaxCount;
            this.totalWipTextEdit.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.totalWipTextEdit.Properties.Mask.EditMask = "N0";
            this.totalWipTextEdit.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.totalWipTextEdit.Properties.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.totalWipTextEdit.MaximumSize = new Size(70, this.totalWipTextEdit.Size.Height);
            this.totalWipTextEdit.MinimumSize = new Size(70, this.totalWipTextEdit.Size.Height);

            this.totalWipTrackBarControl.Properties.Minimum = 0;
            this.totalWipTrackBarControl.Properties.Maximum = totalWipMaxCount;
            this.totalWipTrackBarControl.Properties.TickFrequency = totalWipMaxCount / 4;
            this.totalWipTrackBarControl.MaximumSize = new Size(400, this.totalWipTrackBarControl.Size.Height);
            this.totalWipTrackBarControl.MinimumSize = new Size(400, this.totalWipTrackBarControl.Size.Height);

            DevExpress.XtraEditors.Repository.TrackBarLabel labelFirst = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel labelCenter = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel labelLast = new DevExpress.XtraEditors.Repository.TrackBarLabel();

            labelFirst.Label = "0";
            labelFirst.Value = 0;

            labelCenter.Label = string.Format("{0:n0}", totalWipMaxCount / 2);
            labelCenter.Value = totalWipMaxCount / 2;

            labelLast.Label = string.Format("{0:n0}", totalWipMaxCount);
            labelLast.Value = totalWipMaxCount;

            this.totalWipTrackBarControl.Properties.Labels.Clear();
            this.totalWipTrackBarControl.Properties.Labels.AddRange(new DevExpress.XtraEditors.Repository.TrackBarLabel[] {
            labelFirst, labelCenter, labelLast});
            this.totalWipTrackBarControl.Properties.ShowLabels = true;

            this.totalWipTrackBarControl.Value = totalWipMaxCount;
            this.totalWipTrackBarControl.Properties.ShowValueToolTip = true;


            this.totalWipTextEdit.EditValueChanged += new EventHandler(textChanged);
            this.totalWipTrackBarControl.ValueChanged += new EventHandler(trackBarControl_Scroll);
            this.totalWipTrackBarControl.BeforeShowValueToolTip += new TrackBarValueToolTipEventHandler(this.trackBarControl1_BeforeShowValueToolTip);
            #endregion

            #region Lot Size Setting
            this.lotSizeLabel.SizeConstraintsType = SizeConstraintsType.Custom;
            this.lotSizeLabel.MaxSize = new Size(100, this.lotSizeLabel.Size.Height);
            this.lotSizeLabel.MinSize = new Size(100, this.lotSizeLabel.Size.Height);

            this.lotSizeTextEdit.EditValue = 100;
            this.lotSizeTextEdit.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.lotSizeTextEdit.Properties.Mask.EditMask = "N0";
            this.lotSizeTextEdit.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.lotSizeTextEdit.Properties.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.lotSizeTextEdit.MaximumSize = new Size(70, this.lotSizeTextEdit.Size.Height);
            this.lotSizeTextEdit.MinimumSize = new Size(70, this.lotSizeTextEdit.Size.Height);
            this.lotSizeTextEdit.EditValueChanged += new EventHandler(lotSizeTextChanged);
            #endregion

            #region Target TAT Setting
            int configTargetCT = this.modelDataContext.Target.Configs.ContainsKey("TargetCT") ? this.modelDataContext.GetConfigValue<int>(PARAM_GROUP: "Lot_InPlan", PARAM_NAME: "targetCT") : 90;

            this.targetTATLable.SizeConstraintsType = SizeConstraintsType.Custom;
            this.targetTATLable.MaxSize = new Size(100, this.targetTATLable.Size.Height);
            this.targetTATLable.MinSize = new Size(100, this.targetTATLable.Size.Height);

            this.targetTatTextEdit.EditValue = configTargetCT;
            this.targetTatTextEdit.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.targetTatTextEdit.Properties.Mask.EditMask = "N0";
            this.targetTatTextEdit.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.targetTatTextEdit.Properties.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.targetTatTextEdit.MaximumSize = new Size(70, this.targetTatTextEdit.Size.Height);
            this.targetTatTextEdit.MinimumSize = new Size(70, this.targetTatTextEdit.Size.Height);
            #endregion

            #region Input Smoothing Setting
            this.InputSmoothingCheckEdit.MaximumSize = new Size(135, this.InputSmoothingCheckEdit.Size.Height);
            this.InputSmoothingCheckEdit.MinimumSize = new Size(135, this.InputSmoothingCheckEdit.Size.Height);

            this.inputSmoothingTextEdit.EditValue = (int)this.lotSizeTextEdit.EditValue != 0 ? (int)((int)this.totalWipTextEdit.EditValue / (int)this.lotSizeTextEdit.EditValue) : 0;
            this.inputSmoothingTextEdit.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.inputSmoothingTextEdit.Properties.Mask.EditMask = "N0";
            this.inputSmoothingTextEdit.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.inputSmoothingTextEdit.Properties.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.inputSmoothingTextEdit.MaximumSize = new Size(70, this.inputSmoothingTextEdit.Size.Height);
            this.inputSmoothingTextEdit.MinimumSize = new Size(70, this.inputSmoothingTextEdit.Size.Height);
            #endregion

            #region Wip Level Keeping Setting
            this.wipLevelKeepingCheckEdit.MaximumSize = new Size(135, this.wipLevelKeepingCheckEdit.Size.Height);
            this.wipLevelKeepingCheckEdit.MinimumSize = new Size(135, this.wipLevelKeepingCheckEdit.Size.Height);
            #endregion

            #region Hot Ratio TrackBar Setting
            this.hotRatioTextEdit.EditValue = (float)hotNReworkMaxPercent / 100f;
            this.hotRatioTextEdit.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.hotRatioTextEdit.Properties.Mask.EditMask = "f2";
            this.hotRatioTextEdit.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.hotRatioTextEdit.Properties.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.hotRatioTextEdit.MaximumSize = new Size(70, this.hotRatioTextEdit.Size.Height);
            this.hotRatioTextEdit.MinimumSize = new Size(70, this.hotRatioTextEdit.Size.Height);

            this.hotRatioTrackBarControl.Properties.Minimum = 0;
            this.hotRatioTrackBarControl.Properties.Maximum = hotNReworkMaxPercent;
            this.hotRatioTrackBarControl.Properties.TickFrequency = hotNReworkMaxPercent / 4;
            this.hotRatioTrackBarControl.MaximumSize = new Size(400, this.hotRatioTrackBarControl.Size.Height);
            this.hotRatioTrackBarControl.MinimumSize = new Size(400, this.hotRatioTrackBarControl.Size.Height);

            labelFirst = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            labelCenter = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            labelLast = new DevExpress.XtraEditors.Repository.TrackBarLabel();

            labelFirst.Label = "0";
            labelFirst.Value = 0;

            labelCenter.Label = string.Format("{0:n2}", hotNReworkMaxPercent / 2 / 100);
            labelCenter.Value = hotNReworkMaxPercent / 2;

            labelLast.Label = string.Format("{0:n2}", hotNReworkMaxPercent / 100);
            labelLast.Value = hotNReworkMaxPercent;

            this.hotRatioTrackBarControl.Properties.Labels.Clear();
            this.hotRatioTrackBarControl.Properties.Labels.AddRange(new DevExpress.XtraEditors.Repository.TrackBarLabel[] {
            labelFirst, labelCenter, labelLast});
            this.hotRatioTrackBarControl.Properties.ShowLabels = true;

            this.hotRatioTrackBarControl.Value = hotNReworkMaxPercent;
            this.hotRatioTrackBarControl.Properties.ShowValueToolTip = true;


            this.hotRatioTextEdit.EditValueChanged += new EventHandler(textChanged);
            this.hotRatioTrackBarControl.ValueChanged += new EventHandler(trackBarControl_Scroll);
            this.hotRatioTrackBarControl.BeforeShowValueToolTip += new TrackBarValueToolTipEventHandler(this.trackBarControl1_BeforeShowValueToolTip);
            #endregion

            #region Rework Ratio TrackBar Setting
            this.reworkRatioTextEdit.EditValue = (float)hotNReworkMaxPercent / 100f;
            this.reworkRatioTextEdit.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.reworkRatioTextEdit.Properties.Mask.EditMask = "f2";
            this.reworkRatioTextEdit.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.reworkRatioTextEdit.Properties.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.reworkRatioTextEdit.MaximumSize = new Size(70, this.reworkRatioTextEdit.Size.Height);
            this.reworkRatioTextEdit.MinimumSize = new Size(70, this.reworkRatioTextEdit.Size.Height);

            this.reworkRatioTrackBarControl.Properties.Minimum = 0;
            this.reworkRatioTrackBarControl.Properties.Maximum = hotNReworkMaxPercent;
            this.reworkRatioTrackBarControl.Properties.TickFrequency = hotNReworkMaxPercent / 4;
            this.reworkRatioTrackBarControl.MaximumSize = new Size(400, this.reworkRatioTrackBarControl.Size.Height);
            this.reworkRatioTrackBarControl.MinimumSize = new Size(400, this.reworkRatioTrackBarControl.Size.Height);

            labelFirst = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            labelCenter = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            labelLast = new DevExpress.XtraEditors.Repository.TrackBarLabel();

            labelFirst.Label = "0";
            labelFirst.Value = 0;

            labelCenter.Label = string.Format("{0:n2}", hotNReworkMaxPercent / 2 / 100);
            labelCenter.Value = hotNReworkMaxPercent / 2;

            labelLast.Label = string.Format("{0:n2}", hotNReworkMaxPercent / 100);
            labelLast.Value = hotNReworkMaxPercent;

            this.reworkRatioTrackBarControl.Properties.Labels.Clear();
            this.reworkRatioTrackBarControl.Properties.Labels.AddRange(new DevExpress.XtraEditors.Repository.TrackBarLabel[] {
            labelFirst, labelCenter, labelLast});
            this.reworkRatioTrackBarControl.Properties.ShowLabels = true;

            this.reworkRatioTrackBarControl.Value = hotNReworkMaxPercent;
            this.reworkRatioTrackBarControl.Properties.ShowValueToolTip = true;


            this.reworkRatioTextEdit.EditValueChanged += new EventHandler(textChanged);
            this.reworkRatioTrackBarControl.ValueChanged += new EventHandler(trackBarControl_Scroll);
            this.reworkRatioTrackBarControl.BeforeShowValueToolTip += new TrackBarValueToolTipEventHandler(this.trackBarControl1_BeforeShowValueToolTip);
            #endregion

            findControl = new Dictionary<string, BaseEdit>();
            int index = 0;

            #region Product Ratio
            var product = this.modelDataContext.PRODUCT;
            var demand = this.modelDataContext.DEMAND;

            var mfgProductIDs = from a in demand.Where(x => string.IsNullOrEmpty(x.PRODUCT_ID) == false)
                                join b in product.Where(x => string.IsNullOrEmpty(x.PRODUCT_ID) == false && string.IsNullOrEmpty(x.PART_ID) == false)
                                on a.PRODUCT_ID equals b.PRODUCT_ID into outer
                                from b in outer.DefaultIfEmpty()
                                group b by b.PART_ID into data
                                orderby data.Key
                                select new { data.Key };


            productRatioTBCList = new List<TrackBarControl>();

            this.productRatioLayoutControlGroup.LayoutMode = DevExpress.XtraLayout.Utils.LayoutMode.Table;

            ColumnDefinition columnDefinition3 = new ColumnDefinition();
            this.productRatioLayoutControl.Root.OptionsTableLayoutGroup.ColumnDefinitions.Add(columnDefinition3);

            this.productRatioLayoutControl.BeginUpdate();
            this.productRatioLayoutControl.Root.OptionsTableLayoutGroup.ColumnDefinitions[0].SizeType = SizeType.Absolute;
            this.productRatioLayoutControl.Root.OptionsTableLayoutGroup.ColumnDefinitions[0].Width = 440;
            this.productRatioLayoutControl.Root.OptionsTableLayoutGroup.ColumnDefinitions[1].SizeType = SizeType.Absolute;
            this.productRatioLayoutControl.Root.OptionsTableLayoutGroup.ColumnDefinitions[1].Width = 90;
            this.productRatioLayoutControl.EndUpdate();

            foreach (var item in mfgProductIDs)
            {
                #region Product Ratio TrackBar
                TrackBarControl tempTBC = new DevExpress.XtraEditors.TrackBarControl();
                ((System.ComponentModel.ISupportInitialize)(tempTBC)).BeginInit();
                ((System.ComponentModel.ISupportInitialize)(tempTBC.Properties)).BeginInit();
                tempTBC.Name = string.Concat(item.Key, "HTrackBarControl");

                tempTBC.Properties.Minimum = 0;
                tempTBC.Properties.Maximum = percent;
                tempTBC.Properties.TickFrequency = percent / 4;
                tempTBC.MaximumSize = new Size(400, 49);
                tempTBC.MinimumSize = new Size(400, 49);

                labelFirst = new DevExpress.XtraEditors.Repository.TrackBarLabel();
                labelCenter = new DevExpress.XtraEditors.Repository.TrackBarLabel();
                labelLast = new DevExpress.XtraEditors.Repository.TrackBarLabel();

                labelFirst.Label = "0";
                labelFirst.Value = 0;

                labelCenter.Label = string.Format("{0:n2}", percent / 2 / 100);
                labelCenter.Value = percent / 2;

                labelLast.Label = string.Format("{0:n2}", percent / 100);
                labelLast.Value = percent;

                tempTBC.Properties.Labels.Clear();
                tempTBC.Properties.Labels.AddRange(new DevExpress.XtraEditors.Repository.TrackBarLabel[] {
                    labelFirst, labelCenter, labelLast});
                tempTBC.Properties.ShowLabels = true;

                tempTBC.Value = index == 0 ? percent : 0;
                tempTBC.Properties.ShowValueToolTip = true;

                tempTBC.EditValueChanged += new EventHandler(trackBar_editValueChanged);
                tempTBC.BeforeShowValueToolTip += new TrackBarValueToolTipEventHandler(this.trackBarControl1_BeforeShowValueToolTip);
                tempTBC.MouseEnter += new EventHandler(trackBar_MouseEnter);
                tempTBC.MouseDown += new MouseEventHandler(trackBar_MouseDown);

                ((System.ComponentModel.ISupportInitialize)(tempTBC.Properties)).EndInit();
                ((System.ComponentModel.ISupportInitialize)(tempTBC)).EndInit();

                productRatioTBCList.Add(tempTBC);
                #endregion

                #region Product Ratio Product Label
                LayoutControlItem layoutControlItem = new DevExpress.XtraLayout.LayoutControlItem();
                ((System.ComponentModel.ISupportInitialize)(layoutControlItem)).BeginInit();

                layoutControlItem.Control = tempTBC;
                layoutControlItem.Name = string.Concat(item.Key, "layoutControlItem");
                layoutControlItem.TextVisible = true;
                layoutControlItem.Text = item.Key;
                layoutControlItem.AppearanceItemCaption.Options.UseTextOptions = true;
                layoutControlItem.AppearanceItemCaption.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
                layoutControlItem.AppearanceItemCaption.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Top;
                layoutControlItem.MaxSize = new System.Drawing.Size(0, 49);
                layoutControlItem.MinSize = new System.Drawing.Size(49, 49);
                layoutControlItem.Size = new System.Drawing.Size(215, 49);
                layoutControlItem.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;

                ((System.ComponentModel.ISupportInitialize)(layoutControlItem)).EndInit();
                #endregion

                #region Product Ratio TextBox
                TextEdit ratioTextEdit = new DevExpress.XtraEditors.TextEdit();
                ((System.ComponentModel.ISupportInitialize)(ratioTextEdit.Properties)).BeginInit();

                ratioTextEdit.Name = string.Concat(item.Key, "HRatioTextEdit");
                ratioTextEdit.EditValue = index == 0 ? 100f : 0f;
                ratioTextEdit.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
                ratioTextEdit.Properties.Mask.EditMask = "f2";
                ratioTextEdit.Properties.Mask.UseMaskAsDisplayFormat = true;
                ratioTextEdit.Properties.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
                ratioTextEdit.MaximumSize = new Size(70, ratioTextEdit.Size.Height);
                ratioTextEdit.MinimumSize = new Size(70, ratioTextEdit.Size.Height);
                ratioTextEdit.EditValueChanged += new EventHandler(textChanged);
                //ratioTextEdit.MouseEnter += new EventHandler(text_MouseEnter);
                ratioTextEdit.MouseDown += new MouseEventHandler(text_MouseDown);

                ((System.ComponentModel.ISupportInitialize)(ratioTextEdit.Properties)).EndInit();
                #endregion

                #region Product Ratio Percent Label
                LayoutControlItem textLayoutControlItem = new DevExpress.XtraLayout.LayoutControlItem();
                ((System.ComponentModel.ISupportInitialize)(textLayoutControlItem)).BeginInit();

                textLayoutControlItem.Control = ratioTextEdit;
                textLayoutControlItem.Name = string.Concat(item.Key, "layoutControlItemTest");
                textLayoutControlItem.TextVisible = true;
                textLayoutControlItem.SizeConstraintsType = SizeConstraintsType.Custom;
                textLayoutControlItem.MaxSize = new Size(90, 49);
                textLayoutControlItem.MinSize = new Size(90, 49);
                textLayoutControlItem.TextLocation = DevExpress.Utils.Locations.Right;
                textLayoutControlItem.Text = "%";
                textLayoutControlItem.AppearanceItemCaption.Options.UseTextOptions = true;
                textLayoutControlItem.AppearanceItemCaption.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
                textLayoutControlItem.AppearanceItemCaption.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Top;

                ((System.ComponentModel.ISupportInitialize)(textLayoutControlItem)).EndInit();
                #endregion

                this.productRatioLayoutControlGroup.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] { layoutControlItem, textLayoutControlItem });
                //this.productRatioLayoutControlGroup.ViewInfo.BorderInfo.BorderStyle = BorderStyles.Flat;

                layoutControlItem.OptionsTableLayoutItem.RowIndex = index;
                layoutControlItem.OptionsTableLayoutItem.ColumnIndex = 0;

                textLayoutControlItem.OptionsTableLayoutItem.RowIndex = index;
                textLayoutControlItem.OptionsTableLayoutItem.ColumnIndex = 1;

                index++;

                if (index > 1)
                {
                    RowDefinition rowDefinition = new RowDefinition(this.productRatioLayoutControl.Root);

                    this.productRatioLayoutControl.Root.OptionsTableLayoutGroup.RowDefinitions.AddRange(new RowDefinition[] { rowDefinition });
                }

                if (findControl.ContainsKey(ratioTextEdit.Name) == false)
                    findControl.Add(ratioTextEdit.Name, tempTBC);

                if (findControl.ContainsKey(tempTBC.Name) == false)
                    findControl.Add(tempTBC.Name, ratioTextEdit);
            }

            //this.productRatioLayoutControl.MaximumSize = new Size(this.productRatioLayoutControl.Width + 20, 450);

            productRatioTBCList.Sort(new Comparison<TrackBarControl>((x, y) => y.Name.CompareTo(x.Name)));

            #endregion

            index = 0;

            #region Area Ratio
            var routeStep = this.modelDataContext.ROUTE_STEP;

            var areaIDs = from a in routeStep.Where
                          (
                            x => string.IsNullOrEmpty(x.AREA_ID) == false &&
                            onlyReworkArea.Contains(x.AREA_ID) == false &&
                            exceptStepArea.Contains(x.STEP_ID) == false
                          )
                          group a by a.AREA_ID into data
                          orderby data.Key
                          select new { data.Key };


            areaRatioTBCList = new List<TrackBarControl>();

            this.areaRatioLayoutControlGroup.LayoutMode = DevExpress.XtraLayout.Utils.LayoutMode.Table;

            ColumnDefinition columnDefinition4 = new ColumnDefinition();
            this.areaRatioLayoutControl.Root.OptionsTableLayoutGroup.ColumnDefinitions.Add(columnDefinition4);

            this.areaRatioLayoutControl.BeginUpdate();
            this.areaRatioLayoutControl.Root.OptionsTableLayoutGroup.ColumnDefinitions[0].SizeType = SizeType.Absolute;
            this.areaRatioLayoutControl.Root.OptionsTableLayoutGroup.ColumnDefinitions[0].Width = 460;
            this.areaRatioLayoutControl.Root.OptionsTableLayoutGroup.ColumnDefinitions[1].SizeType = SizeType.Absolute;
            this.areaRatioLayoutControl.Root.OptionsTableLayoutGroup.ColumnDefinitions[1].Width = 90;
            this.areaRatioLayoutControl.EndUpdate();

            foreach (var item in areaIDs)
            {
                #region Area Ratio TrackBar
                TrackBarControl tempTBC = new DevExpress.XtraEditors.TrackBarControl();
                ((System.ComponentModel.ISupportInitialize)(tempTBC)).BeginInit();
                ((System.ComponentModel.ISupportInitialize)(tempTBC.Properties)).BeginInit();
                tempTBC.Name = string.Concat(item.Key, "areaHTrackBarControl");

                tempTBC.Properties.Minimum = 0;
                tempTBC.Properties.Maximum = percent;
                tempTBC.Properties.TickFrequency = percent / 4;
                tempTBC.MaximumSize = new Size(400, 49);
                tempTBC.MinimumSize = new Size(400, 49);

                labelFirst = new DevExpress.XtraEditors.Repository.TrackBarLabel();
                labelCenter = new DevExpress.XtraEditors.Repository.TrackBarLabel();
                labelLast = new DevExpress.XtraEditors.Repository.TrackBarLabel();

                labelFirst.Label = "0";
                labelFirst.Value = 0;

                labelCenter.Label = string.Format("{0:n2}", percent / 2 / 100);
                labelCenter.Value = percent / 2;

                labelLast.Label = string.Format("{0:n2}", percent / 100);
                labelLast.Value = percent;

                tempTBC.Properties.Labels.Clear();
                tempTBC.Properties.Labels.AddRange(new DevExpress.XtraEditors.Repository.TrackBarLabel[] {
                    labelFirst, labelCenter, labelLast});
                tempTBC.Properties.ShowLabels = true;

                tempTBC.Value = index == 0 ? percent : 0;
                tempTBC.Properties.ShowValueToolTip = true;

                tempTBC.EditValueChanged += new EventHandler(trackBar_editValueChanged);
                tempTBC.BeforeShowValueToolTip += new TrackBarValueToolTipEventHandler(this.trackBarControl1_BeforeShowValueToolTip);
                tempTBC.MouseEnter += new EventHandler(trackBar_MouseEnter);
                tempTBC.MouseDown += new MouseEventHandler(trackBar_MouseDown);

                ((System.ComponentModel.ISupportInitialize)(tempTBC.Properties)).EndInit();
                ((System.ComponentModel.ISupportInitialize)(tempTBC)).EndInit();

                areaRatioTBCList.Add(tempTBC);
                #endregion

                #region Area Ratio Product Label
                LayoutControlItem layoutControlItem = new DevExpress.XtraLayout.LayoutControlItem();
                ((System.ComponentModel.ISupportInitialize)(layoutControlItem)).BeginInit();

                layoutControlItem.Control = tempTBC;
                layoutControlItem.Name = string.Concat(item.Key, "layoutControlItem");
                layoutControlItem.TextVisible = true;
                layoutControlItem.Text = item.Key;
                layoutControlItem.AppearanceItemCaption.Options.UseTextOptions = true;
                layoutControlItem.AppearanceItemCaption.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
                layoutControlItem.AppearanceItemCaption.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Top;
                layoutControlItem.MaxSize = new System.Drawing.Size(0, 49);
                layoutControlItem.MinSize = new System.Drawing.Size(49, 49);
                layoutControlItem.Size = new System.Drawing.Size(215, 49);
                layoutControlItem.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;

                ((System.ComponentModel.ISupportInitialize)(layoutControlItem)).EndInit();
                #endregion

                #region Area Ratio TextBox
                TextEdit ratioTextEdit = new DevExpress.XtraEditors.TextEdit();
                ((System.ComponentModel.ISupportInitialize)(ratioTextEdit.Properties)).BeginInit();

                ratioTextEdit.Name = string.Concat(item.Key, "HRatioTextEdit");
                ratioTextEdit.EditValue = index == 0 ? 100f : 0f;
                ratioTextEdit.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
                ratioTextEdit.Properties.Mask.EditMask = "f2";
                ratioTextEdit.Properties.Mask.UseMaskAsDisplayFormat = true;
                ratioTextEdit.Properties.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
                ratioTextEdit.MaximumSize = new Size(70, ratioTextEdit.Size.Height);
                ratioTextEdit.MinimumSize = new Size(70, ratioTextEdit.Size.Height);
                ratioTextEdit.EditValueChanged += new EventHandler(textChanged);
                //ratioTextEdit.MouseEnter += new EventHandler(text_MouseEnter);
                ratioTextEdit.MouseDown += new MouseEventHandler(text_MouseDown);

                ((System.ComponentModel.ISupportInitialize)(ratioTextEdit.Properties)).EndInit();
                #endregion

                #region Area Ratio Percent Label
                LayoutControlItem textLayoutControlItem = new DevExpress.XtraLayout.LayoutControlItem();
                ((System.ComponentModel.ISupportInitialize)(textLayoutControlItem)).BeginInit();

                textLayoutControlItem.Control = ratioTextEdit;
                textLayoutControlItem.Name = string.Concat(item.Key, "layoutControlItemTest");
                textLayoutControlItem.TextVisible = true;
                textLayoutControlItem.SizeConstraintsType = SizeConstraintsType.Custom;
                textLayoutControlItem.MaxSize = new Size(90, 49);
                textLayoutControlItem.MinSize = new Size(90, 49);
                textLayoutControlItem.TextLocation = DevExpress.Utils.Locations.Right;
                textLayoutControlItem.Text = "%";
                textLayoutControlItem.AppearanceItemCaption.Options.UseTextOptions = true;
                textLayoutControlItem.AppearanceItemCaption.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
                textLayoutControlItem.AppearanceItemCaption.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Top;

                ((System.ComponentModel.ISupportInitialize)(textLayoutControlItem)).EndInit();
                #endregion

                this.areaRatioLayoutControlGroup.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] { layoutControlItem, textLayoutControlItem });
                //this.areaRatioLayoutControlGroup.ViewInfo.BorderInfo.BorderStyle = BorderStyles.Flat;

                layoutControlItem.OptionsTableLayoutItem.RowIndex = index;
                layoutControlItem.OptionsTableLayoutItem.ColumnIndex = 0;

                textLayoutControlItem.OptionsTableLayoutItem.RowIndex = index;
                textLayoutControlItem.OptionsTableLayoutItem.ColumnIndex = 1;

                index++;

                if (index > 1)
                {
                    RowDefinition rowDefinition = new RowDefinition(this.areaRatioLayoutControl.Root);

                    this.areaRatioLayoutControl.Root.OptionsTableLayoutGroup.RowDefinitions.AddRange(new RowDefinition[] { rowDefinition });
                }

                if (findControl.ContainsKey(ratioTextEdit.Name) == false)
                    findControl.Add(ratioTextEdit.Name, tempTBC);

                if (findControl.ContainsKey(tempTBC.Name) == false)
                    findControl.Add(tempTBC.Name, ratioTextEdit);
            }

            //this.areaRatioLayoutControl.MaximumSize = new Size(this.areaRatioLayoutControl.Width + 20, 450);

            areaRatioTBCList.Sort(new Comparison<TrackBarControl>((x, y) => y.Name.CompareTo(x.Name)));

            #endregion

            //this.Resize += new EventHandler(dockPanel_Resize);

            //this.dockPanel1.Dock = DevExpress.XtraBars.Docking.DockingStyle.Float;
            //this.dockPanel2.Dock = DevExpress.XtraBars.Docking.DockingStyle.Float;
            //this.dockPanel1.DockTo(DevExpress.XtraBars.Docking.DockingStyle.Bottom, 0);
            //this.dockPanel2.DockTo(this.dockPanel1, DevExpress.XtraBars.Docking.DockingStyle.Right);
            //this.dockPanel1.Size = new Size(this.dockPanel1.Size.Width, this.Size.Height /10 * 4);
            //this.dockPanel2.Size = new Size(this.dockPanel2.Size.Width, this.Size.Height / 10 * 4);
        }
        #endregion

        #region Table
        private DataTable GetWIPDataTable()
        {
            DataTable dt = new DataTable();
            dt.Columns.Add("LINE_ID", typeof(string));
            dt.Columns.Add("LOT_ID", typeof(string));
            dt.Columns.Add("LOT_START_TIME", typeof(DateTime));
            dt.Columns.Add("SOP_PRODUCT_ID", typeof(string));
            dt.Columns.Add("PRODUCT_ID", typeof(string));
            dt.Columns.Add("ROUTE_ID", typeof(string));
            dt.Columns.Add("OPER_ID", typeof(string));
            dt.Columns.Add("LOT_QTY", typeof(int));
            dt.Columns.Add("LOT_PRIORITY_STATUS", typeof(string));
            dt.Columns.Add("HOLD_CODE", typeof(string));
            dt.Columns.Add("LOT_STATE", typeof(string));
            dt.Columns.Add("RESOURCE_ID", typeof(string));
            dt.Columns.Add("LOT_STATE_CHANGE_DATETIME", typeof(DateTime));

            return dt;
        }

        private DataTable GetWIP_PARAMDataTable()
        {
            DataTable dt = new DataTable();
            dt.Columns.Add("LOT_ID", typeof(string));
            dt.Columns.Add("PARAM_NAME", typeof(string));
            dt.Columns.Add("PARAM_VALUE", typeof(string));

            return dt;
        }
        #endregion

        #region Method
        private void GetArgumentValue()
        {
            startOperation = this.modelDataContext.GetConfigValue<string>(PARAM_GROUP: "Bop_Step", PARAM_NAME: "fabInStepID");
            endOperation = this.modelDataContext.GetConfigValue<string>(PARAM_GROUP: "Bop_Step", PARAM_NAME: "fabOutStepID");

            if (this.Document.DocumentName.Split('/').Count() > 1)
            {
                string expName = this.Document.DocumentName.Split('/')[0];

                //object lID;
                //if (modelDataContext.Target.GetExperiment(expName).Arguments.TryGetValue("LineID", out lID) == false)
                //    lineID = modelDataContext.Target.Arguments["LineID"].InitialValue.ToString();
                //else
                //    lineID = lID.ToString();

                object startTime;
                if (modelDataContext.Target.GetExperiment(expName).Arguments.TryGetValue("start-time", out startTime))
                    engineStartTime = DateTime.Parse(startTime.ToString());

            }

            exceptStepArea.Add(startOperation);
            exceptStepArea.Add(endOperation);
        }

        private string FindEqpLocation()
        {
            string eqpLocation = string.Empty;

            if (eqpLocations.Count <= 0)
                return eqpLocation;

            int random_number = rand.Next(eqpLocations.Count() - 1);
            eqpLocation = eqpLocations[random_number];

            return eqpLocation;
        }

        int reworkRouteIndex = 0;
        private Route FindReworkRoute()
        {
            if (reworkRouteList.Count <= 0)
                return null;

            Route rwRT = reworkRouteList[reworkRouteIndex];

            reworkRouteIndex++;

            if (reworkRouteIndex == reworkRouteList.Count)
                reworkRouteIndex = 0;

            return rwRT;
        }

        private object FindLotStateChangeTime(Product pt, string operID)
        {
            DateTime stateChangeTime = engineStartTime;

            string key = pt.MFG_PRODUCT_ID + pt.ROUTE_ID + operID;

            int makeCount;
            if (findLotStateChangeCount.TryGetValue(key, out makeCount) == false)
            {
                makeCount = 0;
                findLotStateChangeCount.Add(key, makeCount);
            }

            stateChangeTime = stateChangeTime.AddHours(-makeCount);

            makeCount++;
            findLotStateChangeCount[key] = makeCount;

            return stateChangeTime;
        }

        private DateTime FindLotStartTime(List<string> opers, string soProductID, string indexOperID)
        {
            DateTime lotStartTime = engineStartTime;

            foreach (string opID in opers)
            {
                if (opID == indexOperID)
                    break;

                string key = soProductID + opID;

                float value;
                if (findStepCT.TryGetValue(key, out value))
                    lotStartTime = lotStartTime.AddMinutes(-value);
            }

            return lotStartTime;
        }
        #endregion

        #region SetVdat
        private void CreateData()
        {
            int totalLotCount = (int)Math.Round((double)this.totalWipTrackBarControl.Value / double.Parse(this.lotSizeTextEdit.Text), 0);

            if (totalLotCount <= 0)
                return;

            wipDt = GetWIPDataTable();
            wipParaDt = GetWIP_PARAMDataTable();

            int lotSize = (int)this.lotSizeTextEdit.EditValue;
            findLotStateChangeCount = new Dictionary<string, int>();

            string[] ptTbcNameSeparators = new string[] { "HTrackBarControl" };
            string[] areaTbcNameSeparators = new string[] { "areaHTrackBarControl" };

            int lotIDCount = 1;
            foreach (TrackBarControl productTbc in productRatioTBCList)
            {
                if (productTbc.Value <= 0)
                    continue;

                double tempValue = (productTbc.Value * (double)totalLotCount) / 10000d;
                int productCount = (int)Math.Round(tempValue, 0);

                if (productCount <= 0)
                    continue;

                string mfgProductID = productTbc.Name.Split(ptTbcNameSeparators, StringSplitOptions.None)[0];

                Product pt;
                if (findProdcut.TryGetValue(mfgProductID, out pt))
                {
                    Route ptRoute = pt.ROUTE;

                    foreach (TrackBarControl areaTbc in areaRatioTBCList)
                    {
                        if (areaTbc.Value <= 0)
                            continue;

                        tempValue = (areaTbc.Value * (double)productCount) / 10000d;
                        int areaCount = (int)Math.Round(tempValue, 0);

                        if (areaCount <= 0)
                            continue;

                        int reworkCount = (int)Math.Round(areaCount * (reworkRatioTrackBarControl.Value / 10000d), 0);
                        int hotCount = (int)Math.Round(areaCount * (hotRatioTrackBarControl.Value / 10000d), 0);

                        int hotRatioIndex = areaCount - hotCount - reworkCount;
                        int reWorkRatioIndex = areaCount - reworkCount;
                        string lotPriorityStatus = "NORMAL";

                        string areaID = areaTbc.Name.Split(areaTbcNameSeparators, StringSplitOptions.None)[0];
                        string operID = string.Empty;

                        for (int i = 0; i < areaCount; i++)
                        {
                            if (i == hotRatioIndex)
                                lotPriorityStatus = "HOT";

                            if (i == reWorkRatioIndex)
                                lotPriorityStatus = "REWORK";

                            List<string> steps;
                            if (ptRoute.AreaToOperSet.TryGetValue(areaID, out steps))
                            {
                                int random_number = rand.Next(steps.Count() - 1);
                                operID = steps[random_number];
                            }
                            else
                                operID = ptRoute.MainSteps.FirstOrDefault();

                            if (string.IsNullOrEmpty(operID))
                                operID = string.Empty;

                            DataRow wipRow = wipDt.NewRow();
                            string lotID = string.Concat("LOT_", lotIDCount.ToString().PadLeft(5, '0'));
                            wipRow["LINE_ID"] = lineID;
                            wipRow["LOT_ID"] = lotID;
                            lotIDCount++;
                            wipRow["SOP_PRODUCT_ID"] = pt.SOP_PRODUCT_ID;
                            wipRow["PRODUCT_ID"] = pt.OrgData.PRODUCT_ID;
                            if (lotPriorityStatus == "REWORK")
                            {
                                Route reWorkRoute = FindReworkRoute();
                                wipRow["ROUTE_ID"] = reWorkRoute.ROUTE_ID;
                                wipRow["OPER_ID"] = reWorkRoute.MainSteps.Count != 0 ? reWorkRoute.MainSteps.First() : string.Empty;
                                wipRow["LOT_START_TIME"] = FindLotStartTime(reWorkRoute.OperIDs, pt.SOP_PRODUCT_ID, operID);
                            }
                            else
                            {
                                wipRow["ROUTE_ID"] = ptRoute.ROUTE_ID;
                                wipRow["OPER_ID"] = operID;
                                wipRow["LOT_START_TIME"] = FindLotStartTime(pt.ROUTE.OperIDs, pt.SOP_PRODUCT_ID, operID);
                            }
                            wipRow["LOT_QTY"] = lotSize;
                            wipRow["LOT_PRIORITY_STATUS"] = lotPriorityStatus;
                            wipRow["LOT_STATE"] = "WAIT";
                            wipRow["LOT_STATE_CHANGE_DATETIME"] = FindLotStateChangeTime(pt, operID);
                            wipDt.Rows.Add(wipRow);

                            foreach (string para in paraCategories)
                            {
                                if (lotPriorityStatus != "REWORK" && para != "BAY NAME")
                                    continue;

                                DataRow wipParaRow = wipParaDt.NewRow();
                                wipParaRow["LOT_ID"] = lotID;
                                wipParaRow["PARAM_NAME"] = para;

                                string value = string.Empty;

                                if (para == "BAY NAME")
                                    value = FindEqpLocation();
                                else if (para == "MAIN ROUTE ID")
                                    value = pt.ROUTE_ID;
                                else if (para == "RETURN STEP ID")
                                    value = operID;

                                wipParaRow["PARAM_VALUE"] = value;

                                wipParaDt.Rows.Add(wipParaRow);
                            }
                        }
                    }
                }
            }
        }

        private void DeleteVdat()
        {
            using (var acc = this.modelDataContext.Target.LocalAccessorFor("WIP_PARAM"))
            {
                var dtable = acc.QueryTable(null, -1, -1);

                List<DataRow> removable = new List<DataRow>();

                foreach (DataRow row in dtable.Rows)
                    removable.Add(row);

                removable.ForEach(x => dtable.Rows.Remove(x));

                acc.Save(dtable);
            }

            using (var acc = this.modelDataContext.Target.LocalAccessorFor("WIP"))
            {
                var dtable = acc.QueryTable(null, -1, -1);

                List<DataRow> removable = new List<DataRow>();

                foreach (DataRow row in dtable.Rows)
                    removable.Add(row);

                removable.ForEach(x => dtable.Rows.Remove(x));

                acc.Save(dtable);
            }
        }

        private void InsertVdat()
        {
            using (var acc = this.modelDataContext.Target.LocalAccessorFor("WIP"))
            {
                var dtable = acc.QueryTable(null, -1, -1);

                foreach (DataRow row in wipDt.Rows)
                {
                    var nrow = dtable.NewRow();

                    nrow["LINE_ID"] = row.ItemArray[0];
                    nrow["LOT_ID"] = row.ItemArray[1];
                    nrow["LOT_START_TIME"] = row.ItemArray[2];
                    nrow["SOP_PRODUCT_ID"] = row.ItemArray[3];
                    nrow["PRODUCT_ID"] = row.ItemArray[4];
                    nrow["ROUTE_ID"] = row.ItemArray[5];
                    nrow["OPER_ID"] = row.ItemArray[6];
                    nrow["LOT_QTY"] = row.ItemArray[7];
                    nrow["LOT_PRIORITY_STATUS"] = row.ItemArray[8];
                    nrow["LOT_STATE"] = row.ItemArray[10];
                    nrow["LOT_STATE_CHANGE_DATETIME"] = row.ItemArray[12];

                    dtable.Rows.Add(nrow);
                }

                acc.Save(dtable);
            }

            using (var acc = this.modelDataContext.Target.LocalAccessorFor("WIP_PARAM"))
            {
                var dtable = acc.QueryTable(null, -1, -1);

                foreach (DataRow row in wipParaDt.Rows)
                {
                    var nrow = dtable.NewRow();

                    nrow["LOT_ID"] = row.ItemArray[0];
                    nrow["PARAM_NAME"] = row.ItemArray[1];
                    nrow["PARAM_VALUE"] = row.ItemArray[2];

                    dtable.Rows.Add(nrow);
                }

                acc.Save(dtable);
            }

            XtraMessageBox.Show("WIP & WIP_PARAM Data Generation completed.", "Inform", MessageBoxButtons.OK);
        }

        private void UpdateConfigVdat(string key, string value)
        {
            using (var acc = this.modelDataContext.Target.LocalAccessorFor("Config"))
            {
                var dtable = acc.QueryTable(null, -1, -1);

                bool exist = false;
                foreach (DataRow row in dtable.Rows)
                {
                    if (row["Group"].ToString() != "STD")
                        continue;

                    if (row["Key"].ToString() == key)
                    {
                        exist = true;
                        row["Value"] = value;

                        break;
                    }
                }

                if (exist == false)
                {
                    var nrow = dtable.NewRow();
                    nrow["Group"] = "STD";
                    nrow["Key"] = key;
                    nrow["Value"] = value;

                    dtable.Rows.Add(nrow);
                }

                dtable.AcceptChanges();
                acc.Save(dtable);
            }
        }

        #endregion
    }
}
