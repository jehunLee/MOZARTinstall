﻿using DevExpress.Office.Import.OpenXml;
using FabSimulator;
using Mozart.Task.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FabSimulatorUI.Config
{
    public delegate void FormSendDataHandler(int num = 1, int numNormal = 100, int numHot = 0, int tag = 1);

    public partial class WipCreationViewPopup_Capa : Form
    {
        public FormSendDataHandler FormSendEvent;
        public WipCreationViewPopup_Capa()
        {
            InitializeComponent();
        }

        private void btnOk_Click(object sender, EventArgs e)
        {
            if (radioDemand.Checked)
            {
                FormSendEvent(num: 1);
            }
            else if (radioFab.Checked)
            {
                FormSendEvent(num: 2);
            }
            this.Close();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
