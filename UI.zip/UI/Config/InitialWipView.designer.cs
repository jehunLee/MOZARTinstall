﻿
namespace FabSimulatorUI.Config
{
    partial class InitialWipView
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 구성 요소 디자이너에서 생성한 코드

        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            DevExpress.XtraSplashScreen.SplashScreenManager splashScreenManager1 = new DevExpress.XtraSplashScreen.SplashScreenManager(this, null, true, true, typeof(System.Windows.Forms.UserControl));
            this.panelControl1 = new DevExpress.XtraEditors.PanelControl();
            this.layoutControl1 = new DevExpress.XtraLayout.LayoutControl();
            this.reworkRatioTrackBarControl = new DevExpress.XtraEditors.TrackBarControl();
            this.totalWipTrackBarControl = new DevExpress.XtraEditors.TrackBarControl();
            this.hotRatioTrackBarControl = new DevExpress.XtraEditors.TrackBarControl();
            this.totalWipTextEdit = new DevExpress.XtraEditors.TextEdit();
            this.lotSizeTextEdit = new DevExpress.XtraEditors.TextEdit();
            this.InputSmoothingCheckEdit = new DevExpress.XtraEditors.CheckEdit();
            this.inputSmoothingTextEdit = new DevExpress.XtraEditors.TextEdit();
            this.targetTatTextEdit = new DevExpress.XtraEditors.TextEdit();
            this.wipLevelKeepingCheckEdit = new DevExpress.XtraEditors.CheckEdit();
            this.hotRatioTextEdit = new DevExpress.XtraEditors.TextEdit();
            this.reworkRatioTextEdit = new DevExpress.XtraEditors.TextEdit();
            this.Root = new DevExpress.XtraLayout.LayoutControlGroup();
            this.emptySpaceItem2 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.layoutControlItem4 = new DevExpress.XtraLayout.LayoutControlItem();
            this.simpleLabelItem1 = new DevExpress.XtraLayout.SimpleLabelItem();
            this.lotSizeLabel = new DevExpress.XtraLayout.SimpleLabelItem();
            this.layoutControlItem3 = new DevExpress.XtraLayout.LayoutControlItem();
            this.emptySpaceItem3 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.layoutControlItem5 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem6 = new DevExpress.XtraLayout.LayoutControlItem();
            this.emptySpaceItem4 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.targetTATLable = new DevExpress.XtraLayout.SimpleLabelItem();
            this.layoutControlItem7 = new DevExpress.XtraLayout.LayoutControlItem();
            this.emptySpaceItem5 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.layoutControlItem8 = new DevExpress.XtraLayout.LayoutControlItem();
            this.emptySpaceItem1 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.wipDetailsLabel = new DevExpress.XtraLayout.SimpleLabelItem();
            this.emptySpaceItem7 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.layoutControlItem9 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem10 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem11 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem2 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem12 = new DevExpress.XtraLayout.LayoutControlItem();
            this.emptySpaceItem6 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.hotRatioLabel = new DevExpress.XtraLayout.SimpleLabelItem();
            this.reworkRatioLabel = new DevExpress.XtraLayout.SimpleLabelItem();
            this.expandablePanel1 = new Mozart.Studio.UIComponents.ExpandablePanel();
            this.SaveButton = new System.Windows.Forms.Button();
            this.dockManager1 = new DevExpress.XtraBars.Docking.DockManager(this.components);
            this.dockPanel1 = new DevExpress.XtraBars.Docking.DockPanel();
            this.dockPanel1_Container = new DevExpress.XtraBars.Docking.ControlContainer();
            this.productRatioLayoutControl = new DevExpress.XtraLayout.LayoutControl();
            this.productRatioLayoutControlGroup = new DevExpress.XtraLayout.LayoutControlGroup();
            this.dockPanel2 = new DevExpress.XtraBars.Docking.DockPanel();
            this.dockPanel2_Container = new DevExpress.XtraBars.Docking.ControlContainer();
            this.areaRatioLayoutControl = new DevExpress.XtraDataLayout.DataLayoutControl();
            this.areaRatioLayoutControlGroup = new DevExpress.XtraLayout.LayoutControlGroup();
            this.panelContainer1 = new DevExpress.XtraBars.Docking.DockPanel();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl1)).BeginInit();
            this.panelControl1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControl1)).BeginInit();
            this.layoutControl1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.reworkRatioTrackBarControl)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.reworkRatioTrackBarControl.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.totalWipTrackBarControl)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.totalWipTrackBarControl.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.hotRatioTrackBarControl)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.hotRatioTrackBarControl.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.totalWipTextEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lotSizeTextEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.InputSmoothingCheckEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.inputSmoothingTextEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.targetTatTextEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.wipLevelKeepingCheckEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.hotRatioTextEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.reworkRatioTextEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Root)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.simpleLabelItem1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lotSizeLabel)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.targetTATLable)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.wipDetailsLabel)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.hotRatioLabel)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.reworkRatioLabel)).BeginInit();
            this.expandablePanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dockManager1)).BeginInit();
            this.dockPanel1.SuspendLayout();
            this.dockPanel1_Container.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.productRatioLayoutControl)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.productRatioLayoutControlGroup)).BeginInit();
            this.dockPanel2.SuspendLayout();
            this.dockPanel2_Container.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.areaRatioLayoutControl)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.areaRatioLayoutControlGroup)).BeginInit();
            this.panelContainer1.SuspendLayout();
            this.SuspendLayout();
            // 
            // splashScreenManager1
            // 
            splashScreenManager1.ClosingDelay = 500;
            // 
            // panelControl1
            // 
            this.panelControl1.Controls.Add(this.layoutControl1);
            this.panelControl1.Controls.Add(this.expandablePanel1);
            this.panelControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelControl1.Location = new System.Drawing.Point(0, 0);
            this.panelControl1.Name = "panelControl1";
            this.panelControl1.Size = new System.Drawing.Size(1035, 128);
            this.panelControl1.TabIndex = 0;
            // 
            // layoutControl1
            // 
            this.layoutControl1.Controls.Add(this.reworkRatioTrackBarControl);
            this.layoutControl1.Controls.Add(this.totalWipTrackBarControl);
            this.layoutControl1.Controls.Add(this.hotRatioTrackBarControl);
            this.layoutControl1.Controls.Add(this.totalWipTextEdit);
            this.layoutControl1.Controls.Add(this.lotSizeTextEdit);
            this.layoutControl1.Controls.Add(this.InputSmoothingCheckEdit);
            this.layoutControl1.Controls.Add(this.inputSmoothingTextEdit);
            this.layoutControl1.Controls.Add(this.targetTatTextEdit);
            this.layoutControl1.Controls.Add(this.wipLevelKeepingCheckEdit);
            this.layoutControl1.Controls.Add(this.hotRatioTextEdit);
            this.layoutControl1.Controls.Add(this.reworkRatioTextEdit);
            this.layoutControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.layoutControl1.Location = new System.Drawing.Point(2, 73);
            this.layoutControl1.Name = "layoutControl1";
            this.layoutControl1.Root = this.Root;
            this.layoutControl1.Size = new System.Drawing.Size(1031, 53);
            this.layoutControl1.TabIndex = 84;
            this.layoutControl1.Text = "layoutControl1";
            // 
            // reworkRatioTrackBarControl
            // 
            this.reworkRatioTrackBarControl.EditValue = null;
            this.reworkRatioTrackBarControl.Location = new System.Drawing.Point(98, 241);
            this.reworkRatioTrackBarControl.Name = "reworkRatioTrackBarControl";
            this.reworkRatioTrackBarControl.Properties.LabelAppearance.Options.UseTextOptions = true;
            this.reworkRatioTrackBarControl.Properties.LabelAppearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.reworkRatioTrackBarControl.Size = new System.Drawing.Size(211, 45);
            this.reworkRatioTrackBarControl.StyleController = this.layoutControl1;
            this.reworkRatioTrackBarControl.TabIndex = 93;
            // 
            // totalWipTrackBarControl
            // 
            this.totalWipTrackBarControl.EditValue = null;
            this.totalWipTrackBarControl.Location = new System.Drawing.Point(12, 30);
            this.totalWipTrackBarControl.Name = "totalWipTrackBarControl";
            this.totalWipTrackBarControl.Properties.LabelAppearance.Options.UseTextOptions = true;
            this.totalWipTrackBarControl.Properties.LabelAppearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.totalWipTrackBarControl.Size = new System.Drawing.Size(483, 45);
            this.totalWipTrackBarControl.StyleController = this.layoutControl1;
            this.totalWipTrackBarControl.TabIndex = 92;
            // 
            // hotRatioTrackBarControl
            // 
            this.hotRatioTrackBarControl.EditValue = null;
            this.hotRatioTrackBarControl.Location = new System.Drawing.Point(98, 192);
            this.hotRatioTrackBarControl.Name = "hotRatioTrackBarControl";
            this.hotRatioTrackBarControl.Properties.LabelAppearance.Options.UseTextOptions = true;
            this.hotRatioTrackBarControl.Properties.LabelAppearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.hotRatioTrackBarControl.Size = new System.Drawing.Size(211, 45);
            this.hotRatioTrackBarControl.StyleController = this.layoutControl1;
            this.hotRatioTrackBarControl.TabIndex = 90;
            // 
            // totalWipTextEdit
            // 
            this.totalWipTextEdit.Location = new System.Drawing.Point(499, 30);
            this.totalWipTextEdit.Name = "totalWipTextEdit";
            this.totalWipTextEdit.Size = new System.Drawing.Size(97, 20);
            this.totalWipTextEdit.StyleController = this.layoutControl1;
            this.totalWipTextEdit.TabIndex = 84;
            // 
            // lotSizeTextEdit
            // 
            this.lotSizeTextEdit.Location = new System.Drawing.Point(174, 79);
            this.lotSizeTextEdit.Name = "lotSizeTextEdit";
            this.lotSizeTextEdit.Size = new System.Drawing.Size(102, 20);
            this.lotSizeTextEdit.StyleController = this.layoutControl1;
            this.lotSizeTextEdit.TabIndex = 85;
            this.lotSizeTextEdit.EditValueChanged += new System.EventHandler(this.LotSizeTextEdit_EditValueChanged);
            // 
            // InputSmoothingCheckEdit
            // 
            this.InputSmoothingCheckEdit.EditValue = true;
            this.InputSmoothingCheckEdit.Location = new System.Drawing.Point(12, 127);
            this.InputSmoothingCheckEdit.Name = "InputSmoothingCheckEdit";
            this.InputSmoothingCheckEdit.Properties.Caption = "*Input Smoothing";
            this.InputSmoothingCheckEdit.Properties.GlyphAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.InputSmoothingCheckEdit.Size = new System.Drawing.Size(158, 19);
            this.InputSmoothingCheckEdit.StyleController = this.layoutControl1;
            this.InputSmoothingCheckEdit.TabIndex = 86;
            this.InputSmoothingCheckEdit.CheckStateChanged += new System.EventHandler(this.InputSmoothingCheckEdit_CheckStateChanged);
            // 
            // inputSmoothingTextEdit
            // 
            this.inputSmoothingTextEdit.Location = new System.Drawing.Point(174, 127);
            this.inputSmoothingTextEdit.Name = "inputSmoothingTextEdit";
            this.inputSmoothingTextEdit.Size = new System.Drawing.Size(102, 20);
            this.inputSmoothingTextEdit.StyleController = this.layoutControl1;
            this.inputSmoothingTextEdit.TabIndex = 87;
            // 
            // targetTatTextEdit
            // 
            this.targetTatTextEdit.Location = new System.Drawing.Point(174, 103);
            this.targetTatTextEdit.Name = "targetTatTextEdit";
            this.targetTatTextEdit.Size = new System.Drawing.Size(102, 20);
            this.targetTatTextEdit.StyleController = this.layoutControl1;
            this.targetTatTextEdit.TabIndex = 88;
            // 
            // wipLevelKeepingCheckEdit
            // 
            this.wipLevelKeepingCheckEdit.EditValue = true;
            this.wipLevelKeepingCheckEdit.Location = new System.Drawing.Point(12, 151);
            this.wipLevelKeepingCheckEdit.Name = "wipLevelKeepingCheckEdit";
            this.wipLevelKeepingCheckEdit.Properties.Caption = "*Wip Level Keeping";
            this.wipLevelKeepingCheckEdit.Properties.GlyphAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.wipLevelKeepingCheckEdit.Size = new System.Drawing.Size(158, 19);
            this.wipLevelKeepingCheckEdit.StyleController = this.layoutControl1;
            this.wipLevelKeepingCheckEdit.TabIndex = 89;
            this.wipLevelKeepingCheckEdit.CheckStateChanged += new System.EventHandler(this.WipLevelKeepingCheckEdit_CheckStateChanged);
            // 
            // hotRatioTextEdit
            // 
            this.hotRatioTextEdit.Location = new System.Drawing.Point(313, 192);
            this.hotRatioTextEdit.Name = "hotRatioTextEdit";
            this.hotRatioTextEdit.Size = new System.Drawing.Size(107, 20);
            this.hotRatioTextEdit.StyleController = this.layoutControl1;
            this.hotRatioTextEdit.TabIndex = 91;
            // 
            // reworkRatioTextEdit
            // 
            this.reworkRatioTextEdit.Location = new System.Drawing.Point(313, 241);
            this.reworkRatioTextEdit.Name = "reworkRatioTextEdit";
            this.reworkRatioTextEdit.Size = new System.Drawing.Size(107, 20);
            this.reworkRatioTextEdit.StyleController = this.layoutControl1;
            this.reworkRatioTextEdit.TabIndex = 94;
            // 
            // Root
            // 
            this.Root.EnableIndentsWithoutBorders = DevExpress.Utils.DefaultBoolean.True;
            this.Root.GroupBordersVisible = false;
            this.Root.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.emptySpaceItem2,
            this.layoutControlItem4,
            this.simpleLabelItem1,
            this.lotSizeLabel,
            this.layoutControlItem3,
            this.emptySpaceItem3,
            this.layoutControlItem5,
            this.layoutControlItem6,
            this.emptySpaceItem4,
            this.targetTATLable,
            this.layoutControlItem7,
            this.emptySpaceItem5,
            this.layoutControlItem8,
            this.emptySpaceItem1,
            this.wipDetailsLabel,
            this.emptySpaceItem7,
            this.layoutControlItem9,
            this.layoutControlItem10,
            this.layoutControlItem11,
            this.layoutControlItem2,
            this.layoutControlItem12,
            this.emptySpaceItem6,
            this.hotRatioLabel,
            this.reworkRatioLabel});
            this.Root.Name = "Root";
            this.Root.Size = new System.Drawing.Size(1014, 298);
            this.Root.TextVisible = false;
            // 
            // emptySpaceItem2
            // 
            this.emptySpaceItem2.AllowHotTrack = false;
            this.emptySpaceItem2.Location = new System.Drawing.Point(663, 18);
            this.emptySpaceItem2.Name = "emptySpaceItem2";
            this.emptySpaceItem2.Size = new System.Drawing.Size(331, 144);
            this.emptySpaceItem2.TextSize = new System.Drawing.Size(0, 0);
            // 
            // layoutControlItem4
            // 
            this.layoutControlItem4.Control = this.totalWipTextEdit;
            this.layoutControlItem4.Location = new System.Drawing.Point(487, 18);
            this.layoutControlItem4.Name = "layoutControlItem4";
            this.layoutControlItem4.Size = new System.Drawing.Size(176, 144);
            this.layoutControlItem4.Text = "Wafers";
            this.layoutControlItem4.TextLocation = DevExpress.Utils.Locations.Right;
            this.layoutControlItem4.TextSize = new System.Drawing.Size(72, 14);
            // 
            // simpleLabelItem1
            // 
            this.simpleLabelItem1.AllowHotTrack = false;
            this.simpleLabelItem1.Location = new System.Drawing.Point(0, 0);
            this.simpleLabelItem1.Name = "simpleLabelItem1";
            this.simpleLabelItem1.Size = new System.Drawing.Size(994, 18);
            this.simpleLabelItem1.Text = "*Total WIP";
            this.simpleLabelItem1.TextSize = new System.Drawing.Size(72, 14);
            // 
            // lotSizeLabel
            // 
            this.lotSizeLabel.AllowHotTrack = false;
            this.lotSizeLabel.Location = new System.Drawing.Point(0, 67);
            this.lotSizeLabel.Name = "lotSizeLabel";
            this.lotSizeLabel.Size = new System.Drawing.Size(162, 24);
            this.lotSizeLabel.Text = "*Lot Size";
            this.lotSizeLabel.TextSize = new System.Drawing.Size(72, 14);
            // 
            // layoutControlItem3
            // 
            this.layoutControlItem3.Control = this.lotSizeTextEdit;
            this.layoutControlItem3.Location = new System.Drawing.Point(162, 67);
            this.layoutControlItem3.Name = "layoutControlItem3";
            this.layoutControlItem3.Size = new System.Drawing.Size(181, 24);
            this.layoutControlItem3.Text = "Wafers";
            this.layoutControlItem3.TextLocation = DevExpress.Utils.Locations.Right;
            this.layoutControlItem3.TextSize = new System.Drawing.Size(72, 14);
            // 
            // emptySpaceItem3
            // 
            this.emptySpaceItem3.AllowHotTrack = false;
            this.emptySpaceItem3.Location = new System.Drawing.Point(343, 67);
            this.emptySpaceItem3.Name = "emptySpaceItem3";
            this.emptySpaceItem3.Size = new System.Drawing.Size(144, 24);
            this.emptySpaceItem3.TextSize = new System.Drawing.Size(0, 0);
            // 
            // layoutControlItem5
            // 
            this.layoutControlItem5.Control = this.InputSmoothingCheckEdit;
            this.layoutControlItem5.Location = new System.Drawing.Point(0, 115);
            this.layoutControlItem5.Name = "layoutControlItem5";
            this.layoutControlItem5.Size = new System.Drawing.Size(162, 24);
            this.layoutControlItem5.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem5.TextVisible = false;
            // 
            // layoutControlItem6
            // 
            this.layoutControlItem6.Control = this.inputSmoothingTextEdit;
            this.layoutControlItem6.Location = new System.Drawing.Point(162, 115);
            this.layoutControlItem6.Name = "layoutControlItem6";
            this.layoutControlItem6.Size = new System.Drawing.Size(181, 24);
            this.layoutControlItem6.Text = "Wfr/Day";
            this.layoutControlItem6.TextLocation = DevExpress.Utils.Locations.Right;
            this.layoutControlItem6.TextSize = new System.Drawing.Size(72, 14);
            // 
            // emptySpaceItem4
            // 
            this.emptySpaceItem4.AllowHotTrack = false;
            this.emptySpaceItem4.Location = new System.Drawing.Point(343, 115);
            this.emptySpaceItem4.Name = "emptySpaceItem4";
            this.emptySpaceItem4.Size = new System.Drawing.Size(144, 24);
            this.emptySpaceItem4.TextSize = new System.Drawing.Size(0, 0);
            // 
            // targetTATLable
            // 
            this.targetTATLable.AllowHotTrack = false;
            this.targetTATLable.Location = new System.Drawing.Point(0, 91);
            this.targetTATLable.Name = "targetTATLable";
            this.targetTATLable.Size = new System.Drawing.Size(162, 24);
            this.targetTATLable.Text = "*Target TAT";
            this.targetTATLable.TextSize = new System.Drawing.Size(72, 14);
            // 
            // layoutControlItem7
            // 
            this.layoutControlItem7.Control = this.targetTatTextEdit;
            this.layoutControlItem7.Location = new System.Drawing.Point(162, 91);
            this.layoutControlItem7.Name = "layoutControlItem7";
            this.layoutControlItem7.Size = new System.Drawing.Size(181, 24);
            this.layoutControlItem7.Text = "Days";
            this.layoutControlItem7.TextLocation = DevExpress.Utils.Locations.Right;
            this.layoutControlItem7.TextSize = new System.Drawing.Size(72, 14);
            // 
            // emptySpaceItem5
            // 
            this.emptySpaceItem5.AllowHotTrack = false;
            this.emptySpaceItem5.Location = new System.Drawing.Point(343, 91);
            this.emptySpaceItem5.Name = "emptySpaceItem5";
            this.emptySpaceItem5.Size = new System.Drawing.Size(144, 24);
            this.emptySpaceItem5.TextSize = new System.Drawing.Size(0, 0);
            // 
            // layoutControlItem8
            // 
            this.layoutControlItem8.Control = this.wipLevelKeepingCheckEdit;
            this.layoutControlItem8.Location = new System.Drawing.Point(0, 139);
            this.layoutControlItem8.Name = "layoutControlItem8";
            this.layoutControlItem8.Size = new System.Drawing.Size(162, 23);
            this.layoutControlItem8.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem8.TextVisible = false;
            // 
            // emptySpaceItem1
            // 
            this.emptySpaceItem1.AllowHotTrack = false;
            this.emptySpaceItem1.Location = new System.Drawing.Point(162, 139);
            this.emptySpaceItem1.Name = "emptySpaceItem1";
            this.emptySpaceItem1.Size = new System.Drawing.Size(325, 23);
            this.emptySpaceItem1.TextSize = new System.Drawing.Size(0, 0);
            // 
            // wipDetailsLabel
            // 
            this.wipDetailsLabel.AllowHotTrack = false;
            this.wipDetailsLabel.Location = new System.Drawing.Point(0, 162);
            this.wipDetailsLabel.Name = "wipDetailsLabel";
            this.wipDetailsLabel.Size = new System.Drawing.Size(994, 18);
            this.wipDetailsLabel.Text = "*WIP Details";
            this.wipDetailsLabel.TextSize = new System.Drawing.Size(72, 14);
            // 
            // emptySpaceItem7
            // 
            this.emptySpaceItem7.AllowHotTrack = false;
            this.emptySpaceItem7.Location = new System.Drawing.Point(487, 180);
            this.emptySpaceItem7.MaxSize = new System.Drawing.Size(507, 49);
            this.emptySpaceItem7.MinSize = new System.Drawing.Size(507, 49);
            this.emptySpaceItem7.Name = "emptySpaceItem7";
            this.emptySpaceItem7.Size = new System.Drawing.Size(507, 49);
            this.emptySpaceItem7.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.emptySpaceItem7.TextSize = new System.Drawing.Size(0, 0);
            // 
            // layoutControlItem9
            // 
            this.layoutControlItem9.AppearanceItemCaption.Options.UseTextOptions = true;
            this.layoutControlItem9.AppearanceItemCaption.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.layoutControlItem9.AppearanceItemCaption.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Top;
            this.layoutControlItem9.Control = this.hotRatioTrackBarControl;
            this.layoutControlItem9.Location = new System.Drawing.Point(86, 180);
            this.layoutControlItem9.MaxSize = new System.Drawing.Size(0, 49);
            this.layoutControlItem9.MinSize = new System.Drawing.Size(49, 49);
            this.layoutControlItem9.Name = "layoutControlItem9";
            this.layoutControlItem9.Size = new System.Drawing.Size(215, 49);
            this.layoutControlItem9.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.layoutControlItem9.Text = "Hot Ratio";
            this.layoutControlItem9.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem9.TextVisible = false;
            // 
            // layoutControlItem10
            // 
            this.layoutControlItem10.Control = this.hotRatioTextEdit;
            this.layoutControlItem10.Location = new System.Drawing.Point(301, 180);
            this.layoutControlItem10.Name = "layoutControlItem10";
            this.layoutControlItem10.Size = new System.Drawing.Size(186, 49);
            this.layoutControlItem10.Text = "%";
            this.layoutControlItem10.TextLocation = DevExpress.Utils.Locations.Right;
            this.layoutControlItem10.TextSize = new System.Drawing.Size(72, 14);
            // 
            // layoutControlItem11
            // 
            this.layoutControlItem11.Control = this.totalWipTrackBarControl;
            this.layoutControlItem11.Location = new System.Drawing.Point(0, 18);
            this.layoutControlItem11.Name = "layoutControlItem11";
            this.layoutControlItem11.Size = new System.Drawing.Size(487, 49);
            this.layoutControlItem11.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem11.TextVisible = false;
            // 
            // layoutControlItem2
            // 
            this.layoutControlItem2.AppearanceItemCaption.Options.UseTextOptions = true;
            this.layoutControlItem2.AppearanceItemCaption.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.layoutControlItem2.AppearanceItemCaption.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Top;
            this.layoutControlItem2.Control = this.reworkRatioTrackBarControl;
            this.layoutControlItem2.Location = new System.Drawing.Point(86, 229);
            this.layoutControlItem2.Name = "layoutControlItem2";
            this.layoutControlItem2.Size = new System.Drawing.Size(215, 49);
            this.layoutControlItem2.Text = "Rework Ratio";
            this.layoutControlItem2.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem2.TextVisible = false;
            // 
            // layoutControlItem12
            // 
            this.layoutControlItem12.Control = this.reworkRatioTextEdit;
            this.layoutControlItem12.Location = new System.Drawing.Point(301, 229);
            this.layoutControlItem12.Name = "layoutControlItem12";
            this.layoutControlItem12.Size = new System.Drawing.Size(186, 49);
            this.layoutControlItem12.Text = "%";
            this.layoutControlItem12.TextLocation = DevExpress.Utils.Locations.Right;
            this.layoutControlItem12.TextSize = new System.Drawing.Size(72, 14);
            // 
            // emptySpaceItem6
            // 
            this.emptySpaceItem6.AllowHotTrack = false;
            this.emptySpaceItem6.Location = new System.Drawing.Point(487, 229);
            this.emptySpaceItem6.MaxSize = new System.Drawing.Size(507, 49);
            this.emptySpaceItem6.MinSize = new System.Drawing.Size(507, 49);
            this.emptySpaceItem6.Name = "emptySpaceItem6";
            this.emptySpaceItem6.Size = new System.Drawing.Size(507, 49);
            this.emptySpaceItem6.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.emptySpaceItem6.TextSize = new System.Drawing.Size(0, 0);
            // 
            // hotRatioLabel
            // 
            this.hotRatioLabel.AllowHotTrack = false;
            this.hotRatioLabel.AppearanceItemCaption.Options.UseTextOptions = true;
            this.hotRatioLabel.AppearanceItemCaption.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.hotRatioLabel.AppearanceItemCaption.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Top;
            this.hotRatioLabel.Location = new System.Drawing.Point(0, 180);
            this.hotRatioLabel.MaxSize = new System.Drawing.Size(86, 49);
            this.hotRatioLabel.MinSize = new System.Drawing.Size(86, 49);
            this.hotRatioLabel.Name = "hotRatioLabel";
            this.hotRatioLabel.Size = new System.Drawing.Size(86, 49);
            this.hotRatioLabel.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.hotRatioLabel.Text = "Hot Ratio";
            this.hotRatioLabel.TextSize = new System.Drawing.Size(72, 14);
            // 
            // reworkRatioLabel
            // 
            this.reworkRatioLabel.AllowHotTrack = false;
            this.reworkRatioLabel.AppearanceItemCaption.Options.UseTextOptions = true;
            this.reworkRatioLabel.AppearanceItemCaption.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.reworkRatioLabel.AppearanceItemCaption.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Top;
            this.reworkRatioLabel.Location = new System.Drawing.Point(0, 229);
            this.reworkRatioLabel.MaxSize = new System.Drawing.Size(86, 49);
            this.reworkRatioLabel.MinSize = new System.Drawing.Size(86, 49);
            this.reworkRatioLabel.Name = "reworkRatioLabel";
            this.reworkRatioLabel.Size = new System.Drawing.Size(86, 49);
            this.reworkRatioLabel.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.reworkRatioLabel.Text = "Rework Ratio";
            this.reworkRatioLabel.TextSize = new System.Drawing.Size(72, 14);
            // 
            // expandablePanel1
            // 
            this.expandablePanel1.Controls.Add(this.SaveButton);
            this.expandablePanel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.expandablePanel1.ForeColor = System.Drawing.Color.SteelBlue;
            this.expandablePanel1.Location = new System.Drawing.Point(2, 2);
            this.expandablePanel1.Name = "expandablePanel1";
            this.expandablePanel1.Size = new System.Drawing.Size(1031, 71);
            this.expandablePanel1.TabIndex = 0;
            this.expandablePanel1.Text = "Initial WIP";
            this.expandablePanel1.UseAnimation = true;
            // 
            // SaveButton
            // 
            this.SaveButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.SaveButton.Location = new System.Drawing.Point(939, 34);
            this.SaveButton.Name = "SaveButton";
            this.SaveButton.Size = new System.Drawing.Size(75, 27);
            this.SaveButton.TabIndex = 3;
            this.SaveButton.Text = "Save";
            this.SaveButton.UseVisualStyleBackColor = true;
            this.SaveButton.Click += new System.EventHandler(this.SaveButton_Click);
            // 
            // dockManager1
            // 
            this.dockManager1.Form = this;
            this.dockManager1.RootPanels.AddRange(new DevExpress.XtraBars.Docking.DockPanel[] {
            this.panelContainer1});
            this.dockManager1.TopZIndexControls.AddRange(new string[] {
            "DevExpress.XtraBars.BarDockControl",
            "DevExpress.XtraBars.StandaloneBarDockControl",
            "System.Windows.Forms.StatusBar",
            "System.Windows.Forms.MenuStrip",
            "System.Windows.Forms.StatusStrip",
            "DevExpress.XtraBars.Ribbon.RibbonStatusBar",
            "DevExpress.XtraBars.Ribbon.RibbonControl",
            "DevExpress.XtraBars.Navigation.OfficeNavigationBar",
            "DevExpress.XtraBars.Navigation.TileNavPane"});
            // 
            // dockPanel1
            // 
            this.dockPanel1.Controls.Add(this.dockPanel1_Container);
            this.dockPanel1.Dock = DevExpress.XtraBars.Docking.DockingStyle.Fill;
            this.dockPanel1.FloatVertical = true;
            this.dockPanel1.ID = new System.Guid("1b1a5619-0c30-45dd-a7cc-1caf331240d2");
            this.dockPanel1.Location = new System.Drawing.Point(0, 0);
            this.dockPanel1.Name = "dockPanel1";
            this.dockPanel1.OriginalSize = new System.Drawing.Size(200, 200);
            this.dockPanel1.Size = new System.Drawing.Size(497, 274);
            this.dockPanel1.Text = "Product Ratio";
            // 
            // dockPanel1_Container
            // 
            this.dockPanel1_Container.Controls.Add(this.productRatioLayoutControl);
            this.dockPanel1_Container.Location = new System.Drawing.Point(4, 24);
            this.dockPanel1_Container.Name = "dockPanel1_Container";
            this.dockPanel1_Container.Size = new System.Drawing.Size(488, 246);
            this.dockPanel1_Container.TabIndex = 0;
            // 
            // productRatioLayoutControl
            // 
            this.productRatioLayoutControl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.productRatioLayoutControl.Location = new System.Drawing.Point(0, 0);
            this.productRatioLayoutControl.Name = "productRatioLayoutControl";
            this.productRatioLayoutControl.Root = this.productRatioLayoutControlGroup;
            this.productRatioLayoutControl.Size = new System.Drawing.Size(488, 246);
            this.productRatioLayoutControl.TabIndex = 0;
            this.productRatioLayoutControl.Text = "layoutControl2";
            // 
            // productRatioLayoutControlGroup
            // 
            this.productRatioLayoutControlGroup.EnableIndentsWithoutBorders = DevExpress.Utils.DefaultBoolean.True;
            this.productRatioLayoutControlGroup.GroupBordersVisible = false;
            this.productRatioLayoutControlGroup.Name = "productRatioLayoutControlGroup";
            this.productRatioLayoutControlGroup.Size = new System.Drawing.Size(488, 246);
            this.productRatioLayoutControlGroup.TextVisible = false;
            // 
            // dockPanel2
            // 
            this.dockPanel2.Controls.Add(this.dockPanel2_Container);
            this.dockPanel2.Dock = DevExpress.XtraBars.Docking.DockingStyle.Fill;
            this.dockPanel2.FloatVertical = true;
            this.dockPanel2.ID = new System.Guid("f3e54cf9-dcb8-4028-9f76-664d8d0a3794");
            this.dockPanel2.Location = new System.Drawing.Point(497, 0);
            this.dockPanel2.Name = "dockPanel2";
            this.dockPanel2.OriginalSize = new System.Drawing.Size(497, 274);
            this.dockPanel2.Size = new System.Drawing.Size(538, 274);
            this.dockPanel2.Text = "Area Ratio";
            // 
            // dockPanel2_Container
            // 
            this.dockPanel2_Container.Controls.Add(this.areaRatioLayoutControl);
            this.dockPanel2_Container.Location = new System.Drawing.Point(4, 24);
            this.dockPanel2_Container.Name = "dockPanel2_Container";
            this.dockPanel2_Container.Size = new System.Drawing.Size(530, 246);
            this.dockPanel2_Container.TabIndex = 0;
            // 
            // areaRatioLayoutControl
            // 
            this.areaRatioLayoutControl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.areaRatioLayoutControl.Location = new System.Drawing.Point(0, 0);
            this.areaRatioLayoutControl.Name = "areaRatioLayoutControl";
            this.areaRatioLayoutControl.Root = this.areaRatioLayoutControlGroup;
            this.areaRatioLayoutControl.Size = new System.Drawing.Size(530, 246);
            this.areaRatioLayoutControl.TabIndex = 0;
            this.areaRatioLayoutControl.Text = "dataLayoutControl1";
            // 
            // areaRatioLayoutControlGroup
            // 
            this.areaRatioLayoutControlGroup.EnableIndentsWithoutBorders = DevExpress.Utils.DefaultBoolean.True;
            this.areaRatioLayoutControlGroup.GroupBordersVisible = false;
            this.areaRatioLayoutControlGroup.Name = "areaRatioLayoutControlGroup";
            this.areaRatioLayoutControlGroup.Size = new System.Drawing.Size(530, 246);
            this.areaRatioLayoutControlGroup.TextVisible = false;
            // 
            // panelContainer1
            // 
            this.panelContainer1.Controls.Add(this.dockPanel1);
            this.panelContainer1.Controls.Add(this.dockPanel2);
            this.panelContainer1.Dock = DevExpress.XtraBars.Docking.DockingStyle.Bottom;
            this.panelContainer1.FloatVertical = true;
            this.panelContainer1.ID = new System.Guid("17454922-19c7-47c1-9c05-e4671161a740");
            this.panelContainer1.Location = new System.Drawing.Point(0, 128);
            this.panelContainer1.Name = "panelContainer1";
            this.panelContainer1.OriginalSize = new System.Drawing.Size(497, 274);
            this.panelContainer1.Size = new System.Drawing.Size(1035, 274);
            this.panelContainer1.Text = "panelContainer1";
            // 
            // InitialWipView
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 14F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.panelControl1);
            this.Controls.Add(this.panelContainer1);
            this.Name = "InitialWipView";
            this.Size = new System.Drawing.Size(1035, 402);
            ((System.ComponentModel.ISupportInitialize)(this.panelControl1)).EndInit();
            this.panelControl1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.layoutControl1)).EndInit();
            this.layoutControl1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.reworkRatioTrackBarControl.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.reworkRatioTrackBarControl)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.totalWipTrackBarControl.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.totalWipTrackBarControl)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.hotRatioTrackBarControl.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.hotRatioTrackBarControl)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.totalWipTextEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lotSizeTextEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.InputSmoothingCheckEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.inputSmoothingTextEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.targetTatTextEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.wipLevelKeepingCheckEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.hotRatioTextEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.reworkRatioTextEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Root)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.simpleLabelItem1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lotSizeLabel)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.targetTATLable)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.wipDetailsLabel)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.hotRatioLabel)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.reworkRatioLabel)).EndInit();
            this.expandablePanel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dockManager1)).EndInit();
            this.dockPanel1.ResumeLayout(false);
            this.dockPanel1_Container.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.productRatioLayoutControl)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.productRatioLayoutControlGroup)).EndInit();
            this.dockPanel2.ResumeLayout(false);
            this.dockPanel2_Container.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.areaRatioLayoutControl)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.areaRatioLayoutControlGroup)).EndInit();
            this.panelContainer1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        /// <summary>   The first panel control. </summary>
        private DevExpress.XtraEditors.PanelControl panelControl1;
        /// <summary>   The first expandable panel. </summary>
        private Mozart.Studio.UIComponents.ExpandablePanel expandablePanel1;
        /// <summary>   The button query control. </summary>
        private System.Windows.Forms.Button SaveButton;
        /// <summary>   The first dock manager. </summary>
        private DevExpress.XtraBars.Docking.DockManager dockManager1;
        private DevExpress.XtraLayout.LayoutControl layoutControl1;
        private DevExpress.XtraLayout.LayoutControlGroup Root;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem2;
        private DevExpress.XtraLayout.SimpleLabelItem simpleLabelItem1;
        private DevExpress.XtraEditors.TextEdit totalWipTextEdit;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem4;
        private DevExpress.XtraEditors.TextEdit lotSizeTextEdit;
        private DevExpress.XtraLayout.SimpleLabelItem lotSizeLabel;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem3;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem3;
        private DevExpress.XtraEditors.CheckEdit InputSmoothingCheckEdit;
        private DevExpress.XtraEditors.TextEdit inputSmoothingTextEdit;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem5;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem6;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem4;
        private DevExpress.XtraEditors.TextEdit targetTatTextEdit;
        private DevExpress.XtraLayout.SimpleLabelItem targetTATLable;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem7;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem5;
        private DevExpress.XtraEditors.CheckEdit wipLevelKeepingCheckEdit;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem8;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem1;
        private DevExpress.XtraLayout.SimpleLabelItem wipDetailsLabel;
        private DevExpress.XtraEditors.TrackBarControl hotRatioTrackBarControl;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem7;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem9;
        private DevExpress.XtraEditors.TextEdit hotRatioTextEdit;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem10;
        private DevExpress.XtraEditors.TrackBarControl totalWipTrackBarControl;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem11;
        private DevExpress.XtraEditors.TrackBarControl reworkRatioTrackBarControl;
        private DevExpress.XtraEditors.TextEdit reworkRatioTextEdit;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem2;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem12;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem6;
        private DevExpress.XtraLayout.SimpleLabelItem hotRatioLabel;
        private DevExpress.XtraLayout.SimpleLabelItem reworkRatioLabel;
        private DevExpress.XtraBars.Docking.DockPanel dockPanel1;
        private DevExpress.XtraBars.Docking.ControlContainer dockPanel1_Container;
        private DevExpress.XtraLayout.LayoutControl productRatioLayoutControl;
        private DevExpress.XtraLayout.LayoutControlGroup productRatioLayoutControlGroup;
        private DevExpress.XtraBars.Docking.DockPanel dockPanel2;
        private DevExpress.XtraBars.Docking.ControlContainer dockPanel2_Container;
        private DevExpress.XtraDataLayout.DataLayoutControl areaRatioLayoutControl;
        private DevExpress.XtraLayout.LayoutControlGroup areaRatioLayoutControlGroup;
        private DevExpress.XtraBars.Docking.DockPanel panelContainer1;
    }
}
