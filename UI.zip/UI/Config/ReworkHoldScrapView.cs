﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Mozart.Studio.TaskModel.UserInterface;
using Mozart.Studio.TaskModel.Projects;
using Mozart.Studio.Application;
using Mozart.Collections;
using DevExpress.XtraPivotGrid;
using DevExpress.XtraCharts;

using Mozart.Studio.UIComponents;
using Mozart.Studio.TaskModel.Utility;

using Mozart.Studio.TaskModel.UserLibrary; //linq2
using DevExpress.XtraEditors.Controls;// linq1

using FabSimulator;
using DevExpress.XtraEditors;
using DevExpress.XtraGrid.Views.Grid;
using DevExpress.XtraEditors.Repository;
using DevExpress.XtraSplashScreen;
using FabSimulatorUI.Common;

namespace FabSimulatorUI.Config
{
    public partial class ReworkHoldScrapView : XtraPivotGridControlView
    {
        #region Variable&Property

        IExperimentResultItem result;
        ModelDataContext modelDataContext;
        ExpDataContext expDataContext;
        bool initializing;
        bool loading;
        bool comparing;

        string layoutPath;

        List<EqpInfo> photoEqps;

        string photoArea;

        HashSet<string> selectedGen = new HashSet<string>(); //+ 체크박스 추가

        List<string> validRoutes = new List<string>();

        int currentRadioIndex;
        string currentMainRoute;

        #endregion

        #region Ctor

        public ReworkHoldScrapView(IServiceProvider serviceProvider)
            : base(serviceProvider)
        {
            InitializeComponent();

            this.initializing = true;
            this.ConstructInit();
        }

        protected override void LoadDocument()
        {
            this.LoadInit();
            this.initializing = false;

            this.loading = true;
            this.Query();
            this.loading = false;
        }

        private void Query()
        {
            using (var wc = new Mozart.Studio.UIComponents.WaitCursor())
            {
                this.BindBegin();
                this.BindDo();
                this.BindEnd();
            }
        }

        #endregion

        #region Init

        private void ConstructInit()
        {
        }

        private void LoadInit()
        {
            this.result = this.Document.GetResultItem();

            this.modelDataContext = this.Document.GetCtx<ModelDataContext>();
            Globals.InitFactoryTimeNew(this.modelDataContext);

            this.photoArea = FabSimulatorUI.Helper.GetPhotoArea(this.modelDataContext);
        }
        #endregion 

        private void BindBegin()
        {
            this.gridControl1.BeginUpdate();
        }

        private void BindDo()
        {
            using (var wc = new Mozart.Studio.UIComponents.WaitCursor())
            {
                this.photoEqps = GetPhotoEqps();

                SetModelComoboBox();
                SetNxtCheckedListBox();

                FillGrid();

                this.comboBoxEdit1.SelectedIndex = 0;
                this.currentRadioIndex = 0;
            }
        }

        private void FillGrid(bool needColumnPopulate = false)
        {
            this.gridControl1.DataSource = null;
            this.gridControl1.DataSource = GetDataTable();
            if (needColumnPopulate)
            {
                this.gridView1.Columns.Clear();
                this.gridView1.PopulateColumns();
            }

            SetRepositoryItem();

            SetReworkRoute();
        }

        private void SetRepositoryItem()
        {
            RepositoryItemComboBox repositoryItemCombo = new RepositoryItemComboBox();
            this.gridControl1.RepositoryItems.Add(repositoryItemCombo);
            this.gridView1.Columns[2].ColumnEdit = repositoryItemCombo;
        }

        private DataTable GetDataTable()
        {
            DataTable dt = new DataTable();
            dt.Columns.Add("INDEX");
            dt.Columns.Add("PHOTO_OPERATION");
            dt.Columns.Add("REWORK_ROUTE");
            dt.Columns.Add("REWORK_RATIO");
            dt.Columns.Add("HOLD_RATIO");
            dt.Columns.Add("HOLD_TIME");
            dt.Columns.Add("SCRAP_RATIO");

            dt.Columns[0].DataType = typeof(int);

            for (int i = 3; i < dt.Columns.Count; i++)
                dt.Columns[i].DataType = typeof(double);

            return dt;
        }

        private List<EqpInfo> GetPhotoEqps()
        {
            var eqp = this.modelDataContext.EQP;
            var eqpParam = this.modelDataContext.EQP_PARAM;

            var photoEqps = from a in eqp.Where(x => x.AREA_ID == this.photoArea).OrderBy(x => x.EQP_ID)
                            //join b in eqpParam.Where(x=> x.PARAM_NAME == "IS_NXT") on a.RESOURCE_ID equals b.RESOURCE_ID into outer
                            join b in eqpParam.Where(x => x.PARAM_NAME == "SCANNER_GENERATION") on a.EQP_ID equals b.EQP_ID into outer
                            from o in outer.DefaultIfEmpty()
                            select new EqpInfo
                            {
                                RESOURCE_ID = a.EQP_ID,
                                //IS_NXT = o != null ? o.PARAM_VALUE == "Y" : false,
                                SCANNER_GENERATION = o != null ? o.PARAM_VALUE : "XT"
                            };

            return photoEqps.ToList();
        }

        private void SetModelComoboBox()
        {
            foreach (var row in this.modelDataContext.PRODUCT.Select(x => x.PART_ID).Distinct())
            {
                ComboBoxItem item = new ComboBoxItem(row);

                this.comboBoxEdit1.Properties.Items.Add(item);
            }
        }

        private void SetNxtCheckedListBox()
        {
            foreach (var res in this.photoEqps)
            {
                CheckedListBoxItem item1 = new CheckedListBoxItem(res.RESOURCE_ID);
                CheckedListBoxItem item2 = new CheckedListBoxItem(res.RESOURCE_ID);

                if (res.SCANNER_GENERATION == "NXT")
                    item1.CheckState = CheckState.Checked; //PHOTO_TYPE
                else if (res.SCANNER_GENERATION == "NXE")
                    item2.CheckState = CheckState.Checked;

                this.checkedComboBoxEdit1.Properties.Items.Add(item1);
                this.checkedComboBoxEdit2.Properties.Items.Add(item2);

                res.NXTCheckedListBoxItem = item1;
                res.NXECheckedListBoxItem = item2;
            }
        }

        private void BindEnd()
        {
            this.gridControl1.EndUpdate();

            this.gridView1.BestFitColumns();
            this.gridView1.OptionsView.ColumnAutoWidth = false;

            this.gridView1.OptionsSelection.EnableAppearanceFocusedRow = false;

            SetCaption();

            SetHeaderOption();

            SetColumnOption(0);
        }

        private void SetCaption()
        {
            this.gridView1.Columns[0].Caption = "Index";
            this.gridView1.Columns[1].Caption = "Photo Operation";
            this.gridView1.Columns[2].Caption = "Rework Route";
            this.gridView1.Columns[3].Caption = "Rework Ratio (%)";
            this.gridView1.Columns[4].Caption = "Hold Ratio (%)";
            this.gridView1.Columns[5].Caption = "Hold Time (Hour)";
            this.gridView1.Columns[6].Caption = "Scrap Ratio (%)";

            this.gridView1.BestFitColumns();
        }

        class EqpInfo
        {
            public string RESOURCE_ID { get; set; }
            public string SCANNER_GENERATION { get; set; } //public bool IS_NXT { get; set; }

            //+
            public CheckedListBoxItem NXTCheckedListBoxItem { get; set; }
            public CheckedListBoxItem NXECheckedListBoxItem { get; set; }
        }

        class OperInfo
        {
            public string OPER_ID { get; set; }

            public int SEQ { get; set; }

            public List<FabSimulator.Inputs.ARRANGE> ARRANGES { get; set; }
        }

        private void SaveButton_Click(object sender, EventArgs e)
        {
            DeleteVdat();
            InsertVdat();

            UpdateEqpParamVdat();
        }

        private void DeleteVdat()
        {
            using (var acc = this.modelDataContext.Target.LocalAccessorFor("ROUTE_STEP_PARAM"))
            {
                var dtable = acc.QueryTable(null, -1, -1);

                string paramName = this.currentRadioIndex == 0 ? "REWORK" : 
                    (this.currentRadioIndex == 1 ? "HOLD" : "SCRAP");

                List<DataRow> removable = new List<DataRow>();
                foreach (DataRow row in dtable.Rows)
                {
                    if (row["PARAM_NAME"].ToString() == paramName && row["ROUTE_ID"].ToString() == this.currentMainRoute)
                    {
                        removable.Add(row);
                    }
                }

                removable.ForEach(x => dtable.Rows.Remove(x));

                acc.Save(dtable);
            }
        }

        private void InsertVdat()
        {
            using (var acc = this.modelDataContext.Target.LocalAccessorFor("ROUTE_STEP_PARAM"))
            {
                var dtable = acc.QueryTable(null, -1, -1);

                string paramName = this.currentRadioIndex == 0 ? "REWORK" :
                    (this.currentRadioIndex == 1 ? "HOLD" : "SCRAP");

                foreach (DataRowView item in (this.gridControl1.DataSource as DataTable).DefaultView)
                {
                    var value = GetParamValue(item);
                    if (value == null)
                        continue;

                    var nrow = dtable.NewRow();

                    nrow["LINE_ID"] = string.Empty;// this.expDataContext.Target.Arguments["LineID"].ToString();
                    nrow["ROUTE_ID"] = this.currentMainRoute;
                    nrow["OPER_ID"] = item.Row.ItemArray[1].ToString();
                    nrow["PARAM_NAME"] = paramName;
                    nrow["PARAM_VALUE"] = value;

                    dtable.Rows.Add(nrow);
                }

                acc.Save(dtable);
            }
        }

        private string GetParamValue(DataRowView item)
        {
            StringBuilder sb = new StringBuilder();
            if (this.currentRadioIndex == 0)
            {
                var reworkRoute = item.Row.ItemArray[2].ToString();
                var reworkRatio = item.Row.ItemArray[3].ToString();

                if (double.Parse(reworkRatio) <= 0)
                    return null;

                if (string.IsNullOrEmpty(reworkRoute))
                {
                    XtraMessageBox.Show("Please set Rework Route", "Alert");
                    return null;
                }

                sb.Append(reworkRoute);
                sb.Append(";");
                sb.Append(reworkRatio);
            }
            else if (this.currentRadioIndex == 1)
            {
                var holdRatio = item.Row.ItemArray[4].ToString();
                var holdHour = item.Row.ItemArray[5].ToString();

                if (double.Parse(holdRatio) <= 0 || double.Parse(holdHour) <= 0)
                    return null;

                sb.Append(holdHour);
                sb.Append(";");
                sb.Append(holdRatio);
            }
            else
            {
                var scrapRatio = item.Row.ItemArray[6].ToString();
                if (double.Parse(scrapRatio) <= 0)
                    return null;

                sb.Append(scrapRatio);
            }

            return sb.ToString();
        }

        private void RadioGroup1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (this.loading)
                return;

            if (XtraMessageBox.Show("Save Changes?", "Alert", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                DeleteVdat();
                InsertVdat();

                UpdateEqpParamVdat();
            }

            this.currentRadioIndex = this.radioGroup1.SelectedIndex;

            RadioGroup edit = sender as RadioGroup;

            SetColumnOption(edit.SelectedIndex);
        }

        private void SetColumnOption(int radioIndex)
        {
            int[] editableIndex = new int[] { 2, 3 };
            if (radioIndex == 1)
                editableIndex = new int[] { 4, 5 };
            else if (radioIndex == 2)
                editableIndex = new int[] { 6 };

            for (int i = 2; i < 7; i++)
            {
                if (editableIndex.Contains(i))
                {
                    this.gridView1.Columns[i].OptionsColumn.AllowEdit = true;
                    this.gridView1.Columns[i].OptionsColumn.AllowFocus = true;
                    this.gridView1.Columns[i].AppearanceCell.BackColor = Color.FloralWhite;
                    this.gridView1.Columns[i].AppearanceCell.ForeColor = Color.Black;
                }
                else
                {
                    this.gridView1.Columns[i].OptionsColumn.AllowEdit = false;
                    this.gridView1.Columns[i].OptionsColumn.AllowFocus = false;
                    this.gridView1.Columns[i].AppearanceCell.BackColor = Color.White;
                    this.gridView1.Columns[i].AppearanceCell.ForeColor = Color.LightGray;
                }
            }
        }

        private void SetHeaderOption()
        {
            for (int i = 0; i < 2; i++)
            {
                this.gridView1.Columns[i].OptionsColumn.AllowEdit = false;
                this.gridView1.Columns[i].OptionsColumn.AllowFocus = false;
                this.gridView1.Columns[i].AppearanceCell.BackColor = Color.WhiteSmoke;
            }
        }

        private void CheckedComboBoxEdit1_EditValueChanged(object sender, EventArgs e)
        {
            if (this.loading)
                return;

            if (this.comparing)
                return;

            this.comparing = true;
            foreach (var info in this.photoEqps)
            {
                if (info.NXTCheckedListBoxItem.CheckState == CheckState.Checked)
                {
                    info.NXECheckedListBoxItem.CheckState = CheckState.Unchecked;
                    info.SCANNER_GENERATION = "NXT";
                }
                else if (info.NXECheckedListBoxItem.CheckState == CheckState.Checked)
                {
                    info.SCANNER_GENERATION = "NXE";
                }
                else
                {
                    info.SCANNER_GENERATION = "XT";
                }
            }
            this.comparing = false;

            AddRows();

            SetReworkRoute();

            SetHeaderOption();
        }

        private void checkedComboBoxEdit2_EditValueChanged(object sender, EventArgs e)
        {
            if (this.loading)
                return;

            if (this.comparing)
                return;

            this.comparing = true;
            foreach (var info in this.photoEqps)
            {
                if (info.NXECheckedListBoxItem.CheckState == CheckState.Checked)
                {
                    info.NXTCheckedListBoxItem.CheckState = CheckState.Unchecked;
                    info.SCANNER_GENERATION = "NXE";
                }
                else if (info.NXTCheckedListBoxItem.CheckState == CheckState.Checked)
                {
                    info.SCANNER_GENERATION = "NXT";
                }
                else
                {
                    info.SCANNER_GENERATION = "XT";
                }
            }
            this.comparing = false;

            AddRows();

            SetReworkRoute();

            SetHeaderOption();
        }

        private void ComboBoxEdit1_SelectedIndexChanged(object sender, EventArgs e)
        {
            AddRows();

            SetMainRoute();

            SetReworkRoute();
        }

        private void SetMainRoute()
        {
            this.currentMainRoute = this.modelDataContext.PRODUCT.Where(x => x.PART_ID == this.comboBoxEdit1.Text).First().ROUTE_ID;
        }

        private void SetReworkRoute()
        {
            this.validRoutes.Clear();

            foreach (var route in this.modelDataContext.ROUTE.Where(x => x.ROUTE_TYPE == "REWORK"))
            {
                this.validRoutes.Add(route.ROUTE_ID);
            }

            var repo = this.gridControl1.RepositoryItems[0] as RepositoryItemComboBox;
            repo.Items.Clear();
            repo.Items.AddRange(this.validRoutes);
        }

        private void AddRows()
        {
            var model = this.comboBoxEdit1.Text;
            var arranges = this.modelDataContext.ARRANGE.Where(x => x.PART_ID == model).ToList();

            for (int i = 0; i < gridView1.RowCount;)
                gridView1.DeleteRow(i);

            var q1 = from a in this.modelDataContext.PRODUCT.Where(x => x.PART_ID == model)
                     join b in this.modelDataContext.ROUTE_STEP.Where(x => x.AREA_ID == this.photoArea) on a.ROUTE_ID equals b.ROUTE_ID
                     select new OperInfo
                     {
                         OPER_ID = b.STEP_ID,
                         SEQ = b.STEP_SEQ
                     };

            var nxtEqps = this.photoEqps.Where(x => this.selectedGen.Contains(x.SCANNER_GENERATION)).ToList(); //<- 체크박스 조건에 따라

            List<OperInfo> list = new List<OperInfo>();
            foreach (var item in q1)
            {
                var arrs = arranges.Where(x => x.STEP_ID == item.OPER_ID).ToList();

                if (arrs.Any(x => nxtEqps.Any(y => y.RESOURCE_ID == x.EQP_ID)))
                {
                    item.ARRANGES = arrs.ToList();
                    list.Add(item);
                }
            }

            int index = 1;
            foreach (var item in list.OrderBy(x => x.SEQ))
            {
                this.gridView1.AddNewRow();
                gridView1.SetRowCellValue(gridView1.FocusedRowHandle, gridView1.Columns["INDEX"], index++);
                gridView1.SetRowCellValue(gridView1.FocusedRowHandle, gridView1.Columns["PHOTO_OPERATION"], item.OPER_ID);
                //gridView1.SetRowCellValue(gridView1.FocusedRowHandle, gridView1.Columns["REWORK_ROUTE"], 
                //    (this.gridControl1.RepositoryItems[0] as RepositoryItemComboBox).Items[0]);

                gridView1.SetRowCellValue(gridView1.FocusedRowHandle, gridView1.Columns["REWORK_RATIO"], 0);
                gridView1.SetRowCellValue(gridView1.FocusedRowHandle, gridView1.Columns["HOLD_RATIO"], 0);
                gridView1.SetRowCellValue(gridView1.FocusedRowHandle, gridView1.Columns["HOLD_TIME"], 0);
                gridView1.SetRowCellValue(gridView1.FocusedRowHandle, gridView1.Columns["SCRAP_RATIO"], 0);
            }

            this.gridView1.BestFitColumns();
        }

        private void UpdateEqpParamVdat()
        {
            using (var acc = this.modelDataContext.Target.LocalAccessorFor("EQP_PARAM"))
            {
                var dtable = acc.QueryTable(null, -1, -1);

                foreach (DataRow row in dtable.Rows)
                {
                    if (row["PARAM_NAME"].ToString() != "SCANNER_GENERATION")
                        continue;

                    var eqp = this.photoEqps.FirstOrDefault(x => x.RESOURCE_ID == row["RESOURCE_ID"].ToString());
                    if (eqp == null)
                        continue;

                    row["PARAM_VALUE"] = eqp.SCANNER_GENERATION;
                }

                dtable.AcceptChanges();
                acc.Save(dtable);
            }
        }

        private void GridView1_CellValueChanged(object sender, DevExpress.XtraGrid.Views.Base.CellValueChangedEventArgs e)
        {
            if (e.Column.FieldName != "REWORK_ROUTE")
                return;

            var reworkRouteID = this.gridView1.GetRowCellValue(e.RowHandle, e.Column.FieldName).ToString();

            SplashScreenManager.ShowForm(typeof(WaitForm1));

            bool isValid = IsValidReworkRoute(reworkRouteID);

            SplashScreenManager.CloseForm();

            if (isValid == false)
            {
                XtraMessageBox.Show("Invalid (No-Arrange) Route", "Alert");
                var repo = this.gridControl1.RepositoryItems[0] as RepositoryItemComboBox;
                var index = repo.Items.IndexOf(reworkRouteID);
                if (index >= 0)
                    repo.Items.RemoveAt(index);

                this.gridView1.SetRowCellValue(e.RowHandle, e.Column, null);
            }
        }

        private bool IsValidReworkRoute(string reworkRouteID)
        {
            foreach (var step in this.modelDataContext.ROUTE_STEP.Where(x => x.ROUTE_ID == reworkRouteID && x.STEP_LEVEL == 1))
            {
                if (this.modelDataContext.ARRANGE.Any(x => x.PART_ID == this.comboBoxEdit1.Text && x.STEP_ID == step.STEP_ID))
                    continue;

                return false;
            }

            return true;
        }

        private void checkEdit2_CheckedChanged(object sender, EventArgs e)
        {
            if ((sender as CheckEdit).Checked)
                selectedGen.Add("XT");
            else
                selectedGen.Remove("XT");

            RePopulate();
        }

        private void checkEdit3_CheckedChanged(object sender, EventArgs e)
        {
            if ((sender as CheckEdit).Checked)
                selectedGen.Add("NXT");
            else
                selectedGen.Remove("NXT");

            RePopulate();
        }

        private void checkEdit4_CheckedChanged(object sender, EventArgs e)
        {
            if ((sender as CheckEdit).Checked)
                selectedGen.Add("NXE");
            else
                selectedGen.Remove("NXE");

            RePopulate();
        }

        private void RePopulate()
        {
            // Row만 새로 생성하면 되는 경우에는 SetRowValues()만 호출하려고 했으나
            // 사용자가 Filter를 건드린 상태에서 상호작용할 경우 꼬이게 됨.
            // 퍼포먼스에 큰 영향이 없어서 항상 RePopulate() 함수를 호출하도록 변경함.

            AddRows();

            SetMainRoute();

            SetReworkRoute();

            this.gridView1.BestFitColumns();

            // 마지막 row가 focus 되어 RowCellStyle이 즉시적용되지 않는 문제 해결책
            //this.gridView1.FocusedRowHandle = -1;
        }
    }
}
