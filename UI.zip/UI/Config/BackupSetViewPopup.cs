﻿namespace FabSimulatorUI.Config
{
    public partial class BackupSetViewPopup : DevExpress.XtraEditors.XtraForm
    {
        ResourceBackupView _parent;
        int _rowHandle;

        public BackupSetViewPopup(ResourceBackupView parent, object tag)
        {
            _parent = parent;
            var arg = tag.ToString().Split('|');
            _rowHandle = Int32.Parse(arg.First());

            InitializeComponent();
            this.Text = "Backup Set";

            listView1.View = View.Details;
            listView2.View = View.Details;

            listView1.Sorting = SortOrder.Ascending;
            listView2.MultiSelect = false; // 상하이동 버튼동작 위해서

            ColumnHeader header = new ColumnHeader();
            header.Text = "";
            header.Name = "col1";
            listView1.Columns.Add(header);
            listView1.HeaderStyle = ColumnHeaderStyle.None;

            ColumnHeader header2 = new ColumnHeader();
            header2.Text = "";
            header2.Name = "col1";
            listView2.Columns.Add(header2);
            listView2.HeaderStyle = ColumnHeaderStyle.None;

            foreach (var item in arg[1].Split(',').ToList())
            {
                if (string.IsNullOrEmpty(item))
                    continue;

                listView1.Items.Add(item);
            }

            foreach (var item in arg.Last().Split(',').ToList())
            {
                if (string.IsNullOrEmpty(item))
                    continue;

                listView2.Items.Add(item);
            }
        }

        private void buttonOK_Click(object sender, EventArgs e)
        {
            string backupSets = "";
            var count = listView2.Items.Count;
            for (int i = 0; i < count; i++)
            {
                backupSets += listView2.Items[i].Text;

                if (i < count - 1)
                    backupSets += ',';
            }

            _parent.CurrentGrid.SetRowCellValue(_rowHandle, "BACKUP_SET", backupSets);
            _parent.CurrentGrid.BestFitColumns();

            this.Close();
        }

        private void buttonCacnel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void buttonRight_Click(object sender, EventArgs e)
        {
            foreach (ListViewItem item in listView1.SelectedItems)
            {
                listView1.Items.Remove(item);
                listView2.Items.Add(item);
            }
        }

        private void buttonLeft_Click(object sender, EventArgs e)
        {
            foreach (ListViewItem item in listView2.SelectedItems)
            {
                listView2.Items.Remove(item);
                listView1.Items.Add(item);
            }
        }

        private void buttonUp_Click(object sender, EventArgs e)
        {
            if (listView2.SelectedItems.Count <= 0)
                return;

            var selected = listView2.SelectedItems[0];
            var currentIndex = listView2.SelectedIndices[0];

            if (currentIndex > 0)
            {
                listView2.Items.Remove(selected);
                listView2.Items.Insert(currentIndex - 1, selected);
            }
        }

        private void buttonDown_Click(object sender, EventArgs e)
        {
            if (listView2.SelectedItems.Count <= 0)
                return;

            var selected = listView2.SelectedItems[0];
            var currentIndex = listView2.SelectedIndices[0];

            if (currentIndex < listView2.Items.Count - 1)
            {
                listView2.Items.Remove(selected);
                listView2.Items.Insert(currentIndex + 1, selected);
            }
        }
    }
}