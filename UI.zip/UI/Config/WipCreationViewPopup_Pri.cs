﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FabSimulatorUI.Config
{
    public partial class WipCreationViewPopup_Pri : Form
    {
        public FormSendDataHandler FormSendEvent;

        private int numericOneValue = WipCreationView.numericOne;
        private int numericTwoValue = WipCreationView.numericTwo;

        public WipCreationViewPopup_Pri()
        {
            InitializeComponent();
            numericUpDown1.Value = numericOneValue;
            numericUpDown2.Value = numericTwoValue;
        }

        private void btnOk_Click(object sender, EventArgs e)
        {
            WipCreationView.numericOne = (int)numericUpDown1.Value;
            WipCreationView.numericTwo = (int)numericUpDown2.Value;
            FormSendEvent(numNormal: (int)numericUpDown1.Value, numHot: (int)numericUpDown2.Value, tag: 2);
            this.Close();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }        
    }
}