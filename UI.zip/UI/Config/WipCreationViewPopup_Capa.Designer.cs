﻿namespace FabSimulatorUI.Config
{
    partial class WipCreationViewPopup_Capa
    {
        /// <summary> 
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary> 
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>        
        private void InitializeComponent()
        {
            labelControl1 = new DevExpress.XtraEditors.LabelControl();
            btnOk = new DevExpress.XtraEditors.SimpleButton();
            btnCancel = new DevExpress.XtraEditors.SimpleButton();
            backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            radioDemand = new RadioButton();
            radioFab = new RadioButton();
            SuspendLayout();
            // 
            // labelControl1
            // 
            labelControl1.Location = new Point(98, 56);
            labelControl1.Name = "labelControl1";
            labelControl1.Size = new Size(327, 18);
            labelControl1.TabIndex = 0;
            labelControl1.Text = "Select a data source to set the initial daily capacity";
            // 
            // btnOk
            // 
            btnOk.Location = new Point(109, 236);
            btnOk.Name = "btnOk";
            btnOk.Size = new Size(118, 36);
            btnOk.TabIndex = 1;
            btnOk.Text = "OK";
            btnOk.Click += btnOk_Click;
            // 
            // btnCancel
            // 
            btnCancel.Location = new Point(326, 236);
            btnCancel.Name = "btnCancel";
            btnCancel.Size = new Size(118, 36);
            btnCancel.TabIndex = 2;
            btnCancel.Text = "Cancel";
            btnCancel.Click += btnCancel_Click;
            // 
            // radioDemand
            // 
            radioDemand.AutoSize = true;
            radioDemand.Location = new Point(96, 116);
            radioDemand.Name = "radioDemand";
            radioDemand.Size = new Size(134, 24);
            radioDemand.TabIndex = 3;
            radioDemand.Text = "From DEMAND";
            radioDemand.UseVisualStyleBackColor = true;
            // 
            // radioFab
            // 
            radioFab.AutoSize = true;
            radioFab.Location = new Point(96, 167);
            radioFab.Name = "radioFab";
            radioFab.Size = new Size(159, 24);
            radioFab.TabIndex = 4;
            radioFab.Text = "From FAB_IN_PLAN";
            radioFab.UseVisualStyleBackColor = true;
            // 
            // WipCreationViewPopup_Capa
            // 
            AutoScaleDimensions = new SizeF(9F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(542, 313);
            Controls.Add(radioFab);
            Controls.Add(radioDemand);
            Controls.Add(btnCancel);
            Controls.Add(btnOk);
            Controls.Add(labelControl1);
            Name = "WipCreationViewPopup_Capa";
            Text = "WipCreationViewPopup_Capa";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DevExpress.XtraEditors.LabelControl labelControl1;
        private DevExpress.XtraEditors.SimpleButton btnOk;
        private DevExpress.XtraEditors.SimpleButton btnCancel;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private RadioButton radioDemand;
        private RadioButton radioFab;
    }
}