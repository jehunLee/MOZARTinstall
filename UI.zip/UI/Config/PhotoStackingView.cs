﻿using System.Data;
using Mozart.Studio.TaskModel.UserInterface;
using Mozart.Studio.TaskModel.UserLibrary;
using FabSimulator;
using FabSimulatorUI.Common;
using Mozart.Extensions;
using FabSimulator.Inputs;
using DevExpress.XtraEditors;
using System.ComponentModel.DataAnnotations;
using Mozart.Task.Model;

namespace FabSimulatorUI.Config
{
    public partial class PhotoStackingView : XtraGridControlView
    {
        #region Variable&Property

        ModelDataContext modelDataContext;
        Experiment experiment;

        bool initializing;
        bool loading;
        bool onEdit;

        List<PhotoStackingInfo> photoStackingInfos;

        Dictionary<string, Tuple<string, string>> partGroupData = new Dictionary<string, Tuple<string, string>>();

        #endregion

        #region Ctor

        public PhotoStackingView(IServiceProvider serviceProvider)
            : base(serviceProvider)
        {
            InitializeComponent();

            this.initializing = true;
            this.ConstructInit();
        }

        protected override void LoadDocument()
        {
            this.LoadInit();
            this.initializing = false;

            this.loading = true;
            this.Query();
            this.loading = false;
        }

        private void Query()
        {
            using (var wc = new Mozart.Studio.UIComponents.WaitCursor())
            {
                this.BindBegin();
                this.BindDo();
                this.BindEnd();
            }
        }

        #endregion

        #region Init

        private void ConstructInit()
        {
        }

        private void LoadInit()
        {
            this.modelDataContext = this.Document.GetCtx<ModelDataContext>();
            this.experiment = Globals.GetExperiment(this.modelDataContext);

            Globals.InitFactoryTimeNew(this.modelDataContext);
        }
        #endregion

        #region Data Binding
        private void BindBegin()
        {
            this.gridControl1.BeginUpdate();
        }

        private void BindDo()
        {
            using (var wc = new Mozart.Studio.UIComponents.WaitCursor())
            {
                SetVersionComboxBox();

                SetPartGroupComboBox();

                SetPartIdComboBox();

                FillGrid();
            }
        }

        private void SetVersionComboxBox()
        {
            if (this.comboBoxEdit1.Properties.Items.Count > 0 && this.comboBoxEdit1.Text != "New")
                return;

            var versions = this.modelDataContext.UI_STACK_INFO.Select(x => x.VERSION_ID).OrderByDescending(x => x).Distinct().ToList();
            versions.Add("New");

            this.comboBoxEdit1.Properties.Items.Clear();
            this.comboBoxEdit1.FillValues(versions);
        }

        private void SetPartGroupComboBox()
        {
            var partGroups = this.modelDataContext.PRODUCT.Select(x => x.PART_GROUP).Distinct().OrderBy(x => x).ToList();

            this.comboBoxEdit2.FillValues(partGroups);
        }

        private void SetPartIdComboBox()
        {
            var partIds = GetPartIdList(this.comboBoxEdit2.Text);
            partIds.Insert(0, "-");

            this.comboBoxEdit3.Properties.Items.Clear();
            this.comboBoxEdit3.FillValues(partIds);
        }

        private List<string> GetPartIdList(string partGroup)
        {
            var list = this.modelDataContext.PRODUCT.Where(x => x.PART_GROUP == partGroup)
                .Select(x => x.PART_ID).Distinct().OrderBy(x => x).ToList();

            return list;
        }


        private void FillGrid(bool needGroupInherit = false)
        {
            var partCount = this.modelDataContext.PRODUCT.Where(x => x.PART_GROUP == this.comboBoxEdit2.Text).Select(x => x.PART_ID).Distinct().Count();

            var stack = from a in this.modelDataContext.PRODUCT.Where(x => x.PART_GROUP == this.comboBoxEdit2.Text)
                        join b in this.modelDataContext.ROUTE_STEP on a.ROUTE_ID equals b.ROUTE_ID
                        join c in this.modelDataContext.ARRANGE on new { a.PART_ID, b.STEP_ID } equals new { c.PART_ID, c.STEP_ID }
                        join d in this.modelDataContext.EQP.Where(x => x.EQP_GROUP == "NXT" || x.EQP_GROUP == "NXE") on c.EQP_ID equals d.EQP_ID
                        select new
                        {
                            a.PART_GROUP,
                            a.PART_ID,
                            c.STEP_ID,
                            b.STEP_SEQ
                        };

            var steps = from a in stack
                        group a by new { a.PART_GROUP, a.STEP_ID } into grp
                        select new
                        {
                            grp.Key.PART_GROUP,
                            grp.Key.STEP_ID,

                            PART_ID = this.comboBoxEdit3.Text,
                            STEP_SEQ = grp.Select(x => x.STEP_SEQ).Average(),
                            PARTS = grp.Select(x => x.PART_ID).Distinct().ToList(),
                            PART_COUNT = grp.Select(x => x.PART_ID).Distinct().Count()
                        };

            if (needGroupInherit)
            {
                if (this.photoStackingInfos.Any(x => x.PART_ID == "-"))
                {
                    this.partGroupData.Clear();

                    foreach (var item in this.photoStackingInfos)
                    {
                        this.partGroupData.Add(item.STEP_ID, new Tuple<string, string>(item.STACK_GROUP, item.STACK_TYPE));
                    }
                }
            }

            var prod = this.modelDataContext.PRODUCT.Where(x => x.PART_ID == this.comboBoxEdit3.Text).FirstOrDefault();
            var routeId = prod != null ? prod.ROUTE_ID : "-";

            this.photoStackingInfos = (from a in steps.Where(x => x.PART_COUNT == partCount || x.PARTS.Contains(this.comboBoxEdit3.Text)).OrderBy(x => x.STEP_SEQ)
                                       join b in this.modelDataContext.UI_STACK_INFO.Where(x => x.VERSION_ID == this.comboBoxEdit1.Text)
                                       on new { a.PART_GROUP, a.PART_ID, a.STEP_ID } equals new { b.PART_GROUP, b.PART_ID, b.STEP_ID } into outer
                                       join c in this.modelDataContext.ROUTE_STEP.Where(x => x.ROUTE_ID == routeId) on a.STEP_ID equals c.STEP_ID into outer2
                                       from o in outer.DefaultIfEmpty()
                                       from o2 in outer2.DefaultIfEmpty()
                                       select new PhotoStackingInfo
                                       {
                                           PART_GROUP = a.PART_GROUP,
                                           PART_ID = a.PART_ID,
                                           STEP_ID = a.STEP_ID,
                                           LAYER_ID = o2 != null ? o2.LAYER_ID : "-",
                                           STACK_GROUP = o != null ? o.STACK_GROUP : string.Empty,
                                           STACK_TYPE = o != null ? o.STACK_TYPE : "-",
                                       }).ToList();

            if (needGroupInherit)
            {
                foreach (var item in this.photoStackingInfos)
                {
                    if (item.STACK_GROUP.IsNullOrEmpty() == false)
                        continue; // PART_GROUP 값의 상속보다 UI_STACK_INFO 에 저장된 값을 우선 사용

                    if (this.partGroupData.ContainsKey(item.STEP_ID) == false)
                        continue;

                    item.STACK_GROUP = this.partGroupData.SafeGet(item.STEP_ID).Item1;
                    item.STACK_TYPE = this.partGroupData.SafeGet(item.STEP_ID).Item2;
                }
            }

            this.gridControl1.DataSource = this.photoStackingInfos;

            this.gridView1.BestFitColumns();
        }

        private void BindEnd()
        {
            SetHeaderOption();

            ResetEditingAppearance();

            this.gridView1.BestFitColumns();
            this.gridView1.OptionsView.ColumnAutoWidth = false;
            this.gridView1.OptionsView.ShowGroupPanel = false;
            this.gridView1.OptionsSelection.EnableAppearanceFocusedRow = false;
            this.gridView1.OptionsCustomization.AllowSort = false;
            this.gridView1.OptionsCustomization.AllowFilter = false;

            this.gridControl1.EndUpdate();
        }

        private void SetHeaderOption()
        {
            for (int i = 0; i < 6; i++)
            {
                if (i == 4)
                    continue;

                this.gridView1.Columns[i].OptionsColumn.AllowEdit = false;
                this.gridView1.Columns[i].OptionsColumn.AllowFocus = false;
            }

            this.gridView1.Columns[4].AppearanceCell.BackColor = Color.FloralWhite;
        }

        private void ResetEditingAppearance()
        {
            this.saveButton.Enabled = false;

            this.gridView1.RefreshData();

            this.photoStackingInfos.ForEach(x => x.IS_EDITED = false);
        }

        #endregion

        #region Event Handler

        private void gridView1_CellValueChanged(object sender, DevExpress.XtraGrid.Views.Base.CellValueChangedEventArgs e)
        {
            if (this.onEdit)
                return;

            this.onEdit = true;
            this.saveButton.Enabled = true;

            var stackGroupCol = this.gridView1.Columns[4];
            var stackTypeCol = this.gridView1.Columns[5];

            if (e.Value.ToString().IsNullOrEmpty() == false)
            {
                for (int i = e.RowHandle; i < this.photoStackingInfos.Count; i++)
                {
                    //var currentGroup = this.gridView1.GetRowCellValue(i, stackGroupCol).ToString();
                    //if (i > e.RowHandle && currentGroup.IsNullOrEmpty() == false)
                    //    break;

                    this.gridView1.SetRowCellValue(i, stackGroupCol, e.Value);

                    var info = GetPhotoStackingInfo(i);
                    if (info != null)
                        info.IS_EDITED = true;
                }
            }
            else
            {
                var info = GetPhotoStackingInfo(e.RowHandle);
                if (info != null)
                    info.IS_EDITED = true;
            }

            List<string> stackGroups = new List<string>();
            for (int i = 0; i < this.photoStackingInfos.Count; i++)
            {
                var currentGroup = this.gridView1.GetRowCellValue(i, stackGroupCol).ToString();

                string stackType;
                if (currentGroup.IsNullOrEmpty())
                    stackType = "-";
                else if (stackGroups.Contains(currentGroup))
                    stackType = "Y";
                else
                {
                    stackType = "S";
                    stackGroups.Add(currentGroup);
                }

                this.gridView1.SetRowCellValue(i, stackTypeCol, stackType);
            }

            this.onEdit = false;
        }

        private void gridView1_RowStyle(object sender, DevExpress.XtraGrid.Views.Grid.RowStyleEventArgs e)
        {
            if (this.initializing || this.loading)
                return;

            var info = GetPhotoStackingInfo(e.RowHandle);
            if (info == null)
                return;

            if (info.IS_EDITED)
                e.Appearance.ForeColor = Color.Blue;
            else
                e.Appearance.ForeColor = Color.Black;
        }

        private PhotoStackingInfo GetPhotoStackingInfo(int rowHandle)
        {
            PhotoStackingInfo info = null;

            var stepCol = this.gridView1.Columns[2];
            var value = this.gridView1.GetRowCellValue(rowHandle, stepCol);
            if (value != null)
            {
                info = this.photoStackingInfos.Where(x => x.STEP_ID == value.ToString()).FirstOrDefault();
            }

            return info;
        }

        private void comboBoxEdit1_EditValueChanged(object sender, EventArgs e)
        {
            if (this.initializing || this.loading)
                return;

            ResetEditingAppearance();

            FillGrid();
        }

        private void comboBoxEdit2_EditValueChanged(object sender, EventArgs e)
        {
            if (this.initializing || this.loading)
                return;

            SetPartIdComboBox();

            FillGrid();
        }

        private void comboBoxEdit3_EditValueChanged(object sender, EventArgs e)
        {
            if (this.initializing || this.loading)
                return;

            FillGrid(true);
        }

        private void SaveButton_Click(object sender, EventArgs e)
        {
            using (var wc = new Mozart.Studio.UIComponents.WaitCursor())
            {
                SaveChanges();
            }
        }

        private void SaveChanges()
        {
            try
            {
                DeleteUIVdat();

                InsertUIVdat();

                SetVersionComboxBox();

                ResetEditingAppearance();

                XtraMessageBox.Show("success to save changes", "Note");
            }
            catch (Exception)
            {
                XtraMessageBox.Show("fail to save changes", "Alert");
            }
        }

        private void convertButton_Click(object sender, EventArgs e)
        {
            using (var wc = new Mozart.Studio.UIComponents.WaitCursor())
            {
                try
                {
                    SaveChanges();

                    DeleteConvertedVdat();

                    InsertConvertedVdat();

                    XtraMessageBox.Show("success to convert", "Note");
                }
                catch (Exception ex)
                {
                    XtraMessageBox.Show("fail to convert", "Alert");
                }
            }
        }

        #endregion

        #region Data Interface
        private void DeleteUIVdat()
        {
            using (var acc = this.modelDataContext.Target.LocalAccessorFor("UI_STACK_INFO"))
            {
                var dtable = acc.QueryTable(null, -1, -1);

                List<DataRow> removable = new List<DataRow>();

                foreach (DataRow row in dtable.Rows)
                {
                    if (row["VERSION_ID"].ToString() == this.comboBoxEdit1.Text
                        && row["PART_GROUP"].ToString() == this.comboBoxEdit2.Text && row["PART_ID"].ToString() == this.comboBoxEdit3.Text)
                        removable.Add(row);
                }

                removable.ForEach(x => dtable.Rows.Remove(x));

                acc.Save(dtable);
            }
        }

        private void InsertUIVdat()
        {
            using (var acc = this.modelDataContext.Target.LocalAccessorFor("UI_STACK_INFO"))
            {
                var dtable = acc.QueryTable(null, -1, -1);

                var versionID = this.comboBoxEdit1.Text;
                if (versionID == "New")
                    versionID = "UI_" + DateTime.Now.ToString("yyyyMMddHHmmss");

                foreach (var item in this.gridControl1.DataSource as List<PhotoStackingInfo>)
                {
                    if (item.STACK_TYPE == "-")
                        continue;

                    var nrow = dtable.NewRow();

                    nrow["VERSION_ID"] = versionID;
                    nrow["PART_GROUP"] = item.PART_GROUP;
                    nrow["PART_ID"] = item.PART_ID;
                    nrow["STEP_ID"] = item.STEP_ID;
                    nrow["STACK_TYPE"] = item.STACK_TYPE;
                    nrow["STACK_GROUP"] = item.STACK_GROUP;

                    dtable.Rows.Add(nrow);
                }

                acc.Save(dtable);
            }
        }

        private void DeleteConvertedVdat()
        {
            DeleteStackInfoVdat();
        }

        private void DeleteStackInfoVdat()
        {
            using (var acc = this.modelDataContext.Target.LocalAccessorFor("STACK_INFO"))
            {
                var dtable = acc.QueryTable(null, -1, -1);

                List<DataRow> removable = new List<DataRow>();

                foreach (DataRow row in dtable.Rows)
                {
                    // 전체 데이터 초기화 후 입력
                    removable.Add(row);
                }

                removable.ForEach(x => dtable.Rows.Remove(x));

                acc.Save(dtable);
            }
        }

        private void InsertConvertedVdat()
        {
            var currentData = this.modelDataContext.UI_STACK_INFO
                .Where(x => x.VERSION_ID == this.comboBoxEdit1.Text).OrderByDescending(x => x.PART_ID).ToList();

            InsertStackInfoVdat(currentData);
        }

        private void InsertStackInfoVdat(IEnumerable<UI_STACK_INFO> infos)
        {
            using (var acc = this.modelDataContext.Target.LocalAccessorFor("STACK_INFO"))
            {
                var dtable = acc.QueryTable(null, -1, -1);

                HashSet<string> detailedParts = new HashSet<string>();
                List<string> currentParts = new List<string>();

                // Sorting 되어, PART_ID 값이 있는 데이터를 먼저 로딩
                foreach (var item in infos)
                {
                    currentParts.Clear();
                    if (item.PART_ID != "-")
                    {
                        currentParts.Add(item.PART_ID);
                        detailedParts.Add(item.PART_ID);
                    }
                    else
                        currentParts = GetPartIdList(item.PART_GROUP);

                    foreach (var partID in currentParts)
                    {
                        if (item.PART_ID == "-" && detailedParts.Contains(partID))
                            continue; // Part단위의 detail한 입력이 있을 경우, PartGroup 단위의 입력은 무시함.

                        var nrow = dtable.NewRow();
                        nrow["PART_ID"] = partID;
                        nrow["STEP_ID"] = item.STEP_ID;
                        nrow["STACK_GROUP"] = item.STACK_GROUP + "_" + partID;
                        nrow["STACK_TYPE"] = item.STACK_TYPE;

                        dtable.Rows.Add(nrow);
                    }
                }

                acc.Save(dtable);
            }
        }

        #endregion

        #region Data Class
        class PhotoStackingInfo
        {
            public string PART_GROUP { get; set; }
            public string PART_ID { get; set; }
            public string STEP_ID { get; set; }
            public string LAYER_ID { get; set; }
            public string STACK_GROUP { get; set; }
            public string STACK_TYPE { get; set; }

            [Display(Order = -1)]
            public bool IS_EDITED { get; set; }
        }

        #endregion
    }
}