﻿
namespace FabSimulatorUI.Config
{
    partial class WaferStartView
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 구성 요소 디자이너에서 생성한 코드

        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            DevExpress.XtraSplashScreen.SplashScreenManager splashScreenManager1 = new DevExpress.XtraSplashScreen.SplashScreenManager(this, null, true, true, typeof(UserControl));
            panelControl1 = new DevExpress.XtraEditors.PanelControl();
            pivotGridControl1 = new DevExpress.XtraPivotGrid.PivotGridControl();
            expandablePanel1 = new Mozart.Studio.UIComponents.ExpandablePanel();
            convertButton = new Button();
            comboBoxEdit1 = new DevExpress.XtraEditors.ComboBoxEdit();
            label4 = new Label();
            checkBox1 = new CheckBox();
            spinEdit2 = new DevExpress.XtraEditors.SpinEdit();
            spinEdit1 = new DevExpress.XtraEditors.SpinEdit();
            dateEdit1 = new DevExpress.XtraEditors.DateEdit();
            label3 = new Label();
            label1 = new Label();
            SaveButton = new Button();
            label2 = new Label();
            dockManager1 = new DevExpress.XtraBars.Docking.DockManager(components);
            ((System.ComponentModel.ISupportInitialize)panelControl1).BeginInit();
            panelControl1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pivotGridControl1).BeginInit();
            expandablePanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)comboBoxEdit1.Properties).BeginInit();
            ((System.ComponentModel.ISupportInitialize)spinEdit2.Properties).BeginInit();
            ((System.ComponentModel.ISupportInitialize)spinEdit1.Properties).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dateEdit1.Properties).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dateEdit1.Properties.CalendarTimeProperties).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dockManager1).BeginInit();
            SuspendLayout();
            // 
            // splashScreenManager1
            // 
            splashScreenManager1.ClosingDelay = 500;
            // 
            // panelControl1
            // 
            panelControl1.Controls.Add(pivotGridControl1);
            panelControl1.Controls.Add(expandablePanel1);
            panelControl1.Dock = DockStyle.Fill;
            panelControl1.Location = new Point(0, 0);
            panelControl1.Name = "panelControl1";
            panelControl1.Size = new Size(1336, 666);
            panelControl1.TabIndex = 0;
            // 
            // pivotGridControl1
            // 
            pivotGridControl1.Dock = DockStyle.Fill;
            pivotGridControl1.Location = new Point(2, 73);
            pivotGridControl1.Name = "pivotGridControl1";
            pivotGridControl1.OptionsData.DataProcessingEngine = DevExpress.XtraPivotGrid.PivotDataProcessingEngine.Optimized;
            pivotGridControl1.Size = new Size(1332, 591);
            pivotGridControl1.TabIndex = 1;
            pivotGridControl1.CustomCellDisplayText += pivotGridControl1_CustomCellDisplayText;
            pivotGridControl1.CustomAppearance += pivotGridControl1_CustomAppearance;
            pivotGridControl1.EditValueChanged += pivotGridControl1_EditValueChanged;
            pivotGridControl1.CustomCellEdit += pivotGridControl1_CustomCellEdit;
            // 
            // expandablePanel1
            // 
            expandablePanel1.Controls.Add(convertButton);
            expandablePanel1.Controls.Add(comboBoxEdit1);
            expandablePanel1.Controls.Add(label4);
            expandablePanel1.Controls.Add(checkBox1);
            expandablePanel1.Controls.Add(spinEdit2);
            expandablePanel1.Controls.Add(spinEdit1);
            expandablePanel1.Controls.Add(dateEdit1);
            expandablePanel1.Controls.Add(label3);
            expandablePanel1.Controls.Add(label1);
            expandablePanel1.Controls.Add(SaveButton);
            expandablePanel1.Controls.Add(label2);
            expandablePanel1.Dock = DockStyle.Top;
            expandablePanel1.ForeColor = Color.SteelBlue;
            expandablePanel1.Location = new Point(2, 2);
            expandablePanel1.Name = "expandablePanel1";
            expandablePanel1.Size = new Size(1332, 71);
            expandablePanel1.TabIndex = 0;
            expandablePanel1.Text = "Wafer Start";
            expandablePanel1.UseAnimation = true;
            // 
            // convertButton
            // 
            convertButton.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            convertButton.Location = new Point(1212, 35);
            convertButton.Name = "convertButton";
            convertButton.Size = new Size(96, 27);
            convertButton.TabIndex = 88;
            convertButton.Text = "Convert";
            convertButton.UseVisualStyleBackColor = true;
            convertButton.Click += convertButton_Click;
            // 
            // comboBoxEdit1
            // 
            comboBoxEdit1.Location = new Point(84, 39);
            comboBoxEdit1.Name = "comboBoxEdit1";
            comboBoxEdit1.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] { new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo) });
            comboBoxEdit1.Size = new Size(155, 20);
            comboBoxEdit1.TabIndex = 87;
            comboBoxEdit1.EditValueChanged += comboBoxEdit1_EditValueChanged;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(31, 42);
            label4.Name = "label4";
            label4.Size = new Size(47, 14);
            label4.TabIndex = 86;
            label4.Text = "Version";
            // 
            // checkBox1
            // 
            checkBox1.AutoSize = true;
            checkBox1.Location = new Point(831, 41);
            checkBox1.Name = "checkBox1";
            checkBox1.Size = new Size(95, 18);
            checkBox1.TabIndex = 85;
            checkBox1.Text = "Auto Spread";
            checkBox1.UseVisualStyleBackColor = true;
            // 
            // spinEdit2
            // 
            spinEdit2.EditValue = new decimal(new int[] { 0, 0, 0, 0 });
            spinEdit2.Location = new Point(689, 38);
            spinEdit2.Name = "spinEdit2";
            spinEdit2.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] { new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo) });
            spinEdit2.Size = new Size(100, 20);
            spinEdit2.TabIndex = 83;
            spinEdit2.EditValueChanged += spinEdit2_EditValueChanged;
            // 
            // spinEdit1
            // 
            spinEdit1.EditValue = new decimal(new int[] { 0, 0, 0, 0 });
            spinEdit1.Location = new Point(484, 38);
            spinEdit1.Name = "spinEdit1";
            spinEdit1.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] { new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo) });
            spinEdit1.Size = new Size(100, 20);
            spinEdit1.TabIndex = 82;
            spinEdit1.EditValueChanged += spinEdit1_EditValueChanged;
            // 
            // dateEdit1
            // 
            dateEdit1.EditValue = null;
            dateEdit1.Location = new Point(314, 39);
            dateEdit1.Name = "dateEdit1";
            dateEdit1.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] { new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo) });
            dateEdit1.Properties.CalendarTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] { new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo) });
            dateEdit1.Size = new Size(100, 20);
            dateEdit1.TabIndex = 81;
            dateEdit1.EditValueChanged += dateEdit1_EditValueChanged;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(279, 42);
            label3.Name = "label3";
            label3.Size = new Size(29, 14);
            label3.TabIndex = 80;
            label3.Text = "PST";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(611, 42);
            label1.Name = "label1";
            label1.Size = new Size(72, 14);
            label1.TabIndex = 79;
            label1.Text = "Weekly Max";
            // 
            // SaveButton
            // 
            SaveButton.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            SaveButton.Location = new Point(1131, 35);
            SaveButton.Name = "SaveButton";
            SaveButton.Size = new Size(75, 27);
            SaveButton.TabIndex = 3;
            SaveButton.Text = "Save";
            SaveButton.UseVisualStyleBackColor = true;
            SaveButton.Click += SaveButton_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(437, 41);
            label2.Name = "label2";
            label2.Size = new Size(41, 14);
            label2.TabIndex = 61;
            label2.Text = "Period";
            // 
            // dockManager1
            // 
            dockManager1.Form = this;
            dockManager1.TopZIndexControls.AddRange(new string[] { "DevExpress.XtraBars.BarDockControl", "DevExpress.XtraBars.StandaloneBarDockControl", "System.Windows.Forms.StatusBar", "System.Windows.Forms.MenuStrip", "System.Windows.Forms.StatusStrip", "DevExpress.XtraBars.Ribbon.RibbonStatusBar", "DevExpress.XtraBars.Ribbon.RibbonControl", "DevExpress.XtraBars.Navigation.OfficeNavigationBar", "DevExpress.XtraBars.Navigation.TileNavPane" });
            // 
            // WaferStartView
            // 
            AutoScaleDimensions = new SizeF(7F, 14F);
            AutoScaleMode = AutoScaleMode.Font;
            Controls.Add(panelControl1);
            Name = "WaferStartView";
            Size = new Size(1336, 666);
            ((System.ComponentModel.ISupportInitialize)panelControl1).EndInit();
            panelControl1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pivotGridControl1).EndInit();
            expandablePanel1.ResumeLayout(false);
            expandablePanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)comboBoxEdit1.Properties).EndInit();
            ((System.ComponentModel.ISupportInitialize)spinEdit2.Properties).EndInit();
            ((System.ComponentModel.ISupportInitialize)spinEdit1.Properties).EndInit();
            ((System.ComponentModel.ISupportInitialize)dateEdit1.Properties.CalendarTimeProperties).EndInit();
            ((System.ComponentModel.ISupportInitialize)dateEdit1.Properties).EndInit();
            ((System.ComponentModel.ISupportInitialize)dockManager1).EndInit();
            ResumeLayout(false);
        }

        #endregion

        /// <summary>   The first panel control. </summary>
        private DevExpress.XtraEditors.PanelControl panelControl1;
        /// <summary>   The first expandable panel. </summary>
        private Mozart.Studio.UIComponents.ExpandablePanel expandablePanel1;
        /// <summary>   The label 2 control. </summary>
        private Label label2;
        /// <summary>   The button query control. </summary>
        private Button SaveButton;
        /// <summary>   The first dock manager. </summary>
        private DevExpress.XtraBars.Docking.DockManager dockManager1;
        private Label label1;
        private Label label3;
        private DevExpress.XtraPivotGrid.PivotGridControl pivotGridControl1;
        private DevExpress.XtraEditors.SpinEdit spinEdit2;
        private DevExpress.XtraEditors.SpinEdit spinEdit1;
        private DevExpress.XtraEditors.DateEdit dateEdit1;
        private CheckBox checkBox1;
        private Label label4;
        private DevExpress.XtraEditors.ComboBoxEdit comboBoxEdit1;
        private Button convertButton;
    }
}
