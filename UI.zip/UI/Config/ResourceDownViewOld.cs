﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Mozart.Studio.TaskModel.UserInterface;
using Mozart.Studio.TaskModel.Projects;
using Mozart.Studio.Application;
using Mozart.Collections;
using DevExpress.XtraPivotGrid;
using DevExpress.XtraCharts;

using Mozart.Studio.UIComponents;
using Mozart.Studio.TaskModel.Utility;

using Mozart.Studio.TaskModel.UserLibrary; //linq2
using DevExpress.XtraEditors.Controls;// linq1

using FabSimulator;
using DevExpress.XtraEditors;
using DevExpress.XtraGrid.Views.Grid;
using FabSimulatorUI.Common;

namespace FabSimulatorUI.Config
{
    public partial class ResourceDownViewOld : XtraPivotGridControlView
    {
        #region Variable&Property

        IExperimentResultItem result;
        ModelDataContext modelDataContext;
        ExpDataContext expDataContext;
        bool initializing;
        bool loading;
        bool comparing;

        string layoutPath;

        List<DownInfo> otherAreas;
        List<DownInfo> photoEqps;

        double horizonHrs;
        string photoArea;

        #endregion

        #region Ctor

        public ResourceDownViewOld(IServiceProvider serviceProvider)
            : base(serviceProvider)
        {
            InitializeComponent();

            this.initializing = true;
            this.ConstructInit();
        }

        protected override void LoadDocument()
        {
            this.LoadInit();
            this.initializing = false;

            this.loading = true;
            this.Query();
            this.loading = false;
        }

        private void Query()
        {
            using (var wc = new Mozart.Studio.UIComponents.WaitCursor())
            {
                this.BindBegin();
                this.BindDo();
                this.BindEnd();
            }
        }

        #endregion

        #region Init

        private void ConstructInit()
        {
        }

        private void LoadInit()
        {
            this.result = this.Document.GetResultItem();

            Globals.InitFactoryTime(this.result);

            this.modelDataContext = result.GetCtx<ModelDataContext>();
            this.expDataContext = result.GetCtx<ExpDataContext>();

            if (double.TryParse(this.expDataContext.Target.Arguments["period"].ToString(), out double period))
                this.horizonHrs = period * 24d;

            this.photoArea = FabSimulatorUI.Helper.GetPhotoArea(this.modelDataContext);
        }
        #endregion 

        private void BindBegin()
        {
            this.gridControl1.BeginUpdate();
        }

        private void BindDo()
        {
            using (var wc = new Mozart.Studio.UIComponents.WaitCursor())
            {
                var eqp = this.modelDataContext.EQP;

                var areaList = eqp.Select(x => x.AREA_ID).Distinct();

                this.otherAreas = GetOtherAreas(areaList);
                this.photoEqps = GetPhotoEqps(areaList);

                SetNxtCheckedListBox(photoEqps);

                this.gridControl1.DataSource = this.otherAreas.ToBindingList();
                this.gridControl2.DataSource = this.photoEqps.Where(x => x.SCANNER_GENERATION == "NXT").ToBindingList(); //PHOTO_TYPE
                this.gridControl3.DataSource = this.photoEqps.Where(x => x.SCANNER_GENERATION == "XT").ToBindingList();
                this.gridControl4.DataSource = this.photoEqps.Where(x => x.SCANNER_GENERATION == "NXE").ToBindingList();

            }
        }

        private void SetNxtCheckedListBox(IEnumerable<DownInfo> photoEqps)
        {
            foreach (var res in photoEqps)
            {
                CheckedListBoxItem item1 = new CheckedListBoxItem(res.RESOURCE_ID);
                CheckedListBoxItem item2 = new CheckedListBoxItem(res.RESOURCE_ID);

                if (res.SCANNER_GENERATION == "NXT")
                    item1.CheckState = CheckState.Checked; //PHOTO_TYPE
                else if (res.SCANNER_GENERATION == "NXE")
                    item2.CheckState = CheckState.Checked;

                this.checkedComboBoxEdit1.Properties.Items.Add(item1);
                this.checkedComboBoxEdit2.Properties.Items.Add(item2);

                res.NXTCheckedListBoxItem = item1;
                res.NXECheckedListBoxItem = item2;
            }
        }

        private List<DownInfo> GetOtherAreas(IEnumerable<string> areaList)
        {
            var otherAreas = from a in areaList.Where(x => x != this.photoArea)
                             select new DownInfo
                             {
                                 AREA_ID = a,
                                 //PHOTO_TYPE = "-", //PHOTO_TYPE
                                 SCANNER_GENERATION = "-",
                                 RESOURCE_ID = "-"
                             };

            return otherAreas.ToList();
        }

        private List<DownInfo> GetPhotoEqps(IEnumerable<string> areaList)
        {
            var eqp = this.modelDataContext.EQP;
            var eqpParam = this.modelDataContext.EQP_PARAM;

            var photoEqps = from a in eqp.Where(x => x.AREA_ID == this.photoArea).OrderBy(x => x.EQP_ID)
                            //join b in eqpParam.Where(x=> x.PARAM_NAME == "IS_NXT") on a.RESOURCE_ID equals b.RESOURCE_ID into outer
                            join b in eqpParam.Where(x => x.PARAM_NAME == "SCANNER_GENERATION") on a.EQP_ID equals b.EQP_ID into outer
                            from o in outer.DefaultIfEmpty()
                            select new DownInfo
                            {
                                AREA_ID = a.AREA_ID,
                                //PHOTO_TYPE = o != null ? (o.PARAM_VALUE == "Y" ? "NXT" : "XT") : "XT",
                                RESOURCE_ID = a.EQP_ID,
                                SCANNER_GENERATION = o != null ? o.PARAM_VALUE : "XT"
                            };

            return photoEqps.ToList();
        }

        private void BindEnd()
        {
            //this.gridControlNonPhoto.EndUpdate();
            List<GridView> gvList = new List<GridView>() { gridView1, gridView2, gridView3, gridView4 };

            foreach (GridView gv in gvList)
            {
                SetCaption(gv);
                SetHeaderOption(gv);
                SetColumnOption(gv, 0, gv != gridView1);
            }
        }

        private void SetCaption(GridView gridView)
        {
            gridView.GridControl.EndUpdate();

            gridView.Columns[0].Caption = "Area ID";
            gridView.Columns[1].Caption = "Photo Type";
            gridView.Columns[2].Caption = "Resource ID";
            gridView.Columns[3].Caption = "Availability (%)";
            gridView.Columns[4].Caption = "UD MTTR (Hour)";
            gridView.Columns[5].Caption = "MTTF (Hour)";
            gridView.Columns[6].Caption = "Uniform Margin (+/-)";
            gridView.Columns[7].Caption = "Expected UD Count";

            if (gridView.GridControl.EmbeddedNavigator.Text == "Non-Photo")
            {
                gridView.Columns[1].Visible = false;
                gridView.Columns[2].Visible = false;
                gridView.Columns[5].Visible = false;
                gridView.Columns[6].Visible = false;
                gridView.Columns[7].Visible = false;
            }
            else
            {
                gridView.Columns[0].Visible = false;
                gridView.Columns[1].Visible = false;
            }

            gridView.Columns[8].Visible = false;
            gridView.Columns[9].Visible = false;

            gridView.BestFitColumns();
            gridView.OptionsView.ColumnAutoWidth = false;
            gridView.OptionsSelection.EnableAppearanceFocusedRow = false;
            // gridView.Columns[i++].Caption = "Photo Type";
        }

        class DownInfo
        {
            public string AREA_ID { get; set; }

            public string SCANNER_GENERATION { get; set; }             //public string PHOTO_TYPE { get; set; }
            public string RESOURCE_ID { get; set; }
            public double AVAILABILITY { get; set; }
            public double UD_MTTR { get; set; }

            public double MTTF_HOUR { get; set; }
            public double UNIFORM_MARGIN { get; set; }
            public int EXPECTED_UD_COUNT { get; set; }

            //+
            public CheckedListBoxItem NXTCheckedListBoxItem { get; set; }
            public CheckedListBoxItem NXECheckedListBoxItem { get; set; }

        }

        private void SaveButton_Click(object sender, EventArgs e)
        {
            GridView gv;
            List<string> applyEqpIds = new List<string>();

            if (IsEmptyValue(out gv,  ref applyEqpIds))
            {
                XtraMessageBox.Show("Please input value (0 or null is not allowed)", "Alert");
                return;
            }
            
            DeleteVdat(applyEqpIds);
            InsertVdat(gv);
        }

        private bool IsEmptyValue(out GridView gv, ref List<string> eqpIdList)
        {
            gv = null;
            //resIdList = null; ;

            if (xtraTabControl1.SelectedTabPage.Text == "Non-Photo")
            {
                gv = this.gridView1;
            }
            else if (xtraTabControl2.SelectedTabPage.Text == "NXT")
            {
                gv = this.gridView2;

            }
            else if (xtraTabControl2.SelectedTabPage.Text == "NXE")
            {
                gv = this.gridView4;
            }
            else if (xtraTabControl2.SelectedTabPage.Text == "XT")
            {
                gv = this.gridView3;
            }
            
            return IsEmpty(gv, ref eqpIdList);
        }

        private bool IsEmpty(GridView gridView, ref List<string> eqpIdList)
        {
            foreach (var row in gridView.GridControl.DataSource as IEnumerable<DownInfo>)
            {
                if (eqpIdList.Contains(row.RESOURCE_ID) == false)
                    eqpIdList.Add(row.RESOURCE_ID);

                if (row.AVAILABILITY == 0 || row.UD_MTTR == 0)
                    return true;

                if (radioGroup1.SelectedIndex == 1)
                {
                    if (row.EXPECTED_UD_COUNT == 0)
                        return true;
                }
                else if (radioGroup1.SelectedIndex == 2)
                {
                    if (row.UNIFORM_MARGIN == 0)
                        return true;
                }
            }

            if (eqpIdList.Count == 1 && eqpIdList.Contains("-"))
                eqpIdList = this.modelDataContext.EQP.Where(x => x.AREA_ID.Contains("PHT") == false).Select(x => x.EQP_ID).ToList();

            return false;
        }

        private void DeleteVdat(List<string> resIdList)
        {
            using (var acc = this.modelDataContext.Target.LocalAccessorFor("EQP_PARAM"))
            {
                var dtable = acc.QueryTable(null, -1, -1);

                List<DataRow> removable = new List<DataRow>();
                foreach (DataRow row in dtable.Rows)
                {
                    if (resIdList.Contains(row["RESOURCE_ID"]))
                    {
                        if (row["PARAM_NAME"].ToString() == "SCHED_DOWN"
                            || row["PARAM_NAME"].ToString() == "UNSCHED_DOWN"
                            || row["PARAM_NAME"].ToString() == "SCANNER_GENERATION") //IS_NXT
                        {
                            removable.Add(row);
                        }
                    }
                }

                removable.ForEach(x => dtable.Rows.Remove(x));

                acc.Save(dtable);
            }
        }

        private void InsertVdat(GridView gv)
        {
            using (var acc = this.modelDataContext.Target.LocalAccessorFor("EQP_PARAM"))
            {
                var dtable = acc.QueryTable(null, -1, -1);

                foreach (var item in gv.GridControl.DataSource as IEnumerable<DownInfo>)
                {
                    bool isPhoto = item.RESOURCE_ID != "-";

                    if (isPhoto)
                    {
                        var nrow = dtable.NewRow();

                        nrow["RESOURCE_ID"] = item.RESOURCE_ID;
                        nrow["PARAM_NAME"] = "UNSCHED_DOWN";
                        nrow["PARAM_VALUE"] = GetParamValue(item, isPhoto);

                        dtable.Rows.Add(nrow);

                        //var isNxtRow = dtable.NewRow();

                        //isNxtRow["RESOURCE_ID"] = item.RESOURCE_ID;
                        //isNxtRow["PARAM_NAME"] = "IS_NXT";
                        //isNxtRow["PARAM_VALUE"] = item.PHOTO_TYPE == "NXT" ? "Y" : "N";

                        //
                        var isNxtRow = dtable.NewRow();

                        isNxtRow["RESOURCE_ID"] = item.RESOURCE_ID;
                        isNxtRow["PARAM_NAME"] = "SCANNER_GENERATION";
                        isNxtRow["PARAM_VALUE"] = item.SCANNER_GENERATION;

                        dtable.Rows.Add(isNxtRow);
                    }
                    else
                    {
                        var eqps = this.modelDataContext.EQP.Where(x => x.AREA_ID == item.AREA_ID && string.IsNullOrEmpty(x.PARENT_EQP_ID)).ToList();
                        foreach(var eqp in eqps)
                        {
                            var nrow = dtable.NewRow();

                            nrow["RESOURCE_ID"] = eqp.EQP_ID;
                            nrow["PARAM_NAME"] = "UNSCHED_DOWN";
                            nrow["PARAM_VALUE"] = GetParamValue(item, isPhoto);

                            dtable.Rows.Add(nrow);
                        }
                    }
                }

                acc.Save(dtable);
            }
        }

        private string GetParamValue(DownInfo item, bool isPhoto)
        {
            string value;
            if (this.radioGroup1.SelectedIndex == 0 || isPhoto == false)
                value = string.Format("Exponential({0});Constant({1})", item.MTTF_HOUR, item.UD_MTTR);
            else if (this.radioGroup1.SelectedIndex == 1)
            {
                var availability = item.AVAILABILITY / 100d;
                var availableHour = this.horizonHrs * availability;
                //var totalDownTime = this.horizonHrs * (1 - availability);
                //var unschedDownTime = item.EXPECTED_UD_COUNT * item.UD_MTTR;
                var udMTTF = item.EXPECTED_UD_COUNT <= 0 ? 0 : Math.Round(availableHour / item.EXPECTED_UD_COUNT, 2);

                var unschedX = Math.Round(udMTTF / 2d, 2);

                value = string.Format("Normal({0});Repeat({1});Constant({2})", unschedX, udMTTF, item.UD_MTTR);
            }
            else
                value = string.Format("Uniform({0});Repeat({1});Constant({2})", item.UNIFORM_MARGIN, item.MTTF_HOUR, item.UD_MTTR);

            return value;
        }

        private void RadioGroup1_SelectedIndexChanged(object sender, EventArgs e)
        {
            RadioGroup edit = sender as RadioGroup;

            SetColumnOption(this.gridView1, edit.SelectedIndex, false);
            SetColumnOption(this.gridView2, edit.SelectedIndex);
            SetColumnOption(this.gridView3, edit.SelectedIndex);
            SetColumnOption(this.gridView4, edit.SelectedIndex);
        }

        private void SetColumnOption(GridView gridView,int radioIndex, bool isPhoto = true)
        {
            int[] editableIndex = new int[] { 4, 7 };
            if (radioIndex == 1)
                editableIndex = new int[] { 4, 7 };
            else if (radioIndex == 2)
                editableIndex = new int[] { 4, 6, 7 };

            if (isPhoto == false)
                editableIndex = new int[] { 3, 4 };

            for (int i = 3; i < 8; i++)
            {
                if (editableIndex.Contains(i))
                {
                    gridView.Columns[i].OptionsColumn.AllowEdit = true;
                    gridView.Columns[i].OptionsColumn.AllowFocus = true;
                    gridView.Columns[i].AppearanceCell.BackColor = Color.FloralWhite;
                    gridView.Columns[i].AppearanceCell.ForeColor = Color.Black;
                }
                else
                {
                    gridView.Columns[i].OptionsColumn.AllowEdit = false;
                    gridView.Columns[i].OptionsColumn.AllowFocus = false;
                    gridView.Columns[i].AppearanceCell.BackColor = Color.White;
                    gridView.Columns[i].AppearanceCell.ForeColor = Color.LightGray;
                }
            }

            gridView.RowCellStyle += (sender, e) => 
            {
                GridView view = sender as GridView;

                if (view.GetRowCellValue(e.RowHandle, "SCANNER_GENERATION").ToString() == "-") //PHOTO_TYPE
                {
                    if (e.Column.FieldName == "AREA_ID" || e.Column.FieldName == "SCANNER_GENERATION" || e.Column.FieldName == "RESOURCE_ID")
                        return;

                    if (e.Column.FieldName == "AVAILABILITY")
                    {
                        if (isPhoto)
                        {
                            e.Appearance.BackColor = Color.White;
                            e.Appearance.ForeColor = Color.LightGray;
                        }
                        else
                        {
                            e.Appearance.BackColor = Color.FloralWhite;
                            e.Appearance.ForeColor = Color.Black;
                        }
                    }
                    else if (e.Column.FieldName == "UD_MTTR")
                    {
                        e.Appearance.BackColor = Color.FloralWhite;
                        e.Appearance.ForeColor = Color.Black;
                    }
                    else
                    { 
                        e.Appearance.BackColor = Color.White;
                        e.Appearance.ForeColor = Color.LightGray;
                    }
                }
            };

            gridView.CustomRowCellEditForEditing += (sender, e) =>
            {
                GridView view = sender as GridView;

                if (view.GetRowCellValue(e.RowHandle, "SCANNER_GENERATION").ToString() == "-")
                {
                    if (e.Column.FieldName == "AREA_ID" || e.Column.FieldName == "SCANNER_GENERATION" || e.Column.FieldName == "RESOURCE_ID")
                        return;

                    if (e.Column.FieldName == "AVAILABILITY" || e.Column.FieldName == "UD_MTTR")
                    {
                        //e.RepositoryItem = new DevExpress.XtraEditors.Repository.RepositoryItem() { ReadOnly = false };
                    }
                    else
                    {
                        e.RepositoryItem = new DevExpress.XtraEditors.Repository.RepositoryItem() { ReadOnly = true };
                    }
                }
            };
        }

        private void SetHeaderOption(GridView gv)
        {
            for (int i = 0; i < 3; i++)
            {
                gv.Columns[i].OptionsColumn.AllowEdit = false;
                gv.Columns[i].OptionsColumn.AllowFocus = false;
                gv.Columns[i].AppearanceCell.BackColor = Color.WhiteSmoke;
            }
        }

        private void CheckedComboBoxEdit1_EditValueChanged(object sender, EventArgs e)
        {
            if (this.loading)
                return;

            if (this.comparing)
                return;

            this.comparing = true;
            foreach (var info in this.photoEqps)
            {
                if (info.NXTCheckedListBoxItem.CheckState == CheckState.Checked)
                {
                    info.NXECheckedListBoxItem.CheckState = CheckState.Unchecked;
                    info.SCANNER_GENERATION = "NXT";
                }
                else if (info.NXECheckedListBoxItem.CheckState == CheckState.Checked)
                {
                    info.SCANNER_GENERATION = "NXE";
                }
                else
                {
                    info.SCANNER_GENERATION = "XT";
                }
            }
            this.comparing = false;

            this.gridControl2.DataSource = this.photoEqps.Where(x => x.SCANNER_GENERATION == "NXT").ToBindingList(); //PHOTO_TYPE
            this.gridControl3.DataSource = this.photoEqps.Where(x => x.SCANNER_GENERATION == "XT").ToBindingList();
            this.gridControl4.DataSource = this.photoEqps.Where(x => x.SCANNER_GENERATION == "NXE").ToBindingList();

        }

        //+
        private void checkedComboBoxEdit2_EditValueChanged(object sender, EventArgs e)
        {
            if (this.loading)
                return;

            if (this.comparing)
                return;

            this.comparing = true;
            foreach (var info in this.photoEqps)
            {
                if (info.NXECheckedListBoxItem.CheckState == CheckState.Checked)
                {
                    info.NXTCheckedListBoxItem.CheckState = CheckState.Unchecked;
                    info.SCANNER_GENERATION = "NXE";
                }
                else if (info.NXTCheckedListBoxItem.CheckState == CheckState.Checked)
                {
                    info.SCANNER_GENERATION = "NXT";
                }
                else
                {
                    info.SCANNER_GENERATION = "XT";
                }
            }
            this.comparing = false;


            this.gridControl2.DataSource = this.photoEqps.Where(x => x.SCANNER_GENERATION == "NXT").ToBindingList(); //PHOTO_TYPE
            this.gridControl3.DataSource = this.photoEqps.Where(x => x.SCANNER_GENERATION == "XT").ToBindingList();
            this.gridControl4.DataSource = this.photoEqps.Where(x => x.SCANNER_GENERATION == "NXE").ToBindingList();
        }

        private void GridView1_CellValueChanged(object sender, DevExpress.XtraGrid.Views.Base.CellValueChangedEventArgs e)
        {
            if (e.Column.FieldName == "MTTF_HOUR")
                return;

            GridView view = sender as GridView;
            var availability = (double)view.GetRowCellValue(e.RowHandle, "AVAILABILITY") / 100d;
            var ud_mttr = (double)view.GetRowCellValue(e.RowHandle, "UD_MTTR");

            var availableHour = this.horizonHrs * availability;
            var downFrequency = this.horizonHrs * (1d - availability) / ud_mttr;

            var mttf = Math.Round(availableHour / downFrequency, 2);

            view.SetRowCellValue(e.RowHandle, "MTTF_HOUR", mttf);
        }

        private void XtraTabControl1_SelectedPageChanged(object sender, DevExpress.XtraTab.TabPageChangedEventArgs e)
        {
            int itemCount = this.radioGroup1.Properties.Items.Count;
            
            if (e.Page.Text == "Non-Photo")
            {
                this.radioGroup1.SelectedIndex = 0;
                this.radioGroup1.Properties.Items[1].Enabled = false;
                this.radioGroup1.Properties.Items[2].Enabled = false;
            }
            else
            {
                this.radioGroup1.Properties.Items[1].Enabled = true;
                this.radioGroup1.Properties.Items[2].Enabled = true;
            }
        }

        private void GridView2_CellValueChanged(object sender, DevExpress.XtraGrid.Views.Base.CellValueChangedEventArgs e)
        {
            if (e.Column.FieldName == "MTTF_HOUR")
                return;

            if (e.Column.FieldName == "AVAILABILITY")
                return;

            GridView view = sender as GridView;
#if true
            var ud_mttr = (double)view.GetRowCellValue(e.RowHandle, "UD_MTTR");
            var downFrequency = (int)view.GetRowCellValue(e.RowHandle, "EXPECTED_UD_COUNT");

            var availability = Math.Round(1 - (ud_mttr * downFrequency / this.horizonHrs), 4);
            var availableHour = this.horizonHrs * availability;

            var mttf = Math.Round(availableHour / downFrequency, 2);

            view.SetRowCellValue(e.RowHandle, "AVAILABILITY", availability * 100);
            view.SetRowCellValue(e.RowHandle, "MTTF_HOUR", mttf);

#else
            var availability = (double)view.GetRowCellValue(e.RowHandle, "AVAILABILITY") / 100d;
            var ud_mttr = (double)view.GetRowCellValue(e.RowHandle, "UD_MTTR");

            var availableHour = this.horizonHrs * availability;
            var downFrequency = this.horizonHrs * (1d - availability) / ud_mttr;

            var mttf = Math.Round(availableHour / downFrequency, 2);

            view.SetRowCellValue(e.RowHandle, "MTTF_HOUR", mttf); 
#endif
        }

        private void GridView3_CellValueChanged(object sender, DevExpress.XtraGrid.Views.Base.CellValueChangedEventArgs e)
        {
            if (e.Column.FieldName == "MTTF_HOUR")
                return;

            if (e.Column.FieldName == "AVAILABILITY")
                return;

            GridView view = sender as GridView;
#if true
            var ud_mttr = (double)view.GetRowCellValue(e.RowHandle, "UD_MTTR");
            var downFrequency = (int)view.GetRowCellValue(e.RowHandle, "EXPECTED_UD_COUNT");

            var availability = Math.Round(1 - (ud_mttr * downFrequency / this.horizonHrs), 4);
            var availableHour = this.horizonHrs * availability;

            var mttf = Math.Round(availableHour / downFrequency, 2);

            view.SetRowCellValue(e.RowHandle, "AVAILABILITY", availability * 100);
            view.SetRowCellValue(e.RowHandle, "MTTF_HOUR", mttf);
#else
            var availability = (double)view.GetRowCellValue(e.RowHandle, "AVAILABILITY") / 100d;
            var ud_mttr = (double)view.GetRowCellValue(e.RowHandle, "UD_MTTR");

            var availableHour = this.horizonHrs * availability;
            var downFrequency = this.horizonHrs * (1d - availability) / ud_mttr;

            var mttf = Math.Round(availableHour / downFrequency, 2);

            view.SetRowCellValue(e.RowHandle, "MTTF_HOUR", mttf); 
#endif
        }

        private void GridView4_CellValueChanged(object sender, DevExpress.XtraGrid.Views.Base.CellValueChangedEventArgs e)
        {
            if (e.Column.FieldName == "MTTF_HOUR")
                return;

            if (e.Column.FieldName == "AVAILABILITY")
                return;

            GridView view = sender as GridView;
#if true
            var ud_mttr = (double)view.GetRowCellValue(e.RowHandle, "UD_MTTR");
            var downFrequency = (int)view.GetRowCellValue(e.RowHandle, "EXPECTED_UD_COUNT");

            var availability = Math.Round(1 - (ud_mttr * downFrequency / this.horizonHrs), 4);
            var availableHour = this.horizonHrs * availability;

            var mttf = Math.Round(availableHour / downFrequency, 2);

            view.SetRowCellValue(e.RowHandle, "AVAILABILITY", availability * 100);
            view.SetRowCellValue(e.RowHandle, "MTTF_HOUR", mttf);
#else
            var availability = (double)view.GetRowCellValue(e.RowHandle, "AVAILABILITY") / 100d;
            var ud_mttr = (double)view.GetRowCellValue(e.RowHandle, "UD_MTTR");

            var availableHour = this.horizonHrs * availability;
            var downFrequency = this.horizonHrs * (1d - availability) / ud_mttr;

            var mttf = Math.Round(availableHour / downFrequency, 2);

            view.SetRowCellValue(e.RowHandle, "MTTF_HOUR", mttf); 
#endif
        }

    }
}
