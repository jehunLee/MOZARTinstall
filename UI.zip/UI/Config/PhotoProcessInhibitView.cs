﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Mozart.Studio.TaskModel.UserInterface;
using Mozart.Studio.TaskModel.Projects;
using Mozart.Studio.Application;
using Mozart.Collections;
using DevExpress.XtraPivotGrid;
using DevExpress.XtraCharts;

using Mozart.Studio.UIComponents;
using Mozart.Studio.TaskModel.Utility;

using Mozart.Studio.TaskModel.UserLibrary; //linq2
using DevExpress.XtraEditors.Controls;// linq1

using FabSimulator;
using DevExpress.XtraEditors;
using DevExpress.XtraGrid.Views.Grid;
using DevExpress.XtraEditors.Repository;
using DevExpress.XtraGrid;
using System.ComponentModel.DataAnnotations;
using FabSimulatorUI.Common;

namespace FabSimulatorUI.Config
{
    public partial class PhotoProcessInhibitView : XtraPivotGridControlView
    {
        #region Variable&Property

        IExperimentResultItem result;
        ModelDataContext modelDataContext;
        ExpDataContext expDataContext;
        bool initializing;
        bool loading;
        bool setDefault;

        string layoutPath;

        List<EqpInfo> photoEqps;
        List<ProcessInhibitInfo> currentOriginData = new List<ProcessInhibitInfo>();
        List<ProcessInhibitInfo> currentViewData = new List<ProcessInhibitInfo>();

        string lineID;
        string photoArea;

        MultiDictionary<string, string> backupDict = new MultiDictionary<string, string>();

        #endregion

        #region Ctor

        public PhotoProcessInhibitView(IServiceProvider serviceProvider)
            : base(serviceProvider)
        {
            InitializeComponent();

            this.initializing = true;
            this.ConstructInit();
        }

        protected override void LoadDocument()
        {
            this.LoadInit();
            this.initializing = false;

            this.loading = true;
            this.Query();
            this.loading = false;
        }

        private void Query()
        {
            using (var wc = new Mozart.Studio.UIComponents.WaitCursor())
            {
                this.BindBegin();
                this.BindDo();
                this.BindEnd();
            }
        }

        #endregion

        #region Init

        private void ConstructInit()
        {
        }

        private void LoadInit()
        {
            this.result = this.Document.GetResultItem();

            Globals.InitFactoryTime(this.result);

            this.modelDataContext = result.GetCtx<ModelDataContext>();
            this.expDataContext = result.GetCtx<ExpDataContext>();

            //this.lineID = this.expDataContext.Target.Arguments["LineID"].ToString();

            this.photoArea = FabSimulatorUI.Helper.GetPhotoArea(this.modelDataContext);

            this.photoEqps = GetPhotoEqps();
        }
        #endregion 

        private void BindBegin()
        {
            this.gridControl1.BeginUpdate();
        }

        private void BindDo()
        {
            using (var wc = new Mozart.Studio.UIComponents.WaitCursor())
            {
                SetEqpLookupEdit();
                SetSDLookupEdit();
                SetNumeric();
                SetBackupDict();

                FillGrid();
            }
        }

        private void SetBackupDict()
        {
            foreach (var item in modelDataContext.EQP_PARAM.Where(x => x.PARAM_NAME == "BACKUP_EQP"))
            {
                this.backupDict.Add(item.EQP_ID, item.PARAM_VALUE.Split(';').First());
            }

            foreach (var item in this.photoEqps)
            {
                foreach (var item2 in this.photoEqps)
                {
                    if (item == item2)
                        continue;

                    if (item.TYPE != item2.TYPE)
                        continue;

                    this.backupDict.Add(item.RESOURCE_ID, item2.RESOURCE_ID);
                }
            }
        }

        private void SetNumeric()
        {
            this.numericUpDown1.Value = 30;
            this.numericUpDown2.Value = 30;
            this.numericUpDown3.Value = 1;
            this.numericUpDown4.Value = 1;

            this.numericUpDown1.DecimalPlaces = 3;
            this.numericUpDown2.DecimalPlaces = 3;
            this.numericUpDown3.DecimalPlaces = 3;
            this.numericUpDown4.DecimalPlaces = 3;
        }

        private void FillGrid()
        {
            SetCurrentOriginData();

            SetCurrentViewData();

            this.setDefault = true;

            //SetRepositoryItem();
        }

        private void SetCurrentViewData()
        {
            // numeric을 건드려도 사용자가 선택한 backup eqp는 유지하기 위함
            Dictionary<(string, string), string> backupTemp = new Dictionary<(string, string), string>();
            foreach (var row in this.currentViewData)
            {
                backupTemp.Add((row.MFG_PRODUCT_ID, row.OPER_ID), row.BACKUP_PHOTO);
            }

            this.currentViewData.Clear();

            int i = 0;
            foreach (var org in currentOriginData)
            {
                if (this.checkBox1.Checked && org.IS_STACKING == false)
                    continue;

                if (org.INHIBIT_START == DateTime.MinValue || org.INHIBIT_END == DateTime.MaxValue)
                    continue;

                ProcessInhibitInfo view = new ProcessInhibitInfo();
                view.LAYER = org.LAYER;
                view.MFG_PRODUCT_ID = org.MFG_PRODUCT_ID;
                view.OPER_ID = org.OPER_ID;

                var key = (org.MFG_PRODUCT_ID, org.OPER_ID);
                view.BACKUP_PHOTO = backupTemp.ContainsKey(key) ? backupTemp[key] : org.BACKUP_PHOTO;

                var preValue = (double)(this.numericUpDown1.Value * -1 + this.numericUpDown3.Value * i);
                var postValue = (double)(this.numericUpDown2.Value + this.numericUpDown4.Value * i);

                view.INHIBIT_START = org.INHIBIT_START.AddDays(preValue);
                view.INHIBIT_END = org.INHIBIT_END.AddDays(postValue);
                view.IS_STACKING = org.IS_STACKING;

                this.currentViewData.Add(view);

                i++;
            }

            backupTemp.Clear();

            this.gridControl1.DataSource = this.currentViewData;
            this.gridControl1.RefreshDataSource();

            this.gridView1.BestFitColumns();
        }

        private void SetCurrentOriginData()
        {
            var stackingInfo = modelDataContext.ROUTE_STEP_PARAM.Where(x => x.PARAM_NAME == "IS_STACKING" && x.PARAM_VALUE == "Y");

            var eqp = this.lookUpEdit1.Text;
            var infos = from a in modelDataContext.ARRANGE.Where(x => x.EQP_ID == eqp)
                        join b in modelDataContext.PRODUCT on a.PART_ID equals b.PART_ID
                        join c in modelDataContext.ROUTE_STEP on new { b.ROUTE_ID, a.STEP_ID } equals new { c.ROUTE_ID, c.STEP_ID }
                        join d in stackingInfo on new { b.ROUTE_ID, a.STEP_ID } equals new { d.ROUTE_ID, d.STEP_ID } into outer
                        from o in outer.DefaultIfEmpty()
                        let pmInfo = (this.lookUpEdit2.EditValue) as PMInfo
                        select new ProcessInhibitInfo
                        {
                            LAYER = int.Parse(c.LAYER_ID, 0),
                            MFG_PRODUCT_ID = a.PART_ID,
                            OPER_ID = a.STEP_ID,
                            INHIBIT_START = pmInfo != null ? pmInfo.START_DATETIME : DateTime.MinValue,
                            INHIBIT_END = pmInfo != null ? pmInfo.END_DATETIME : DateTime.MinValue,
                            BACKUP_PHOTO = this.backupDict[eqp].First(),
                            IS_STACKING = o != null
                        };

            this.currentOriginData = infos.OrderBy(x => x.LAYER).ThenBy(x => x.MFG_PRODUCT_ID).ThenBy(x => x.OPER_ID).ToList();
        }

        private void SetRepositoryItem()
        {
            for (int i = 3; i < gridView1.Columns.Count; i++)
            {
                RepositoryItemCheckEdit riCheckEdit = new RepositoryItemCheckEdit();
                riCheckEdit.NullStyle = StyleIndeterminate.Unchecked;

                gridControl1.RepositoryItems.Add(riCheckEdit);
                gridView1.Columns[i].ColumnEdit = riCheckEdit;
            }
        }

        private void SetEqpLookupEdit()
        {
            this.lookUpEdit1.Properties.DataSource = this.photoEqps;
            this.lookUpEdit1.Properties.DisplayMember = "RESOURCE_ID";
            this.lookUpEdit1.Properties.NullText = string.Empty;
            this.lookUpEdit1.ItemIndex = 0;
        }

        private void SetSDLookupEdit()
        {
            var sd = (from a in this.modelDataContext.EQP_DOWN_SCHED.Where(x => x.EQP_ID == this.lookUpEdit1.Text)
                      select new PMInfo
                      {
                          START_DATETIME = a.START_DATETIME,
                          END_DATETIME = a.END_DATETIME,
                      }).OrderBy(x => x.START_DATETIME).ToList();

            this.lookUpEdit2.Properties.DataSource = sd;
            this.lookUpEdit2.Properties.DisplayMember = "PERIOD";
            this.lookUpEdit2.Properties.NullText = string.Empty;
            this.lookUpEdit2.ItemIndex = 0;

            if (sd.Count == 0)
            {
                this.gridControl1.DataSource = null;
            }
        }

        private List<EqpInfo> GetPhotoEqps()
        {
            var eqp = this.modelDataContext.EQP;
            var eqpParam = this.modelDataContext.EQP_PARAM;

            var photoEqps = from a in eqp.Where(x => x.AREA_ID == this.photoArea).OrderBy(x => x.EQP_ID)
                            join b in eqpParam.Where(x => x.PARAM_NAME == "SCANNER_GENERATION") on a.EQP_ID equals b.EQP_ID into outer
                            from o in outer.DefaultIfEmpty()
                            select new EqpInfo
                            {
                                RESOURCE_ID = a.EQP_ID,
                                TYPE = o != null ? o.PARAM_VALUE : "XT"
                            };

            return photoEqps.OrderBy(x=> x.RESOURCE_ID).ToList();
        }

        private void BindEnd()
        {
            this.gridControl1.EndUpdate();

            this.gridView1.BestFitColumns();
            this.gridView1.OptionsView.ColumnAutoWidth = false;

            this.gridView1.OptionsSelection.EnableAppearanceFocusedRow = false;

            SetCaption();

            SetHeaderOption();
        }

        private void SetCaption()
        {
            this.gridView1.Columns[0].Caption = "Layer";

            this.gridView1.Columns[3].Caption = "Inhibit Start";
            this.gridView1.Columns[3].DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.gridView1.Columns[3].DisplayFormat.FormatString = "yyyy-MM-dd HH:mm:ss";
            
            this.gridView1.Columns[4].Caption = "Inhibit End";
            this.gridView1.Columns[4].DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.gridView1.Columns[4].DisplayFormat.FormatString = "yyyy-MM-dd HH:mm:ss";

            this.gridView1.Columns[5].Caption = "Backup Photo";
        }

        class ProcessInhibitInfo
        {
            public int LAYER { get; set; }

            public string MFG_PRODUCT_ID { get; set; }
            public string OPER_ID { get; set; }
            public DateTime INHIBIT_START { get; set; }
            public DateTime INHIBIT_END { get; set; }
            public string BACKUP_PHOTO { get; set; }

            [Display(Order = -1)]
            public bool IS_STACKING { get; set; }
        }

        class EqpInfo
        {
            public string RESOURCE_ID { get; set; }
            public string TYPE { get; set; }
        }

        class PMInfo
        {
            public DateTime START_DATETIME { get; set; }
            public DateTime END_DATETIME { get; set; }

            [Display(Order = -1)]
            public string PERIOD
            {
                get { return START_DATETIME.ToString("yyyy-MM-dd HH:mm:ss") + " ~ " + END_DATETIME.ToString("yyyy-MM-dd HH:mm:ss"); }
            }
        }

        private void SaveButton_Click(object sender, EventArgs e)
        {
            foreach (var item in this.gridControl1.DataSource as List<ProcessInhibitInfo>)
            {
                if (item.BACKUP_PHOTO == null || item.BACKUP_PHOTO == string.Empty)
                {
                    XtraMessageBox.Show("Invalid Backup Photo", "Alert");
                    return;
                }

                if (item.INHIBIT_START > item.INHIBIT_END)
                {
                    XtraMessageBox.Show("Invalid DateTime", "Alert");
                    return;
                }
            }

            DeleteVdat();

            InsertVdat();
        }

        private void DeleteVdat()
        {
            using (var acc = this.modelDataContext.Target.LocalAccessorFor("PROCESS_INHIBIT"))
            {
                var dtable = acc.QueryTable(null, -1, -1);

                List<DataRow> removable = new List<DataRow>();

                foreach (DataRow row in dtable.Rows)
                {
                    if (row["RESOURCE_ID"].ToString() == this.lookUpEdit1.Text)
                        removable.Add(row);
                }

                removable.ForEach(x => dtable.Rows.Remove(x));

                acc.Save(dtable);
            }
        }

        private void InsertVdat()
        {
            using (var acc = this.modelDataContext.Target.LocalAccessorFor("PROCESS_INHIBIT"))
            {
                var dtable = acc.QueryTable(null, -1, -1);

                foreach (var item in this.gridControl1.DataSource as List<ProcessInhibitInfo>)
                {
                    if (item.BACKUP_PHOTO == null)
                        continue;

                    var nrow = dtable.NewRow();

                    //nrow["LINE_ID"] = this.lineID;
                    nrow["MFG_PRODUCT_ID"] = item.MFG_PRODUCT_ID;
                    nrow["OPER_ID"] = item.OPER_ID;
                    nrow["RESOURCE_ID"] = this.lookUpEdit1.Text;
                    nrow["BACKUP_RESOURCE_ID"] = item.BACKUP_PHOTO;
                    nrow["START_DATE"] = item.INHIBIT_START;
                    nrow["END_DATE"] = item.INHIBIT_END;

                    dtable.Rows.Add(nrow);
                }

                acc.Save(dtable);
            }
        }

        private void SetHeaderOption()
        {
            for (int i = 0; i < 3; i++)
            {
                this.gridView1.Columns[i].OptionsColumn.AllowEdit = false;
                this.gridView1.Columns[i].OptionsColumn.AllowFocus = false;
                this.gridView1.Columns[i].AppearanceCell.BackColor = Color.WhiteSmoke;
            }
        }

        private void GridView1_CustomRowCellEdit(object sender, CustomRowCellEditEventArgs e)
        {
            if (e.Column.FieldName == "BACKUP_PHOTO")
            {
                var eqps = this.backupDict[this.lookUpEdit1.Text].ToList();

                e.RepositoryItem = null;
                e.RepositoryItem = GetRepositoryItem(eqps);

                if (this.setDefault)
                    this.gridView1.SetRowCellValue(e.RowHandle, e.Column.FieldName, (e.RepositoryItem as RepositoryItemComboBox).Items[0]);
            }

            if (e.Column.FieldName == "INHIBIT_START" || e.Column.FieldName == "INHIBIT_END")
            {
                e.RepositoryItem = null;

                var dateEdit = new RepositoryItemDateEdit();
                dateEdit.CalendarTimeEditing = DevExpress.Utils.DefaultBoolean.True;
                dateEdit.EditMask = "yyyy-MM-dd HH:mm:ss";

                e.RepositoryItem = dateEdit;
            }
        }

        private RepositoryItemComboBox GetRepositoryItem(List<string> eqps)
        {
            RepositoryItemComboBox repositoryItemCombo = new RepositoryItemComboBox();
            repositoryItemCombo.Items.AddRange(eqps);

            repositoryItemCombo.SelectedIndexChanged += (sender, e) =>
            {
                this.setDefault = false;
            };

            return repositoryItemCombo;
        }

        private void GridView1_ShowingEditor(object sender, CancelEventArgs e)
        {
            // make cell disable condition
            e.Cancel = (bool)this.gridView1.GetRowCellValue(this.gridView1.FocusedRowHandle, "IS_STACKING") == false;
        }

        private void GridView1_RowStyle(object sender, RowStyleEventArgs e)
        {
            //if (e.RowHandle < 0)
            //    return;

            //bool noRecipe = this.gridView1.GetRowCellValue(e.RowHandle, "RECIPE").ToString() == "No Recipe";
            //if (noRecipe)
            //{
            //    e.Appearance.ForeColor = Color.Red;
            //}
        }

        private void gridView1_RowCellStyle(object sender, RowCellStyleEventArgs e)
        {
            if (e.RowHandle < 0)
                return;

            var stackingValue = this.gridView1.GetRowCellValue(e.RowHandle, "IS_STACKING");
            if (stackingValue != null)
            {
                bool isStacking = (bool)stackingValue;
                if (isStacking == false)
                {
                    e.Appearance.ForeColor = Color.Gray;
                    e.Appearance.BackColor = Color.LightGray;
                }
            }
        }

        private void lookUpEdit1_EditValueChanged(object sender, EventArgs e)
        {
            if (this.loading)
                return;

            this.SetSDLookupEdit();
        }

        private void lookUpEdit2_EditValueChanged(object sender, EventArgs e)
        {
            if (this.loading)
                return;

            this.FillGrid();
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (this.loading)
                return;

            SetCurrentViewData();
        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            if (this.loading)
                return;

            if (this.checkBox2.Checked)
            {
                this.numericUpDown3.Value = 1;
                this.numericUpDown4.Value = 1;

                this.numericUpDown3.Enabled = false;
                this.numericUpDown4.Enabled = false;
            }
            else
            {
                this.numericUpDown3.Enabled = true;
                this.numericUpDown4.Enabled = true;
            }

            SetCurrentViewData();
        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {
            if (this.loading)
                return;

            SetCurrentViewData();
        }

        private void numericUpDown2_ValueChanged(object sender, EventArgs e)
        {
            if (this.loading)
                return;

            SetCurrentViewData();
        }

        private void numericUpDown3_ValueChanged(object sender, EventArgs e)
        {
            if (this.loading)
                return;

            SetCurrentViewData();
        }

        private void numericUpDown4_ValueChanged(object sender, EventArgs e)
        {
            if (this.loading)
                return;

            SetCurrentViewData();
        }
    }
}