﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DevExpress.XtraWaitForm;

namespace FabSimulatorUI.Config
{
    class WaitForm1 : WaitForm
    {
        private ProgressPanel progressPanel1;

        public WaitForm1()
        {
            InitializeComponent();
            this.progressPanel1.AutoHeight = false;
            this.progressPanel1.Caption = "Please Wait";
            this.progressPanel1.ShowCaption = true;
            this.progressPanel1.Description = "In progress...";
            this.progressPanel1.ShowDescription = true;
            //this.progressPanel1.ToolTip = "";
            //this.progressPanel1.ShowToolTips = true;
            this.progressPanel1.WaitAnimationType = DevExpress.Utils.Animation.WaitingAnimatorType.Ring;
            this.progressPanel1.CaptionToDescriptionDistance = 5;
        }

        private void InitializeComponent()
        {
            DevExpress.XtraSplashScreen.SplashScreenManager splashScreenManager1 = new DevExpress.XtraSplashScreen.SplashScreenManager(this, null, true, true);
            this.progressPanel1 = new DevExpress.XtraWaitForm.ProgressPanel();
            this.SuspendLayout();
            // 
            // splashScreenManager1
            // 
            splashScreenManager1.ClosingDelay = 500;
            // 
            // progressPanel1
            // 
            this.progressPanel1.Appearance.BackColor = System.Drawing.Color.Transparent;
            this.progressPanel1.Appearance.Options.UseBackColor = true;
            this.progressPanel1.BarAnimationElementThickness = 2;
            this.progressPanel1.Location = new System.Drawing.Point(12, 12);
            this.progressPanel1.Name = "progressPanel1";
            this.progressPanel1.Size = new System.Drawing.Size(229, 64);
            this.progressPanel1.TabIndex = 0;
            this.progressPanel1.Text = "progressPanel1";
            // 
            // WaitForm1
            // 
            this.ClientSize = new System.Drawing.Size(254, 88);
            this.Controls.Add(this.progressPanel1);
            this.Name = "WaitForm1";
            this.ResumeLayout(false);

        }
    }
}
