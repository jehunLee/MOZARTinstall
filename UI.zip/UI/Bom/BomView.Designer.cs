﻿namespace FabSimulatorUI.Bom
{
    partial class BomView
    {
        /// <summary> 
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 구성 요소 디자이너에서 생성한 코드

        /// <summary> 
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마십시오.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            emptySpaceItem3 = new DevExpress.XtraLayout.EmptySpaceItem();
            panelMainView = new Panel();
            elementHost1 = new System.Windows.Forms.Integration.ElementHost();
            layoutControl1 = new DevExpress.XtraLayout.LayoutControl();
            layoutControlGroup1 = new DevExpress.XtraLayout.LayoutControlGroup();
            layoutControlItem3 = new DevExpress.XtraLayout.LayoutControlItem();
            panelBack = new Panel();
            expandablePanel1 = new Mozart.Studio.UIComponents.ExpandablePanel();
            convertButton = new Button();
            comboBoxEdit1 = new DevExpress.XtraEditors.ComboBoxEdit();
            saveButton = new Button();
            labe1 = new Label();
            panelControl1 = new DevExpress.XtraEditors.PanelControl();
            dockManager1 = new DevExpress.XtraBars.Docking.DockManager(components);
            dockPanel1 = new DevExpress.XtraBars.Docking.DockPanel();
            dockPanel1_Container = new DevExpress.XtraBars.Docking.ControlContainer();
            gridControl1 = new DevExpress.XtraGrid.GridControl();
            gridView1 = new DevExpress.XtraGrid.Views.Grid.GridView();
            ((System.ComponentModel.ISupportInitialize)emptySpaceItem3).BeginInit();
            panelMainView.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)layoutControl1).BeginInit();
            layoutControl1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)layoutControlGroup1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)layoutControlItem3).BeginInit();
            panelBack.SuspendLayout();
            expandablePanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)comboBoxEdit1.Properties).BeginInit();
            ((System.ComponentModel.ISupportInitialize)panelControl1).BeginInit();
            panelControl1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dockManager1).BeginInit();
            dockPanel1.SuspendLayout();
            dockPanel1_Container.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)gridControl1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)gridView1).BeginInit();
            SuspendLayout();
            // 
            // emptySpaceItem3
            // 
            emptySpaceItem3.AllowHotTrack = false;
            emptySpaceItem3.Location = new Point(0, 0);
            emptySpaceItem3.Name = "emptySpaceItem3";
            emptySpaceItem3.Size = new Size(688, 10);
            emptySpaceItem3.TextSize = new Size(0, 0);
            // 
            // panelMainView
            // 
            panelMainView.Controls.Add(elementHost1);
            panelMainView.Location = new Point(12, 12);
            panelMainView.Margin = new Padding(3, 4, 3, 4);
            panelMainView.Name = "panelMainView";
            panelMainView.Size = new Size(1522, 657);
            panelMainView.TabIndex = 6;
            // 
            // elementHost1
            // 
            elementHost1.Dock = DockStyle.Fill;
            elementHost1.Location = new Point(0, 0);
            elementHost1.Margin = new Padding(3, 4, 3, 4);
            elementHost1.Name = "elementHost1";
            elementHost1.Size = new Size(1522, 657);
            elementHost1.TabIndex = 0;
            elementHost1.Text = "elementHost1";
            elementHost1.ChildChanged += elementHost1_ChildChanged;
            // 
            // layoutControl1
            // 
            layoutControl1.Controls.Add(panelMainView);
            layoutControl1.Dock = DockStyle.Fill;
            layoutControl1.Location = new Point(0, 0);
            layoutControl1.Margin = new Padding(3, 4, 3, 4);
            layoutControl1.Name = "layoutControl1";
            layoutControl1.OptionsCustomizationForm.DesignTimeCustomizationFormPositionAndSize = new Rectangle(2462, 291, 597, 350);
            layoutControl1.Root = layoutControlGroup1;
            layoutControl1.Size = new Size(1546, 681);
            layoutControl1.TabIndex = 0;
            layoutControl1.Text = "layoutControl1";
            // 
            // layoutControlGroup1
            // 
            layoutControlGroup1.CustomizationFormText = "layoutControlGroup1";
            layoutControlGroup1.EnableIndentsWithoutBorders = DevExpress.Utils.DefaultBoolean.True;
            layoutControlGroup1.GroupBordersVisible = false;
            layoutControlGroup1.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] { layoutControlItem3 });
            layoutControlGroup1.Name = "layoutControlGroup1";
            layoutControlGroup1.Size = new Size(1546, 681);
            layoutControlGroup1.TextVisible = false;
            // 
            // layoutControlItem3
            // 
            layoutControlItem3.Control = panelMainView;
            layoutControlItem3.CustomizationFormText = "layoutControlItem3";
            layoutControlItem3.Location = new Point(0, 0);
            layoutControlItem3.Name = "layoutControlItem3";
            layoutControlItem3.Size = new Size(1526, 661);
            layoutControlItem3.TextSize = new Size(0, 0);
            layoutControlItem3.TextVisible = false;
            // 
            // panelBack
            // 
            panelBack.BackColor = Color.White;
            panelBack.Controls.Add(layoutControl1);
            panelBack.Dock = DockStyle.Fill;
            panelBack.Location = new Point(2, 101);
            panelBack.Margin = new Padding(3, 4, 3, 4);
            panelBack.Name = "panelBack";
            panelBack.Size = new Size(1546, 681);
            panelBack.TabIndex = 0;
            // 
            // expandablePanel1
            // 
            expandablePanel1.Controls.Add(convertButton);
            expandablePanel1.Controls.Add(comboBoxEdit1);
            expandablePanel1.Controls.Add(saveButton);
            expandablePanel1.Controls.Add(labe1);
            expandablePanel1.Dock = DockStyle.Top;
            expandablePanel1.ForeColor = Color.SteelBlue;
            expandablePanel1.Location = new Point(2, 2);
            expandablePanel1.Margin = new Padding(3, 4, 3, 4);
            expandablePanel1.Name = "expandablePanel1";
            expandablePanel1.Size = new Size(1546, 99);
            expandablePanel1.TabIndex = 1;
            expandablePanel1.Text = "BOM";
            expandablePanel1.UseAnimation = true;
            // 
            // convertButton
            // 
            convertButton.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            convertButton.Location = new Point(2588, 45);
            convertButton.Margin = new Padding(3, 4, 3, 4);
            convertButton.Name = "convertButton";
            convertButton.Size = new Size(110, 35);
            convertButton.TabIndex = 86;
            convertButton.Text = "Convert";
            convertButton.UseVisualStyleBackColor = true;
            // 
            // comboBoxEdit1
            // 
            comboBoxEdit1.Location = new Point(85, 49);
            comboBoxEdit1.Margin = new Padding(3, 4, 3, 4);
            comboBoxEdit1.Name = "comboBoxEdit1";
            comboBoxEdit1.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] { new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo) });
            comboBoxEdit1.Size = new Size(177, 24);
            comboBoxEdit1.TabIndex = 85;
            comboBoxEdit1.EditValueChanged += comboBoxEdit1_EditValueChanged;
            // 
            // saveButton
            // 
            saveButton.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            saveButton.Location = new Point(2496, 44);
            saveButton.Margin = new Padding(3, 4, 3, 4);
            saveButton.Name = "saveButton";
            saveButton.Size = new Size(86, 35);
            saveButton.TabIndex = 3;
            saveButton.Text = "Save";
            saveButton.UseVisualStyleBackColor = true;
            // 
            // labe1
            // 
            labe1.AutoSize = true;
            labe1.Location = new Point(24, 53);
            labe1.Name = "labe1";
            labe1.Size = new Size(50, 18);
            labe1.TabIndex = 61;
            labe1.Text = "PartID";
            // 
            // panelControl1
            // 
            panelControl1.Controls.Add(panelBack);
            panelControl1.Controls.Add(expandablePanel1);
            panelControl1.Dock = DockStyle.Fill;
            panelControl1.Location = new Point(0, 0);
            panelControl1.Margin = new Padding(3, 4, 3, 4);
            panelControl1.Name = "panelControl1";
            panelControl1.Size = new Size(1550, 784);
            panelControl1.TabIndex = 3;
            // 
            // dockManager1
            // 
            dockManager1.Form = this;
            dockManager1.RootPanels.AddRange(new DevExpress.XtraBars.Docking.DockPanel[] { dockPanel1 });
            dockManager1.TopZIndexControls.AddRange(new string[] { "DevExpress.XtraBars.BarDockControl", "DevExpress.XtraBars.StandaloneBarDockControl", "System.Windows.Forms.MenuStrip", "System.Windows.Forms.StatusStrip", "System.Windows.Forms.StatusBar", "DevExpress.XtraBars.Ribbon.RibbonStatusBar", "DevExpress.XtraBars.Ribbon.RibbonControl", "DevExpress.XtraBars.Navigation.OfficeNavigationBar", "DevExpress.XtraBars.Navigation.TileNavPane", "DevExpress.XtraBars.TabFormControl", "DevExpress.XtraBars.FluentDesignSystem.FluentDesignFormControl", "DevExpress.XtraBars.ToolbarForm.ToolbarFormControl" });
            // 
            // dockPanel1
            // 
            dockPanel1.Controls.Add(dockPanel1_Container);
            dockPanel1.Dock = DevExpress.XtraBars.Docking.DockingStyle.Bottom;
            dockPanel1.ID = new Guid("1a3c2a2e-3695-4efd-9579-24b708ff6ce2");
            dockPanel1.Location = new Point(0, 784);
            dockPanel1.Name = "dockPanel1";
            dockPanel1.OriginalSize = new Size(200, 200);
            dockPanel1.Size = new Size(1550, 200);
            dockPanel1.Text = "Process Part List";
            // 
            // dockPanel1_Container
            // 
            dockPanel1_Container.Controls.Add(gridControl1);
            dockPanel1_Container.Location = new Point(4, 34);
            dockPanel1_Container.Name = "dockPanel1_Container";
            dockPanel1_Container.Size = new Size(1542, 162);
            dockPanel1_Container.TabIndex = 0;
            // 
            // gridControl1
            // 
            gridControl1.Dock = DockStyle.Fill;
            gridControl1.Location = new Point(0, 0);
            gridControl1.MainView = gridView1;
            gridControl1.Name = "gridControl1";
            gridControl1.Size = new Size(1542, 162);
            gridControl1.TabIndex = 0;
            gridControl1.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] { gridView1 });
            // 
            // gridView1
            // 
            gridView1.GridControl = gridControl1;
            gridView1.Name = "gridView1";
            // 
            // BomView
            // 
            AutoScaleDimensions = new SizeF(8F, 18F);
            AutoScaleMode = AutoScaleMode.Font;
            Controls.Add(panelControl1);
            Controls.Add(dockPanel1);
            Margin = new Padding(3, 4, 3, 4);
            Name = "BomView";
            Size = new Size(1550, 984);
            ((System.ComponentModel.ISupportInitialize)emptySpaceItem3).EndInit();
            panelMainView.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)layoutControl1).EndInit();
            layoutControl1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)layoutControlGroup1).EndInit();
            ((System.ComponentModel.ISupportInitialize)layoutControlItem3).EndInit();
            panelBack.ResumeLayout(false);
            expandablePanel1.ResumeLayout(false);
            expandablePanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)comboBoxEdit1.Properties).EndInit();
            ((System.ComponentModel.ISupportInitialize)panelControl1).EndInit();
            panelControl1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dockManager1).EndInit();
            dockPanel1.ResumeLayout(false);
            dockPanel1_Container.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)gridControl1).EndInit();
            ((System.ComponentModel.ISupportInitialize)gridView1).EndInit();
            ResumeLayout(false);
        }

        #endregion
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem3;
        private Panel panelMainView;
        private System.Windows.Forms.Integration.ElementHost elementHost1;
        private DevExpress.XtraLayout.LayoutControl layoutControl1;
        private DevExpress.XtraLayout.LayoutControlGroup layoutControlGroup1;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem3;
        private Panel panelBack;
        private Mozart.Studio.UIComponents.ExpandablePanel expandablePanel1;
        private Button convertButton;
        private DevExpress.XtraEditors.ComboBoxEdit comboBoxEdit1;
        private Button saveButton;
        private Label labe1;
        private DevExpress.XtraEditors.PanelControl panelControl1;
        private DevExpress.XtraBars.Docking.DockManager dockManager1;
        private DevExpress.XtraBars.Docking.DockPanel dockPanel1;
        private DevExpress.XtraBars.Docking.ControlContainer dockPanel1_Container;
        private DevExpress.XtraGrid.GridControl gridControl1;
        private DevExpress.XtraGrid.Views.Grid.GridView gridView1;
    }
}
