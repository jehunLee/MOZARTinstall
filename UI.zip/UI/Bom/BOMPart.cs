﻿using System.Diagnostics;

namespace FabSimulatorUI.Bom
{
    public class BOMPart
    {
        public string MfgPartID { get; private set; }
        public string CompletePartID { get; set; }
        public string StepID { get; set; }
        public int BOMLevel { get; set; }
        //public UIProcess Process { get; private set; }
        //public UIProductDetail ProductDetail { get; private set; }
        public List<BOMPart> ToParts { get; set; }
        public List<BOMPart> FromParts { get; set; }
        public BOMPart CompletePart { get; set; }
        public string Key { get; set; }

        public BOMPart(string completePartID, string mfgPartID, int bomLevel)
        {
            this.Key = mfgPartID;
            this.MfgPartID = mfgPartID;
            this.BOMLevel = bomLevel;
            this.CompletePartID = completePartID;

            this.ToParts = new List<BOMPart>();
            this.FromParts = new List<BOMPart>();
        }

        //public int GetNextMinCompSeq(BOMPart part, BOMPart completePart)
        //{
        //    int minSeq = 9999;
        //    foreach (BOMPart next in part.ToParts)
        //    {
        //        if (next.CompletePart == completePart && next.BOMLevel < minSeq)
        //            minSeq = next.BOMLevel;
        //    }

        //    return minSeq;
        //}
    }
}
