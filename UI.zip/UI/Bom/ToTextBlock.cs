﻿using System.Windows.Controls;

namespace FabSimulatorUI.Bom
{
    public class ToTextBlock
    {
        public System.Windows.Shapes.Line Line { get; private set; }
        public TextBlock LineText { get; set; }
        public TextBlock BinText { get; set; }

        public ToTextBlock(System.Windows.Shapes.Line line)
        {
            this.Line = line;
        }
    }
}
