﻿namespace FabSimulatorUI.Bom
{
    /// <summary>
    /// RouteMainView.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class RouteMainView : System.Windows.Controls.UserControl
    {
        public RouteMainView()
        {
            InitializeComponent();
        }
    }
}
