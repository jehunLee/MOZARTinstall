﻿using System.Windows.Controls;
using System.Windows.Media;

namespace FabSimulatorUI.Bom
{
    public class Bar : Grid
    {
        public BOMPart bomPart { get; private set; }
        public System.Windows.Shapes.Rectangle Rectangle { get; set; }
        public TextBlock TextBlock { get; set; }
        public Dictionary<string, Bar> NextBarList { get; set; }
        public Dictionary<string, Bar> PrevBarList { get; set; }
        public int Depth { get; set; }
        public Dictionary<Bar, Tuple<System.Windows.Shapes.Line, ToTextBlock>> LineList { get; set; }
        public System.Windows.Media.Brush OriginalColor { get; set; }
        public Dictionary<int, Bar> AltProdBar { get; set; }
        public Dictionary<Bar, Tuple<System.Windows.Shapes.Path, TextBlock>> AltLineList { get; set; }
        public Dictionary<Bar, Tuple<System.Windows.Shapes.Path, TextBlock>> PrevAltLineList { get; set; }
        public SolidColorBrush OriginalSolidColorBursh { get; set; }

        public string Key { get; private set; }

        public Bar(BOMPart bomPart)
        {
            NextBarList = new Dictionary<string, Bar>();
            PrevBarList = new Dictionary<string, Bar>();
            LineList = new Dictionary<Bar, Tuple<System.Windows.Shapes.Line, ToTextBlock>>();
            AltProdBar = new Dictionary<int, Bar>();
            AltLineList = new Dictionary<Bar, Tuple<System.Windows.Shapes.Path, TextBlock>>();
            PrevAltLineList = new Dictionary<Bar, Tuple<System.Windows.Shapes.Path, TextBlock>>();
            this.bomPart = bomPart;
            Key = bomPart.Key;
        }

        public System.Windows.Point GetLeftCenterPoint()
        {
            System.Windows.Point point = new System.Windows.Point();

            double x = Canvas.GetLeft(this);
            double y = Canvas.GetTop(this);

            double w = 0;
            double h = 0;
            foreach (var info in this.Children)
            {
                if (info is System.Windows.Shapes.Rectangle)
                {
                    w = (info as System.Windows.Shapes.Rectangle).Width;
                    h = (info as System.Windows.Shapes.Rectangle).Height;
                }
            }

            point.X = x;
            point.Y = y + (h / 2);

            return point;
        }

        public System.Windows.Point GetRightCenterPoint()
        {
            System.Windows.Point point = new System.Windows.Point();

            double x = Canvas.GetLeft(this);
            double y = Canvas.GetTop(this);

            double w = 0;
            double h = 0;
            foreach(var info in this.Children)
            {
                if (info is System.Windows.Shapes.Rectangle)
                {
                    w = (info as System.Windows.Shapes.Rectangle).Width;
                    h = (info as System.Windows.Shapes.Rectangle).Height;
                }
            }

            point.X = x + w;
            point.Y = y + (h / 2);

            return point;
        }
    }
}
