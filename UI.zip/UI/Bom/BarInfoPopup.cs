﻿using DevExpress.XtraGrid;

namespace FabSimulatorUI.Bom
{
    public partial class BarInfoPopup : Form
    {
        public GridControl Grid { get; private set; }

        public BarInfoPopup()
        {
            InitializeComponent();

            this.Grid = this.gridControlBarInformation;
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
