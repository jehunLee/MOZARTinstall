﻿using System.Data;
using Mozart.Studio.TaskModel.UserInterface;
using Mozart.Studio.TaskModel.Projects;
using Mozart.Studio.TaskModel.UserLibrary;
using System.Windows.Controls;
using System.Windows;
using System.Windows.Media;
using System.Windows.Input;
using System.Globalization;
using FabSimulator;
using Mozart.Extensions;
using DevExpress.XtraScheduler.Native;
using FabSimulator.Inputs;

namespace FabSimulatorUI.Bom
{
    public partial class BomView : XtraGridControlView
    {
        IExperimentResultItem result;
        ModelDataContext modelDataContext;
        ExpDataContext expDataContext;

        bool initializing;
        bool loading;

        bool manipulating;

        RouteMainView mainView = new RouteMainView();
        Dictionary<string, BOMPart> bomParts = new Dictionary<string, BOMPart>();

        Bar selectBar = null;
        Dictionary<string, List<BOM>> bomCompletePartIdInfo = new Dictionary<string, List<BOM>>();
        Dictionary<string, BOM> bomPartIdInfo = new Dictionary<string, BOM>();
        List<string> currentRoute = new List<string>();

        public BomView()
            : base()
        {
            InitializeComponent();

            this.initializing = true;
        }

        public BomView(IServiceProvider serviceProvider)
            : base(serviceProvider)
        {
            InitializeComponent();

            this.initializing = true;
        }

        protected override void LoadDocument()
        {
            this.LoadInit();
            this.initializing = false;

            this.loading = true;

            // MainView의 Size가 초기화 된 이후에 호출해야, 일관된 위치로 Redering됨.
            //Rendering();
            this.loading = false;
        }

        #region Init
        private void LoadInit()
        {
            if (this.Document != null)
            {
                result = this.Document.GetResultItem();

                if (result == null)
                    return;

                this.modelDataContext = result.GetCtx<ModelDataContext>();
                this.expDataContext = result.GetCtx<ExpDataContext>();
            }

            InitializeData();

            InitializeControl();
        }

        private void InitializeData()
        {
            SetPartIDComboBox();

            SetBOMParts();
            SetBOMinfo();
        }

        private void InitializeControl()
        {
            this.elementHost1.Child = mainView;
            mainView.SizeChanged += MainView_SizeChanged;

            mainView.PreviewKeyDown += MainView_PreviewKeyDown;
            mainView.PreviewMouseWheel += MainView_PreviewMouseWheel;
            mainView.PreviewMouseMove += MainView_PreviewMouseMove;

            mainView.scrollViewer1.MouseLeftButtonUp += ScrollViewer1_MouseLeftButtonUp;

            bomCompletePartIdInfo.TryGetValue(this.comboBoxEdit1.Text, out var bomDataList);

            var sortedBOMData = OrderByBOM(bomDataList);
            gridControl1.DataSource = sortedBOMData;

            // dock manager의 grid view를 read only 모드로만 설정
            gridView1.Columns.ForEach(columns => columns.OptionsColumn.ReadOnly = true);

            //this.ribbonControl1.DrawGroupCaptions = DevExpress.Utils.DefaultBoolean.False;
            //this.LineLengthEditItem.EditValue = 150;

            //foreach (var item in comboxProductIDItems.Keys.ToArray())
            //    this.LineIDItemComboBox.Items.Add(item);

            //this.LineIDEditItem.EditValue = this.LineIDItemComboBox.Items[0];

            //HashSet<string> list;
            //if (this.comboxProductIDItems.TryGetValue(this.LineIDItemComboBox.Items[0].ToString(), out list))
            //{
            //    this.ProductIDItemComboBox.Items.Clear();
            //    this.ProductIDItemComboBox.Items.AddRange(list.ToArray());
            //    this.ProductIDEditItem.EditValue = this.ProductIDItemComboBox.Items[0];
            //}
        }

        private void ScrollViewer1_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            // BOM 그래프 캔버스 위에 바로 위치해 있지 않는다면
            if (mainView.scrollViewer1.IsMouseDirectlyOver)
            {
                // 이전에 선택했던 bar 원상복귀하기
                if (selectBar != null)
                {
                    selectBar.Rectangle.Fill = selectBar.OriginalColor;

                    SetRightHighLight(selectBar, true);
                    SetLeftHighLight(selectBar, true);
                    selectBar = null;
                }

                bomCompletePartIdInfo.TryGetValue(this.comboBoxEdit1.Text, out var bomDataList);

                var sortedBOMData = OrderByBOM(bomDataList);
                gridControl1.DataSource = sortedBOMData;
            }
        }

        private void SetPartIDComboBox()
        {
            var parts = this.modelDataContext.BOM.Select(x => x.PART_ID).Distinct();

            this.comboBoxEdit1.FillValues(parts);
            this.comboBoxEdit1.Properties.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.Standard;
        }

        private void SetBOMParts()
        {
            var partsGroup = this.modelDataContext.BOM.GroupBy(x => x.PART_ID);

            foreach (var items in partsGroup)
            {
                var completePartID = items.Key;
                var completePart = new BOMPart(completePartID, completePartID, 0);
                this.bomParts.Add(completePart.Key, completePart);

                var bomLevelGroup = items.OrderBy(x => x.BOM_LEVEL).GroupBy(x => x.BOM_LEVEL);

                foreach (var bomLevelItems in bomLevelGroup)
                {
                    foreach (var mfgPart in bomLevelItems)
                    {
                        var bomPart = new BOMPart(completePartID, mfgPart.FROM_PART_ID, mfgPart.BOM_LEVEL);
                        this.bomParts.Add(mfgPart.FROM_PART_ID, bomPart);

                        var toPart = this.bomParts.SafeGet(mfgPart.TO_PART_ID);
                        if (toPart != null)
                        {
                            bomPart.ToParts.Add(toPart);
                            toPart.FromParts.Add(bomPart);
                        }
                    }
                }
            }
        }

        private void SetBOMinfo()
        {
            var bomModelData = modelDataContext.BOM;

            foreach (var item in bomModelData)
            {
                bomPartIdInfo.Add(item.FROM_PART_ID, item);
            }

            var orderByPartIdBomData = bomModelData.GroupBy(x => x.PART_ID);

            foreach(var item in orderByPartIdBomData)
            {
                bomCompletePartIdInfo.Add(item.Key, item.ToList());
            }
        }

        #endregion

        #region Event
        private void MainView_SizeChanged(object sender, SizeChangedEventArgs e)
        {
            // ComboBox 조작 전, 초기 Rendering을 수행.
            // 창 크기 조절시에도 위치를 일관되게 하려면 조건문을 없애면 되지만,
            // 성능 측면에서 초기 Size 자동 변경 시 Re-Redering 수행.
            if (manipulating == false)
                Rendering();
        }

        private void comboBoxEdit1_EditValueChanged(object sender, EventArgs e)
        {
            if (initializing)
                return;

            manipulating = true;

            // combobox가 바뀔 때마다 dock manager data 바꿔주기
            bomCompletePartIdInfo.TryGetValue(this.comboBoxEdit1.Text, out var bomDataList);

            var sortedBOMData = OrderByBOM(bomDataList);
            gridControl1.DataSource = sortedBOMData;

            Rendering();
        }

        double zoom = 1;
        void MainView_PreviewMouseWheel(object sender, MouseWheelEventArgs e)
        {
            if ((System.Windows.Forms.Control.ModifierKeys) == Keys.Control)
            {
                System.Windows.Point mousePos = e.GetPosition(this.mainView.canvas1);

                double rate = 0;

                if (e.Delta > 0)
                    rate = 0.1;
                else if (e.Delta < 0)
                    rate = -0.1;

                zoom = zoom + rate;

                if (zoom <= 0)
                    zoom = 0.1;

                this.mainView.canvas1.RenderTransform = new ScaleTransform(zoom, zoom);

                ReSizeCanvas(Math.Ceiling(this.mainView.canvas1.Width + (this.mainView.canvas1.Width * rate)), Math.Ceiling(this.mainView.canvas1.Height + (this.mainView.canvas1.Height * rate)));

                this.mainView.scrollViewer1.ScrollToHorizontalOffset(0);
                this.mainView.scrollViewer1.ScrollToVerticalOffset(0);
            }
        }

        void MainView_PreviewKeyDown(object sender, System.Windows.Input.KeyEventArgs e)
        {
            if (selectBar != null && e.Key == Key.C && Keyboard.Modifiers == System.Windows.Input.ModifierKeys.Control)
            {
                System.Windows.Clipboard.SetDataObject(selectBar.TextBlock.Text);
            }
        }

        private void Line_MouseEnter(object sender, EventArgs e)
        {
            if (_currentDragBar == null)
            {
                System.Windows.Shapes.Line line = sender as System.Windows.Shapes.Line;

                line.StrokeThickness = 3;
            }
        }

        private void Line_MouseLeave(object sender, EventArgs e)
        {
            if (_currentDragBar == null)
            {
                System.Windows.Shapes.Line line = sender as System.Windows.Shapes.Line;

                line.StrokeThickness = 1;
            }
        }

        System.Windows.Point prevMousePoint;
        Bar _currentDragBar = null;

        private void MouseLeftButtonDown(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            Bar bar = sender as Bar;

            if (e.ClickCount == 1)
            {
                this.mainView.canvas1.Children.Remove(bar);
                this.mainView.canvas1.Children.Add(bar);

                _currentDragBar = bar;
                prevMousePoint = e.GetPosition(bar);

                // 이전에 선택했던 bar가 존재한다면 원상복귀
                if (selectBar != null)
                {
                    SetRightHighLight(selectBar, true);
                    SetLeftHighLight(selectBar, true);
                }

                selectBar = bar;

                SetRightHighLight(bar, false);
                SetLeftHighLight(bar, false);
                
                var bomDataList = currentRoute.Distinct().ToList();
                bomDataList.Sort();

                var currentBomInfo = new List<BOM>();

                foreach (var item in bomDataList)
                {
                    if (bomPartIdInfo.TryGetValue(item, out var bom))
                        currentBomInfo.Add(bom);
                }

                // bom_level, from_part_id 오름차순 정렬
                var sortedBOMData = OrderByBOM(currentBomInfo);
                gridControl1.DataSource = sortedBOMData;
                currentRoute.Clear();
            }
            else if (e.ClickCount > 1)
            {
                //if (bar.Product.ProductDetail != null)
                //{
                //    BarInfoPopup popup = new BarInfoPopup();

                //    popup.TopLevel = true;
                //    popup.Text = string.Format("Information - ( PRODUCT ID : {0} )", bar.Product.ProductID);

                //    DataTable dt = GetBarInformation(bar);
                //    popup.Grid.DataSource = dt;

                //    (popup.Grid.MainView as DevExpress.XtraGrid.Views.Grid.GridView).BestFitColumns();
                //    (popup.Grid.MainView as DevExpress.XtraGrid.Views.Grid.GridView).OptionsView.ShowGroupPanel = false;
                //    popup.StartPosition = FormStartPosition.CenterScreen;

                //    popup.ShowDialog();
                //}
            }
        }

        private void MouseLeftButtonUp(object sender, System.Windows.Input.MouseEventArgs e)
        {
            Bar bar = sender as Bar;

            _currentDragBar = null;

            if (selectBar != null)
            {
                if (bar.NextBarList.Values.Contains(selectBar) == false
                    && bar.PrevBarList.Values.Contains(selectBar) == false
                    && bar.AltProdBar.Values.Contains(selectBar) == false
                    && bar.PrevAltLineList.Keys.Contains(selectBar) == false)
                    bar.Rectangle.StrokeThickness = 2;
            }
            else
                bar.Rectangle.StrokeThickness = 1;

            prevMousePoint = e.GetPosition(bar);
        }

        private void SetHighLightAltLine(Dictionary<Bar, Tuple<System.Windows.Shapes.Path, TextBlock>> altLines, double strokeThickness, FontWeight fontWeight)
        {
            foreach (KeyValuePair<Bar, Tuple<System.Windows.Shapes.Path, TextBlock>> info in altLines)
            {
                info.Key.Rectangle.StrokeThickness = strokeThickness;
                info.Value.Item1.StrokeThickness = strokeThickness;
                info.Value.Item2.FontWeight = fontWeight;
            }
        }

        private void SetRightHighLight(Bar bar, bool isClear)
        {
            if (!isClear)
                currentRoute.Add(bar.Key);

            foreach (var nextBar in bar.LineList.Keys)
            {
                if (nextBar != null)
                    SetRightHighLight(nextBar, isClear);
            }

            SetHighLight(bar, isClear);
            return;
        }

        private void SetLeftHighLight(Bar bar, bool isClear)
        {
            if (!isClear)
                currentRoute.Add(bar.Key);

            foreach (Bar prevBar in bar.PrevBarList.Values)
            {
                if (prevBar != null)
                    SetLeftHighLight(prevBar, isClear);                
            }

            SetHighLight(bar, isClear);
            return;
        }

        private void SetHighLight(Bar bar, bool isClear)
        {
            double strokeThickness = isClear ? 1 : 2;
            bar.Rectangle.StrokeThickness = strokeThickness;

            SolidColorBrush brush = isClear ? System.Windows.Media.Brushes.SkyBlue : System.Windows.Media.Brushes.ForestGreen;
            GradientStop start = new GradientStop(System.Windows.Media.Colors.White, 0.7);
            GradientStop end = isClear ? new GradientStop(brush.Color, 1) : new GradientStop(brush.Color, 1);
            LinearGradientBrush gb = new LinearGradientBrush(new GradientStopCollection() { start, end }, 90);

            bar.Rectangle.Stroke = brush;
            bar.OriginalColor = gb;
            bar.OriginalSolidColorBursh = brush;
            bar.Rectangle.Fill = bar.OriginalColor;

            if (bar.LineList.Count > 0)
            {
                foreach (KeyValuePair<Bar, Tuple<System.Windows.Shapes.Line, ToTextBlock>> info in bar.LineList)
                {
                    //info.Value.Item1.StrokeThickness = strokeThickness;
                    info.Value.Item1.Stroke = isClear ? System.Windows.Media.Brushes.LightGray : System.Windows.Media.Brushes.Gray;
                }
            }
        }

        private void MainView_PreviewMouseMove(object sender, System.Windows.Input.MouseEventArgs e)
        {
            Bar bar = _currentDragBar;

            if (bar != null && e.MouseDevice.LeftButton == MouseButtonState.Pressed)
            {
                System.Windows.Point point = e.GetPosition(bar);

                double pointX = point.X - prevMousePoint.X;
                double pointY = point.Y - prevMousePoint.Y;

                Canvas.SetTop(bar, Canvas.GetTop(bar) + pointY);
                Canvas.SetLeft(bar, Canvas.GetLeft(bar) + pointX);

                double width = Canvas.GetLeft(bar);
                double heigth = Canvas.GetTop(bar);

                width += bar.Rectangle.Width + 100;
                heigth += bar.Rectangle.Height + 100;

                if (this.mainView.canvas1.Width < width)
                    this.mainView.canvas1.Width = width;

                if (this.mainView.canvas1.Height < heigth)
                    this.mainView.canvas1.Height = heigth;

                ReDrawLines(bar, pointX, pointY);

                ReDrawAltLine(bar);
            }
        }

        private void ClearMainView()
        {
            mainView.canvas1.Children.Clear();
            this.mainView.canvas1.RenderTransform = null;
            selectBar = null;
        }

        private void DrawAltLine(List<Bar> resultBarList)
        {
            Random r = new Random();

            foreach (Bar bar in resultBarList)
            {
                System.Windows.Media.Color color = new System.Windows.Media.Color();
                color.R = (byte)r.Next(0, 255);
                color.G = (byte)r.Next(0, 255);
                color.B = (byte)r.Next(0, 255);
                color.A = (byte)255;

                SolidColorBrush scb = new SolidColorBrush();
                scb.Color = color;

                foreach (KeyValuePair<int, Bar> altBar in bar.AltProdBar)
                {
                    System.Windows.Shapes.Path path = new System.Windows.Shapes.Path();
                    path.Stroke = scb;

                    path.StrokeDashArray = new DoubleCollection { 10, 1 };

                    PathGeometry pg = new PathGeometry();
                    PathFigure pf = new PathFigure();
                    pg.Figures.Add(pf);
                    pf.StartPoint = bar.GetRightCenterPoint();

                    BezierSegment bs = new BezierSegment();

                    bs.Point1 = bar.GetRightCenterPoint();
                    bs.Point2 = GetBezierSegmentPoint2(bar.GetRightCenterPoint(), altBar.Value.GetRightCenterPoint());
                    bs.Point3 = altBar.Value.GetRightCenterPoint();

                    pf.Segments.Add(bs);

                    PolyLineSegment poly = new PolyLineSegment();
                    List<System.Windows.Point> arrowPointList = GetArrowLinePoints(bs.Point2, bs.Point3);

                    foreach (System.Windows.Point p in arrowPointList)
                    {
                        poly.Points.Add(p);
                    }

                    pf.Segments.Add(poly);

                    path.Data = pg;

                    TextBlock pri = CreateTextBlock(altBar.Key.ToString());
                    pri.FontSize = 9;

                    DrawTextBlockByAltLine(pri, bs.Point1, bs.Point2, bs.Point3);

                    if (bar.AltLineList.ContainsKey(altBar.Value) == false)
                        bar.AltLineList.Add(altBar.Value, new Tuple<System.Windows.Shapes.Path, TextBlock>(path, pri));

                    if (altBar.Value.PrevAltLineList.ContainsKey(bar) == false)
                        altBar.Value.PrevAltLineList.Add(bar, new Tuple<System.Windows.Shapes.Path, TextBlock>(path, pri));

                    this.mainView.canvas1.Children.Add(path);
                    this.mainView.canvas1.Children.Add(pri);
                }
            }
        }

        private void DrawTextBlockByAltLine(TextBlock pri, System.Windows.Point p1, System.Windows.Point p2, System.Windows.Point p3)
        {
            double t = 0.5;

            double p1x = p1.X;
            double p2x = p2.X;
            double p3x = p3.X;

            double x = (1 - t) * ((1 - t) * p1x + t * p2x) + t * ((1 - t) * p2x + t * p3x);

            Canvas.SetTop(pri, p2.Y - pri.FontSize);

            Canvas.SetLeft(pri, x);
        }

        private List<System.Windows.Point> GetArrowLinePoints(System.Windows.Point p1, System.Windows.Point p2)
        {
            double theta = Math.Atan2(p1.Y - p2.Y, p1.X - p2.X);
            double sint = Math.Sin(theta);
            double cost = Math.Cos(theta);

            System.Windows.Point ap1 = new System.Windows.Point(
                p2.X + (5 * cost - 2 * sint),
                p2.Y + (5 * sint + 2 * cost));

            System.Windows.Point ap2 = new System.Windows.Point(
                p2.X + (5 * cost + 2 * sint),
                p2.Y - (2 * cost - 5 * sint));

            List<System.Windows.Point> list = new List<System.Windows.Point>();

            list.Add(ap1);
            list.Add(ap2);
            list.Add(p2);

            return list;
        }

        #endregion Event

        #region CreateControl

        private System.Windows.Shapes.Rectangle CreateRectangle(SolidColorBrush brush)
        {
            System.Windows.Shapes.Rectangle rec = new System.Windows.Shapes.Rectangle();

            rec.Width = 100;
            rec.Height = 20;
            rec.Stroke = brush;
            rec.RadiusX = 5;
            rec.RadiusY = 5;

            return rec;
        }

        private TextBlock CreateProductTextBlock(BOMPart product)
        {
            string text = product.MfgPartID;
            return CreateTextBlock(text);
        }

        private TextBlock CreateTextBlock(string text)
        {
            TextBlock textBlock = new TextBlock();

            textBlock.TextAlignment = TextAlignment.Center;
            textBlock.VerticalAlignment = VerticalAlignment.Center;

            textBlock.Text = text;

            return textBlock;
        }

        private System.Windows.Shapes.Line CreateLine()
        {
            System.Windows.Shapes.Line line = new System.Windows.Shapes.Line();
            line.Stroke = System.Windows.Media.Brushes.LightGray;
            line.StrokeThickness = 1;

            //line.MouseLeave += Line_MouseLeave;
            //line.MouseEnter += Line_MouseEnter;

            return line;
        }

        private Bar CreateBar(BOMPart part, int depth)
        {
            Bar bar = new Bar(part);
            bar.Focusable = true;
            bar.Depth = depth;

            TextBlock textBlock = CreateProductTextBlock(part);

            SolidColorBrush brush = null;
            brush = System.Windows.Media.Brushes.SkyBlue;
            //if (prod.IsWaferPart)
            //    brush = System.Windows.Media.Brushes.SkyBlue;
            //else if (prod.IsMidPart)
            //    brush = System.Windows.Media.Brushes.Orange;
            //else if (prod.IsMcpPart)
            //    brush = System.Windows.Media.Brushes.ForestGreen;
            //else
            //    brush = System.Windows.Media.Brushes.Red;

            System.Windows.Shapes.Rectangle rec = CreateRectangle(brush);

            bar.Rectangle = rec;
            bar.TextBlock = textBlock;

            bar.Children.Add(rec);
            bar.Children.Add(textBlock);

            GradientStop start = new GradientStop(System.Windows.Media.Colors.White, 0.7);
            GradientStop end = new GradientStop(brush.Color, 1);
            LinearGradientBrush gb = new LinearGradientBrush(new GradientStopCollection() { start, end }, 90);

            bar.OriginalColor = gb;
            bar.OriginalSolidColorBursh = brush;

            bar.Rectangle.Fill = bar.OriginalColor;

            bar.MouseLeftButtonDown += MouseLeftButtonDown;
            bar.MouseLeftButtonUp += MouseLeftButtonUp;

            MouseButtonEventArgs doubleClickEvent = new MouseButtonEventArgs(Mouse.PrimaryDevice, (int)DateTime.Now.Ticks, MouseButton.Left);
            doubleClickEvent.RoutedEvent = System.Windows.Controls.Control.MouseDoubleClickEvent;
            doubleClickEvent.Source = bar;
            bar.RaiseEvent(doubleClickEvent);

            return bar;
        }

        #endregion CreateControl

        #region Draw
        private void Rendering()
        {
            ClearMainView();

            string completePartID = this.comboBoxEdit1.Text;
            if (completePartID.IsNullOrEmpty())
                return;

            BOMPart completePart = bomParts.SafeGet(completePartID);
            if (completePart == null)
                return;

            double maxHeight = 10;
            double maxWidth = 10;

            Dictionary<string, Bar> barList = new Dictionary<string, Bar>();

            Bar completeBar = CreateBar(completePart, 0);

            if (barList.ContainsKey(completeBar.Key) == false)
                barList.Add(completeBar.Key, completeBar);

            GetBars(completeBar, completeBar.Depth - 1, barList);

            List<Bar> resultBarList = new List<Bar>(barList.Values);

            SetReCalcDepth(resultBarList);

            DrawBar(resultBarList, 10, ref maxWidth, ref maxHeight);

            DrawLine(resultBarList);

            //DrawAltLine(resultBarList);

            ReSizeCanvas(completeBar, maxWidth, maxHeight);
        }

        private void ReDrawAltLine(Bar bar)
        {
            foreach (Tuple<System.Windows.Shapes.Path, TextBlock> lineInfo in bar.AltLineList.Values)
            {
                PathGeometry pg = lineInfo.Item1.Data as PathGeometry;
                PathFigure pf = pg.Figures.ElementAt(0) as PathFigure;

                BezierSegment bs = null;
                foreach (PathSegment ps in pf.Segments)
                {
                    if (ps is BezierSegment)
                    {
                        bs = ps as BezierSegment;

                        pf.StartPoint = bar.GetRightCenterPoint();
                        bs.Point1 = bar.GetRightCenterPoint();
                        bs.Point2 = GetBezierSegmentPoint2(bs.Point1, bs.Point3);
                    }
                    else if (ps is PolyLineSegment)
                    {
                        PolyLineSegment poly = ps as PolyLineSegment;

                        poly.Points.Clear();

                        List<System.Windows.Point> list = GetArrowLinePoints(bs.Point2, bs.Point3);
                        foreach (System.Windows.Point p in list)
                            poly.Points.Add(p);
                    }

                    DrawTextBlockByAltLine(lineInfo.Item2, bs.Point1, bs.Point2, bs.Point3);
                }
            }

            foreach (Tuple<System.Windows.Shapes.Path, TextBlock> lineInfo in bar.PrevAltLineList.Values)
            {
                PathGeometry pg = lineInfo.Item1.Data as PathGeometry;
                PathFigure pf = pg.Figures.ElementAt(0) as PathFigure;

                BezierSegment bs = null;

                foreach (PathSegment ps in pf.Segments)
                {
                    if (ps is BezierSegment)
                    {
                        bs = ps as BezierSegment;
                        bs.Point3 = bar.GetRightCenterPoint();
                        bs.Point2 = GetBezierSegmentPoint2(bs.Point1, bs.Point3);
                    }
                    else if (ps is PolyLineSegment)
                    {
                        PolyLineSegment poly = ps as PolyLineSegment;

                        poly.Points.Clear();

                        List<System.Windows.Point> list = GetArrowLinePoints(bs.Point2, bs.Point3);
                        foreach (System.Windows.Point p in list)
                            poly.Points.Add(p);
                    }

                    DrawTextBlockByAltLine(lineInfo.Item2, bs.Point1, bs.Point2, bs.Point3);
                }
            }
        }

        private void ReDrawLines(Bar bar, double pointX, double pointY)
        {
            foreach (Tuple<System.Windows.Shapes.Line, ToTextBlock> lineInfo in bar.LineList.Values)
            {
                lineInfo.Item1.X1 = lineInfo.Item1.X1 + pointX;
                lineInfo.Item1.Y1 = lineInfo.Item1.Y1 + pointY;

                DrawTextBlockByLine(lineInfo.Item2.LineText, lineInfo.Item1);

                DrawBinTextBlockByLine(lineInfo.Item2.BinText, lineInfo.Item1);
            }

            foreach (Bar prevBar in bar.PrevBarList.Values)
            {
                Tuple<System.Windows.Shapes.Line, ToTextBlock> prevLineInfo;
                if (prevBar.LineList.TryGetValue(bar, out prevLineInfo))
                {
                    prevLineInfo.Item1.X2 = prevLineInfo.Item1.X2 + pointX;
                    prevLineInfo.Item1.Y2 = prevLineInfo.Item1.Y2 + pointY;

                    DrawTextBlockByLine(prevLineInfo.Item2.LineText, prevLineInfo.Item1);

                    DrawBinTextBlockByLine(prevLineInfo.Item2.BinText, prevLineInfo.Item1);
                }
            }
        }

        private void DrawLine(List<Bar> resultBarList)
        {
            foreach (Bar info in resultBarList)
            {
                if (info.NextBarList.Count > 0)
                {
                    foreach (Bar toBar in info.NextBarList.Values)
                    {
                        if (info.LineList.ContainsKey(toBar) == false)
                        {
                            System.Windows.Shapes.Line line = CreateLine();

                            line.X1 = info.GetRightCenterPoint().X;
                            line.Y1 = info.GetRightCenterPoint().Y;
                            line.X2 = toBar.GetLeftCenterPoint().X;
                            line.Y2 = toBar.GetLeftCenterPoint().Y;

                            mainView.canvas1.Children.Add(line);

                            TextBlock tb = CreateTextBlock(info.bomPart.StepID);
                            tb.FontSize = 9;

                            DrawTextBlockByLine(tb, line);

                            mainView.canvas1.Children.Add(tb);

                            ToTextBlock ttb = new ToTextBlock(line);
                            ttb.LineText = tb;

                            Tuple<System.Windows.Shapes.Line, ToTextBlock> lineInfo = new Tuple<System.Windows.Shapes.Line, ToTextBlock>(line, ttb);

                            if (info.LineList.ContainsKey(toBar) == false)
                                info.LineList.Add(toBar, lineInfo);
                        }
                    }
                }
            }
        }

        private void DrawBar(List<Bar> resultBarList, double startHeight, ref double maxWidth, ref double maxHeight)
        {
            int depth = 0;
            int i = 0;
            var margin = 50;

            Bar maxLengthBar = FindMaxLengthBar(resultBarList);
            double recWidth = GetStringSize(maxLengthBar.TextBlock).Width + margin;

            foreach (Bar bar in resultBarList)
            {
                bar.Rectangle.Width = recWidth;

                if (depth != bar.Depth)
                {
                    i = 0;
                    maxWidth += recWidth + margin;// + double.Parse(this.LineLengthEditItem.EditValue.ToString());
                }

                depth = bar.Depth;

                double recHeigth = startHeight + (i * margin);

                if (maxHeight < recHeigth)
                    maxHeight = recHeigth;

                Canvas.SetTop(bar, recHeigth);
                Canvas.SetLeft(bar, maxWidth);

                i++;

                this.mainView.canvas1.Children.Add(bar);
            }
        }

        private void DrawTextBlockByLine(TextBlock tb, System.Windows.Shapes.Line line)
        {
            if (tb == null)
                return;

            System.Windows.Size strSize = GetStringSize(tb);

            double topPoint = line.Y2 - tb.FontSize - ((line.Y2 - line.Y1) / 2);
            double leftPoint = line.X2 - (strSize.Width / 2) - ((line.X2 - line.X1) / 2);

            Canvas.SetTop(tb, topPoint);
            Canvas.SetLeft(tb, leftPoint);
        }

        private void DrawBinTextBlockByLine(TextBlock tb, System.Windows.Shapes.Line line)
        {
            if (tb == null)
                return;

            Canvas.SetTop(tb, line.Y2 - tb.FontSize - ((line.Y2 - line.Y1) / 4));
            Canvas.SetLeft(tb, line.X2 - ((line.X2 - line.X1) / 4));
        }

        #endregion

        #region Helper

        //private DataTable GetBarInformation(Bar bar)
        //{
        //    DataTable dt = new DataTable();

        //    DataColumn colAttribute = new DataColumn("Attribute", typeof(string));
        //    DataColumn colValue = new DataColumn("Value", typeof(string));

        //    dt.Columns.Add(colAttribute);
        //    dt.Columns.Add(colValue);

        //    DataRow lineRow = dt.NewRow();
        //    lineRow[colAttribute] = "LINE ID";
        //    //lineRow[colValue] = bar.Product.ProductDetail.LineID;
        //    dt.Rows.Add(lineRow);

        //    DataRow productIDRow = dt.NewRow();
        //    productIDRow[colAttribute] = "PRODUCT ID";
        //    //productIDRow[colValue] = bar.Product.ProductDetail.ProductID;
        //    dt.Rows.Add(productIDRow);

        //    DataRow processIDRow = dt.NewRow();
        //    processIDRow[colAttribute] = "PROCESS ID";
        //    //processIDRow[colValue] = bar.Product.ProductDetail.Process != null ? bar.Product.ProductDetail.Process.ProcessID : string.Empty;
        //    dt.Rows.Add(processIDRow);

        //    DataRow designIDRow = dt.NewRow();
        //    designIDRow[colAttribute] = "PROD GROUP ID";
        //    //designIDRow[colValue] = bar.Product.ProductDetail.ProdGroupID;
        //    dt.Rows.Add(designIDRow);

        //    DataRow materialGroupRow = dt.NewRow();
        //    materialGroupRow[colAttribute] = "PROC GROUP";
        //    //materialGroupRow[colValue] = bar.Product.ProductDetail.ProcGroup;
        //    dt.Rows.Add(materialGroupRow);

        //    DataRow pkgFamilyRow = dt.NewRow();
        //    pkgFamilyRow[colAttribute] = "PRODUCT FAMILY";
        //    //pkgFamilyRow[colValue] = bar.Product.ProductDetail.ProductFamily;
        //    dt.Rows.Add(pkgFamilyRow);

        //    DataRow pkgTypeRow = dt.NewRow();
        //    pkgTypeRow[colAttribute] = "PACKAGE TYPE";
        //    //pkgTypeRow[colValue] = bar.Product.ProductDetail.PackageType;
        //    dt.Rows.Add(pkgTypeRow);

        //    DataRow pkgLeadCountRow = dt.NewRow();
        //    pkgLeadCountRow[colAttribute] = "LEAD CNT";
        //    //pkgLeadCountRow[colValue] = bar.Product.ProductDetail.LeadCnt;
        //    dt.Rows.Add(pkgLeadCountRow);

        //    DataRow pkgWidthRow = dt.NewRow();
        //    pkgWidthRow[colAttribute] = "PACKAGE WIDTH";
        //    //pkgWidthRow[colValue] = bar.Product.ProductDetail.PackageWidth;
        //    dt.Rows.Add(pkgWidthRow);

        //    DataRow pkgLengthRow = dt.NewRow();
        //    pkgLengthRow[colAttribute] = "PACKAGE LENGTH";
        //    //pkgLengthRow[colValue] = bar.Product.ProductDetail.PackageLength;
        //    dt.Rows.Add(pkgLengthRow);

        //    DataRow pkgHeigthRow = dt.NewRow();
        //    pkgHeigthRow[colAttribute] = "PACKAGE HEIGHT";
        //    //pkgHeigthRow[colValue] = bar.Product.ProductDetail.PackageHeight;
        //    dt.Rows.Add(pkgHeigthRow);

        //    DataRow netDieRow = dt.NewRow();
        //    netDieRow[colAttribute] = "NET DIE";
        //    //netDieRow[colValue] = bar.Product.ProductDetail.NetDie;
        //    dt.Rows.Add(netDieRow);

        //    DataRow productGradeRow = dt.NewRow();
        //    productGradeRow[colAttribute] = "PRODUCT GRADE";
        //    //productGradeRow[colValue] = bar.Product.ProductDetail.ProductGrade;
        //    dt.Rows.Add(productGradeRow);

        //    DataRow configurationWidthRow = dt.NewRow();
        //    configurationWidthRow[colAttribute] = "ORG TYPE";
        //    //configurationWidthRow[colValue] = bar.Product.ProductDetail.OrgType;
        //    dt.Rows.Add(configurationWidthRow);

        //    DataRow dieInPackageRow = dt.NewRow();
        //    dieInPackageRow[colAttribute] = "USED CHIP CNT";
        //    //dieInPackageRow[colValue] = bar.Product.ProductDetail.UsedChipCnt;
        //    dt.Rows.Add(dieInPackageRow);

        //    return dt;
        //}

        private void SetReCalcDepth(List<Bar> resultBarList)
        {
            int minDepth = resultBarList.Min(x => x.Depth);

            resultBarList.ForEach(x => x.Depth = x.Depth + (int)Math.Abs(minDepth));

            resultBarList.Sort(new BarComparer());

            //foreach (Bar bar in resultBarList)
            //{
            //    //if (bar.Product.IsMcpPart == true && bar.Product.IsMidPart == false)//AssyInPart ( MCP 투입 Part )이면 Depth 1로 고정
            //    //    bar.Depth = 1;
            //    //else if (bar.PrevBarList.Count == 0)
            //    //    bar.Depth = 0;

            //    if (bar.PrevBarList.Count == 0)
            //        bar.Depth = 0;
            //    else
            //        bar.Depth = 1;
            //}

            foreach (Bar bar in resultBarList)
            {
                if (bar.PrevBarList.Values.Count > 0)
                {
                    int maxDepth = bar.PrevBarList.Values.Max(x => x.Depth);

                    bar.Depth = maxDepth + 1;
                }
            }
        }

        private Bar FindMaxLengthBar(List<Bar> resultBarList)
        {
            Bar maxLengthBar = null;
            foreach (Bar b in resultBarList)
            {
                if (maxLengthBar == null || maxLengthBar.TextBlock.Text.Length < b.TextBlock.Text.Length)
                    maxLengthBar = b;
            }

            return maxLengthBar;
        }

        private System.Windows.Size GetStringSize(TextBlock tb)
        {
            FormattedText ft = new FormattedText(
                tb.Text,
                CultureInfo.CurrentCulture,
                System.Windows.FlowDirection.LeftToRight,
                new Typeface(tb.FontFamily, tb.FontStyle, tb.FontWeight, tb.FontStretch, tb.FontFamily),
                tb.FontSize,
                System.Windows.Media.Brushes.Black);

            System.Windows.Size size = new System.Windows.Size(ft.Width, ft.Height);

            return size;
        }

        private void ReSizeCanvas(Bar bar, double width, double heidth)
        {
            double canvasWidth = width;
            double canvasHeight = heidth;
            if (bar != null)
            {
                canvasWidth = width + bar.Rectangle.Width + 100;
                canvasHeight = heidth + bar.Rectangle.Height + 100;
            }

            ReSizeCanvas(canvasWidth, canvasHeight);
        }

        private void ReSizeCanvas(double canvasWidth, double canvasHeight)
        {
            double actualWidth = this.mainView.scrollViewer1.ActualWidth;
            double actualHeight = this.mainView.scrollViewer1.ActualHeight;

            this.mainView.canvas1.Width = Math.Max(canvasWidth, actualWidth);
            this.mainView.canvas1.Height = Math.Max(canvasHeight, actualHeight);
        }

        private void GetBars(Bar toBar, int depth, Dictionary<string, Bar> bars)
        {
            List<BOMPart> bomPartList = toBar.bomPart.FromParts;

            foreach (BOMPart bomPart in bomPartList)
            {
                Bar fromBar = CreateBar(bomPart, depth);

                if (bars.ContainsKey(fromBar.Key) == false)
                    bars.Add(fromBar.Key, fromBar);

                if (toBar.PrevBarList.ContainsKey(fromBar.Key) == false)
                    toBar.PrevBarList.Add(fromBar.Key, fromBar);

                if (fromBar.NextBarList.ContainsKey(toBar.Key) == false)
                    fromBar.NextBarList.Add(toBar.Key, toBar);

                GetBars(fromBar, fromBar.Depth - 1, bars);
            }
        }

        private System.Windows.Point GetBezierSegmentPoint2(System.Windows.Point start, System.Windows.Point end)
        {
            double y = Math.Max(start.Y, end.Y);

            double gapY = Math.Abs(start.Y - end.Y);

            double maxX = Math.Max(start.X, end.X);

            System.Windows.Point point = new System.Windows.Point(maxX + 100, y - (gapY / 2));

            return point;
        }

        private IEnumerable<BOM> OrderByBOM(List<BOM> listOfBOM)
        {
            return from word in listOfBOM
                   orderby word.BOM_LEVEL, word.FROM_PART_ID
                   select word;
        }

        #endregion

        private void elementHost1_ChildChanged(object sender, System.Windows.Forms.Integration.ChildChangedEventArgs e)
        {

        }
    }

    public class BarComparer : IComparer<Bar>
    {
        public BarComparer()
        {
        }

        //public BOMPart CompletePart = null;
        public int Compare(Bar x, Bar y)
        {
            try
            {
                int cmp = 0;

                if (cmp == 0)
                    cmp = x.Depth.CompareTo(y.Depth);

                //if (cmp == 0 && x.Depth == 0 && y.Depth == 0)
                //{
                //    int xMinSeq = x.bomPart.GetNextMinCompSeq(x.bomPart, this.CompletePart);
                //    int yMinSeq = y.bomPart.GetNextMinCompSeq(y.bomPart, this.CompletePart);
                //    cmp = xMinSeq.CompareTo(yMinSeq);
                //}

                if (cmp == 0)
                    cmp = x.bomPart.BOMLevel.CompareTo(y.bomPart.BOMLevel);

                if (cmp == 0)
                    cmp = x.bomPart.MfgPartID.CompareTo(y.bomPart.MfgPartID);

                return cmp;
            }
            catch
            {
                return 0;
            }
        }
    }
}
