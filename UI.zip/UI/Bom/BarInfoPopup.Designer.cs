﻿namespace FabSimulatorUI.Bom
{
    partial class BarInfoPopup
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            gridControlBarInformation = new DevExpress.XtraGrid.GridControl();
            gridView1 = new DevExpress.XtraGrid.Views.Grid.GridView();
            ((System.ComponentModel.ISupportInitialize)gridControlBarInformation).BeginInit();
            ((System.ComponentModel.ISupportInitialize)gridView1).BeginInit();
            SuspendLayout();
            // 
            // gridControlBarInformation
            // 
            gridControlBarInformation.Dock = DockStyle.Fill;
            gridControlBarInformation.EmbeddedNavigator.Margin = new Padding(3, 4, 3, 4);
            gridControlBarInformation.Location = new Point(0, 0);
            gridControlBarInformation.MainView = gridView1;
            gridControlBarInformation.Margin = new Padding(3, 4, 3, 4);
            gridControlBarInformation.Name = "gridControlBarInformation";
            gridControlBarInformation.Size = new Size(868, 725);
            gridControlBarInformation.TabIndex = 2;
            gridControlBarInformation.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] { gridView1 });
            // 
            // gridView1
            // 
            gridView1.DetailHeight = 437;
            gridView1.GridControl = gridControlBarInformation;
            gridView1.Name = "gridView1";
            // 
            // BarInfoPopup
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(868, 725);
            Controls.Add(gridControlBarInformation);
            Margin = new Padding(3, 4, 3, 4);
            Name = "BarInfoPopup";
            Text = "BarInfoPopup";
            ((System.ComponentModel.ISupportInitialize)gridControlBarInformation).EndInit();
            ((System.ComponentModel.ISupportInitialize)gridView1).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private DevExpress.XtraGrid.GridControl gridControlBarInformation;
        private DevExpress.XtraGrid.Views.Grid.GridView gridView1;

    }
}