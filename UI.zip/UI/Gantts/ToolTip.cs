﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace FabSimulatorUI.Gantts
{
    public partial class ToolTip : Form
    {
        public GanttBar bar;
        public ToolTip(GanttBar bar, string type)
        {
            InitializeComponent();
            this.bar = bar;
            SetInfo(type);
            this.BackColor = Color.White;
            this.textBox1.BackColor = Color.White;
            this.textBox1.Select(0, -1);
        }

        public void SetInfo(string type)
        {
            string str1 = bar.LotId + "/" + bar.TIQty + "/" + bar.PartID + "/" + bar.StepID;
            switch (type)
            {
                case "RecipeName":
                    str1 += "/" + (string.IsNullOrEmpty(bar.RecipeId) ? "-" : bar.RecipeId); break;
                case "RouteID":
                    str1 += "/" + (string.IsNullOrEmpty(bar.RouteID) ? "-" : bar.RouteID); break;
                case "OperID":
                    str1 += "/" + (string.IsNullOrEmpty(bar.StepID) ? "-" : bar.StepID); break;
            }
            this.Width = TextRenderer.MeasureText(str1, this.textBox1.Font).Width + 20;

            string str2 = bar.TkinTime.ToString("yyyyMMdd HHmmss") + " ~ " + bar.TkoutTime.ToString("yyyyMMdd HHmmss");
            string str3 = GetWeight();

            this.textBox1.Text = str1 + System.Environment.NewLine;
            this.textBox1.Text += str2 + System.Environment.NewLine;
            this.textBox1.Text += str3;            
        }

        public string GetWeight()
        {
            if (bar.DispatchingInfo == null || bar.DispatchingInfo.Count() == 0)
                return "-";

            string weight = "";
            var dInfo = bar.DispatchingInfo.FirstOrDefault();
            if (dInfo == null)
                return "-";
            else
            {
                int index = GetNthIndex(dInfo.DISPATCH_WIP_LOG, 5);
                if (index == -1)
                    return "-";

                weight = dInfo.DISPATCH_WIP_LOG.Substring(index + 1);
                
                int index2 = weight.IndexOf(';');
                if(index2 != -1)
                    weight = weight.Substring(0, index2);
            }

            return weight;
        }

        public int GetNthIndex(string str, int n)
        {
            if (str == null)
                return -1;

            int offset = str.IndexOf('/');
            for (int i = 1; i < n; i++)
            {
                if (offset == -1) return -1;
                offset = str.IndexOf('/', offset + 1);
            }
            return offset;
        }
    }
}
