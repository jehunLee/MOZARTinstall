﻿using Mozart.Studio.TaskModel.UserLibrary.GanttChart;
using Mozart.Studio.TaskModel.UserLibrary;
using FabSimulator.Outputs;

namespace FabSimulatorUI.Gantts
{
    public class GanttBar : Bar
    {
        public string LotId;
        public string PartID;
        public string StepID;
        public List<LotInfo> BatchComponents;
        public string EqpId;
        public string RouteID;
        public string RecipeId;
        public string ToolingID;
        public string ArrivalTime;
        public string PresetId;
        public Eqp EqpInfo;
        public EQP_DISPATCH_LOG[] DispatchingInfo;
        public Color BackColor;
        public bool isRCS;
        public bool isAtStep;
        public bool isCutIn;
        public LinkedBar LinkedBar;

        public string BarKey
        {
            get { return EqpInfo.IsUnitBatch ? "UNITBATCH" : PartID + "/" + StepID; }
        }

        public string BrushKey { get; set; }

        public GanttBar(
            string eqpId,
            string productID,
            LotInfo lot,
            List<LotInfo> batchComponents,
            string arrivalTime,
            DateTime tkin,
            DateTime tkout,
            int tiqty,
            int toqty,
            string routeID,
            string recipeId,
            EqpState state,
            Eqp info,
            EQP_DISPATCH_LOG[] dispatchingInfo)
            : base(tkin, tkout, tiqty, toqty, state)
        {
            this.EqpId = eqpId;
            this.PartID = lot.PartID;
            this.LotId = lot.LotId;
            this.StepID = lot.StepID;
            this.BatchComponents = batchComponents;
            this.RouteID = routeID;
            this.RecipeId = recipeId;
            this.ToolingID = lot.ToolingID;
            this.EqpInfo = info;
            this.DispatchingInfo = dispatchingInfo;
            this.ArrivalTime = arrivalTime;
            this.isRCS = lot.IsRCS;
            this.isAtStep = lot.IsAtStep;
            this.isCutIn = lot.IsCutIn;
            this.BrushKey = this.BarKey;
        }

        public string GetTitle(bool simple=true)
        {
            if (simple)
            {             
                return TIQty.ToString() + "/" + TOQty.ToString();
            }
            else
            {
                if (this.State != EqpState.BUSY)
                {
                    if (this.State == EqpState.DOWN)
                        return "BM";

                    if (this.State != EqpState.NONE)
                        return string.Format("{0}", this.State);
                }

                return string.Format("{0}/{1}/{2}({3})", this.PartID, this.StepID, this.LotId, TIQty.ToString());
            }
        }

        //public override bool IsConflict(Bar bar)
        //{
        //    GanttBar gBar = bar as GanttBar;

        //    if(gBar.LinkedBar == null && this.LinkedBar == null)
        //        return base.IsConflict(bar);

        //    if (gBar.LinkedBar == this.LinkedBar)
        //        return false;

        //    DateTime tkinTime1 = this.LinkedBar == null ? this.TkinTime : this.LinkedBar.TkinTime;
        //    DateTime tkoutTime1 = this.LinkedBar == null ? this.TkoutTime : this.LinkedBar.TkoutTime;
        //    DateTime tkinTime2 = gBar.LinkedBar == null ? gBar.TkinTime : gBar.LinkedBar.TkinTime;
        //    DateTime tkoutTime2 = gBar.LinkedBar == null ? gBar.TkoutTime : gBar.LinkedBar.TkoutTime;

        //    return (tkinTime1 <= tkinTime2 && tkoutTime2 <= tkoutTime1)
        //        || (tkinTime2 < tkinTime1 && tkinTime1 < tkoutTime2)
        //        || (tkinTime2 < tkoutTime1 && tkoutTime1 < tkoutTime2);
        //}
    }
}
