﻿///
// file:	Gantts\BatchInfoViewPopup.cs
//
// summary:	Implements the batch information view popup class
///
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using DevExpress.XtraCharts;
using Mozart.Studio.TaskModel.UserLibrary;
using DevExpress.XtraGrid.Views.BandedGrid;
using DevExpress.XtraGrid.Views.Grid;
using DevExpress.XtraGrid;
using Mozart.Studio.TaskModel.Projects;
using FabSimulatorUI;
using FabSimulatorUI.Gantts;
using FabSimulator;
using FabSimulator.Outputs;
using DevExpress.XtraGrid.Columns;
using DevExpress.XtraEditors.Repository;

namespace FabSimulatorUI.Gantt
{
    public partial class BatchInfoViewPopup : Form
    {
        #region Variables
        /// <summary>   The parent. </summary>
        EqpGanttView parent;
        /// <summary>   The bar. </summary>
        GanttBar bar;
        /// <summary>   The event time. </summary>
        DateTime eventTime;
        /// <summary>   The selected lots. </summary>
        string[] selectedLots;

        public IExperimentResultItem Result
        {
            get { return this.parent.Result; }
        }


        public ModelDataContext ModelDataContext
        {
            get { return this.parent.ModelDataContext; }
        }


        public ExpDataContext ExpDataContext
        {
            get { return this.parent.ExpDataContext; }
        }

        #endregion Variables

        #region Constructor

        internal BatchInfoViewPopup(EqpGanttView parent, GanttBar bar)
        {
            InitializeComponent();
            this.parent = parent;
            this.bar = bar;

            this.LoadInit();
            this.Query();
        }
        #endregion Constructor

        #region Initialize

        public void LoadInit()
        {
            this.Text += string.Format(" / EquipId: {0} / TrackInTime: {1}", this.bar.EqpId, this.bar.TkinTime.ToString("yyyy-MM-dd HH:mm:ss"));
        }
        #endregion

        #region Query

        private void Query()
        {
            using (var wc = new Mozart.Studio.UIComponents.WaitCursor())
            {
                this.BindBegin();
                this.BindDo();
                this.BindEnd();
            }
        }

        private void BindBegin()
        {
            this.gridControl1.BeginUpdate();
            this.gridControl1.DataSource = null;

            this.gridControl2.BeginUpdate();
            this.gridControl2.DataSource = null;

            this.gridControl3.BeginUpdate();
            this.gridControl3.DataSource = null;
        }

        private void BindEnd()
        {
            this.SetGridOptions();

            this.gridControl1.EndUpdate();
            this.gridView1.BestFitColumns();

            this.gridControl2.EndUpdate();
            this.gridView2.BestFitColumns();

            this.gridControl3.EndUpdate();
            this.gridView3.BestFitColumns();
        }

        private void BindDo()
        {
            this.gridControl1.DataSource = this.CalculateBatchBuildingInfo().ToBindingList();
            this.gridControl2.DataSource = this.CalculateBatchSelectionInfo().ToBindingList();
            this.gridControl3.DataSource = this.CalculateBatchInfo().ToBindingList();
        }

        private IEnumerable<BatchBuildingInfo> CalculateBatchBuildingInfo()
        {
            var rslt = this.ExpDataContext.Result(this.Result.Name);
            var weightPresets = this.ModelDataContext.WEIGHT_PRESETS;
            var weightFactor = this.ModelDataContext.WEIGHT_FACTOR;
            var result = new List<BatchBuildingInfo>();
            var lotIds = this.bar.BatchComponents.Select(x => x.LotId).ToArray();
            var eqpId = bar.EqpInfo.FrameId;
            
            var batchBuildingLog = rslt.BATCH_BUILD_LOG.Where(x => x.EQP_ID == eqpId);
            var selectedLog = batchBuildingLog.Where(x => x.SELECT_YN.StartsWith("Y"))
                .Where(x => x.EVENT_TIME <= this.bar.TkinTime).Where(x => lotIds.Contains(x.LOT_ID));

            var eventRow = selectedLog.OrderByDescending(x => x.EVENT_TIME).FirstOrDefault();
            this.eventTime = eventRow != null ? eventRow.EVENT_TIME : DateTime.MinValue;

            var validBatchBuildingLog = batchBuildingLog.Where(x => x.EVALUATE_LOG != null).Where(x => x.EVENT_TIME == this.eventTime);
            if (validBatchBuildingLog.Count() < 1)
                return result;

            var presetId = "DEFAULT"; //this.bar.EqpInfo.isDiffusion ? "DIFF_BATCH_SELECTION" : "WET_BATCH_SELECTION";
            var presetSel = this.ModelDataContext.PRESET.Where(x => x.PROGRAM_ID == presetId && x.EQP_ID == eqpId).FirstOrDefault();
            if (presetSel != null)
                presetId = presetSel.PRESET_ID;

            var presets = (from row in weightPresets.Where(x => x.PRESET_ID == presetId && x.FACTOR_WEIGHT != 0)
                           join wf in weightFactor on row.FACTOR_ID equals wf.FACTOR_ID into ww
                           from active in ww.Where(x => x.IS_ACTIVE)
                           select new
                           {
                               row.FACTOR_ID,
                               row.FACTOR_SEQ
                           }).OrderBy(x => x.FACTOR_SEQ).Distinct().ToArray();

            Type<BatchBuildingInfo>.ClearProperties();

            foreach (var factor in presets)
                Type<BatchBuildingInfo>.RegisterProperty(factor.FACTOR_ID, typeof(float));

            foreach (var row in validBatchBuildingLog)
            {
                var info = new BatchBuildingInfo(row);

                var scoreStr = row.EVALUATE_LOG.Split('/');
                if (presets.Length != scoreStr.Length)
                {
                    for (int i = 0; i < presets.Length; i++)
                        info[presets[i].FACTOR_ID] = float.NaN;
                }
                else
                {
                    for (int i = 0; i < presets.Length; i++)
                    {
                        try
                        {
                            info[presets[i].FACTOR_ID] = string.Format("{0:#,0}",scoreStr[i]);
                        }
                        catch(Exception e) { }
                    }
                }

                result.Add(info);
            }

            return result.OrderBy(x => x.BATCHING_KEY).ThenBy(x => x.Sequence).ToList();
        }

        private IEnumerable<BatchSelectionInfo> CalculateBatchSelectionInfo()
        {
            var rslt = this.ExpDataContext.Result(this.Result.Name);
            var eqpId = bar.EqpInfo.FrameId;

            var weightPresets = this.ModelDataContext.WEIGHT_PRESETS;
            var weightFactor = this.ModelDataContext.WEIGHT_FACTOR;
            var result = new List<BatchSelectionInfo>();
            var batchSelectionLog = rslt.BATCH_SELECT_LOG.Where(x => x.EQP_ID == eqpId)
                .Where(x => x.EVENT_TIME == this.eventTime);

            var presetId = this.bar.EqpInfo.isDiffusion ? "DIFF_BATCH_SELECTION" : "WET_BATCH_SELECTION";
            var presetSel = this.ModelDataContext.PRESET.Where(x => x.PROGRAM_ID == presetId && x.EQP_ID == eqpId).FirstOrDefault();
            if (presetSel != null)
                presetId = presetSel.PRESET_ID;
     
            var presets = (from row in weightPresets.Where(x => x.PRESET_ID == presetId && x.FACTOR_WEIGHT != 0)
                           join wf in weightFactor on row.FACTOR_ID equals wf.FACTOR_ID into ww
                           from active in ww.Where(x => x.IS_ACTIVE)
                           select new
                           {
                               row.FACTOR_ID,
                               row.FACTOR_SEQ
                           }).OrderBy(x => x.FACTOR_SEQ).Distinct().ToArray();

            Type<BatchSelectionInfo>.ClearProperties();

            foreach (var factor in presets)
                Type<BatchSelectionInfo>.RegisterProperty(factor.FACTOR_ID, typeof(float));

            foreach (var row in batchSelectionLog)
            {
                if (row.SELECT_YN.StartsWith("Y"))
                    this.selectedLots = row.LOTS.Split(',');

                var info = new BatchSelectionInfo(row);
                var scoreStr = string.IsNullOrEmpty(row.EVALUATE_LOG) ? new string[0] : row.EVALUATE_LOG.Split('/');

                if (presets.Length != scoreStr.Length)
                {
                    for (int i = 0; i < presets.Length; i++)
                        info[presets[i].FACTOR_ID] = float.NaN;
                }
                else
                {
                    for (int i = 0; i < presets.Length; i++)
                        info[presets[i].FACTOR_ID] = scoreStr[i];
                }

                result.Add(info);
            }

            return result;//result.OrderBy(x => x.BSTrySeq).ThenBy(x => x.Sequence).ToList();
        }

        private IEnumerable<BatchInfo> CalculateBatchInfo()
        {
            var rslt = this.ExpDataContext.Result(this.Result.Name);
            var eqpId = bar.EqpInfo.FrameId;

            //var batchEfficiencyLog = rslt.BatchEfficiencyLog.Where(x => x.EquipId == eqpId)
            //    .Where(x=> x.MaxETA.DbToDateTime() <= this.bar.TkinTime);

            var result = new List<BatchInfo>();
            
            foreach (var row in this.bar.BatchComponents)
            {
                var info = new BatchInfo(row, this.bar);
                result.Add(info);

                if (row.IsAtStep)
                    info.AtStep = "Y";
                else
                    info.AtStep = "N";

                if (this.selectedLots == null || this.selectedLots.Contains(info.LotId))
                    continue;

                //var upstreamLog = batchEfficiencyLog.Where(x => x.AddedLotList.Contains(info.LotId)).FirstOrDefault();

                //if (upstreamLog != null)
                //{
                //    info.EffUpstream = "Y";
                //    info.OrgWPM = upstreamLog.OrgWPM;
                //    info.WPM = upstreamLog.WPM;

                //    continue;
                //}
            }

            return result;
        }

        /// <summary>   Sets grid options. </summary>
        private void SetGridOptions()
        {
            this.gridView1.OptionsSelection.EnableAppearanceFocusedRow = false;
            this.gridView2.OptionsSelection.EnableAppearanceFocusedRow = false;
            this.gridView3.OptionsSelection.EnableAppearanceFocusedRow = false;

            this.gridView1.OptionsSelection.MultiSelect = true;
            this.gridView2.OptionsSelection.MultiSelect = true;
            this.gridView3.OptionsSelection.MultiSelect = true;

            this.gridView1.OptionsView.ShowAutoFilterRow = true;
            this.gridView2.OptionsView.ShowAutoFilterRow = true;
            this.gridView3.OptionsView.ShowAutoFilterRow = true;

            this.gridView1.OptionsView.ShowGroupPanel = true;
            this.gridView2.OptionsView.ShowGroupPanel = false;
            this.gridView3.OptionsView.ShowGroupPanel = false;

            this.SetDisplayFormat(this.gridView1);
            this.SetDisplayFormat(this.gridView2);
            this.SetDisplayFormat(this.gridView3);

            foreach (var gcol in this.gridView1.Columns.OfType<GridColumn>())
            {
                gcol.Fixed = FixedStyle.Left;
                gcol.BestFit();

                if (gcol.FieldName == "FilteringReason")
                    break;
            }

            foreach (var gcol in this.gridView2.Columns.OfType<GridColumn>())
            {
                gcol.Fixed = FixedStyle.Left;
                gcol.BestFit();

                if (gcol.FieldName == "Filter")
                    break;
            }

            //this.ChangeColumnIndex(gridView2, typeof(BatchBuildingInfo));
            //this.ChangeColumnIndex(gridView3, typeof(BatchSelectionInfo));
        }

        /// <summary>   Change column index. </summary>
        private void ChangeColumnIndex(GridView view, Type type)
        {
            var propCount = type.GetProperties().Count(x => x.PropertyType != typeof(object));
            var columnCount = view.Columns.Count;
            var diff = columnCount - propCount;
            var weightValueIndex = view.Columns["WeightValue"].VisibleIndex;

            var postCols = view.Columns.Where(x => x.VisibleIndex >= weightValueIndex && x.VisibleIndex < propCount).ToList();
            foreach (GridColumn col in postCols)
                col.VisibleIndex += columnCount;
        }

        /// <summary>   Sets display format. </summary>
        private void SetDisplayFormat(GridView view)
        {
            foreach (GridColumn col in view.Columns)
            {
                if (col.ColumnType == typeof(double) || col.ColumnType == typeof(float))
                {
                    col.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Custom;
                    col.DisplayFormat.FormatString = "{0:#,##0.00}";
                }
                else if (col.ColumnType == typeof(DateTime))
                {
                    var dateTimeEdit = new RepositoryItemDateEdit();
                    dateTimeEdit.EditMask = "yyyy/MM/dd HH:mm:ss";
                    dateTimeEdit.DisplayFormat.FormatString = "yyyy/MM/dd HH:mm:ss";

                    col.ColumnEdit = dateTimeEdit;
                }
            }
        }

        #endregion

        #region Inner Classes

        class BatchBuildingInfo : Expandable
        {
            public string LotID { get; set; }
            public string BATCHING_KEY { get; set; }
            public DateTime EventTime { get; set; }
            public double WeightValue { get; set; }
            public string Select { get; set; }
            public int LotQty { get; set; }
            public string FilteringReason { get; set; }
            public int Sequence { get; set; }
            public string CurrentOperID { get; set; }
            public string BatchOperID { get; set; }

            public BatchBuildingInfo(BATCH_BUILD_LOG log)//, int bbTrySeq)
            { 
                this.LotID = log.LOT_ID;
                this.BATCHING_KEY = log.BATCHING_KEY;
                this.EventTime = log.EVENT_TIME;
                this.WeightValue = log.WEIGHT_VALUE;
                this.Select = log.SELECT_YN;
                this.LotQty = log.WAFER_QTY;
                this.FilteringReason = log.FILTERING_REASON;
                this.Sequence = log.LOT_SEQ;
                this.BatchOperID = log.BATCH_STEP_ID;
                this.CurrentOperID = log.CURRENT_STEP_ID;
            }
        }

        class BatchSelectionInfo : Expandable
        {
            public string LotIDs { get; set; }
           //public string ResourceID { get; set; }
            public string BATCHING_KEY { get; set; }
            public DateTime EventTime { get; set; }
            public double WeightValue { get; set; }
            public string Select { get; set; }
            public int LotQty { get; set; }
           //public string Filter { get; set; }
           //public int Sequence { get; set; }
           //public string Reason { get; set; }
           //public int SchedMinBatchSize { get; set; }
           //public int MinBatchSize { get; set; }
           //public int MaxBatchSize { get; set; }
           //public int TuningLotCnt { get; set; }

            public BatchSelectionInfo(BATCH_SELECT_LOG log)
            {
                this.LotIDs = log.LOTS;
                //this.ResourceID = log.RESOURCE_ID;
                this.BATCHING_KEY = log.BATCHING_KEY;
                this.EventTime = log.EVENT_TIME;
                this.WeightValue = log.WEIGHT_VALUE;
                this.Select = log.SELECT_YN;
                this.LotQty = log.WAFER_QTY;
                //this.Filter = log.IsFiltering;
                //this.Sequence = log.Sequence;
                //this.Reason = log.FilteringReason;
                //this.SchedMinBatchSize = log.SchedMinProdCount;
                //this.MinBatchSize = log.MinProdCount;
                //this.MaxBatchSize = log.MaxProdCount;
                //this.TuningLotCnt = log.TuningLotCount;
            }
        }

        class BatchInfo
        {
            public string LotId { get; set; }
            public string StepID { get; set; }
            public string PartID { get; set; }
            public int LotQty { get; set; }
            public DateTime StartTime { get; set; }
            public DateTime EndTime { get; set; }
            public TimeSpan Duration { get; set; }
            public string AtStep { get; set; }

            public BatchInfo(LotInfo info, GanttBar bar)
            {
                this.LotId = info.LotId;
                this.StepID = info.StepID;
                this.PartID = info.PartID;
                this.LotQty = info.Qty;
                this.StartTime = bar.TkinTime;
                this.EndTime = bar.TkoutTime;
                this.Duration = bar.TkoutTime.Subtract(bar.TkinTime);
                this.AtStep = string.Empty;
            }
        }

        #endregion

        private void gridView3_RowStyle(object sender, RowStyleEventArgs e)
        {
            if (this.gridView3.Columns.Count == 0)
                return;

            string AtStep = this.gridView3.GetRowCellDisplayText(e.RowHandle, this.gridView3.Columns["AtStep"]);

            if (AtStep == "Y")
                e.Appearance.BackColor = Color.FromArgb(204, 255, 204);
            //else if (effUpstream == "Y")
            //    e.Appearance.BackColor = Color.FromArgb(255, 204, 255);
        }
    }
}
