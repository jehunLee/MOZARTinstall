﻿///
// file:	Gantts\LoadInfo.cs
//
// summary:	Implements the load information class
///
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Mozart.Studio.TaskModel.UserLibrary;

namespace FabSimulatorUI.Gantts
{
    public class LoadInfo : PackedTable
    {
        [PackedIndex(0)]
        public String State { get; set; }

        [PackedIndex(1)]
        public String StartTime { get; set; }

        [PackedIndex(2)]
        public String LotID { get; set; }

        [PackedIndex(3)]
        public String PartID { get; set; }

        [PackedIndex(4)]
        public String StepID { get; set; }

        [PackedIndex(5)]
        public String Qty { get; set; }

        [PackedIndex(6)]
        public String ArrivalTime { get; set; }

        [PackedIndex(7)]
        public String RecipeID { get; set; }

        [PackedIndex(8)]
        public String ToolingID { get; set; }
    }
}
