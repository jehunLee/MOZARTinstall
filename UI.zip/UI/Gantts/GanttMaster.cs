﻿using DevExpress.Pdf.Native.BouncyCastle.Ocsp;
using DevExpress.Skins;
using DevExpress.XtraRichEdit.Model;
using DevExpress.XtraSpreadsheet;
using FabSimulator;
using FabSimulator.Inputs;
using FabSimulator.Outputs;
using FabSimulatorUI.Common;
using Mozart.Collections;
using Mozart.Extensions;
using Mozart.Studio.TaskModel.Projects;
using Mozart.Studio.TaskModel.UserLibrary;
using Mozart.Studio.TaskModel.UserLibrary.GanttChart;
using System.Collections.Concurrent;
using System.Data;
using System.Drawing.Drawing2D;
using System.Text;

namespace FabSimulatorUI.Gantts
{
    public class GanttMaster : GanttView
    {
        #region Variables & Properties

        public Dictionary<string, GanttInfo> table { get; set; }
        DoubleDictionary<string, DateTime, List<LotInfo>> batchDic;
        public MouseSelectType mouseSelType { get; set; }

        private bool selectMode;
        public bool EnableSelect { get { return this.selectMode; } }

        public IExperimentResultItem result;

        protected DateTime planStartTime;
        protected DateTime periodEnd;

        HashSet<string> visibleItems;
        DoubleDictionary<string, DateTime, List<EQP_DISPATCH_LOG>> dispatchingInfo;
        Dictionary<string, Eqp> validEqps;
        ColorGenerator colorGen;
        Dictionary<Color, string> usedColorDic;
        Dictionary<string, DateTime> unitBatchTrackOutTime = new Dictionary<string, DateTime>();
        public ISet<string> areaIds { get; set; }
        Dictionary<string, Eqp> eqpAll;
        ILookup<string, Eqp> eqpByLine;
        ILookup<string, LOAD_STAT> loadStat;
        bool showIdle;

        public ToolTip toolTip;

        public bool IsParallelChamberToInline;
        public bool IsBatchToInline;

        #endregion

        #region Ctor

        public GanttMaster(SpreadsheetControl grid, IExperimentResultItem rslt, DateTime planStartTime)
            : base(grid)
        {
            this.table = new Dictionary<string, GanttInfo>();
            this.batchDic = new DoubleDictionary<string, DateTime, List<LotInfo>>();

            this.result = rslt;

            this.planStartTime = planStartTime;
            this.periodEnd = planStartTime.AddDays(rslt.GetPlanPeriodF());

            this.colorGen = new ColorGenerator();

            this.visibleItems = new HashSet<string>();

            this.validEqps = new Dictionary<string, Eqp>();

            this.usedColorDic = new Dictionary<Color, string>();

            try
            {
                LoadBaseData();
            }
            catch (Exception)
            {
                MessageBox.Show("Model is Not matched with UI", "Notification", MessageBoxButtons.OKCancel, MessageBoxIcon.Asterisk);
            }
        }
        #endregion

        #region Initialize

        private void LoadBaseData()
        {
            var rslt = this.result.GetCtx<ResultDataContext>();
            var modelCtx = this.result.GetCtx<ModelDataContext>();

            var chamberToInlineArg = modelCtx.GetConfigValue<string>(PARAM_GROUP: "Resource_SimType", PARAM_NAME: "chamberToInline");

            if (chamberToInlineArg != null && chamberToInlineArg == "Y")
                this.IsParallelChamberToInline = true;

            var batchToInlineArg = modelCtx.GetConfigValue<string>(PARAM_GROUP: "Resource_SimType", PARAM_NAME: "batchToInline");

            if (batchToInlineArg != null && batchToInlineArg == "Y")
                this.IsBatchToInline = true;

            // prepare dispatching data
            this.dispatchingInfo = new DoubleDictionary<string, DateTime, List<EQP_DISPATCH_LOG>>();
            foreach (var log in rslt.EQP_DISPATCH_LOG)
            {
                List<EQP_DISPATCH_LOG> list;
                if (!this.dispatchingInfo.TryGetValue(log.EQP_ID, log.EVENT_TIME, out list))
                    this.dispatchingInfo[log.EQP_ID, log.EVENT_TIME] = list = new List<EQP_DISPATCH_LOG>();

                list.Add(log);
            }

            this.LoadEqps(modelCtx);
        }

        private void LoadEqps(ModelDataContext modelCtx)
        {
            this.eqpAll = modelCtx.EQP.GroupBy(x => new { x.LINE_ID, x.EQP_ID }).Select(grp => grp.First())
                .Select(x => new Eqp(x, IsParallelChamberToInline)).ToDictionary(x => x.EqpId);

            this.eqpByLine = this.eqpAll.Values.ToLookup(x => x.LineId);
        }

        public virtual void ClearData()
        {
            this.Clear();
            this.table.Clear();
            this.visibleItems.Clear();
            this.batchDic.Clear();
            this.usedColorDic.Clear();
        }

        protected override void OnFromTimeChanged()
        {
            //loadStat = null;
        }

        protected override void OnToTimeChanged()
        {
            //loadStat = null;
        }

        #endregion

        #region GetTable

        private IEnumerable<LOAD_HISTORY> GetLoadHist(List<string> eqpList)
        {
            var rslt = this.result.GetCtx<ResultDataContext>();

            var factoryStartTime = FromTime.StartTimeOfDayT();

            return rslt.LOAD_HISTORY.Where(x => eqpList.Contains(x.EQP_ID) && x.EVENT_TIME >= factoryStartTime.Date)
                    .OrderBy(x => x.EQP_ID)                    
                    .ThenBy(x => x.EVENT_TIME).ToList();
        }


        private IEnumerable<LOAD_STAT> GetLoadStat(string eqpID)
        {
            if (this.loadStat == null)
            {
                var rslt = this.result.GetCtx<ResultDataContext>();

                this.loadStat = rslt.LOAD_STAT.Where(x =>
                    x.TARGET_DATE >= this.FromTime && x.TARGET_DATE < this.ToTime)
                    .ToLookup(x => x.EQP_ID);
            }

            return this.loadStat[eqpID];
        }

        #endregion

        #region Build

        public void Build(
            string lineId,
            ISet<string> areaIds,
            ISet<string> selectedEqps,
            DateTime fromTime,
            DateTime toTime,
            string searchPattern,
            bool isShowIdle,
            string selectedSimType
        )
        {
            this.ClearData();

            this.FromTime = fromTime;
            this.ToTime = toTime;

            this.areaIds = areaIds;

            this.SetValidEqpIds(lineId, selectedEqps, searchPattern, selectedSimType);
            List<string> eqpList = this.validEqps.IsNullOrEmpty() ? new List<string>() : this.validEqps.Keys.ToList();
            var unitBatchDict = GetUnitBatchDict();

            foreach (var e in this.validEqps.Values.Where(t => string.IsNullOrEmpty(t.ParentEqpId) == false))
            {
                if (eqpList.Contains(e.ParentEqpId) == false)
                    eqpList.Add(e.ParentEqpId);
            }

            // eqpList를 unitBatch가 들어간 부분과 안 들어간 부분으로 나누자.
            var eqpUnitBatchList = eqpList.Where(x => unitBatchDict.ContainsKey(x)).ToList();
            eqpList.RemoveAll(x => unitBatchDict.ContainsKey(x));

            this.showIdle = isShowIdle;
            this.BuildPlan(this.GetLoadHist(eqpList));

            // ChamberMode에 의해, ChamberHistory에만 기록된 작업을 그리도록 추가
            this.BuildPlanChamberModeSerial(this.GetChamberHist(eqpList));

            // UnitBatch 타입일때 간트차트에 lot에 관한 정보를 그리는 함수
            this.BuildPlanInUnitBatch(this.GetPlanInUnitBatch(eqpUnitBatchList));

            // UnitBatch 타입일때 간트차트에 정비(PM)에 관한 정보를 그리는 함수
            this.BuildDownLogInUnitBatch(this.GetDownLogInUnitBatch(eqpUnitBatchList));
            
            // LoadHistory로 LotBatch까지 그리도록 변경함.
            // EqpPlan은 UnitBatch의 EndTime을 찾을 때 필요.

#if false
            this.BuildPlanDiffusion(this.GetDiffusionGantt(eqpList)); //NOTES LotBatch에 한하여, Busy는 EqpPlan에서, PM은 LoadHistory에서 가져오고 있음.  
#endif
        }

        private IEnumerable<CHAMBER_HISTORY> GetChamberHist(List<string> eqpList)
        {
            var outputs = this.result.GetCtx<ResultDataContext>();

            return outputs.CHAMBER_HISTORY.Where(x => eqpList.Contains(x.EQP_ID))
                 .OrderBy(x => x.EQP_ID)
                 .ThenBy(x => x.START_TIME).ToList();
        }

        private void BuildPlanChamberModeSerial(IEnumerable<CHAMBER_HISTORY> chamberHistory)
        {
            foreach (var row in chamberHistory)
            {
                DateTime startTime = row.START_TIME.RemoveMilliseconds();
                DateTime endTime = row.END_TIME.RemoveMilliseconds();

                LotInfo lotinfo = new LotInfo
                {
                    StepID = row.STEP_ID,
                    LotId = row.LOT_ID,
                    //PartID = row.PART_ID,
                    Qty = row.WAFER_QTY,
                    //ToolingID = row.TOOLING_ID,
                    IsAtStep = true,
                    IsCutIn = false,
                    IsRCS = false
                };

                LoadInfo loadInfo = new LoadInfo
                {
                    StepID = row.STEP_ID,
                    StartTime = Convert.ToString(startTime),
                    //ToolingID = row.TOOLING_ID,
                    //PartID = row.PART_ID,
                    Qty = Convert.ToString(row.WAFER_QTY),
                    //RecipeID = row.RECIPE_ID,
                    LotID = row.LOT_ID,
                    //ArrivalTime = Convert.ToString(row.ARRIVAL_TIME),
                    State = Enum.GetName(typeof(EqpState), EqpState.BUSY)
                };

                Eqp eqp = validEqps.SafeGet(row.SUB_EQP_ID);
                if (eqp == null)
                    continue;

                var key = eqp.Key;

                AddVisibleItem(key);

                if (endTime == new DateTime())
                    endTime = periodEnd;

                if (endTime < this.FromTime)
                    continue;

                if (startTime < this.FromTime)
                    startTime = this.FromTime;

                if (this.HasConflictBar(eqp, startTime, endTime))
                    continue; // LeadChamber에서 진행한 이력은 LOAD_HISTORY에 있음.

                var dispatchingInfo = new EQP_DISPATCH_LOG[] { GetEqpDispatchLog(row.EQP_ID, startTime, row.LOT_ID) };

                AddItem(key, eqp.AreaId, lotinfo, loadInfo, startTime, endTime, row.WAFER_QTY,
                    string.Empty, EqpState.BUSY, eqp, dispatchingInfo, GanttInfoType.Plan);
            }
        }

        //[Obsolete]
        //private void BuildPlanDiffusion(IEnumerable<DiffusionGantt> diffs)
        //{
        //    Dictionary<string, List<DateTime>> trackInData = new Dictionary<string, List<DateTime>>();

        //    foreach (DiffusionGantt row in diffs)
        //    {
        //        string key = row.ResourceID;
        //        List<DateTime> trackInList;
        //        if (trackInData.TryGetValue(key, out trackInList) == false)
        //        {
        //            trackInList = new List<DateTime>();
        //            trackInData.Add(key, trackInList);
        //        }

        //        trackInList.Add(row.StartTime);
        //    }

        //    foreach (var row in diffs)
        //    {
        //        LotInfo lot = new LotInfo(row.LotId, row.PartID, row.StepID, row.Qty, string.Empty);

        //        lot.IsRCS = row.IsRCS;
        //        lot.IsAtStep = row.IsAtStep;
        //        lot.IsCutIn = row.isCutIn;

        //        Eqp eqp = row.Equip;
        //        var key = eqp.Key;

        //        string arrivalTime = row.ArrivalTime.ToString("yyyy/MM/dd HH:mm:ss");
        //        DateTime startTime = row.StartTime;
        //        DateTime endTime = row.EndTime;

        //        AddVisibleItem(key);

        //        endTime = TryGetEndTimeEtc(trackInData, key, startTime, endTime);

        //        if (endTime <= this.FromTime)
        //            continue;

        //        if (startTime < this.FromTime)
        //            startTime = this.FromTime;


        //        LinkedBar lBar = null;

        //        GanttBar bar = AddItem(key, eqp.AreaId, lot, arrivalTime,
        //            startTime, endTime, row.Qty,
        //            row.RouteID, row.RecipeID, EqpState.BUSY, eqp, null, GanttInfoType.Plan);

        //        if (lBar != null)
        //        {
        //            lBar.AddBar(bar);
        //            bar.LinkedBar = lBar;
        //        }
        //    }
        //}

        //[Obsolete]
        //private IEnumerable<DiffusionGantt> GetDiffusionGantt(List<string> eqpList)
        //{
        //    var outputs = this.result.GetCtx<ResultDataContext>();

        //    var diffEqps = this.validEqps.Values.Where(x => eqpList.Contains(x.EqpId) && x.isDiffusion);

        //    var diffusionGantt = outputs.EQP_PLAN.Where(x => eqpList.Contains(x.EQP_ID) )
        //         .OrderBy(x => x.EQP_ID)
        //         .ThenBy(x => x.START_TIME);

        //    var batchBuildingLog = outputs.BATCH_BUILD_LOG.Where(x => eqpList.Contains(x.EQP_ID)).
        //        Select(x => new { x.EQP_ID, x.LOT_ID, x.EVENT_TIME, x.BATCH_STEP_ID, x.CURRENT_STEP_ID, x.UPSTREAM_YN }).Distinct();

        //    var result = from a in diffusionGantt
        //             join d in diffEqps on new { a.EQP_ID } equals new { EQP_ID = d.EqpId }
        //             join b in batchBuildingLog on new { a.EQP_ID, a.LOT_ID,  a.START_TIME } equals new { b.EQP_ID, b.LOT_ID, START_TIME = b.EVENT_TIME } into outer
        //             from o in outer.DefaultIfEmpty()
        //             select new DiffusionGantt
        //             {
        //                 Equip = d,
        //                 LotId = a.LOT_ID,
        //                 PartID = a.PART_ID,
        //                 ResourceID = a.EQP_ID,
        //                 ArrivalTime = a.ARRIVAL_TIME,
        //                 TrackInTime = a.START_TIME,
        //                 StartTime = a.START_TIME,
        //                 EndTime = a.END_TIME,
        //                 TrackOutTime = a.END_TIME,
        //                 StepID = a.STEP_ID,
        //                 Qty = a.WAFER_QTY,
        //                 RouteID = a.ROUTE_ID ?? string.Empty,
        //                 RecipeID = a.RECIPE_ID ?? string.Empty,
        //                 IsAtStep = o!= null ? o.UPSTREAM_YN == "N" : true
        //             };

        //    return result.ToList();
        //}

        private void SetValidEqpIds(string lineId, ISet<string> selectedEqps, string searchStr, string selectedSimType)
        {
            this.validEqps.Clear();

            var eqps = this.GetEqpsByLine(lineId);
            if (eqps == null)
                return;

            string[] patterns = string.IsNullOrEmpty(searchStr) ? null : searchStr.Split(',');

            foreach (var eqp in eqps)
            {
                bool includeChamberGroup = eqp.IsChamberGroup && selectedEqps != null && selectedEqps.Contains(eqp.ParentEqpId);
                if (selectedEqps != null && !selectedEqps.Contains(eqp.EqpId) && !includeChamberGroup)
                    continue;

                if (selectedSimType != "ALL" && eqp.EqpType != selectedSimType)
                    continue;

                if (patterns.IsNullOrEmpty() == false)
                {
                    bool found = false;
                    foreach (var p in patterns)
                    {
                        string searchPattern = "%" + p.Trim() + "%";

                        if (Helper.Like(eqp.WorkStation, searchPattern))
                            found = true;
                        if (Helper.Like(eqp.EqpId, searchPattern))
                            found = true;
                        if (Helper.Like(eqp.ParentEqpId, searchPattern))
                            found = true;

                        if (found)
                            break;
                    }
                    if (found == false)
                        continue;
                }

                var validEqpId = eqp.Key;

                if (eqp.IsParallelChamber)
                {
                    if (this.IsParallelChamberToInline)
                    {
                        // FrameEqp만 가져오기
                        if (string.IsNullOrEmpty(eqp.ParentEqpId) == false)
                            continue;
                    }
                    else
                    {
                        // SubEqp만 가져오기
                        if (string.IsNullOrEmpty(eqp.ParentEqpId))
                            continue;
                    }
                }

                this.validEqps[eqp.EqpId] = eqp;

                // For the case of Empty Scheduling, Create an instance at this point
                if (this.areaIds == null || this.areaIds.Contains(eqp.AreaId))
                    this.TryGetGanttInfo(eqp.AreaId, eqp, validEqpId, GanttInfoType.Plan);
            }
        }

        private IEnumerable<Eqp> GetEqpsByLine(string lineID)
        {
            if (lineID == "ALL")
                return this.eqpAll.Values;

            return this.eqpByLine[lineID];
        }

        public GanttInfo TryGetGanttInfo(string prcGroup, Eqp eqp, string eqpId, GanttInfoType type)
        {
            var key = Helper.CreateKey(prcGroup, eqpId, type.ToString());

            GanttInfo info;
            if (!this.table.TryGetValue(key, out info))
            {
                info = new GanttInfo(prcGroup, eqp, eqpId, type);
                this.table.Add(key, info);
            }

            return info;
        }

        protected void BuildPlan(IEnumerable<LOAD_HISTORY> plans)
        {
            //NOTES HistoryInfo : LoadHistory row에 해당
            var dict = this.UnpackGzip(plans);

            this.BuildPlan(dict);
        }

        protected void BuildPlanInUnitBatch(List<EQP_PLAN> planList)
        {
            foreach (var row in planList)
            {
                // isAtstep, isCutln, isRcs => 간트차트 색과 연관있는 변수들
                LotInfo lotinfo = new LotInfo
                {
                    StepID = row.STEP_ID,
                    LotId = row.LOT_ID,
                    PartID = row.PART_ID,
                    Qty = row.WAFER_QTY,
                    ToolingID = row.TOOLING_ID,
                    IsAtStep = true,
                    IsCutIn = false,
                    IsRCS = false
                };

                LoadInfo loadInfo = new LoadInfo
                {
                    StepID = row.STEP_ID,
                    StartTime = Convert.ToString(row.START_TIME),
                    ToolingID = row.TOOLING_ID,
                    PartID = row.PART_ID,
                    Qty = Convert.ToString(row.WAFER_QTY),
                    RecipeID = row.RECIPE_ID,
                    LotID = row.LOT_ID,
                    ArrivalTime = Convert.ToString(row.ARRIVAL_TIME),
                    State = Enum.GetName(typeof(EqpState), EqpState.BUSY)
                };

                // eqp_id에 따라 해당 eqp를 가져오는 validEqps Dictionary 활용
                Eqp eqp = validEqps[row.EQP_ID];
                var key = eqp.Key;

                DateTime startTime = row.START_TIME;
                DateTime endTime = row.END_TIME;

                AddVisibleItem(key);

                // endTime이 "0001-01-01" 이라면 마지막까지 연결되게 만들자.
                if (endTime == new DateTime())
                    endTime = periodEnd;

                if (endTime < this.FromTime)
                    continue;

                if (startTime < this.FromTime)
                    startTime = this.FromTime;

                // ganttChart에서 더블 클릭시 나오는 내용들을 담고 있는 변수
                EQP_DISPATCH_LOG[] dispatchingInfo = null;

                DateTime loadTime = PackedTable.LHStateTime(startTime, loadInfo.StartTime);

                EQP_DISPATCH_LOG dispatchLogOnSetup;
                var state = Enums.ParseEqpState(loadInfo.State);
                var isIdle = showIdle && (state == EqpState.IDLE || state == EqpState.IDLERUN);
                
                this.GetExistPrevItem(eqp, lotinfo, state, loadTime, out dispatchLogOnSetup);

                if (IsDefaultDrawingState(state))
                    dispatchingInfo = new EQP_DISPATCH_LOG[] { GetEqpDispatchLog(row.EQP_ID, loadTime, row.LOT_ID) ?? dispatchLogOnSetup };
                else if (isIdle)
                    dispatchingInfo = GetEqpDispatchLog(row.EQP_ID, loadTime, endTime);

                // AddItem을 활용하여 ganttChart에 해당 내용 더해주기
                // eqp.AreaId => row.Area_ID가 null인 경우 오류가 발생하기에 valideqps 활용
                AddItem(row.EQP_ID, eqp.AreaId, lotinfo, loadInfo, startTime, endTime, row.WAFER_QTY,
                    row.ROUTE_ID,EqpState.BUSY, eqp, dispatchingInfo, GanttInfoType.Plan);
            }
        }

        protected void BuildDownLogInUnitBatch(List<EQP_DOWN_LOG> planList)
        {
            foreach (var row in planList)
            {
                // 해당 eqp가 정비중이기에 lot에 관한 정보는 필요 없음.
                LotInfo lotinfo = new LotInfo
                {
                    IsAtStep = true,
                    IsCutIn = false,
                    IsRCS = false
                };

                LoadInfo loadInfo = new LoadInfo();

                if (row.DOWN_TYPE.Contains("PM"))
                {
                    loadInfo = new LoadInfo
                    {
                        StartTime = Convert.ToString(row.START_TIME),
                        State = Enum.GetName(typeof(EqpState), EqpState.PM)
                    };
                }
                else if (row.DOWN_TYPE.Contains("BM"))
                {
                    loadInfo = new LoadInfo
                    {
                        StartTime = Convert.ToString(row.START_TIME),
                        State = Enum.GetName(typeof(EqpState), EqpState.DOWN)
                    };
                }

                // eqp_id에 따라 해당 eqp를 가져오는 validEqps Dictionary 활용
                Eqp eqp = validEqps[row.EQP_ID];
                var key = eqp.Key;

                DateTime startTime = row.START_TIME;
                DateTime endTime = row.END_TIME;

                AddVisibleItem(key);

                // endTime이 "0001-01-01" 이라면 마지막까지 연결되게 만들자.
                if (endTime == new DateTime())
                    endTime = periodEnd;

                if (endTime < this.FromTime)
                    continue;

                if (startTime < this.FromTime)
                    startTime = this.FromTime;

                // ganttChart에 해당 내용 더해주기
                // 설비 점검중에는 dispatchingInfo가 필요 없어서 제거
                if (row.DOWN_TYPE.Contains("PM"))
                {
                    AddItem(row.EQP_ID, row.AREA_ID, lotinfo, loadInfo, startTime, endTime, 0,
                        string.Empty, EqpState.PM, eqp, null, GanttInfoType.Plan);
                }
                else if (row.DOWN_TYPE.Contains("BM"))
                {
                    AddItem(row.EQP_ID, row.AREA_ID, lotinfo, loadInfo, startTime, endTime, 0,
                        string.Empty, EqpState.DOWN, eqp, null, GanttInfoType.Plan);
                }
            }
        }

        private void BuildPlan(MultiDictionary<string, HistoryInfo> dict)
        {
            Dictionary<string, int> pararrelChamberQty = GetPChamberQtyDic(); //Use PararrelChamber QTY //NOTES ParallelChamber 안그려도 항상 로드 중. 개선 필요

            foreach (var kvp in dict)
            {
                var historyRows = kvp.Value.OrderBy(x => x.TargetDate).ToArray();
                for (int rowIndex = 0; rowIndex < historyRows.Length; rowIndex++)
                {
                    var row = historyRows[rowIndex];
                    this.AddVisibleItem(row.Key);

                    var dailyEvents = row.Data; //NOTES 하루동안의 Event
                    for (int eventIndex = 0; eventIndex < dailyEvents.Length; eventIndex++)
                    {
                        try
                        {
                            var loadInfo = PackedTable.Split<LoadInfo>(dailyEvents[eventIndex]); //NOTES 한 Event에 해당
                            if (loadInfo == null)
                                continue;

                            int qty = 0;
                            string key = row.EqpID + "-" + row.SubEqpId + "-" + loadInfo.LotID + "-" + loadInfo.StepID;

                            if (pararrelChamberQty.ContainsKey(key)) //Use PararrelChamber QTY
                                qty = pararrelChamberQty[key]; //NOTES LoadHistory쪽에서 SubEqp별 Qty를 적어줄 수 없을까?
                            else
                                int.TryParse(loadInfo.Qty, out qty);

                            //NOTES 자정이후의 Event는 일 변경에 맞춰서 LoadHistory factoryTime 기준의 Day를 실제 Day로 전환
                            DateTime loadTime = PackedTable.LHStateTime(row.TargetDate, loadInfo.StartTime);

                            if (loadTime < FromTime || loadTime >= ToTime) // 조회범위 밖의 event 제외
                                continue; // FromTime 이전의 데이터를 필터하지 않으면, 조회 기간 변경시 불필요한 공백 row가 생길 수 있음.

                            var state = Enums.ParseEqpState(loadInfo.State);
                            var isIdle = showIdle && (state == EqpState.IDLE || state == EqpState.IDLERUN);

                            if (isIdle == false && IsDefaultDrawingState(state) == false)
                                continue;

                            var lot = new LotInfo(loadInfo, qty);

                            EQP_DISPATCH_LOG dispatchLogOnSetup;
                            var barInfo = this.GetExistPrevItem(row.Eqp, lot, state, loadTime, out dispatchLogOnSetup);

                            if (isIdle == false && barInfo != null) //NOTES 걸쳐있는 Event의 경우, 다음 row의 첫번째 Event가 동일한 Key를 가지므로 중복하여 시도하지 않도록 스킵
                                continue;

                            ///NOTES
                            /// 기본적으로 EndTime은 NextEvent의 시작 시각
                            /// 1. 다음 row에 걸쳐있는 경우, fullData에서 찾음.
                            /// 2. Batch인 경우, NextEvent가 아니라 시각이 바뀌는 시점을 찾음.
                            /// 3. IdleRun도 Idle 처럼 EndTime으로 취급.

                            var endTime = GetEndTime(row, historyRows, loadTime, state, loadInfo, rowIndex, eventIndex);
                            
                            EQP_DISPATCH_LOG[] dispatchingInfo = null;
                            if (IsDefaultDrawingState(state))
                                dispatchingInfo = new EQP_DISPATCH_LOG[] { GetEqpDispatchLog(row.EqpID, loadTime, loadInfo.LotID) ?? dispatchLogOnSetup };
                            else if (isIdle)
                                dispatchingInfo = GetEqpDispatchLog(row.EqpID, loadTime, endTime);

                            if (loadTime == endTime) // SimulationEnd에 투입된 Lot 걸러내기 위함
                                continue;

                            if (loadTime < FromTime)
                                loadTime = FromTime;

                            if (endTime > ToTime)
                                endTime = ToTime;

                            if (endTime > this.periodEnd)
                                endTime = this.periodEnd;

                            if (row.Eqp.EqpType == "ParallelChamber" && state == EqpState.PM)
                            {
                                var eqpDownLog = this.result.GetCtx<ResultDataContext>().EQP_DOWN_LOG
                                    .Where(x => x.EQP_ID == row.SubEqpId && loadTime >= x.START_TIME && loadTime < x.END_TIME).FirstOrDefault();

                                if (eqpDownLog != null && eqpDownLog.EVENT_CODE == "UNSCHEDULE")
                                    state = EqpState.DOWN;
                            }

                            AddItem(row.Key, row.Eqp.AreaId, lot, loadInfo, loadTime, endTime, qty,
                                        string.Empty, state, row.Eqp, dispatchingInfo, GanttInfoType.Plan);
                        }
                        catch (Exception)
                        {
                            MessageBox.Show("Invaild Data Found", "Notification", MessageBoxButtons.OKCancel, MessageBoxIcon.Asterisk);
                            continue;
                        }
                    }
                }
            }
        }

        public static bool IsDefaultDrawingState(EqpState state)
        {
            return state == EqpState.BUSY || state == EqpState.SETUP || state == EqpState.PM || state == EqpState.DOWN;
        }

        private Dictionary<string, int> GetPChamberQtyDic()
        {
            var rslt = this.result.GetCtx<ResultDataContext>();
            Dictionary<string, int> pChamberQtyDic = new Dictionary<string, int>();

            foreach (var row in rslt.CHAMBER_HISTORY)
            {
                var key = row.EQP_ID + "-" + row.SUB_EQP_ID + "-" + row.LOT_ID + "-" + row.STEP_ID;
                if (pChamberQtyDic.ContainsKey(key) == false)
                    pChamberQtyDic[key] = row.WAFER_QTY;
            }
            return pChamberQtyDic;
        }

        private MultiDictionary<string, HistoryInfo> UnpackGzip(IEnumerable<LOAD_HISTORY> plans)
        {
            var result = new MultiDictionary<string, HistoryInfo>();

            foreach (var row in plans)
            {
                var eqpID = row.EQP_ID;
                var subEqpID = row.SUB_EQP_ID;

                Eqp eqp;
                if (!this.validEqps.TryGetValue(eqpID, out eqp) && !this.validEqps.TryGetValue(subEqpID, out eqp))
                    continue;

                var key = eqp.Key;                
                var info = new HistoryInfo()
                {
                    EqpID = eqpID,
                    SubEqpId = subEqpID,
                    TargetDate = row.EVENT_TIME,
                    Key = key,
                    Eqp = eqp,
                    Data = LoadInfo.Split(row.InfoGZip1, row.InfoGZip2, row.InfoGZip3)
                };

                // 만일 eqp의 type이 inline이며 info.Data에 데이터가 2개 이상 존재하는 경우
                if (eqp.EqpType == "Inline" && info.Data.Length > 1)
                {
                    // info.Data의 처음에 같은 시작시간이 나오는 lot들을 처리
                    var sameTimeDeletedData = info.Data;
                    for (int i = 0; i < info.Data.Length - 1; i++)
                    {
                        var firstTime = info.Data[i].Split(";")[1];
                        var secondTime = info.Data[i + 1].Split(";")[1];
                        if (firstTime == secondTime)
                            sameTimeDeletedData = sameTimeDeletedData.Remove(info.Data[i]);
                        else
                            break;
                    }
                    info.Data = sameTimeDeletedData;
                }

                result.Add(key, info);
            }

            return result;
        }

        // Eqp의 Simtype이 UnitBatch인 Eqp가 기록되어 있는 Dictionary
        private Dictionary<string, bool> GetUnitBatchDict()
        {
            ModelDataContext modelDataContext = this.result.GetCtx<ModelDataContext>();
            var simType = modelDataContext.EQP;
            var simTypeDict = new Dictionary<string, bool>();

            foreach (var row in simType)
            {
                if (row.SIM_TYPE == "UnitBatch")
                {
                    string keyDict = row.EQP_ID;
                    simTypeDict.TryAdd(keyDict, true);
                }
            }
            return simTypeDict;
        }

        // EQP_PLAN의 정보를 가져오는 함수
        protected List<EQP_PLAN> GetPlanInUnitBatch(List<string> eqpUnitBatchList)
        {
            var outputs = this.result.GetCtx<ResultDataContext>();

            return outputs.EQP_PLAN.Where(x => eqpUnitBatchList.Contains(x.EQP_ID))
                 .OrderBy(x => x.EQP_ID)
                 .ThenBy(x => x.START_TIME).ToList();
        }

        // EQP가 Down이 되었을때의 정보를 가져오는 함수
        protected List<EQP_DOWN_LOG> GetDownLogInUnitBatch(List<string> eqpUnitBatchList)
        {
            var outputs = this.result.GetCtx<ResultDataContext>();

            return outputs.EQP_DOWN_LOG.Where(x => eqpUnitBatchList.Contains(x.EQP_ID))
                 .OrderBy(x => x.EQP_ID)
                 .ThenBy(x => x.START_TIME).ToList();
        }

        private EQP_DISPATCH_LOG GetEqpDispatchLog(string eqpID, DateTime loadTime, string lotID)
        {
            List<EQP_DISPATCH_LOG> logs;
            if (this.dispatchingInfo.TryGetValue(eqpID, loadTime, out logs))
            {
                var log = logs.FirstOrDefault(x => x.SELECTED_WIP.Contains(lotID));

                if (log != null)
                    return log;
            }

            // for revised ParallelChamber Dispatching
            if (this.dispatchingInfo.ContainsKey(eqpID))
            {
                var dic = this.dispatchingInfo[eqpID];
                var result = dic.Where(x => x.Key < loadTime).OrderByDescending(x => x.Key).SelectMany(y => y.Value);
                return result.FirstOrDefault(x => x.SELECTED_WIP.Contains(lotID));
            }

            return null;
        }

        private EQP_DISPATCH_LOG[] GetEqpDispatchLog(string eqpID, DateTime startTime, DateTime endTime)
        {
            if (this.dispatchingInfo.ContainsKey(eqpID))
            {
                var dic = this.dispatchingInfo[eqpID];
                var result = dic.Where(x => x.Key >= startTime && x.Key < endTime).SelectMany(y => y.Value);
                return result.ToArray();
            }

            return null;
        }

        public GanttBar AddItem(
            string eqpId,
            string areaId,
            LotInfo lot,
            LoadInfo loadInfo,
            DateTime tkin,
            DateTime tkout,
            int qty,
            string routeID,
            EqpState state,
            Eqp eqp,
            EQP_DISPATCH_LOG[] dispatchingInfo,
            GanttInfoType type
        )
        {
            GanttInfo info = this.TryGetGanttInfo(areaId, eqp, eqpId, type);
            GanttBar currentBar = null;
            List<LotInfo> batchComponents = new List<LotInfo>();
            if (eqp.IsBatchType)
            {
                if (this.batchDic.TryGetValue(eqpId, tkin, out batchComponents) == false)
                    this.batchDic.Add(eqpId, tkin, batchComponents = new List<LotInfo>());

                batchComponents.Add(lot);
            }

            currentBar = new GanttBar(
                eqpId,
                lot.PartID,
                lot,
                batchComponents,
                loadInfo.ArrivalTime,
                tkin,
                tkout,
                qty,
                qty,
                routeID,
                loadInfo.RecipeID,
                state,
                eqp,
                dispatchingInfo
            );
            string key = currentBar.BarKey;

            if (string.IsNullOrEmpty(key) == false)
                info.AddItem(key, currentBar);

            return currentBar;
        }

        private DateTime GetEndTime(HistoryInfo currentRow, HistoryInfo[] full, DateTime startTime, EqpState currentState, LoadInfo currentLoadInfo,
            int rowIndex, int eventIndex)
        {
            //NOTES 이번 row내에서 검색
            for (int k = eventIndex + 1; k < currentRow.Data.Length; k++)
            {
                var nextLoadInfo = PackedTable.Split<LoadInfo>(currentRow.Data[k]);
                var dt = PackedTable.LHStateTime(currentRow.TargetDate, nextLoadInfo.StartTime);

                if (dt > startTime)
                    return dt;
            }

            rowIndex++;
            while (rowIndex < full.Length)
            {
                var nextRow = full[rowIndex];
                for (int k = 0; k < nextRow.Data.Length; k++)
                {
                    var nextLoadInfo = PackedTable.Split<LoadInfo>(nextRow.Data[k]);
                    var nextState = Enums.ParseEqpState(nextLoadInfo.State);
                    var dt = PackedTable.LHStateTime(nextRow.TargetDate, nextLoadInfo.StartTime);

                    // lotid가 같다면 계속해서 이어지는 작업이므로 스킵 아니라면 해당 lot 뒤의 Start가 생긴거니 스킵X
                    if (dt - ShopCalendar.StartTime == nextRow.TargetDate && currentState == nextState && nextLoadInfo.LotID == currentLoadInfo.LotID)
                        continue; // 일변경 시점에 상태정보가 변하지 않으면, dayStartTime 으로 한번 더 찍히기 때문에 스킵.

                    if (dt > startTime)
                        return dt;
                }

                rowIndex++; // Event 길이가 24시간 초과하여 다음 row에서도 못찾을 경우에만 발생.
            }

            return ToTime; // 못 찾을 경우 default
        }

        //[Obsolete]
        //private DateTime TryGetEndTimeEtc(Dictionary<string, List<DateTime>> trackInData, string eqpId, DateTime startTime, DateTime endTime)
        //{
        //    List<DateTime> trackInList;
        //    if (trackInData.TryGetValue(eqpId, out trackInList) == false)
        //        return DateTime.MinValue;

        //    int nextIndex = trackInList.IndexOf(startTime) + 1;

        //    for (int i = nextIndex; i < trackInList.Count(); i++)
        //    {
        //        if (endTime > trackInList[i] && (trackInList[i] - startTime).TotalSeconds > 1)
        //        {
        //            endTime = trackInList[i];
        //            break;
        //        }
        //    }

        //    return endTime;
        //}

        private void AddVisibleItem(string item)
        {
            if (!this.visibleItems.Contains(item))
                this.visibleItems.Add(item);
        }

        public bool HasConflictBar(Eqp eqp, DateTime startTime, DateTime endTime)
        {
            var key = Helper.CreateKey(eqp.AreaId, eqp.Key, GanttInfoType.Plan.ToString());
            GanttInfo info;
            if (this.table.TryGetValue(key, out info))
            {
                foreach (var barList in info.Items.Values)
                {
                    foreach (var bar in barList)
                    {
                        if (bar.TkinTime < startTime && bar.TkoutTime <= startTime)
                            continue;

                        if (bar.TkinTime >= endTime && bar.TkoutTime > endTime)
                            continue;

                        return true;
                    }
                }
            }

            return false;
        }

        public Bar GetExistPrevItem(Eqp eqp, LotInfo lot, EqpState state, DateTime loadtime, out EQP_DISPATCH_LOG dispatchLog)
        {
            var key = Helper.CreateKey(eqp.AreaId, eqp.Key, GanttInfoType.Plan.ToString());
            dispatchLog = null;

            GanttInfo info;
            if (this.table.TryGetValue(key, out info))
            {
                var barKey = lot.PartID + "/" + lot.StepID;
                var barItem = info.GetBarItem(barKey, lot.LotId);
                var pmBar = info.GetBarItem("/", "");

                if (barItem != null)
                {
                    if (barItem.State == EqpState.SETUP || barItem.State == EqpState.PM || barItem.State == EqpState.DOWN)
                    {
                        dispatchLog = (barItem as GanttBar).DispatchingInfo.FirstOrDefault();
                        return null;
                    }

                    if (barItem.State != state)
                        return null;

                    if (pmBar != null && barItem.TkoutTime == pmBar.TkinTime)
                        return null; // for ACT Version (ApplyPMLogic2)    

                    if (barItem.TkoutTime < loadtime)
                        return null;
                }

                return barItem;
            }

            return null;
        }

        #endregion

        #region Expand

        public void Expand(bool isDefault)
        {
            foreach (GanttInfo info in this.table.Values)
            {
                if (!this.visibleItems.Contains(info.EqpId))
                    continue;

                info.Expand(isDefault);
                info.LinkBar(this, isDefault);
            }
        }
        #endregion

        #region Drawing Options

        BrushInfo brushEmpth = new BrushInfo(Color.Transparent);

        public BrushInfo GetBrushInfo(GanttBar bar)
        {
            BrushInfo brushinfo = null;

            if (bar.State == EqpState.SETUP)
                brushinfo = new BrushInfo(Color.Red);
            else if (bar.State == EqpState.PM)
                brushinfo = new BrushInfo(Color.Black);
            else if (bar.State == EqpState.DOWN)
                brushinfo = new BrushInfo(HatchStyle.Percent30, Color.Gray, Color.Black);
            else if (bar.State == EqpState.IDLE || bar.State == EqpState.IDLERUN)
                brushinfo = new BrushInfo(HatchStyle.LightDownwardDiagonal, Color.Gray, Color.White);
            else
            {
                bar.BrushKey = GetBrushKey(bar.BrushKey);
                brushinfo = new BrushInfo(this.colorGen.GetColor(bar.BrushKey));
            }
            var selBar = this.SelectedBar;

            if (!this.EnableSelect || selBar == null)
            {
                bar.BackColor = brushinfo.BackColor;
                return brushinfo;
            }

            if (!CompareToSelectedBar(bar))
            {
                bar.BackColor = brushEmpth.BackColor;
                return brushEmpth;
            }

            bar.BackColor = brushinfo.BackColor;
            return brushinfo;
        }

        public bool CompareToSelectedBar(GanttBar bar)
        {
            var selBar = this.SelectedBar as GanttBar;

            if (this.mouseSelType == MouseSelectType.StepSeq)
                return selBar.BrushKey == bar.BrushKey;
            else if (this.mouseSelType == MouseSelectType.LotId)
            {
                string selLotid = GetLotId(selBar.LotId);
                string curLotid = GetLotId(bar.LotId);

                return selLotid == curLotid;
            }

            return false;
        }

        private string GetLotId(string lotId)
        {
            int idx = lotId.IndexOf('_');
            if (idx > 0)
                return lotId.Substring(0, idx);

            return lotId;
        }

        public void TurnOnSelectMode() { this.selectMode = true; }

        public void TurnOffSelectMode() { this.selectMode = false; }

        private string GetBrushKey(string brushKey)
        {
            //For Color of BrushKey that is not Dupicated

            Color key = this.colorGen.GetColor(brushKey);
            string value = string.Empty;

            if (brushKey.IsNullOrEmpty() == false)
            {
                if (this.usedColorDic.TryGetValue(key, out value) == false)
                    this.usedColorDic.Add(key, brushKey);
                else
                {
                    if (brushKey != value)
                        brushKey = brushKey + "@";
                }
            }
            return brushKey;
        }

        #endregion

        #region 기타

        public void GetTotChgAndLoadRate(string line, string eqpId, out double loadRate, out double chgRate)
        {
            loadRate = 0;
            chgRate = 0;

            int count = 0;

            foreach (var row in this.GetLoadStat(eqpId))
            {
                loadRate += (row.BUSY + row.IDLERUN + row.SETUP);
                chgRate += row.SETUP;
                count++;
            }

            loadRate = loadRate / count;
            chgRate = chgRate / count;
        }
        #endregion
    }

    #region Enum

    public enum GanttInfoType
    {
        Plan,
        Act
    }

    public enum MouseSelectType
    {
        StepSeq,
        LotId
    }

    public enum SortOptions
    {
        EQP_ID,
        STEP_SEQ,
        PROCESS_GROUP,
        TYPE
    }

    #endregion

    #region Other Classes

    public class Eqp
    {
        public string LineId { get; set; }
        public string AreaId { get; set; }
        public string WorkStation { get; set; }
        public string EqpId { get; set; }
        public string ParentEqpId { get; set; }
        public string Key { get; set; }
        public string FrameId { get; set; }
        public string EqpType { get; set; }
        public bool IsDualBoat { get; set; }
        public string MaxBatchSize { get; set; }
        public string MinBatchSize { get; set; }
        public bool IsChamberGroup { get; set; }
        public bool IsBatchType
        {
            get
            {
                if (string.Equals(this.EqpType, "LotBatch", StringComparison.CurrentCultureIgnoreCase) ||
                    string.Equals(this.EqpType, "BatchInline", StringComparison.CurrentCultureIgnoreCase))
                    return true;

                return false;
            }
        }

        /// <summary>   Gets a value indicating whether this object is lot batch. </summary>
        public bool IsLotBatch
        {
            get
            {
                if (string.Equals(this.EqpType, "LotBatch", StringComparison.CurrentCultureIgnoreCase))
                    return true;

                return false;
            }
        }

        public bool isDiffusion
        {
            get
            {
                return string.Equals(this.EqpType, "LotBatch", StringComparison.CurrentCultureIgnoreCase);
            }
        }

        public bool IsUnitBatch
        {
            get
            {
                return string.Equals(this.EqpType, "UnitBatch", StringComparison.CurrentCultureIgnoreCase);
            }
        }

        public bool IsParallelChamber
        {
            get
            {
                if (string.Equals(this.EqpType, "ParallelChamber", StringComparison.CurrentCultureIgnoreCase) ||
                    string.Equals(this.EqpType, "LotBatchChamber", StringComparison.CurrentCultureIgnoreCase))
                    return true;

                return false;
            }
        }

        public Eqp(FabSimulator.Inputs.EQP row, bool isConverted)
        {
            this.LineId = row.LINE_ID;
            this.WorkStation = row.EQP_GROUP;
            this.EqpId = row.EQP_ID;
            this.ParentEqpId = row.PARENT_EQP_ID ?? string.Empty;
            this.AreaId = row.AREA_ID;
            this.EqpType = row.SIM_TYPE;
            this.Key = this.IsParallelChamber && isConverted == false ? string.Join("-", row.PARENT_EQP_ID, row.EQP_ID) : row.EQP_ID;
            this.FrameId = this.IsParallelChamber && isConverted == false ? row.PARENT_EQP_ID : row.EQP_ID;
        }

        public Eqp(Eqp frameEqp, string chamberGroupId)
        {
            this.LineId = frameEqp.LineId;
            this.WorkStation = frameEqp.WorkStation;
            this.EqpId = chamberGroupId;
            this.ParentEqpId = frameEqp.EqpId;
            this.AreaId = frameEqp.AreaId;
            this.EqpType = frameEqp.EqpType;
            this.Key = string.Join("-", frameEqp.EqpId, chamberGroupId);
            this.FrameId = frameEqp.EqpId;
            this.IsChamberGroup = true;
        }

        public string ToString(EQP_DISPATCH_LOG log, string presetId)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("+ -------------------------------------------------\r\n");
            sb.AppendFormat("ResourceID :{0}\r\n", this.EqpId);
            sb.AppendFormat("AreaId :  \t {0}\r\n", this.AreaId);
            sb.AppendFormat("SimType :   \t {0}\r\n", this.EqpType);
            sb.AppendFormat("Workstation :{0}\r\n", this.WorkStation);
            sb.AppendFormat("Preset : {0}\r\n", presetId);
            //sb.AppendFormat("MinBatchSize : \t {0}\r\n", string.IsNullOrEmpty(this.MinBatchSize) ? "-" : this.MinBatchSize);
            //sb.AppendFormat("MaxBatchSize : \t {0}\r\n", string.IsNullOrEmpty(this.MaxBatchSize) ? "-" : this.MaxBatchSize);

            return sb.ToString();
        }
    }

    public class DiffusionGantt
    {
        public Eqp Equip { get; set; }
        public string ResourceID { get; set; }
        public string LotId { get; set; }
        public string PartID { get; set; }
        public DateTime ReservedTime { get; set; }
        public DateTime TrackInTime { get; set; }
        public DateTime ArrivalTime { get; set; }
        public DateTime StartTime { get; set; }
        public DateTime EndTime { get; set; }
        public DateTime TrackOutTime { get; set; }
        public string StepID { get; set; }
        public int Qty { get; set; }
        public bool IsRCS { get; set; }
        public bool IsAtStep { get; set; }
        public bool isCutIn { get; set; }
        public string RouteID { get; set; }
        public string RecipeID { get; set; }
    }

    public class HistoryInfo : IComparable<HistoryInfo>
    {
        public string EqpID { get; set; }
        public string SubEqpId { get; set; }
        public string Key { get; set; }
        public DateTime TargetDate { get; set; }
        public string[] Data { get; set; }
        public Eqp Eqp { get; set; }

        public int CompareTo(HistoryInfo y)
        {
            int cmp = Key.CompareTo(y.Key);

            if (cmp == 0)
                cmp = TargetDate.CompareTo(y.TargetDate);

            return cmp;
        }
    }

    public class LotInfo
    {
        public string LotId { get; set; }
        public string PartID { get; set; }
        public string StepID { get; set; }
        public int Qty { get; set; }
        public string ToolingID { get; set; }
        public bool IsRCS { get; set; }
        public bool IsAtStep { get; set; }
        public bool IsCutIn { get; set; }

        public LotInfo()
        {
            this.LotId = "PM";
            this.PartID = string.Empty;
            this.StepID = string.Empty;
            this.Qty = 0;
        }

        public LotInfo(LoadInfo loadInfo, int qty)
        {
            this.LotId = loadInfo.LotID;
            this.PartID = loadInfo.PartID;
            this.StepID = loadInfo.StepID;
            this.Qty = qty;
            this.ToolingID = loadInfo.ToolingID;
            this.IsAtStep = true;
        }
    }

    public class LoadDetail
    {
        public string ResourceID { get; set; }
        public string State { get; set; }
        public string LotID { get; set; }
        public string OperID { get; set; }
        public string ProductID { get; set; }
        public string ArrivalTime { get; set; }
        public string StartTime { get; set; }
        public string EndTime { get; set; }
        public TimeSpan ProcessTime { get; set; }
        public int LotQty { get; set; }
        public string RecipeID { get; set; }
        public string ToolingID { get; set; }
        [System.ComponentModel.Browsable(false)]
        public int OriginalIndex { get; set; }

        [System.ComponentModel.Browsable(false)]
        public DateTime StartTimeForSort { get; set; }
    }

    public class ColName
    {
        public static string PrcGroup = "EQP_GRP_ID";
        public static string EqpId = "EQP_ID";
        public static string OperId = "OPER_ID";
        public static string Type = "TYPE";
        public static string LoadRate = "LOAD";
        public static string ChangRage = "CHANGE";
        public static string TIQtySum = "QTY";
        public static string TOQtySum = "T/O\nQTY";
        public static string TITotal = "TOTAL";
        public static string TOTotal = "T/O\nTOTAL";
    }

    public class ComparerByTime : IComparer<String>
    {
        public int Compare(String a, String b)
        {
            var aTime = int.Parse(a.Split(';')[1]);
            var bTime = int.Parse(b.Split(';')[1]);

            string format = @"hhmmss";
            var startTime = FactoryConfiguration.Current.StartTime;

            if (aTime < int.Parse(startTime.ToString(format)))
                aTime += 240000;
            if (bTime < int.Parse(startTime.ToString(format)))
                bTime += 240000;

            return aTime.CompareTo(bTime);
        }
    }

    #endregion
}
