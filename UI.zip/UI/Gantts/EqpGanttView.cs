﻿using DevExpress.Spreadsheet;
using DevExpress.XtraEditors;
using FabSimulator;
using FabSimulator.Inputs;
using FabSimulatorUI.Common;
using Mozart.Extensions;
using Mozart.Studio.TaskModel.Projects;
using Mozart.Studio.TaskModel.UserInterface;
using Mozart.Studio.TaskModel.UserLibrary;
using Mozart.Studio.TaskModel.UserLibrary.GanttChart;
using System.Data;

namespace FabSimulatorUI.Gantts
{
    public partial class EqpGanttView : XtraGridControlView
    {
        #region Variables & Properties
        /// <summary>   The result. </summary>
        IExperimentResultItem result;
        /// <summary>   Context for the model. </summary>
        ModelDataContext modelCtx;
        /// <summary>   Context for the exponent. </summary>
        ExpDataContext expCtx;

        /// <summary>   The gantt. </summary>
        GanttMaster gantt;

#warning Check : Change to Zero base index
        /// <summary>   The list. </summary>
        List<GanttInfo> list;
        /// <summary>   List of presets. </summary>
        List<WEIGHT_PRESETS> presetList;

        string presetMode;

        /// <summary>   True if is first, false if not. </summary>
        bool isFirst = true;
        /// <summary>   Identifier for the pre area. </summary>
        string preAreaId = string.Empty;
        /// <summary>   Identifier for the pre eqp. </summary>
        string preEqpId = string.Empty;
        /// <summary>   Type of the pre. </summary>
        string preType = string.Empty;
        /// <summary>   The pre row key. </summary>
        string preRowKey = string.Empty;

        /// <summary>   The start same type row index. </summary>
        int startSameTypeRowIdx = 0;
        /// <summary>   The start same eqp row index. </summary>
        int startSameEqpRowIdx = 0;
        /// <summary>   The start same row key index. </summary>
        int startSameRowKeyIdx = 0;
        /// <summary>   Number of eqps. </summary>
        int eqpCount = 0;
        /// <summary>   Number of calendars. </summary>
        int calCount = 0;

        /// <summary>   The sub total ti. </summary>
        double subTotalTI = 0;
        /// <summary>   The total ti. </summary>
        double totalTI = 0;
        /// <summary>   The total load rate. </summary>
        double totLoadRate = 0;
        /// <summary>   The rowsumti. </summary>
        double rowsumti = 0;
        /// <summary>   The rowsumto. </summary>
        double rowsumto = 0;

        /// <summary>   The area idlist. </summary>
        ISet<string> areaIdlist;

        /// <summary>   The pre color. </summary>
        Color preColor = XtraSheetHelper.AltColor;
        /// <summary>   The curr color. </summary>
        Color currColor = XtraSheetHelper.AltColor2;

        /// <summary>   Gets the result. </summary>
        public IExperimentResultItem Result { get { return this.result; } }

        /// <summary>   Gets a context for the model data. </summary>
        public ModelDataContext ModelDataContext { get { return this.modelCtx; } }

        /// <summary>   Gets a context for the exponent data. </summary>
        public ExpDataContext ExpDataContext { get { return this.expCtx; } }

        /// <summary>   Gets the plan start time. </summary>
        DateTime PlanStartTime { get { return this.result.StartTime; } }

        /// <summary>   Gets the identifier of the line. </summary>
        string LineID { get { return lindIDcomboBox.SelectedItem != null ? lindIDcomboBox.SelectedItem.ToString() : "Blank"; } }

        /// <summary>   Gets the type of the selected simulation. </summary>
        string SelectedSimType { get { return this.cbeSimType.Text; } }

        /// <summary>   Gets the start date. </summary>
        private DateTime StartDate { get { return dateEdit1.DateTime.AddHours(Convert.ToDouble(cbeStartTime.Text)); } }

        /// <summary>   Gets the end date. </summary>
        private DateTime EndDate { get { return StartDate.AddHours(Math.Ceiling(Convert.ToDouble(cbeDurationHr.Value))); } }

        /// <summary>   Gets the size of the cell width. </summary>
        public int CellWidthSize { get { return ganttSizeControl1.CellWidth; } }

        /// <summary>   Gets the size of the cell height. </summary>
        public int CellHeightSize { get { return ganttSizeControl1.CellHeight; } }

        /// <summary>   Gets the selected prc groups. </summary>
        ISet<string> SelectedAreaIDs
        {
            get
            {
                if (areaIdlist == null)
                    areaIdlist = new HashedSet<string>();
                else
                    areaIdlist.Clear();

                foreach (var item in areaCheckedBox.CheckedItems)
                    areaIdlist.Add(item.ToString());

                return areaIdlist;
            }
        }

        #endregion

        #region Ctor

        public EqpGanttView(IServiceProvider serviceProvider)
            : base(serviceProvider)
        {
            InitializeComponent();
            WindowsFormsSettings.AllowAutoFilterConditionChange = DevExpress.Utils.DefaultBoolean.False;

#warning Check : Added
            XtraSheetHelper.InitGanttSheet(this.spreadsheetControl1);
            this.spreadsheetControl1.Options.Behavior.ShowPopupMenu = DevExpress.XtraSpreadsheet.DocumentCapability.Hidden;
        }

        #endregion

        #region Initialize

        protected override void LoadDocument()
        {
            if (this.Document != null)
            {
                this.result = this.Document.GetResultItem();
                if (this.result == null)
                    return;

                Globals.InitFactoryTime(this.result);

                modelCtx = this.result.GetCtx<ModelDataContext>();
                expCtx = this.result.GetCtx<ExpDataContext>();

                this.presetMode = "DEFAULT";

                var customPresetMode = modelCtx.GetConfigValue<string>(PARAM_GROUP: "Logic_Dispatching", PARAM_NAME: "presetMode");

                if (customPresetMode != null)
                    this.presetMode = customPresetMode;
            }

            this.InitControl();

            this.InitializeData();
        }

        protected void InitControl()
        {
            this.dateEdit1.DateTime = this.PlanStartTime.Date;

            this.result.FillValues(lindIDcomboBox, "EQP", "LINE_ID", true, true);
            this.result.FillValues(cbeSimType, "EQP", "SIM_TYPE", true, true);

            cbeBrushKey.Properties.Items.Add("LotID");
            cbeBrushKey.Properties.Items.Add("ProductID");
            cbeBrushKey.Properties.Items.Add("OperID");
            cbeBrushKey.Properties.Items.Add("RouteID");
            cbeBrushKey.Properties.Items.Add("RecipeID");
            cbeBrushKey.SelectedIndex = 2;
            cbeBrushKey.Properties.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.DisableTextEditor;

            this.cbeStartTime.Text = this.PlanStartTime.Hour.ToString();
            this.cbeDurationHr.Value = Convert.ToDecimal(this.result.GetPlanPeriodF()) * 24 + (this.PlanStartTime.Minute > 0 ? 1 : 0);

            this.lindIDcomboBox.SelectedText = Consts.All;

            var rs = Extensions.GetLocalSetting(this.ServiceProvider, "ganttRowSize");
            var cs = Extensions.GetLocalSetting(this.ServiceProvider, "ganttCellSize");

#warning Check 
            if (!string.IsNullOrEmpty(cs))
                this.ganttSizeControl1.CellWidth = Convert.ToInt32(cs);

            if (!string.IsNullOrEmpty(rs))
                this.ganttSizeControl1.CellHeight = Convert.ToInt32(rs);
        }

        private void InitializeData()
        {
            base.SetWaitDialogLoadCaption("Eqp Info. ");

            this.areaCheckedBox.ListBox.SortOrder = SortOrder.Ascending;
            this.InitChkListPrcGroup();

            this.SetTreeList(this.SelectedAreaIDs);

            base.SetWaitDialogLoadCaption("Eqp Gantt info.");

            this.gantt = new GanttMaster(this.spreadsheetControl1, this.result, this.PlanStartTime);
            this.gantt.DefaultColumnWidth = this.CellWidthSize;
            this.gantt.DefaultRowHeight = this.CellHeightSize;

            this.gantt.mouseSelType = MouseSelectType.StepSeq;

            this.BindEvents();

            var activated = this.modelCtx.WEIGHT_FACTOR.Where(x => x.IS_ACTIVE).Select(x => x.FACTOR_ID).ToList();
            this.presetList = this.modelCtx.WEIGHT_PRESETS.Where(x => activated.Contains(x.FACTOR_ID) && x.FACTOR_WEIGHT != 0).OrderBy(x => x.FACTOR_SEQ).ToList();

            this.AddCustomStyle();
        }

        private void InitChkListPrcGroup()
        {
            this.areaCheckedBox.ListBox.Items.Clear();
            this.areaCheckedBox.ListBox.Items.Add(" (ALL)");

            string[] values;

            if (this.LineID == "ALL")
                values = this.result.DistinctValues("EQP", "AREA_ID", true);
            else
                values = this.result.DistinctValues("EQP", "AREA_ID", true, string.Format(" LINE_ID = '{0}'", this.LineID));

            this.areaCheckedBox.ListBox.Items.AddRange(values);

            this.areaCheckedBox.ListBox.SetItemCheckState(0, CheckState.Checked);
        }

        private void AddCustomStyle()
        {
            var styleBook = this.gantt.Workbook.Styles;

            var customHeader = styleBook.Add("CustomHeader");
            var customHeaderCenter = styleBook.Add("CustomHeaderCenter");
            var customHeaderRight = styleBook.Add("CustomHeaderRight");
            var customDefaultCenter = styleBook.Add("CustomDefaultCenter");
            var customBar = styleBook.Add("CustomBar");

            customHeader.Fill.BackgroundColor = Color.WhiteSmoke;

            customHeaderCenter.Fill.BackgroundColor = Color.WhiteSmoke;
            customHeaderCenter.Alignment.Horizontal = SpreadsheetHorizontalAlignment.Center;
            customHeaderCenter.Alignment.Vertical = SpreadsheetVerticalAlignment.Center;

            customHeaderRight.Fill.BackgroundColor = Color.WhiteSmoke;
            customHeaderRight.Alignment.Vertical = SpreadsheetVerticalAlignment.Center;
            customHeaderRight.Alignment.Horizontal = SpreadsheetHorizontalAlignment.Right;

            customDefaultCenter.Fill.BackgroundColor = Color.White;
            customDefaultCenter.Alignment.Vertical = SpreadsheetVerticalAlignment.Center;
            customDefaultCenter.Alignment.Horizontal = SpreadsheetHorizontalAlignment.Center;

            customBar.Font.Size = 6;
        }

        #endregion

        #region Bind

        private void Search()
        {
            this.gantt.DefaultColumnWidth = this.CellWidthSize;
            this.gantt.DefaultRowHeight = this.CellHeightSize;

            // Check: Wait Cursor
            using (var wc = new Mozart.Studio.UIComponents.WaitCursor(this))
            {
                this.queryButton.Enabled = false;
                this.BindData();
                this.queryButton.Enabled = true;
            }
        }

        protected void BindData()
        {
            this.gantt.Build(
                this.LineID,
                this.SelectedAreaIDs,
                this.GetCheckedEqpList(),
                this.StartDate,
                this.EndDate,
                searchIDtextBox.Text,
                this.showIdleCheck.Checked,
                this.SelectedSimType
            );

            this.gantt.Expand(false);
            this.list = this.gantt.table.Values.ToList();

            this.BindGrid();
        }

        private void BindGrid()
        {
            this.list.Sort(new CompareGanttInfo(SortOptions.PROCESS_GROUP, SortOptions.EQP_ID, SortOptions.TYPE));

            this.gantt.Workbook.BeginUpdate();
            this.gantt.ResetWorksheet();

            this.SetColumnHeaders();

            this.isFirst = true;
            this.preAreaId = string.Empty;
            this.preRowKey = string.Empty;

            this.preColor = XtraSheetHelper.AltColor;
            this.currColor = XtraSheetHelper.AltColor2;

            this.startSameTypeRowIdx = 0;
            this.startSameEqpRowIdx = 0;
            this.startSameRowKeyIdx = 0;
            this.subTotalTI = 0;
            this.totalTI = 0;

            this.eqpCount = 0;
            this.calCount = 0;
            this.totLoadRate = 0;

            this.gantt.Bind(this.list);

            this.gantt.Worksheet.SetRowHeight(this.gantt.FirstRowIndex, this.gantt.LastRowIndex, this.CellHeightSize);
            this.gantt.Workbook.EndUpdate();

            this.gantt.Worksheet.Columns.AutoFit(0, 2);
            this.gantt.Worksheet.Columns.AutoFit(this.gantt.LastColIndex + 1, this.gantt.LastColIndex + 3);
        }

        protected void SetColumnHeaders()
        {
            int colCount = Convert.ToInt32(this.cbeDurationHr.Value) + 5;
            this.gantt.FixedColCount = 3;
            this.gantt.FixedRowCount = 2;

            this.gantt.SetColumnHeaders(colCount,
                new XtraSheetHelper.SfColumn(ColName.PrcGroup, "Area", 85),
                new XtraSheetHelper.SfColumn(ColName.EqpId, "Equipment", 120),
                new XtraSheetHelper.SfColumn(ColName.Type, "Info", 45)
                );

            this.gantt.Worksheet.Rows[1].Style = this.gantt.Workbook.Styles["CustomHeader"];
            this.gantt.Worksheet.Rows[0].Style = this.gantt.Workbook.Styles["CustomHeader"];

            this.gantt.Worksheet[0, 1].Style = this.gantt.Workbook.Styles["CustomHeaderCenter"];
            this.gantt.Worksheet[0, 2].Style = this.gantt.Workbook.Styles["CustomHeaderCenter"];

            this.gantt.Worksheet[0, colCount].Style = this.gantt.Workbook.Styles["CustomHeaderRight"];
            this.gantt.Worksheet[0, 0].Style = this.gantt.Workbook.Styles["CustomHeaderCenter"];
            this.gantt.Worksheet[0, colCount - 1].Style = this.gantt.Workbook.Styles["CustomHeaderRight"];
            this.gantt.Worksheet[0, colCount - 2].Style = this.gantt.Workbook.Styles["CustomHeaderRight"];
        }

        #endregion

        #region EventHandler

        private void BindEvents()
        {
            this.gantt.HeaderHourChanged += new GanttColumnHeaderEventHandler(GanttView_HeaderHourChanged);
            this.gantt.HeaderShiftChanged += new GanttColumnHeaderEventHandler(GanttView_HeaderShiftChanged);
            this.gantt.HeaderDone += new GanttColumnHeaderEventHandler(GanttView_HeaderDone);

            this.gantt.BindRowAdding += new GanttRowEventHandler(GanttView_BindRowAdding);
            this.gantt.BindBarAdded += new GanttCellEventHandler(GanttView_BindBarAdded);
            this.gantt.BindRowAdded += new GanttRowEventHandler(GanttView_BindRowAdded);
            this.gantt.BindItemAdded += new GanttItemEventHandler(GanttView_BindItemAdded);
            this.gantt.BindDone += new EventHandler(GanttView_BindDone);

            this.gantt.BarDraw += new BarDrawEventHandler(GanttView_BarDraw);

            this.gantt.BarClick += new BarEventHandler(GanttView_BarClick);
            this.gantt.BarDoubleClick += new BarEventHandler(GanttView_BarDoubleClick);
            this.gantt.CellClick += new CellEventHandler(GanttView_CellClick);
        }

        private void btnQuery_Click(object sender, EventArgs e)
        {
            if (this.gantt.toolTip != null)
                this.gantt.toolTip.Close();
            gridControl1.DataSource = null;
            Search();
        }

        private void searchIDtextBox_KeyUp(object sender, System.Windows.Forms.KeyEventArgs e)
        {
            // Determine whether the key entered is the F1 key. Display help if it is.
            if (e.KeyCode == Keys.Enter)
                btnQuery_Click(sender, e);
        }

        void GanttView_HeaderHourChanged(object sender, GanttColumnHeaderEventArgs args)
        {
            string key = args.Time.ToString(gantt.DateKeyPattern);
            string caption = args.Time.Hour.ToString();
            args.ColumnHeader.AddColumn(new XtraSheetHelper.SfColumn(key, caption, gantt.DefaultColumnWidth, true, false));
        }

        void GanttView_HeaderShiftChanged(object sender, GanttColumnHeaderEventArgs args)
        {
            var startColName = args.Time.ToString(gantt.DateKeyPattern);
            var endColName = args.Time.AddHours(ShopCalendar.ShiftHours - 1).ToString(gantt.DateKeyPattern);

            if (this.StartDate.ShiftStartTimeOfDayT() == args.Time)
                startColName = this.StartDate.ToString(gantt.DateKeyPattern);
            else if (this.EndDate.ShiftStartTimeOfDayT() == args.Time)
                endColName = this.EndDate.AddHours(-1).ToString(gantt.DateKeyPattern);

            if (this.StartDate.ShiftStartTimeOfDayT() == this.EndDate.ShiftStartTimeOfDayT())
                endColName = this.EndDate.AddHours(-1).AddMinutes(-this.EndDate.Minute).ToString(gantt.DateKeyPattern);

            args.ColumnHeader.AddGroupColumn(
                new XtraSheetHelper.SfGroupColumn(args.Time.ToString(this.gantt.DateGroupPattern), startColName, endColName)
                );
        }

        void GanttView_HeaderDone(object sender, GanttColumnHeaderEventArgs e)
        {
            var colHeader = e.ColumnHeader;

            double totLoadRate = 0;

            var loadRateString = string.Format("{0}\n{1}%", ColName.LoadRate, totLoadRate);

#warning Check : right align for total
            colHeader.AddColumn(new XtraSheetHelper.SfColumn(ColName.LoadRate, loadRateString, 60) { HAlign = SpreadsheetHorizontalAlignment.Right });
            colHeader.AddColumn(new XtraSheetHelper.SfColumn(ColName.TIQtySum, 60) { HAlign = SpreadsheetHorizontalAlignment.Right });
            colHeader.AddColumn(new XtraSheetHelper.SfColumn(ColName.TITotal, 80) { HAlign = SpreadsheetHorizontalAlignment.Right });

            this.ganttSizeControl1.LeftExceptCount = this.gantt.FixedColCount;
            this.ganttSizeControl1.TopExceptCount = this.gantt.FixedRowCount;
            this.ganttSizeControl1.RightExceptCount = 3;
        }

        void GanttView_BindRowAdding(object sender, GanttRowEventArgs args)
        {
            var worksheet = this.gantt.Worksheet;

            var info = args.Item as GanttInfo;
            var colHeader = gantt.ColumnHeader;

            var exptEqpId = string.Format("{0}({1}/{2})", info.EqpId, ++eqpCount, list.Count);

            SetRowHeaderValue(args.RowIndex, info.AreaId, info.EqpId, info.Type.ToString(), string.IsNullOrEmpty(args.Key) ? "-" : args.Key);

            this.rowsumti = 0; //2010.09.13 by ldw
            this.rowsumto = 0; //2010.09.13 by ldw

            if (args.Node == null)
                return;

            var rows = args.Node.LinkedBarList;
        }

        void GanttView_BindBarAdded(object sender, GanttCellEventArgs args)
        {
            args.Bar.CumulateQty(ref rowsumti, ref rowsumto);
        }

        void GanttView_BindRowAdded(object sender, GanttRowEventArgs args)
        {
            var info = args.Item as GanttInfo;
            var colHeader = gantt.ColumnHeader;

            string eqpId = info.EqpId.ToString();

            // 만일 해당 장비가 parallelChamber라면 parentEqpid-subEqpId 방식으로 간트차트에 표기가 된다
            // 고로, 장비가 parallelChamber라면 subEqpId만을 가져오도록 변경 필요
            var isParallelChamber = info.Eqp.IsParallelChamber;

            if (isParallelChamber)
            {
                // info.Eqp.EqpId - (info.Eqp.ParentEqpId + '-') 를 하여 subEqpId만 따로 분리하자
                eqpId = info.EqpId.Remove(0, info.Eqp.ParentEqpId.Length + 1);
            }

            double loadRate = 0;
            double chgRate = 0;

            if (info.Type == GanttInfoType.Plan)
            {
                this.gantt.GetTotChgAndLoadRate(LineID, eqpId, out loadRate, out chgRate);
                XtraSheetHelper.SetCellFloatValue(colHeader.GetCellInfo(startSameEqpRowIdx, ColName.LoadRate), Math.Round(loadRate, 1));
            }

            totLoadRate += loadRate;
            calCount++;
            subTotalTI += rowsumti;
            totalTI += rowsumti;

            XtraSheetHelper.SetTotCellValue(colHeader.GetCellInfo(startSameTypeRowIdx, ColName.TIQtySum), subTotalTI);
            XtraSheetHelper.SetTotCellValue(colHeader.GetCellInfo(startSameRowKeyIdx, ColName.TITotal), totalTI);
        }

        void GanttView_BindItemAdded(object sender, GanttItemEventArgs args)
        {
        }

        void GanttView_BindDone(object sender, EventArgs e)
        {
            var colHeader = gantt.ColumnHeader;

            totLoadRate = totLoadRate / calCount;

            var loadRateString = string.Format("{0}\n{1}%", ColName.LoadRate, totLoadRate.ToString("#.#"));

            XtraSheetHelper.SetCellFloatValue(colHeader.GetCellInfo(0, ColName.LoadRate), loadRateString);

            MergeRows(startSameRowKeyIdx, gantt.LastRowIndex, 0);
            MergeRows(startSameEqpRowIdx, gantt.LastRowIndex, 1);
            MergeRows(startSameTypeRowIdx, gantt.LastRowIndex, 2);

            this.PaintTotColumnCell();

            this.SetStyleOnDone();
        }

        void GanttView_BarDraw(object sender, BarDrawEventArgs args)
        {
            var bar = args.Bar as GanttBar;

            switch (this.cbeBrushKey.SelectedItem.ToString())
            {
                case "LotID":
                    bar.BrushKey = bar.LotId;
                    break;
                case "ProductID":
                    bar.BrushKey = bar.PartID;
                    break;
                case "OperID":
                    bar.BrushKey = bar.StepID;
                    break;
                case "RouteID":
                    bar.BrushKey = bar.RouteID;
                    break;
                case "RecipeID":
                    bar.BrushKey = bar.RecipeId;
                    break;
            }

            args.Background = gantt.GetBrushInfo(bar);
            args.DrawFrame = bar.isRCS || bar.isAtStep || bar.isCutIn;

            var framColor = Color.Black;

            if (bar.isRCS)
                framColor = Color.Green;
            if (bar.isCutIn)
                framColor = Color.Red;

            args.FrameColor = framColor;

            args.ForeColor = (bar.State == EqpState.PM || bar.State == EqpState.DOWN) ? Color.White : Color.Black;
            args.Text = bar.GetTitle(false);

            args.DrawDefault = true;
        }

        public void GanttView_BarClick(object sender, BarEventArgs e)
        {
            if (this.gantt.ColumnHeader == null)
                return;

            this.spreadsheetControl1.BeginUpdate();

            if (e.Mouse.Button == System.Windows.Forms.MouseButtons.Right && e.Bar != null)
            {
                this.gantt.TurnOnSelectMode();
                this.gantt.SelectedBar = e.Bar as GanttBar;
            }
            else if (e.Mouse.Button == System.Windows.Forms.MouseButtons.Left && Control.ModifierKeys == Keys.Control)
            {
                ShowToolTip(e.Bar as GanttBar);
            }
            else
            {
                this.gantt.TurnOffSelectMode();
            }

            this.spreadsheetControl1.EndUpdate();
            this.spreadsheetControl1.Refresh();
        }

        public void ShowToolTip(GanttBar bar)
        {
            if (this.gantt.toolTip != null)
            {
                this.gantt.toolTip.Close();

                if (this.gantt.toolTip.bar == bar)
                {
                    this.gantt.toolTip.Dispose();
                    this.gantt.toolTip = null;
                    return;
                }
            }

            this.gantt.toolTip = new ToolTip(bar, this.cbeBrushKey.SelectedItem.ToString());
            this.gantt.toolTip.Location = Cursor.Position;
            this.gantt.toolTip.Show(this.spreadsheetControl1);
        }

        public void GanttView_BarDoubleClick(object sender, BarEventArgs e)
        {
            if (e.Bar == null)
                return;

            Form popup = null;

            foreach (Form f in Application.OpenForms)
            {
                if (f is Gantt.DispatchingInfoViewPopup || f is Gantt.BatchInfoViewPopup)
                {
                    popup = f;
                }
            }

            if (popup != null)
                popup.Close();

            var bar = e.Bar as GanttBar;

#warning Check: Wait Cursor
            using (var x = new Mozart.Studio.UIComponents.WaitCursor(this))
            {
                if (bar.EqpInfo.IsBatchType && (bar.State != EqpState.IDLE && bar.State != EqpState.IDLERUN))
                {
                    var dialog = new Gantt.BatchInfoViewPopup(this, bar);
                    dialog.StartPosition = FormStartPosition.Manual;
                    dialog.Show(this);
                }
                else
                {
                    //if (bar.DispatchingInfo == null || bar.DispatchingInfo.Length == 0)
                    //{
                    //    MessageBox.Show("There is no DispatchingInfo for this Bar", "Notification", MessageBoxButtons.OKCancel, MessageBoxIcon.Asterisk);
                    //    return;
                    //}

                    string eqpId = bar.EqpInfo.ParentEqpId == "" ? bar.EqpInfo.EqpId : bar.EqpInfo.ParentEqpId;
                    var presetInfo = this.modelCtx.PRESET.Where(y => y.EQP_ID == eqpId && y.PROGRAM_ID == "DEFAULT" && y.PRESET_MODE == this.presetMode).FirstOrDefault();

                    if (presetInfo == null)
                    {
                        MessageBox.Show("invalid presetInfo");
                        return;
                    }

                    bar.PresetId = presetInfo.PRESET_ID;
                    var matchedList = presetList.Where(y => y.PRESET_ID == presetInfo.PRESET_ID).ToList();

                    var dialog = new Gantt.DispatchingInfoViewPopup(bar, matchedList, result);
                    dialog.StartPosition = FormStartPosition.Manual;
                    dialog.Show(this);
                }
            }
        }

        private void SetRowHeaderValue(int rowIndex, string areaId, string eqpId, string type, string stepSeq)
        {
            string curKey = FabSimulatorUI.Helper.CreateKey(areaId);
            var colHeader = this.gantt.ColumnHeader;

            if (isFirst)
            {
                preAreaId = areaId;
                preEqpId = eqpId;
                preType = type;
                preRowKey = curKey;
                startSameTypeRowIdx = rowIndex;
                startSameEqpRowIdx = rowIndex;
                startSameRowKeyIdx = rowIndex;

                isFirst = false;
            }

            if (isFirst == false && curKey.Equals(preRowKey) == false)
            {
                MergeRows(startSameRowKeyIdx, rowIndex - 1, 0);

#warning Check : PrcGroup Text Alignment
                if (rowIndex - startSameRowKeyIdx > 1)
                    gantt.Worksheet[startSameRowKeyIdx, 0].Alignment.Vertical = SpreadsheetVerticalAlignment.Top;

                Color tmp = preColor;
                preColor = currColor;
                currColor = tmp;
                preRowKey = curKey;
                startSameRowKeyIdx = rowIndex;
                totalTI = 0;
                gantt.GroupRows.Add(rowIndex);
            }

            if (isFirst == false && eqpId.Equals(preEqpId) == false)
            {
                MergeRows(startSameEqpRowIdx, rowIndex - 1, 1);
                MergeRows(startSameTypeRowIdx, rowIndex - 1, 2);

                preEqpId = eqpId;
                preType = type;
                startSameTypeRowIdx = rowIndex;
                startSameEqpRowIdx = rowIndex;
                subTotalTI = 0;
            }
            else if (type.Equals(preType) == false)
            {
                MergeRows(startSameTypeRowIdx, rowIndex - 1, 2);

                preEqpId = eqpId;
                preType = type;
                startSameTypeRowIdx = rowIndex;
                subTotalTI = 0;
            }

            XtraSheetHelper.SetCellText(colHeader.GetCellInfo(rowIndex, ColName.EqpId), eqpId);
            XtraSheetHelper.SetCellText(colHeader.GetCellInfo(rowIndex, ColName.PrcGroup), areaId);
            XtraSheetHelper.SetCellText(colHeader.GetCellInfo(rowIndex, ColName.Type), type);
        }

        private void MergeRows(int fromRowIdx, int toRowIdx, int colIdx = 0)
        {
            var worksheet = this.gantt.Worksheet;

            worksheet.MergeRowsOneColumn(fromRowIdx, toRowIdx, colIdx);

            if (colIdx > 1)
                SetBorder(fromRowIdx, toRowIdx);
        }

        private void SetBorder(int fromRowIdx, int toRowIdx)
        {
            var worksheet = this.gantt.Worksheet;
            var color = System.Drawing.Color.FromArgb(224, 224, 224);

            for (int i = fromRowIdx; i <= toRowIdx; i++)
            {
                if (i == fromRowIdx)
                    XtraSheetHelper.SetRowBorderTopLine(worksheet, i, color, BorderLineStyle.Thin);
                else
                    XtraSheetHelper.SetRowBorderTopLine(worksheet, i, Color.Transparent, BorderLineStyle.Thin);

                XtraSheetHelper.SetRowBorderBottomLine(worksheet, i, Color.Transparent);
            }
        }

        private void PaintTotColumnCell()
        {
            var worksheet = this.gantt.Worksheet;

            var colHeader = this.gantt.ColumnHeader;
#warning Check
            worksheet.SetUsedColumnFillColor(colHeader.TryGetColumnIndex(ColName.LoadRate), Color.FromArgb(248, 223, 224), 2);
            worksheet.SetUsedColumnFillColor(colHeader.TryGetColumnIndex(ColName.TIQtySum), Color.FromArgb(219, 236, 216), 2);
            worksheet.SetUsedColumnFillColor(colHeader.TryGetColumnIndex(ColName.TITotal), Color.FromArgb(204, 255, 195), 2);
        }

        private void SetStyleOnDone()
        {
            for (int i = 2; i < gantt.LastRowIndex + 2; i++)
            {
                for (int j = 0; j < gantt.FixedColCount; j++)
                    gantt.Worksheet[i, j].Style = gantt.Workbook.Styles["CustomDefaultCenter"];

                for (int j = 3; j <= gantt.LastColIndex; j++)
                    gantt.Worksheet[i, j].Style = gantt.Workbook.Styles["CustomBar"];
            }
        }

        private void cbeBrushKey_SelectedValueChanged(object sender, EventArgs e)
        {
            this.spreadsheetControl1.Refresh();
        }

        private void spreadsheetControl1_BeforeDispose(object sender, EventArgs e)
        {
            if (this.gantt.toolTip != null)
                this.gantt.toolTip.Close();
        }

        private void ganttSizeControl1_CellHeightChanged(object sender, EventArgs e)
        {
            Extensions.SetLocalSetting(this.ServiceProvider, "ganttRowSize", this.ganttSizeControl1.CellHeight.ToString());
        }

        private void ganttSizeControl1_CellWidthChanged(object sender, EventArgs e)
        {
            Extensions.SetLocalSetting(this.ServiceProvider, "ganttCellSize", this.ganttSizeControl1.CellWidth.ToString());
        }

        private void toolTipController1_GetActiveObjectInfo(object sender, DevExpress.Utils.ToolTipControllerGetActiveObjectInfoEventArgs e)
        {
            if (e.SelectedControl != spreadsheetControl1) return;

            DevExpress.Utils.ToolTipControlInfo info = null;
            //Get the view at the current mouse position

            DevExpress.Spreadsheet.Cell cell = spreadsheetControl1.GetCellFromPoint(e.ControlMousePosition);
            if (cell != null)
            {
                //An object that uniquely identifies a row indicator cell                
                string text = String.Format("Cell:{0}, Value:{1}", cell.CurrentRegion.GetReferenceA1(), cell.Value.ToString());
                string cellIndex = String.Format("Cell:{0}{1}", cell.RowIndex, cell.ColumnIndex);
                info = new DevExpress.Utils.ToolTipControlInfo(cellIndex, text);
            }
            //Supply tooltip information if applicable, otherwise preserve default tooltip (if any)
            if (info != null)
                e.Info = info;
        }

        #endregion

        #region ProcessLotList Grid

        void GanttView_CellClick(object sender, CellEventArgs e)
        {
#warning Check
            if (gantt.ColumnHeader == null)
                return;
            if (e.ColIndex >= gantt.FixedColCount)
                return;
            if (e.RowIndex < gantt.FixedRowCount)
                return;

            var worksheet = this.gantt.Worksheet;
            worksheet.SelectRowUsed(e.RowIndex, false, 0);

            var rowIndex = worksheet.GetMergedTopRowIndex(e.RowIndex, 1);

            var eqpId = worksheet[rowIndex, 1].DisplayText;

            if (string.IsNullOrEmpty(eqpId))
                return;

            // 설비명에 괄호가 포함되는 경우가 있음 (ISU)
            //int idx = eqpId.IndexOf("(");
            //if (idx > 0)
            //    eqpId = eqpId.Substring(0, idx);

            var type = worksheet[e.RowIndex, 2].DisplayText;
            ViewEqpProcessDetail(eqpId, type);
        }

        private void ViewEqpProcessDetail(string eqpId, string type)
        {
            var info = this.GetGanttInfo(eqpId, type);
            if (info == null)
                return;

            this.BindEqpProcessDetail(info);
        }

        private GanttInfo GetGanttInfo(string eqpId, string type)
        {
            foreach (var info in list)
            {
                if (info.EqpId == eqpId && info.Type.ToString() == type)
                    return info;
            }
            return null;
        }

        private void BindEqpProcessDetail(GanttInfo info)
        {
            var dt = new List<LoadDetail>();

            foreach (var item in info.Items)
            {
                string step = item.Key;

                foreach (GanttBar b in item.Value)
                {
                    if (b.BarKey != step)
                        continue;

                    var drow = new LoadDetail();

                    drow.ResourceID = b.EqpId;

                    string state = string.Empty;

                    state = b.State.ToString();

                    drow.State = state;

                    if (b.State == EqpState.BUSY)
                    {
                        drow.LotID = b.LotId;
                        drow.ProductID = b.PartID;
                        drow.OperID = b.StepID;
                        drow.LotQty = (int)b.TIQty;
                        drow.RecipeID = b.RecipeId;
                        drow.ToolingID = b.ToolingID;
                    }
                    drow.ArrivalTime = b.ArrivalTime;
                    drow.StartTime = b.TkinTime.ToString("yyyy/MM/dd HH:mm:ss");
                    drow.EndTime = b.TkoutTime.ToString("yyyy/MM/dd HH:mm:ss");
                    drow.ProcessTime = b.TkoutTime.RoundToSecond() - b.TkinTime.RoundToSecond();

                    drow.OriginalIndex = dt.Count;
                    drow.StartTimeForSort = b.TkinTime;

                    dt.Add(drow);
                }
            }

#warning Check : BUGGY
            var sorted = dt;
            if (info.Eqp.EqpType == "Inline" || info.Eqp.EqpType == "BatchInLine" || info.Eqp.EqpType == "Chamber") //For Sorting InvisibleLots
                sorted = dt.OrderBy(x => x.StartTimeForSort).ThenBy(x => x.OriginalIndex).ToList();
            else
                sorted = dt.OrderBy(x => x.StartTime).ThenBy(x => x.OriginalIndex).ToList();//.Sort((x, y) => x.START_TIME.CompareTo(y.START_TIME)); 

            gridControl1.BeginUpdate();

            gridControl1.DataSource = sorted;
            gridView1.OptionsView.ShowAutoFilterRow = true;
            gridView1.OptionsSelection.MultiSelect = true;

            gridView1.BestFitColumns();

            gridControl1.EndUpdate();
        }

        #endregion

        #region TreeList (Optional)
        void SetTreeList(ISet<String> selectedArea)
        {
            treeView1.Nodes.Clear();

            if (selectedArea.Count == 0)
                return;

            treeView1.CheckBoxes = true;
            treeView1.Nodes.Add("Check All", "Check All");

            foreach (var srow in modelCtx.EQP.OrderBy(x => x.EQP_GROUP))
            {
                if (srow.SIM_TYPE == "Chamber" && !string.IsNullOrEmpty(srow.PARENT_EQP_ID))
                    continue;

                if (string.IsNullOrEmpty(srow.AREA_ID) || string.IsNullOrEmpty(srow.EQP_GROUP) || string.IsNullOrEmpty(srow.EQP_ID))
                    continue;

                if (!selectedArea.Contains(srow.AREA_ID))
                    continue;

                var wsGroup = srow.EQP_GROUP;
                var eqp = srow.EQP_ID;

                if (!treeView1.Nodes.ContainsKey(wsGroup))
                {
                    treeView1.Nodes.Add(wsGroup, wsGroup);
                    treeView1.Nodes[wsGroup].Nodes.Add(eqp, eqp);
                }
                else if (treeView1.Nodes[wsGroup].Nodes.ContainsKey(eqp) == false)
                {
                    treeView1.Nodes[wsGroup].Nodes.Add(eqp, eqp);
                }
            }

            foreach (TreeNode node in treeView1.Nodes)
            {
                node.Checked = true;
                foreach (TreeNode child in node.Nodes)
                {
                    child.Checked = true;
                }
            }
        }

        private ISet<string> GetCheckedEqpList()
        {
            var checkedEqps = new HashedSet<string>();

            foreach (TreeNode node in treeView1.Nodes)
            {
                foreach (TreeNode child in node.Nodes)
                {
                    if (child.Checked)
                        checkedEqps.Add(child.Text);
                }
            }

            if (checkedEqps.Count == 0)
                return null;

            return checkedEqps;
        }

        private void treeView1_AfterCheck(object sender, TreeViewEventArgs e)
        {
            if (e.Node.Text == "Check All")
            {
                SwitchCheckAll(e.Node.Checked);
                return;
            }

            foreach (TreeNode child in e.Node.Nodes)
            {
                if (e.Node.Checked)
                    child.Checked = true;
                else
                    child.Checked = false;
            }
        }

        private void SwitchCheckAll(bool isChecked)
        {
            foreach (TreeNode node in treeView1.Nodes)
            {
                if (node.Text == "Check All")
                    continue;

                node.Checked = isChecked;
                foreach (TreeNode child in node.Nodes)
                {
                    child.Checked = isChecked;
                }
            }
        }

        private void areaCheckedBox_Leave(object sender, EventArgs e)
        {
            this.SetTreeList(this.SelectedAreaIDs);
        }
        #endregion

    }
}
