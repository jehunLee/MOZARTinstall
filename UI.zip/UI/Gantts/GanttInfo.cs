﻿///
// file:	Gantts\GanttInfo.cs
//
// summary:	Implements the gantt information class
///
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Mozart.Studio.TaskModel.UserLibrary.GanttChart;

namespace FabSimulatorUI.Gantts
{

    public class GanttInfo : GanttItem
    {
        public string AreaId;
        public string EqpId;
        public GanttInfoType Type;
        public Eqp Eqp;

        public GanttInfo(string prcGroup,  Eqp eqp, string eqpID, GanttInfoType type)
            : base()
        {
            this.AreaId = prcGroup;
            this.Eqp = eqp;
            this.EqpId = eqpID;
            this.Type = type;
        }

        public void AddItem(string key, GanttBar bar)
        {
            BarList list;
            if (!this.Items.TryGetValue(key, out list))
            {
                this.Items.Add(key, list = new BarList());
                list.Add(bar);
                return;
            }

            // Merge PM when TargetDate Changed
            // Other Cases are already handled through GetExistPrevItem Methods
            foreach (GanttBar it in list)
            {
                if (it.LotId != bar.LotId || it.State != bar.State)
                    continue;

                if (it.Merge(bar))
                {
                    it.TIQty = it.TOQty;
                    return;
                }
            }

            list.Add(bar);
        }

        public Bar GetBarItem(string key, string lotId)
        {
            BarList list;
            if (!this.Items.TryGetValue(key, out list))
                return null;

            return list.FindLast(t => (t as GanttBar).LotId == lotId);
        }
    }

    public class CompareGanttInfo : IComparer<GanttInfo>
    {
        private SortOptions[] sortList;

        public CompareGanttInfo(params SortOptions[] sortList)
        {
            this.sortList = sortList;
        }

        public int Compare(GanttInfo x, GanttInfo y)
        {
            int iCompare = 0;
            foreach (var sort in sortList)
            {
                iCompare = Compare(x, y, sort);
                if (iCompare != 0)
                    break;
            }

            return iCompare;
        }

        private int Compare(GanttInfo x, GanttInfo y, SortOptions sort)
        {     
            if (sort == SortOptions.EQP_ID)
            {
                return x.EqpId.CompareTo(y.EqpId);
            }
            else if (sort == SortOptions.STEP_SEQ)
            {
            }
            else if (sort == SortOptions.PROCESS_GROUP)
            {
                return x.AreaId.CompareTo(y.AreaId);
            }
            else if (sort == SortOptions.TYPE)
            {
                return y.Type.CompareTo(x.Type);
            }

            return 0;
        }
    }
}
