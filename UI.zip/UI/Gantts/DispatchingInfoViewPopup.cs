﻿///
// file:	Gantts\DispatchingInfoViewPopup.cs
//
// summary:	Implements the dispatching information view popup class
///
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using DevExpress.XtraGrid.Columns;
using DevExpress.Data.PivotGrid;
using DevExpress.XtraCharts;
using Mozart.Studio.TaskModel.UserLibrary;
using FabSimulatorUI.Gantts;
using DevExpress.XtraGrid.Views.Grid;
using DevExpress.XtraEditors.Repository;
using FabSimulator.Inputs;
using FabSimulator.Outputs;
using Mozart.Collections;
using Mozart.Studio.TaskModel.Projects;
using FabSimulator;

namespace FabSimulatorUI.Gantt
{
    public partial class DispatchingInfoViewPopup : DevExpress.XtraEditors.XtraForm
    {

        #region Class Variables
        /// <summary>   The bar. </summary>
        GanttBar _bar;
        /// <summary>   The dispatch infos. </summary>
        EQP_DISPATCH_LOG[] _dispatchInfos;
        /// <summary>   Information describing the selected. </summary>
        EQP_DISPATCH_LOG _selectedInfo;
        /// <summary>   Information describing the eqp. </summary>
        Eqp _eqpInfo;
        /// <summary>   The selected WIP. </summary>
        string _selectedWip;
        /// <summary>   The triggered Chamber. </summary>
        string _triggeredChamber;
        /// <summary>   List of presets. </summary>
        List<WEIGHT_PRESETS> _presetList;
        /// <summary>   List of factors. </summary>
        List<string> _factorList = new List<string>();
        /// <summary>   The result. </summary>
        IExperimentResultItem _result;
        /// <summary>   The back color. </summary>
        Color _backColor;
        /// <summary>   True to show, false to hide the product information. </summary>
        bool showProductInfo;

        /// <summary>   True while initialization is in progress. </summary>
        bool initializing;
        #endregion

        private EQP_DISPATCH_LOG SelectedInfo
        {
            get { return _selectedInfo; }
            set
            {
                _selectedInfo = value;

                SetControl(_bar);
                BindData(_selectedInfo);

                if (_selectedInfo != null)
                    DecorateTable();
            }
        }

        #region Constructors

        public DispatchingInfoViewPopup(GanttBar bar, List<WEIGHT_PRESETS> presetList, IExperimentResultItem result)
        {
            _bar = bar;
            var info = bar.EqpInfo;
            var dispatchingInfos = bar.DispatchingInfo;
            var backColor = bar.BackColor;

            this.initializing = true;

            _result = result;
            _backColor = backColor;

            InitializeComponent();

            _eqpInfo = info;
            _dispatchInfos = dispatchingInfos;
            _presetList = presetList;

            InitializeUserControl();

            this.SelectedInfo = (dispatchingInfos == null || dispatchingInfos.Count() == 0) ? null : dispatchingInfos.FirstOrDefault();

            //SetControl(bar);
            //BindData(_selectedInfo);

            

            this.initializing = false;

#if true
            this.FillDispatchingForReservation(gridView1);
#else
            this.FillEqpPlan(gridView1); 
#endif
        }

        /// <summary>   Initializes the user control. </summary>
        private void InitializeUserControl()
        {
            if (_dispatchInfos == null || _dispatchInfos.Count() == 0)
                return;
            
            foreach (var log in _dispatchInfos)
                this.dispatchInTimeComboBox.Items.Add(new ComboBoxItem(log));

            if(this.dispatchInTimeComboBox.Items.Count > 0)
                this.dispatchInTimeComboBox.SelectedIndex = 0;
        }


        #endregion

        #region Set Control

        private void SetControl(GanttBar bar)
        {
            var log = this._selectedInfo;
            string state = bar.State.ToString();

            StringBuilder sb = new StringBuilder();
            
            if (_eqpInfo != null)
                sb.AppendLine(_eqpInfo.ToString(log,_bar.PresetId));                

            if (log != null)
            {
                this.Text = string.Format("Dispatching Information - {0}", log.EVENT_TIME.DbToString());
            
                sb.AppendFormat("Initial Wip Count:\t\t{0}\r\n", log.INIT_WIP_CNT);
                sb.AppendFormat("Filtered Wip Count:\t\t{0}\r\n", log.FILTERED_WIP_COUNT);
                sb.AppendFormat("Selected Wip Count:\t{0}\r\n", log.SELECTED_WIP_COUNT);

                sb.AppendLine("+ -------------------------------------------------");
                sb.AppendLine();
            }

            sb.AppendLine(string.Format("ProductID : {0}", bar.PartID));
            sb.AppendLine(string.Format("LotID\t : {0}", bar.LotId));
            sb.AppendLine(string.Format("OperID\t : {0}", bar.StepID));
            sb.AppendLine(string.Format("RecipeID\t : {0}", bar.RecipeId));
            sb.AppendLine(string.Format("ToolingID\t : {0}", bar.ToolingID));
            sb.AppendLine();
            sb.AppendLine(string.Format("{0} -> {1}", bar.TkinTime, bar.TkoutTime));
            sb.AppendLine(string.Format("Gap\t : {0}", bar.TkoutTime - bar.TkinTime));

            this.eqpInfoTextBox.Text = sb.ToString();
        }

        #endregion

        #region Binding

        ///
        /// <summary>   Bind data. </summary>
        private void BindData(EQP_DISPATCH_LOG log)
        {
            if (this._selectedInfo == null)
                return;

            this._selectedWip = log.SELECTED_WIP; // SELECTED_WIP
            var dispatchWipLog = log.DISPATCH_WIP_LOG ?? string.Empty; // DISPATCH_WIP_LOG
            var infoList = dispatchWipLog.Split(';');
            var sample = infoList[0].Split('/');     

            this.showProductInfo = sample.Length - _presetList.Count > 1;
            this.SetupDispatchInfoSchema(_presetList);

            var result = new List<DispatchInfo>();
            var summary = new MultiDictionary<string, int>();

            
            foreach (string info in infoList)
            {
                if (!string.IsNullOrEmpty(info))
                {
                    string[] split = info.Split('/');
                    var item = new DispatchInfo();


                    item.LOT_ID = split[0];
                    var productID = split[1];
                    var operID = split[2];
                    //var select = split[4];
                    //if (_triggeredChamber.IsEmptyID())
                    //    _triggeredChamber = select;

                    var sIndex = 4;
                    //int temp;
                    //if (int.TryParse(select, out temp))
                    //{
                    //    sIndex = 4; // for old version
                    //    select = "-";
                    //}

                    if (this.showProductInfo)
                    {
                        item[ColName.ProductID] = productID;
                        item[ColName.OperID] = operID;

                        int qty;
                        if (!int.TryParse(split[3], out qty))
                            qty = 0;

                        item[ColName.LotQty] = qty;
                       // item[ColName.SELECT] = select;
                        //item[ColName.DueDate] = split[4].Length >= 8 ? split[4].Substring(0, 8) : split[4];

                        summary.Add(productID, qty);
                    }

                    double sum = 0d;
                    for (int i = this.showProductInfo ? sIndex : 1; i < split.Length; i++)
                    {
                        double dvalue;
                        if (double.TryParse(split[i], out dvalue) == false)
                            dvalue = 0;

                        var factorID = _factorList[i - (this.showProductInfo ? sIndex : 1)];
                        item[factorID] = Math.Round(dvalue, 4);
                        sum += dvalue;
                    }

                    item[ColName.WEIGHTED_SUM] = sum;

                    result.Add(item);
                }
            }

            this.FillGrid(result);
            this.FillSummaryTable(summary);

            this.FillFilterTable(log.FILTERED_WIP_LOG);
        }


        private void FillGrid(List<DispatchInfo> results)
        {
            gridControl1.DataSource = results.ToBindingList();
            //gridControl1.DataSource = results.OrderByDescending(x => x[ColName.WEIGHTED_SUM]).ToBindingList();
            gridView1.PopulateColumns();

            foreach (var column in gridView1.Columns.OfType<GridColumn>())
            {
                //if (column.ColumnType == typeof(double))
                //{
                //    column.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Custom;
                //    column.DisplayFormat.FormatString = "{0:##0.0%}";
                //}
            }

            gridView1.BestFitColumns();
        }

        private void FillFilterTable(string filterLog)
        {
            var list = new List<FilterInfo>();

            if (filterLog.IndexOf(':') > 0)
            {
                var reasons = filterLog.Split(';');

                foreach (var str in reasons)
                {
                    var split = str.Split(':');

                    var reason = split[0].Trim();
                    var lotInfos = split[1].Split(',');

                    foreach (var info in lotInfos)
                    {
                        var infoSplit = info.Split('/');

                        if(infoSplit.Count() == 4)
                        {
                            var lotId = infoSplit[0].Trim();
                            var prodId = infoSplit[1].Trim();
                            var operId = infoSplit[2].Trim();
                            var qty = Convert.ToInt32(infoSplit[3].Trim());
                            //var reticleSet = infoSplit[4].Trim();

                            list.Add(new FilterInfo() { REASON = reason, LOT_ID = lotId, PRODUCT_ID = prodId, OPER_ID = operId, LOT_QTY = qty});//, RETICLE_SET = reticleSet });
                        }
                        else
                        {
                            list.Add(new FilterInfo() { REASON = reason, LOT_ID = info });
                        }
                    }
                }
            } 
            gridControl3.DataSource = list;
            gridView3.PopulateColumns();
            gridView3.BestFitColumns();
        }

        private void FillSummaryTable(MultiDictionary<string, int> summary)
        {
            var result = new List<SummaryInfo>();

            foreach (var pair in summary)
            {
                var row = new SummaryInfo()
                {
                    PRODUCT_ID = pair.Key,
                    COUNT = pair.Value.Count,
                    WaferQty = pair.Value.Sum()
                };

                result.Add(row);
            }

            gridControl2.DataSource = result;
            gridView2.BestFitColumns();
        }

        class DispatchInfo : Expandable
        {
            public string LOT_ID { get; set; }
            //public double WEIGHTED_SUM { get; set; }
        }

        class FilterInfo
        {
            public string REASON { get; set; }

            public string LOT_ID { get; set; }

            public string PRODUCT_ID { get; set; }

            public string OPER_ID { get; set; }

            public int LOT_QTY { get; set; }

            //public string RETICLE_SET { get; set; }
        }

        class SummaryInfo 
        {
            public string PRODUCT_ID { get; set; }
           
            public int COUNT { get; set; }

            public int WaferQty { get; set; }
        }

        class ColName
        {
            #region DispatchInfo
            public static string ProductID = "PRODUCT_ID";
            public static string OperID = "OPER_ID";
            public static string LotQty = "LOT_QTY";
            public static string DueDate = "DUE_DATE";
            #endregion

            public static string LotID = "LOT_ID";
            //public static string SELECT = "SELECT";
            public static string WEIGHTED_SUM = "WEIGHTED_SUM";
            public static string COUNT = "COUNT";
        }

        private void SetupDispatchInfoSchema(IEnumerable<WEIGHT_PRESETS> factorList)
        {
            Type<DispatchInfo>.ClearProperties();

            var test = new DispatchInfo();
            
            if (this.showProductInfo)
            {
                Type<DispatchInfo>.RegisterProperty(ColName.ProductID,typeof(string));
                Type<DispatchInfo>.RegisterProperty(ColName.OperID, typeof(string));
                Type<DispatchInfo>.RegisterProperty(ColName.LotQty, typeof(int));
                //Type<DispatchInfo>.RegisterProperty(ColName.SELECT, typeof(string));
            }

            Type<DispatchInfo>.RegisterProperty(ColName.WEIGHTED_SUM, typeof(double));

            foreach (var f in factorList)
            {
                _factorList.Add(f.FACTOR_ID);
                Type<DispatchInfo>.RegisterProperty(f.FACTOR_ID, typeof(string));
            }
        }

        private void DecorateTable()
        {
            var fix = true;

            foreach (var gcol in this.gridView1.Columns.OfType<GridColumn>())
            {
                if (fix)
                {
                    gcol.Fixed = FixedStyle.Left;
                    gcol.BestFit();

                    if (gcol.FieldName == ColName.WEIGHTED_SUM)
                        break;
                }
            }

            this.gridView1.Columns[ColName.WEIGHTED_SUM].AppearanceCell.BackColor = Color.FromArgb(204, 255, 195);

            this.gridView2.Columns[ColName.COUNT].SortOrder = DevExpress.Data.ColumnSortOrder.Descending;

            SetDisplayFormat(gridView1);
            SetDisplayFormat(gridView2);
        }

        private void gridView1_RowStyle(object sender, DevExpress.XtraGrid.Views.Grid.RowStyleEventArgs e)
        {
            if (e.RowHandle < 0)
                return;

            string wipID = gridView1.GetRowCellDisplayText(e.RowHandle, gridView1.Columns[ColName.LotID]);
            //string triggeredChamber = gridView1.GetRowCellDisplayText(e.RowHandle, gridView1.Columns[ColName.SELECT]);

            if (string.IsNullOrEmpty(wipID) || !_selectedWip.Contains(wipID))
                return;

            //if (triggeredChamber != _triggeredChamber)
            //{
            //    e.Appearance.BackColor = _backColor == Color.White ? _backColor : Color.LightYellow;
            //    return;
            //}

            e.Appearance.Font = this.GetBoldFont ();
            e.Appearance.BackColor = _backColor == Color.White ? _backColor : Color.LightPink;
        }

        /// <summary>   The bold font. </summary>
        Font _boldFont;

        private Font GetBoldFont()
        {
            if (_boldFont == null)
                _boldFont = new System.Drawing.Font(DefaultFont, FontStyle.Bold);

            return _boldFont;
        }

        private void FillEqpPlan(GridView view)
        {
            var selection = view.GetFocusedRow();
            if (selection == null)
                return;

            string lotID;
            if (selection is DispatchInfo)
                lotID = (selection as DispatchInfo).LOT_ID;
            else lotID = (selection as FilterInfo).LOT_ID;

            //string lotID = view.GetFocusedRowCellDisplayText("LOT_ID");

            if (!string.IsNullOrEmpty(lotID))
                this.FillEqpPlan(lotID);
        }

        private void FillDispatchingForReservation(GridView view)
        {
            var selection = view.GetFocusedRow();
            if (selection == null)
                return;

            string lotID;
            string operID;
            if (selection is DispatchInfo)
            {
                lotID = (selection as DispatchInfo).LOT_ID;
                operID = (string)(selection as DispatchInfo)[ColName.OperID];
            }
            else
            {
                lotID = (selection as FilterInfo).LOT_ID;
                operID = (selection as FilterInfo).OPER_ID;
            }
        }

        private void FillEqpPlan(string lotID)
        {
            this.gridControl4.BeginUpdate();
            this.gridControl4.DataSource = null;

            var rslt = _result.GetCtx<ResultDataContext>();
            var eqpPlan = rslt.EQP_PLAN;

            var fQyery = (from eqp in eqpPlan.Where(x => x.LOT_ID == lotID)
                         select new 
                         {
                              eqp.LINE_ID,
                             // eqp.ProcessFacilityId,
                              eqp.EQP_ID,
                              eqp.ROUTE_ID,
                              eqp.STEP_SEQ,
                              eqp.STEP_ID,
                              eqp.START_TIME,
                              eqp.END_TIME,
                              eqp.RECIPE_ID,
                              eqp.TOOLING_ID,
                              eqp.WAFER_QTY,
                              eqp.LOT_PRIORITY,
                              //eqp.MfgPartCode,
                              //eqp.OPER_TYPE,
                              eqp.AREA_ID,
                              //eqp.RECIPE_ID,
                              eqp.ARRIVAL_TIME,
                              //eqp.PodId
                         }).OrderBy(x => x.ARRIVAL_TIME).ThenBy(x => x.START_TIME);

            gridControl4.DataSource = fQyery.ToBindingList();

            this.SetGridControlFields(gridView4);
            this.gridControl4.EndUpdate();
            this.gridView4.BestFitColumns();
        }

        #endregion

        private void SetGridControlFields(GridView view)
        {
            foreach (GridColumn col in view.Columns)
            {
                if (col.ColumnType == typeof(DateTime))
                {
                    var dateTimeEdit = new RepositoryItemDateEdit();
                    dateTimeEdit.EditMask = "yyyy/MM/dd HH:mm:ss";
                    dateTimeEdit.DisplayFormat.FormatString = "yyyy/MM/dd HH:mm:ss";

                    col.ColumnEdit = dateTimeEdit;
                }
            }
        }

        private void tabControl1_SelectedIndexChanged(object sender, EventArgs e)
        {
#if true
            if (tabControl1.SelectedIndex == 0)
                this.FillDispatchingForReservation(gridView1);
            else if (tabControl1.SelectedIndex == 1)
                this.FillDispatchingForReservation(gridView3); 
#else
            if (tabControl1.SelectedIndex == 0)
                this.FillEqpPlan(gridView1);
            else if (tabControl1.SelectedIndex == 1)
                this.FillEqpPlan(gridView3); 
#endif
        }

        private void gridView1_FocusedRowChanged(object sender, DevExpress.XtraGrid.Views.Base.FocusedRowChangedEventArgs e)
        {
            if (this.initializing)
                return;

#if true
            this.FillDispatchingForReservation(gridView1);
#else
            this.FillEqpPlan(gridView1); 
#endif
        }

        private void gridView3_FocusedRowChanged(object sender, DevExpress.XtraGrid.Views.Base.FocusedRowChangedEventArgs e)
        {
            if (this.initializing)
                return;

#if true
            this.FillDispatchingForReservation(gridView3);
#else
            this.FillEqpPlan(gridView3); 
#endif
        }

        private class ComboBoxItem
        {

            public EQP_DISPATCH_LOG Info { get; private set; }

            public ComboBoxItem(EQP_DISPATCH_LOG info)
            {
                this.Info = info;
            }

            public override string ToString()
            {
                if (this.Info == null)
                    return "";

                return this.Info.EVENT_TIME.ToString();
            }
        }

        private void dispatchInTimeComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            var item = this.dispatchInTimeComboBox.SelectedItem;
            if (item == null)
                return;

            var log = (item as ComboBoxItem).Info;
            this.SelectedInfo = log;
        }

        private void SetDisplayFormat(GridView view)
        {
            foreach (GridColumn col in view.Columns)
            {
                if (col.ColumnType == typeof(double) || col.ColumnType == typeof(float))
                {
                    col.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Custom;
                    col.DisplayFormat.FormatString = "{0:#,##0}";
                }
                else if (col.ColumnType == typeof(DateTime))
                {
                    var dateTimeEdit = new RepositoryItemDateEdit();
                    dateTimeEdit.EditMask = "yyyy/MM/dd HH:mm:ss";
                    dateTimeEdit.DisplayFormat.FormatString = "yyyy/MM/dd HH:mm:ss";

                    col.ColumnEdit = dateTimeEdit;
                }
            }
        }
    }
}
