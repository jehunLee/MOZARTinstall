﻿namespace FabSimulatorUI.Gantts
{

    partial class EqpGanttView
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 구성 요소 디자이너에서 생성한 코드

        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.layoutControlItem5 = new DevExpress.XtraLayout.LayoutControlItem();
            this.areaCheckedBox = new Mozart.Studio.TaskModel.UserLibrary.CheckedComboBox();
            this.layoutControlItem2 = new DevExpress.XtraLayout.LayoutControlItem();
            this.cbeDurationHr = new DevExpress.XtraEditors.SpinEdit();
            this.layoutControl1 = new DevExpress.XtraLayout.LayoutControl();
            this.showIdleCheck = new DevExpress.XtraEditors.CheckEdit();
            this.ganttFindControl1 = new Mozart.Studio.TaskModel.UserLibrary.GanttChart.GanttFindControl();
            this.spreadsheetControl1 = new DevExpress.XtraSpreadsheet.SpreadsheetControl();
            this.ganttSizeControl1 = new Mozart.Studio.TaskModel.UserLibrary.GanttChart.GanttSizeControl();
            this.cbeSimType = new DevExpress.XtraEditors.ComboBoxEdit();
            this.popupContainerControl1 = new DevExpress.XtraEditors.PopupContainerControl();
            this.treeView1 = new System.Windows.Forms.TreeView();
            this.popupContainerEdit1 = new DevExpress.XtraEditors.PopupContainerEdit();
            this.dateEdit1 = new DevExpress.XtraEditors.DateEdit();
            this.cbeStartTime = new DevExpress.XtraEditors.ComboBoxEdit();
            this.searchIDtextBox = new DevExpress.XtraEditors.TextEdit();
            this.queryButton = new DevExpress.XtraEditors.SimpleButton();
            this.lindIDcomboBox = new DevExpress.XtraEditors.ComboBoxEdit();
            this.cbeBrushKey = new DevExpress.XtraEditors.ComboBoxEdit();
            this.layoutControlGroup1 = new DevExpress.XtraLayout.LayoutControlGroup();
            this.layoutControlItem7 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem3 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem10 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem9 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem8 = new DevExpress.XtraLayout.LayoutControlItem();
            this.emptySpaceItem1 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.emptySpaceItem2 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.layoutControlItem4 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem19 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem1 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem6 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem14 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem15 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem20 = new DevExpress.XtraLayout.LayoutControlItem();
            this.dockManager1 = new DevExpress.XtraBars.Docking.DockManager(this.components);
            this.dockPanel1 = new DevExpress.XtraBars.Docking.DockPanel();
            this.dockPanel1_Container = new DevExpress.XtraBars.Docking.ControlContainer();
            this.gridControl1 = new DevExpress.XtraGrid.GridControl();
            this.gridView1 = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.layoutControlItem12 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem13 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem11 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem17 = new DevExpress.XtraLayout.LayoutControlItem();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cbeDurationHr.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControl1)).BeginInit();
            this.layoutControl1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.showIdleCheck.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cbeSimType.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.popupContainerControl1)).BeginInit();
            this.popupContainerControl1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.popupContainerEdit1.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dateEdit1.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dateEdit1.Properties.CalendarTimeProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cbeStartTime.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.searchIDtextBox.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lindIDcomboBox.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cbeBrushKey.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem19)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem20)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dockManager1)).BeginInit();
            this.dockPanel1.SuspendLayout();
            this.dockPanel1_Container.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridControl1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem17)).BeginInit();
            this.SuspendLayout();
            // 
            // layoutControlItem5
            // 
            this.layoutControlItem5.Control = this.areaCheckedBox;
            this.layoutControlItem5.CustomizationFormText = "EQP_ERP_ID";
            this.layoutControlItem5.Location = new System.Drawing.Point(178, 0);
            this.layoutControlItem5.MaxSize = new System.Drawing.Size(199, 25);
            this.layoutControlItem5.MinSize = new System.Drawing.Size(199, 25);
            this.layoutControlItem5.Name = "layoutControlItem5";
            this.layoutControlItem5.Size = new System.Drawing.Size(199, 26);
            this.layoutControlItem5.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.layoutControlItem5.Text = "Area";
            this.layoutControlItem5.TextSize = new System.Drawing.Size(49, 14);
            // 
            // areaCheckedBox
            // 
            this.areaCheckedBox.EditValue = null;
            this.areaCheckedBox.Location = new System.Drawing.Point(251, 12);
            this.areaCheckedBox.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.areaCheckedBox.Name = "areaCheckedBox";
            this.areaCheckedBox.Size = new System.Drawing.Size(134, 21);
            this.areaCheckedBox.TabIndex = 50;
            this.areaCheckedBox.Leave += new System.EventHandler(this.areaCheckedBox_Leave);
            // 
            // layoutControlItem2
            // 
            this.layoutControlItem2.Control = this.cbeDurationHr;
            this.layoutControlItem2.CustomizationFormText = "layoutControlItem2";
            this.layoutControlItem2.Location = new System.Drawing.Point(265, 26);
            this.layoutControlItem2.Name = "layoutControlItem2";
            this.layoutControlItem2.Size = new System.Drawing.Size(94, 25);
            this.layoutControlItem2.Text = "HOURS";
            this.layoutControlItem2.TextAlignMode = DevExpress.XtraLayout.TextAlignModeItem.CustomSize;
            this.layoutControlItem2.TextLocation = DevExpress.Utils.Locations.Right;
            this.layoutControlItem2.TextSize = new System.Drawing.Size(40, 14);
            this.layoutControlItem2.TextToControlDistance = 0;
            // 
            // cbeDurationHr
            // 
            this.cbeDurationHr.EditValue = new decimal(new int[] {
            2,
            0,
            0,
            0});
            this.cbeDurationHr.Location = new System.Drawing.Point(277, 38);
            this.cbeDurationHr.MaximumSize = new System.Drawing.Size(50, 21);
            this.cbeDurationHr.MinimumSize = new System.Drawing.Size(50, 21);
            this.cbeDurationHr.Name = "cbeDurationHr";
            this.cbeDurationHr.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton()});
            this.cbeDurationHr.Size = new System.Drawing.Size(50, 21);
            this.cbeDurationHr.StyleController = this.layoutControl1;
            this.cbeDurationHr.TabIndex = 46;
            // 
            // layoutControl1
            // 
            this.layoutControl1.Controls.Add(this.showIdleCheck);
            this.layoutControl1.Controls.Add(this.ganttFindControl1);
            this.layoutControl1.Controls.Add(this.ganttSizeControl1);
            this.layoutControl1.Controls.Add(this.cbeSimType);
            this.layoutControl1.Controls.Add(this.popupContainerControl1);
            this.layoutControl1.Controls.Add(this.popupContainerEdit1);
            this.layoutControl1.Controls.Add(this.dateEdit1);
            this.layoutControl1.Controls.Add(this.cbeStartTime);
            this.layoutControl1.Controls.Add(this.searchIDtextBox);
            this.layoutControl1.Controls.Add(this.areaCheckedBox);
            this.layoutControl1.Controls.Add(this.queryButton);
            this.layoutControl1.Controls.Add(this.cbeDurationHr);
            this.layoutControl1.Controls.Add(this.lindIDcomboBox);
            this.layoutControl1.Controls.Add(this.spreadsheetControl1);
            this.layoutControl1.Controls.Add(this.cbeBrushKey);
            this.layoutControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.layoutControl1.Location = new System.Drawing.Point(0, 0);
            this.layoutControl1.Name = "layoutControl1";
            this.layoutControl1.OptionsCustomizationForm.DesignTimeCustomizationFormPositionAndSize = new System.Drawing.Rectangle(670, 258, 250, 350);
            this.layoutControl1.Root = this.layoutControlGroup1;
            this.layoutControl1.Size = new System.Drawing.Size(1018, 542);
            this.layoutControl1.TabIndex = 5;
            this.layoutControl1.Text = "layoutControl1";
            // 
            // showIdleCheck
            // 
            this.showIdleCheck.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.showIdleCheck.Location = new System.Drawing.Point(383, 38);
            this.showIdleCheck.Name = "showIdleCheck";
            this.showIdleCheck.Properties.Caption = "Show Idle";
            this.showIdleCheck.Size = new System.Drawing.Size(279, 20);
            this.showIdleCheck.StyleController = this.layoutControl1;
            this.showIdleCheck.TabIndex = 69;
            // 
            // ganttFindControl1
            // 
            this.ganttFindControl1.BackColor = System.Drawing.SystemColors.Control;
            this.ganttFindControl1.Location = new System.Drawing.Point(666, 38);
            this.ganttFindControl1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.ganttFindControl1.Name = "ganttFindControl1";
            this.ganttFindControl1.Size = new System.Drawing.Size(143, 21);
            this.ganttFindControl1.Spreadsheet = this.spreadsheetControl1;
            this.ganttFindControl1.TabIndex = 73;
            // 
            // spreadsheetControl1
            // 
            this.spreadsheetControl1.Location = new System.Drawing.Point(12, 63);
            this.spreadsheetControl1.Name = "spreadsheetControl1";
            this.spreadsheetControl1.Options.Import.Csv.Encoding = null;
            this.spreadsheetControl1.Options.Import.Txt.Encoding = null;
            this.spreadsheetControl1.Size = new System.Drawing.Size(994, 467);
            this.spreadsheetControl1.TabIndex = 71;
            this.spreadsheetControl1.Text = "spreadsheetControl1";
            this.spreadsheetControl1.BeforeDispose += new System.EventHandler(this.spreadsheetControl1_BeforeDispose);
            // 
            // ganttSizeControl1
            // 
            this.ganttSizeControl1.BackColor = System.Drawing.SystemColors.Control;
            this.ganttSizeControl1.BottomExceptCount = 0;
            this.ganttSizeControl1.CellHeight = 16;
            this.ganttSizeControl1.CellWidth = 26;
            this.ganttSizeControl1.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.ganttSizeControl1.LeftExceptCount = 0;
            this.ganttSizeControl1.Location = new System.Drawing.Point(874, 38);
            this.ganttSizeControl1.Name = "ganttSizeControl1";
            this.ganttSizeControl1.RightExceptCount = 0;
            this.ganttSizeControl1.Size = new System.Drawing.Size(132, 21);
            this.ganttSizeControl1.Spreadsheet = this.spreadsheetControl1;
            this.ganttSizeControl1.TabIndex = 72;
            this.ganttSizeControl1.TopExceptCount = 0;
            this.ganttSizeControl1.CellWidthChanged += new System.EventHandler(this.ganttSizeControl1_CellWidthChanged);
            this.ganttSizeControl1.CellHeightChanged += new System.EventHandler(this.ganttSizeControl1_CellHeightChanged);
            // 
            // cbeSimType
            // 
            this.cbeSimType.Location = new System.Drawing.Point(663, 12);
            this.cbeSimType.Name = "cbeSimType";
            this.cbeSimType.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.cbeSimType.Size = new System.Drawing.Size(84, 20);
            this.cbeSimType.StyleController = this.layoutControl1;
            this.cbeSimType.TabIndex = 70;
            // 
            // popupContainerControl1
            // 
            this.popupContainerControl1.Controls.Add(this.treeView1);
            this.popupContainerControl1.Location = new System.Drawing.Point(458, 100);
            this.popupContainerControl1.Name = "popupContainerControl1";
            this.popupContainerControl1.Size = new System.Drawing.Size(583, 754);
            this.popupContainerControl1.TabIndex = 66;
            // 
            // treeView1
            // 
            this.treeView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.treeView1.Location = new System.Drawing.Point(0, 0);
            this.treeView1.Name = "treeView1";
            this.treeView1.Size = new System.Drawing.Size(583, 754);
            this.treeView1.TabIndex = 0;
            this.treeView1.AfterCheck += new System.Windows.Forms.TreeViewEventHandler(this.treeView1_AfterCheck);
            // 
            // popupContainerEdit1
            // 
            this.popupContainerEdit1.Location = new System.Drawing.Point(389, 12);
            this.popupContainerEdit1.Name = "popupContainerEdit1";
            this.popupContainerEdit1.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.popupContainerEdit1.Properties.PopupControl = this.popupContainerControl1;
            this.popupContainerEdit1.Size = new System.Drawing.Size(59, 20);
            this.popupContainerEdit1.StyleController = this.layoutControl1;
            this.popupContainerEdit1.TabIndex = 65;
            // 
            // dateEdit1
            // 
            this.dateEdit1.EditValue = null;
            this.dateEdit1.Location = new System.Drawing.Point(51, 38);
            this.dateEdit1.MaximumSize = new System.Drawing.Size(100, 21);
            this.dateEdit1.MinimumSize = new System.Drawing.Size(100, 21);
            this.dateEdit1.Name = "dateEdit1";
            this.dateEdit1.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.dateEdit1.Properties.CalendarTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton()});
            this.dateEdit1.Size = new System.Drawing.Size(100, 21);
            this.dateEdit1.StyleController = this.layoutControl1;
            this.dateEdit1.TabIndex = 54;
            // 
            // cbeStartTime
            // 
            this.cbeStartTime.Location = new System.Drawing.Point(158, 38);
            this.cbeStartTime.MaximumSize = new System.Drawing.Size(101, 21);
            this.cbeStartTime.MinimumSize = new System.Drawing.Size(101, 21);
            this.cbeStartTime.Name = "cbeStartTime";
            this.cbeStartTime.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.cbeStartTime.Size = new System.Drawing.Size(101, 21);
            this.cbeStartTime.StyleController = this.layoutControl1;
            this.cbeStartTime.TabIndex = 53;
            this.cbeStartTime.Visible = false;
            // 
            // searchIDtextBox
            // 
            this.searchIDtextBox.EditValue = "";
            this.searchIDtextBox.Location = new System.Drawing.Point(461, 12);
            this.searchIDtextBox.Name = "searchIDtextBox";
            this.searchIDtextBox.Size = new System.Drawing.Size(137, 20);
            this.searchIDtextBox.StyleController = this.layoutControl1;
            this.searchIDtextBox.TabIndex = 48;
            this.searchIDtextBox.KeyUp += new System.Windows.Forms.KeyEventHandler(this.searchIDtextBox_KeyUp);
            // 
            // queryButton
            // 
            this.queryButton.Appearance.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.queryButton.Appearance.ForeColor = System.Drawing.Color.Maroon;
            this.queryButton.Appearance.Options.UseFont = true;
            this.queryButton.Appearance.Options.UseForeColor = true;
            this.queryButton.Location = new System.Drawing.Point(894, 12);
            this.queryButton.MaximumSize = new System.Drawing.Size(112, 20);
            this.queryButton.MinimumSize = new System.Drawing.Size(112, 20);
            this.queryButton.Name = "queryButton";
            this.queryButton.Size = new System.Drawing.Size(112, 20);
            this.queryButton.StyleController = this.layoutControl1;
            this.queryButton.TabIndex = 4;
            this.queryButton.Text = "VIEW CHART";
            this.queryButton.Click += new System.EventHandler(this.btnQuery_Click);
            // 
            // lindIDcomboBox
            // 
            this.lindIDcomboBox.Location = new System.Drawing.Point(39, 12);
            this.lindIDcomboBox.MaximumSize = new System.Drawing.Size(129, 22);
            this.lindIDcomboBox.MinimumSize = new System.Drawing.Size(125, 22);
            this.lindIDcomboBox.Name = "lindIDcomboBox";
            this.lindIDcomboBox.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.lindIDcomboBox.Size = new System.Drawing.Size(129, 22);
            this.lindIDcomboBox.StyleController = this.layoutControl1;
            this.lindIDcomboBox.TabIndex = 40;
            // 
            // cbeBrushKey
            // 
            this.cbeBrushKey.Location = new System.Drawing.Point(751, 12);
            this.cbeBrushKey.Name = "cbeBrushKey";
            this.cbeBrushKey.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.cbeBrushKey.Size = new System.Drawing.Size(126, 20);
            this.cbeBrushKey.StyleController = this.layoutControl1;
            this.cbeBrushKey.TabIndex = 74;
            this.cbeBrushKey.SelectedValueChanged += new System.EventHandler(this.cbeBrushKey_SelectedValueChanged);
            // 
            // layoutControlGroup1
            // 
            this.layoutControlGroup1.CustomizationFormText = "layoutControlGroup1";
            this.layoutControlGroup1.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.layoutControlItem7,
            this.layoutControlItem5,
            this.layoutControlItem2,
            this.layoutControlItem3,
            this.layoutControlItem10,
            this.layoutControlItem9,
            this.layoutControlItem8,
            this.emptySpaceItem1,
            this.layoutControlItem4,
            this.layoutControlItem19,
            this.layoutControlItem1,
            this.layoutControlItem6,
            this.layoutControlItem14,
            this.layoutControlItem15,
            this.layoutControlItem20,
            this.emptySpaceItem2});
            this.layoutControlGroup1.Name = "layoutControlGroup1";
            this.layoutControlGroup1.Size = new System.Drawing.Size(1018, 542);
            this.layoutControlGroup1.TextVisible = false;
            // 
            // layoutControlItem7
            // 
            this.layoutControlItem7.Control = this.lindIDcomboBox;
            this.layoutControlItem7.CustomizationFormText = "Line";
            this.layoutControlItem7.Location = new System.Drawing.Point(0, 0);
            this.layoutControlItem7.MaxSize = new System.Drawing.Size(183, 26);
            this.layoutControlItem7.MinSize = new System.Drawing.Size(178, 26);
            this.layoutControlItem7.Name = "layoutControlItem7";
            this.layoutControlItem7.Size = new System.Drawing.Size(178, 26);
            this.layoutControlItem7.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.layoutControlItem7.Text = "Line";
            this.layoutControlItem7.TextAlignMode = DevExpress.XtraLayout.TextAlignModeItem.AutoSize;
            this.layoutControlItem7.TextSize = new System.Drawing.Size(22, 14);
            this.layoutControlItem7.TextToControlDistance = 5;
            // 
            // layoutControlItem3
            // 
            this.layoutControlItem3.Control = this.dateEdit1;
            this.layoutControlItem3.CustomizationFormText = "From";
            this.layoutControlItem3.Location = new System.Drawing.Point(0, 26);
            this.layoutControlItem3.Name = "layoutControlItem3";
            this.layoutControlItem3.Size = new System.Drawing.Size(146, 25);
            this.layoutControlItem3.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.SupportHorzAlignment;
            this.layoutControlItem3.Text = "Period";
            this.layoutControlItem3.TextAlignMode = DevExpress.XtraLayout.TextAlignModeItem.AutoSize;
            this.layoutControlItem3.TextSize = new System.Drawing.Size(34, 14);
            this.layoutControlItem3.TextToControlDistance = 5;
            // 
            // layoutControlItem10
            // 
            this.layoutControlItem10.Control = this.cbeStartTime;
            this.layoutControlItem10.CustomizationFormText = "~";
            this.layoutControlItem10.Location = new System.Drawing.Point(146, 26);
            this.layoutControlItem10.MaxSize = new System.Drawing.Size(119, 25);
            this.layoutControlItem10.MinSize = new System.Drawing.Size(119, 25);
            this.layoutControlItem10.Name = "layoutControlItem10";
            this.layoutControlItem10.Size = new System.Drawing.Size(119, 25);
            this.layoutControlItem10.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.layoutControlItem10.Text = "~";
            this.layoutControlItem10.TextAlignMode = DevExpress.XtraLayout.TextAlignModeItem.AutoSize;
            this.layoutControlItem10.TextLocation = DevExpress.Utils.Locations.Right;
            this.layoutControlItem10.TextSize = new System.Drawing.Size(9, 14);
            this.layoutControlItem10.TextToControlDistance = 5;
            // 
            // layoutControlItem9
            // 
            this.layoutControlItem9.Control = this.queryButton;
            this.layoutControlItem9.CustomizationFormText = "layoutControlItem9";
            this.layoutControlItem9.Location = new System.Drawing.Point(882, 0);
            this.layoutControlItem9.Name = "layoutControlItem9";
            this.layoutControlItem9.Size = new System.Drawing.Size(116, 26);
            this.layoutControlItem9.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem9.TextVisible = false;
            // 
            // layoutControlItem8
            // 
            this.layoutControlItem8.Control = this.searchIDtextBox;
            this.layoutControlItem8.CustomizationFormText = "EQP_ID";
            this.layoutControlItem8.Location = new System.Drawing.Point(440, 0);
            this.layoutControlItem8.MaxSize = new System.Drawing.Size(150, 25);
            this.layoutControlItem8.MinSize = new System.Drawing.Size(150, 25);
            this.layoutControlItem8.Name = "layoutControlItem8";
            this.layoutControlItem8.Size = new System.Drawing.Size(150, 26);
            this.layoutControlItem8.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.layoutControlItem8.Text = " ";
            this.layoutControlItem8.TextAlignMode = DevExpress.XtraLayout.TextAlignModeItem.AutoSize;
            this.layoutControlItem8.TextSize = new System.Drawing.Size(4, 14);
            this.layoutControlItem8.TextToControlDistance = 5;
            // 
            // emptySpaceItem1
            // 
            this.emptySpaceItem1.AllowHotTrack = false;
            this.emptySpaceItem1.CustomizationFormText = "emptySpaceItem1";
            this.emptySpaceItem1.Location = new System.Drawing.Point(869, 0);
            this.emptySpaceItem1.Name = "emptySpaceItem1";
            this.emptySpaceItem1.Size = new System.Drawing.Size(13, 26);
            this.emptySpaceItem1.TextSize = new System.Drawing.Size(0, 0);
            // 
            // emptySpaceItem2
            // 
            this.emptySpaceItem2.AllowHotTrack = false;
            this.emptySpaceItem2.CustomizationFormText = "emptySpaceItem2";
            this.emptySpaceItem2.Location = new System.Drawing.Point(359, 26);
            this.emptySpaceItem2.MinSize = new System.Drawing.Size(12, 24);
            this.emptySpaceItem2.Name = "emptySpaceItem2";
            this.emptySpaceItem2.Size = new System.Drawing.Size(12, 25);
            this.emptySpaceItem2.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.emptySpaceItem2.TextSize = new System.Drawing.Size(0, 0);
            // 
            // layoutControlItem4
            // 
            this.layoutControlItem4.Control = this.popupContainerEdit1;
            this.layoutControlItem4.CustomizationFormText = "layoutControlItem4";
            this.layoutControlItem4.Location = new System.Drawing.Point(377, 0);
            this.layoutControlItem4.Name = "layoutControlItem4";
            this.layoutControlItem4.Size = new System.Drawing.Size(63, 26);
            this.layoutControlItem4.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem4.TextVisible = false;
            // 
            // layoutControlItem19
            // 
            this.layoutControlItem19.Control = this.cbeSimType;
            this.layoutControlItem19.CustomizationFormText = "SimType";
            this.layoutControlItem19.Location = new System.Drawing.Point(590, 0);
            this.layoutControlItem19.Name = "layoutControlItem19";
            this.layoutControlItem19.Size = new System.Drawing.Size(149, 26);
            this.layoutControlItem19.Text = "SimType";
            this.layoutControlItem19.TextSize = new System.Drawing.Size(49, 14);
            // 
            // layoutControlItem1
            // 
            this.layoutControlItem1.Control = this.spreadsheetControl1;
            this.layoutControlItem1.CustomizationFormText = "GanttChart";
            this.layoutControlItem1.Location = new System.Drawing.Point(0, 51);
            this.layoutControlItem1.Name = "layoutControlItem1";
            this.layoutControlItem1.Size = new System.Drawing.Size(998, 471);
            this.layoutControlItem1.Text = "GanttChart";
            this.layoutControlItem1.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem1.TextVisible = false;
            // 
            // layoutControlItem6
            // 
            this.layoutControlItem6.Control = this.ganttSizeControl1;
            this.layoutControlItem6.CustomizationFormText = "Cell size :";
            this.layoutControlItem6.Location = new System.Drawing.Point(801, 26);
            this.layoutControlItem6.Name = "layoutControlItem6";
            this.layoutControlItem6.Size = new System.Drawing.Size(197, 25);
            this.layoutControlItem6.Text = "Cell size :";
            this.layoutControlItem6.TextSize = new System.Drawing.Size(49, 14);
            // 
            // layoutControlItem14
            // 
            this.layoutControlItem14.Control = this.ganttFindControl1;
            this.layoutControlItem14.CustomizationFormText = "layoutControlItem14";
            this.layoutControlItem14.Location = new System.Drawing.Point(654, 26);
            this.layoutControlItem14.Name = "layoutControlItem14";
            this.layoutControlItem14.Size = new System.Drawing.Size(147, 25);
            this.layoutControlItem14.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem14.TextVisible = false;
            // 
            // layoutControlItem15
            // 
            this.layoutControlItem15.Control = this.showIdleCheck;
            this.layoutControlItem15.CustomizationFormText = "layoutControlItem15";
            this.layoutControlItem15.Location = new System.Drawing.Point(371, 26);
            this.layoutControlItem15.Name = "layoutControlItem15";
            this.layoutControlItem15.Size = new System.Drawing.Size(283, 25);
            this.layoutControlItem15.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem15.TextVisible = false;
            // 
            // layoutControlItem20
            // 
            this.layoutControlItem20.Control = this.cbeBrushKey;
            this.layoutControlItem20.Location = new System.Drawing.Point(739, 0);
            this.layoutControlItem20.Name = "layoutControlItem20";
            this.layoutControlItem20.Size = new System.Drawing.Size(130, 26);
            this.layoutControlItem20.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem20.TextVisible = false;
            // 
            // dockManager1
            // 
            this.dockManager1.Form = this;
            this.dockManager1.RootPanels.AddRange(new DevExpress.XtraBars.Docking.DockPanel[] {
            this.dockPanel1});
            this.dockManager1.TopZIndexControls.AddRange(new string[] {
            "DevExpress.XtraBars.BarDockControl",
            "DevExpress.XtraBars.StandaloneBarDockControl",
            "System.Windows.Forms.StatusBar",
            "DevExpress.XtraBars.Ribbon.RibbonStatusBar",
            "DevExpress.XtraBars.Ribbon.RibbonControl"});
            // 
            // dockPanel1
            // 
            this.dockPanel1.Controls.Add(this.dockPanel1_Container);
            this.dockPanel1.Dock = DevExpress.XtraBars.Docking.DockingStyle.Bottom;
            this.dockPanel1.ID = new System.Guid("3813c849-531d-4d71-8a73-d20e97435d30");
            this.dockPanel1.Location = new System.Drawing.Point(0, 542);
            this.dockPanel1.Name = "dockPanel1";
            this.dockPanel1.OriginalSize = new System.Drawing.Size(200, 200);
            this.dockPanel1.Size = new System.Drawing.Size(1018, 200);
            this.dockPanel1.Text = "Process Lot List";
            // 
            // dockPanel1_Container
            // 
            this.dockPanel1_Container.Controls.Add(this.gridControl1);
            this.dockPanel1_Container.Location = new System.Drawing.Point(3, 27);
            this.dockPanel1_Container.Name = "dockPanel1_Container";
            this.dockPanel1_Container.Size = new System.Drawing.Size(1012, 170);
            this.dockPanel1_Container.TabIndex = 0;
            // 
            // gridControl1
            // 
            this.gridControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gridControl1.Location = new System.Drawing.Point(0, 0);
            this.gridControl1.MainView = this.gridView1;
            this.gridControl1.Name = "gridControl1";
            this.gridControl1.Size = new System.Drawing.Size(1012, 170);
            this.gridControl1.TabIndex = 0;
            this.gridControl1.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridView1});
            // 
            // gridView1
            // 
            this.gridView1.GridControl = this.gridControl1;
            this.gridView1.Name = "gridView1";
            // 
            // layoutControlItem12
            // 
            this.layoutControlItem12.CustomizationFormText = "높이";
            this.layoutControlItem12.Location = new System.Drawing.Point(1095, 26);
            this.layoutControlItem12.Name = "layoutControlItem12";
            this.layoutControlItem12.Size = new System.Drawing.Size(126, 32);
            this.layoutControlItem12.Text = "Height";
            this.layoutControlItem12.TextSize = new System.Drawing.Size(69, 14);
            // 
            // layoutControlItem13
            // 
            this.layoutControlItem13.CustomizationFormText = "넓이";
            this.layoutControlItem13.Location = new System.Drawing.Point(969, 26);
            this.layoutControlItem13.Name = "layoutControlItem13";
            this.layoutControlItem13.Size = new System.Drawing.Size(126, 32);
            this.layoutControlItem13.Text = "Width";
            this.layoutControlItem13.TextSize = new System.Drawing.Size(69, 14);
            // 
            // layoutControlItem11
            // 
            this.layoutControlItem11.CustomizationFormText = "넓이";
            this.layoutControlItem11.Location = new System.Drawing.Point(969, 26);
            this.layoutControlItem11.Name = "layoutControlItem13";
            this.layoutControlItem11.Size = new System.Drawing.Size(126, 32);
            this.layoutControlItem11.Text = "Width";
            this.layoutControlItem11.TextSize = new System.Drawing.Size(69, 14);
            // 
            // layoutControlItem17
            // 
            this.layoutControlItem17.Control = this.dateEdit1;
            this.layoutControlItem17.CustomizationFormText = "From";
            this.layoutControlItem17.Location = new System.Drawing.Point(0, 26);
            this.layoutControlItem17.Name = "layoutControlItem3";
            this.layoutControlItem17.Size = new System.Drawing.Size(178, 25);
            this.layoutControlItem17.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.SupportHorzAlignment;
            this.layoutControlItem17.Text = "Period";
            this.layoutControlItem17.TextAlignMode = DevExpress.XtraLayout.TextAlignModeItem.AutoSize;
            this.layoutControlItem17.TextSize = new System.Drawing.Size(30, 13);
            this.layoutControlItem17.TextToControlDistance = 5;
            // 
            // EqpGanttView
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 14F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.layoutControl1);
            this.Controls.Add(this.dockPanel1);
            this.Name = "EqpGanttView";
            this.Size = new System.Drawing.Size(1018, 742);
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cbeDurationHr.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControl1)).EndInit();
            this.layoutControl1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.showIdleCheck.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cbeSimType.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.popupContainerControl1)).EndInit();
            this.popupContainerControl1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.popupContainerEdit1.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dateEdit1.Properties.CalendarTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dateEdit1.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cbeStartTime.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.searchIDtextBox.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lindIDcomboBox.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cbeBrushKey.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem19)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem20)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dockManager1)).EndInit();
            this.dockPanel1.ResumeLayout(false);
            this.dockPanel1_Container.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gridControl1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem17)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem5;
        private Mozart.Studio.TaskModel.UserLibrary.CheckedComboBox areaCheckedBox;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem2;
        private DevExpress.XtraEditors.SpinEdit cbeDurationHr;
        private DevExpress.XtraLayout.LayoutControl layoutControl1;
        private DevExpress.XtraEditors.SimpleButton queryButton;
        private DevExpress.XtraEditors.TextEdit searchIDtextBox;
        private DevExpress.XtraEditors.ComboBoxEdit lindIDcomboBox;
        private DevExpress.XtraLayout.LayoutControlGroup layoutControlGroup1;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem7;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem8;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem9;
        private DevExpress.XtraBars.Docking.DockManager dockManager1;
        private DevExpress.XtraBars.Docking.DockPanel dockPanel1;
        private DevExpress.XtraBars.Docking.ControlContainer dockPanel1_Container;
        private DevExpress.XtraGrid.GridControl gridControl1;
        private DevExpress.XtraGrid.Views.Grid.GridView gridView1;
        private DevExpress.XtraEditors.DateEdit dateEdit1;
        private DevExpress.XtraEditors.ComboBoxEdit cbeStartTime;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem1;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem3;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem10;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem12;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem13;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem11;
        private DevExpress.XtraEditors.PopupContainerControl popupContainerControl1;
        private System.Windows.Forms.TreeView treeView1;
        private DevExpress.XtraEditors.PopupContainerEdit popupContainerEdit1;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem4;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem17;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem2;
        private DevExpress.XtraEditors.ComboBoxEdit cbeSimType;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem19;
        private DevExpress.XtraSpreadsheet.SpreadsheetControl spreadsheetControl1;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem1;
        private Mozart.Studio.TaskModel.UserLibrary.GanttChart.GanttSizeControl ganttSizeControl1;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem6;
        private Mozart.Studio.TaskModel.UserLibrary.GanttChart.GanttFindControl ganttFindControl1;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem14;
        private DevExpress.XtraEditors.CheckEdit showIdleCheck;        
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem15;
        private DevExpress.XtraEditors.ComboBoxEdit cbeBrushKey;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem20;
    }
}