﻿///
// file:	Gantts\DetailBarInfoDialog.cs
//
// summary:	Implements the detail bar information Dialog
///
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using FabSimulator.Inputs;
using Mozart.Studio.TaskModel.Projects;

namespace FabSimulatorUI.Gantts
{
    public partial class DetailBarInfoDialog : Form
    {
        GanttBar _bar;
        List<WEIGHT_PRESETS> _presetList;
        IExperimentResultItem _result;

        public DetailBarInfoDialog(List<WEIGHT_PRESETS> presetList, IExperimentResultItem result)
        {
            _result = result;
            _presetList = presetList;

            InitializeComponent();
        }

       public void dispatchingInfoButton_Click(object sender, EventArgs e)
        {
            var info = _bar.DispatchingInfo;

            if (info == null)
                return; 
        }
    }
}
